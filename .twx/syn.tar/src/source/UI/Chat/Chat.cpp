#include "stdafx.h"
#include "Core/Text/TextLineWrap.h"
#include "UI/Chat/Chat.h"
#include "UI/Character/NameWindow.h"
#include "UI/Character/WorldNameRules.h"
#include <array>
#include "UI/Core/WindowSystem.h"
#include "Character/CharacterManager.h" // gCharacterManager
#include "Camera/CameraProjection.h" // CameraProjection

// Includes mirror ZzzInterface.cpp.
#include "Core/Platform/Imm.h"
#include "UI/Core/UIManager.h"
#include "Render/Textures/ZzzOpenglUtil.h"
#include "Render/Models/ZzzBMD.h"
#include "Render/Terrain/ZzzLodTerrain.h"
#include "Engine/Object/ZzzInfomation.h"
#include "Engine/Object/ZzzObject.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Engine/Object/PlayerActionState.h"
#include "Render/Textures/ZzzTexture.h"
#include "Engine/AI/ZzzAI.h"
#include "Engine/Object/ZzzInterface.h"
#include "GameLogic/Combat/ClassAttack.h"
#include "GameLogic/Combat/SkillCast.h"
#include "GameLogic/Combat/SkillExecution.h"
#include "Core/Input/ImeInput.h"
#include "Engine/Object/ZzzInventory.h"
#include "Engine/Object/ZzzOpenData.h"
#include "Render/Effects/ZzzEffect.h"
#include "Scenes/SceneCore.h"
#include "Engine/Pathing/ZzzPath.h"
#include "Audio/DSPlaySound.h"
#include "I18N/All.h"
#include "GameLogic/Events/MatchEvent.h"
#include "GameLogic/Items/PersonalShopTitleImp.h"
#include "GameLogic/Quests/CSQuest.h"
#include "GameLogic/Items/CSItemOption.h"
#include "GameLogic/NPCs/npcBreeder.h"
#include "GameLogic/Pets/GIPetManager.h"
#include "Character/CSParts.h"
#include "UI/HUD/UIMapName.h"	// rozy
#include "GameLogic/Events/Cinematic/CDirection.h"
#include "World/MapInfra/MapManager.h"
#include "GameLogic/Events/Event.h"
#include "UI/Core/WindowSystem.h"
#include "GameLogic/Events/w_CursedTemple.h"
#include "GameLogic/Social/PartyManager.h"
#include "UI/Dialogs/CommonMessageBox.h"
#include "GameLogic/Skills/SummonSystem.h"
#include "GameLogic/Skills/SkillManager.h"
#include "World/MapInfra/w_MapHeaders.h"
#include "GameLogic/Combat/DuelMgr.h"
#include "Core/Text/WideString.h"
#include "Render/Text/CUIRenderText.h"

namespace UI::Chat
{
typedef struct
{
    wchar_t   ID[MAX_MONSTER_NAME + 1];
    wchar_t      Union[30];
    wchar_t      Guild[30];
    wchar_t      szShopTitle[16];
    char      Color;
    char      GuildColor;
    float       IDLifeTime;
    wchar_t   Text[2][256];
    float       LifeTime[2];
    CHARACTER* Owner;
    int       x, y;
    int       Width;
    int       Height;
    int       LineHeight;
    vec3_t    Position;
} CHAT;

#define MAX_CHAT 120

CHAT Chat[MAX_CHAT];

bool ShowOwnerName(const CHAT* chat)
{
    if (!g_pNameWindow || !chat->Owner) return true;
    const auto kind = chat->Owner->Object.Kind;
    return kind == KIND_PLAYER ? g_pNameWindow->ArePlayerNamesShown() :
        kind == KIND_MONSTER ? g_pNameWindow->IsMonsterNameShown(chat->Owner) : true;
}

void SetBooleanPosition(CHAT* c)
{
    SIZE Size[5]{};

    if (g_isCharacterBuff((&c->Owner->Object), eBuff_GMEffect) || (c->Owner->CtlCode == CTLCODE_20OPERATOR) || (c->Owner->CtlCode == CTLCODE_08OPERATOR))
    {
        g_pRenderText->SetFont(g_hFontBold);
        Size[0] = g_pRenderText->MeasureText(c->ID, lstrlen(c->ID));
    }
    else
    {
        g_pRenderText->SetFont(g_hFont);
        Size[0] = g_pRenderText->MeasureText(c->ID, lstrlen(c->ID));
    }

    if (!ShowOwnerName(c)) Size[0] = {};
    g_pRenderText->SetFont(g_hFont);
    Size[1] = g_pRenderText->MeasureText(c->Text[0], lstrlen(c->Text[0]));
    Size[2] = g_pRenderText->MeasureText(c->Text[1], lstrlen(c->Text[1]));
    Size[3] = g_pRenderText->MeasureText(c->Union, lstrlen(c->Union));
    Size[4] = g_pRenderText->MeasureText(c->Guild, lstrlen(c->Guild));

    Size[0].cx += 3;

    if (c->LifeTime[1] > 0)
        c->Width = std::max<int>(std::max<int>(std::max<int>(Size[0].cx, Size[1].cx), std::max<int>(Size[2].cx, Size[3].cx)), Size[4].cx);

    else if (c->LifeTime[0] > 0)
        c->Width = std::max<int>(std::max<int>(Size[0].cx, Size[1].cx), std::max<int>(Size[3].cx, Size[4].cx));
    else
        c->Width = std::max<int>(std::max<int>(Size[0].cx, Size[3].cx), Size[4].cx);
    const int lineCount = (ShowOwnerName(c) && c->ID[0] != L'\0') + (c->LifeTime[0] > 0) + (c->LifeTime[1] > 0)
        + (c->Union[0] != L'\0') + (c->Guild[0] != L'\0');
    c->LineHeight = 1;
    for (const SIZE& size : Size)
    {
        c->LineHeight = std::max<int>(c->LineHeight, size.cy);
    }

    if (lstrlen(c->szShopTitle) > 0)
    {
        g_pRenderText->SetFont(g_hFontBold);
        const SIZE shopTitleSize = g_pRenderText->MeasureText(c->szShopTitle, lstrlen(c->szShopTitle));
        const SIZE storeSize = g_pRenderText->MeasureText(I18N::Game::Store, wcslen(I18N::Game::Store));

        if (shopTitleSize.cx > 0 && storeSize.cx > 0)
        {
            if (c->Width < shopTitleSize.cx + storeSize.cx)
                c->Width = shopTitleSize.cx + storeSize.cx;
            c->LineHeight = std::max<int>(c->LineHeight, std::max<int>(shopTitleSize.cy, storeSize.cy));
        }
        g_pRenderText->SetFont(g_hFont);
    }
    c->Height = c->LineHeight * (lineCount + (c->szShopTitle[0] != L'\0'));
}

void SetPlayerColor(BYTE PK)
{
    switch (PK)
    {
    case 0:g_pRenderText->SetTextColor(150, 255, 240, 255); break;//npc
    case 1:g_pRenderText->SetTextColor(100, 120, 255, 255); break;
    case 2:g_pRenderText->SetTextColor(140, 180, 255, 255); break;
    case 3:g_pRenderText->SetTextColor(200, 220, 255, 255); break;//normal
    case 4:g_pRenderText->SetTextColor(255, 150, 60, 255); break; //pk1
    case 5:g_pRenderText->SetTextColor(255, 80, 30, 255); break;  //pk2
    default:g_pRenderText->SetTextColor(255, 0, 0, 255); break;    //pk3
    }
}

	// ※

const int ciSystemColor = 240;

void RenderOwnerName(CHAT* c, POINT& RenderPos, SIZE RenderBoxSize, int iLineHeight, bool bGmMode)
{
    if (ShowOwnerName(c))
    {
        const auto background = g_pRenderText->GetBgColor();
        if (c->Owner->Object.Kind == KIND_PLAYER) g_pRenderText->SetBgColor(0u);
        if (bGmMode)
        {
            g_pRenderText->SetFont(g_hFontBold);
            g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->ID, RenderBoxSize.cx, iLineHeight, RT3_SORT_LEFT);
            RenderPos.y += iLineHeight;
            g_pRenderText->SetFont(g_hFont);
        }
        else
        {
            g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->ID, RenderBoxSize.cx, iLineHeight, RT3_SORT_LEFT);
            RenderPos.y += iLineHeight;
        }
        g_pRenderText->SetBgColor(background);
    }
}

void RenderBoolean(int x, int y, CHAT* c)
{
    if (!ShowOwnerName(c) && c->LifeTime[0] <= 0 && c->LifeTime[1] <= 0) return;
    if (g_isCharacterBuff((&c->Owner->Object), eBuff_CrywolfNPCHide))
    {
        return;
    }

    if (c->Owner != Hero && battleCastle::IsBattleCastleStart() == true && g_isCharacterBuff((&c->Owner->Object), eBuff_Cloaking))
    {
        if ((Hero->EtcPart == PARTS_ATTACK_KING_TEAM_MARK || Hero->EtcPart == PARTS_ATTACK_TEAM_MARK))
        {
            if (!(c->Owner->EtcPart == PARTS_ATTACK_KING_TEAM_MARK || c->Owner->EtcPart == PARTS_ATTACK_TEAM_MARK))
            {
                return;
            }
        }
        else if ((Hero->EtcPart == PARTS_ATTACK_KING_TEAM_MARK2 || Hero->EtcPart == PARTS_ATTACK_TEAM_MARK2))
        {
            if (!(c->Owner->EtcPart == PARTS_ATTACK_KING_TEAM_MARK2 || c->Owner->EtcPart == PARTS_ATTACK_TEAM_MARK2))
            {
                return;
            }
        }
        else if ((Hero->EtcPart == PARTS_ATTACK_KING_TEAM_MARK3 || Hero->EtcPart == PARTS_ATTACK_TEAM_MARK3))
        {
            if (!(c->Owner->EtcPart == PARTS_ATTACK_KING_TEAM_MARK3 || c->Owner->EtcPart == PARTS_ATTACK_TEAM_MARK3))
            {
                return;
            }
        }
        else if ((Hero->EtcPart == PARTS_DEFENSE_KING_TEAM_MARK || Hero->EtcPart == PARTS_DEFENSE_TEAM_MARK))
        {
            if (!(c->Owner->EtcPart == PARTS_DEFENSE_KING_TEAM_MARK || c->Owner->EtcPart == PARTS_DEFENSE_TEAM_MARK))
            {
                return;
            }
        }
    }

    EnableAlphaTest();

    POINT RenderPos = { x, y };
    SIZE RenderBoxSize = { c->Width, c->Height };
    const int iLineHeight = c->LineHeight;

    if (IsShopInViewport(c->Owner))
    {
        SIZE TextSize;
        g_pRenderText->SetFont(g_hFontBold);
        g_pRenderText->SetBgColor(GetShopBGColor(c->Owner));

        g_pRenderText->SetTextColor(GetShopTextColor(c->Owner));
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, I18N::Game::Store, 0, iLineHeight, RT3_SORT_LEFT, &TextSize);
        RenderPos.x += TextSize.cx;

        g_pRenderText->SetTextColor(GetShopText2Color(c->Owner));
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->szShopTitle, RenderBoxSize.cx - TextSize.cx, iLineHeight, RT3_SORT_LEFT, &TextSize);
        g_pRenderText->SetFont(g_hFont);

        RenderPos.x = x;
        RenderPos.y += iLineHeight;
    }
    else if (::IsStrifeMap(gMapManager.WorldActive) && Hero->m_byGensInfluence != c->Owner->m_byGensInfluence && !::IsGMCharacter())
    {
        if (!c->Owner->GensContributionPoints)
            return;

        if (KIND_PLAYER == c->Owner->Object.Kind && MODEL_PLAYER == c->Owner->Object.Type)
        {
            int tempX = (int)(c->x + c->Width * 0.5f + 20.0f);
            switch (c->Owner->m_byGensInfluence)
            {
            case 1:
                g_pNewUIGensRanking->RanderMark(tempX, y, (mu::ui::window::CGensRanking::GENS_TYPE)c->Owner->m_byGensInfluence, c->Owner->GensRanking, mu::ui::window::CGensRanking::MARK_BOOLEAN, (float)RenderPos.y);
                return;
            case 2:
                g_pNewUIGensRanking->RanderMark(tempX, y, (mu::ui::window::CGensRanking::GENS_TYPE)c->Owner->m_byGensInfluence, c->Owner->GensRanking, mu::ui::window::CGensRanking::MARK_BOOLEAN, (float)RenderPos.y);
                return;
            default:
                break;
            }
        }
    }

    bool bGmMode = false;

    if (g_isCharacterBuff((&c->Owner->Object), eBuff_GMEffect) || (c->Owner->CtlCode == CTLCODE_20OPERATOR) || (c->Owner->CtlCode == CTLCODE_08OPERATOR))
    {
        bGmMode = true;
        g_pRenderText->SetBgColor(30, 30, 30, 200);
        g_pRenderText->SetTextColor(200, 255, 255, 255);
    }

    if (c->Owner == Hero)
    {
        g_pRenderText->SetBgColor(60, 100, 0, 150);
        g_pRenderText->SetTextColor(200, 255, 0, 255);
    }
    else if (c->Owner->GuildMarkIndex == Hero->GuildMarkIndex)
    {
        g_pRenderText->SetBgColor(GetGuildRelationShipBGColor(GR_UNION));
        g_pRenderText->SetTextColor(GetGuildRelationShipTextColor(GR_UNION));
    }
    else
    {
        g_pRenderText->SetBgColor(GetGuildRelationShipBGColor(c->Owner->GuildRelationShip));
        g_pRenderText->SetTextColor(GetGuildRelationShipTextColor(c->Owner->GuildRelationShip));
    }

    if (c->Union && c->Union[0])
    {
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->Union, RenderBoxSize.cx, iLineHeight, RT3_SORT_LEFT);
        RenderPos.y += iLineHeight;
    }
    if (c->Guild && c->Guild[0])
    {
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->Guild, RenderBoxSize.cx, iLineHeight, RT3_SORT_LEFT);
        RenderPos.y += iLineHeight;
    }

    if (bGmMode)
    {
        g_pRenderText->SetTextColor(100, 250, 250, 255);
    }
    else
    {
        SetPlayerColor(c->Color);
    }

    if (c->x <= MouseX && MouseX < c->x + c->Width &&
        c->y <= MouseY && MouseY < c->y + c->Height &&
        InputEnable && Hero->SafeZone && wcscmp(c->ID, Hero->ID) != 0 &&
        (DWORD)WorldTime % 24 < 12)
    {
        unsigned int Temp = g_pRenderText->GetBgColor();
        g_pRenderText->SetBgColor(g_pRenderText->GetTextColor());
        g_pRenderText->SetTextColor(Temp);
    }

    RenderOwnerName(c, RenderPos, RenderBoxSize, iLineHeight, bGmMode);

    if (c->GuildColor == 0)
        g_pRenderText->SetBgColor(10, 30, 50, 150);
    else if (c->GuildColor == 1)
        g_pRenderText->SetBgColor(30, 50, 0, 150);
    else if (bGmMode)
        g_pRenderText->SetBgColor(30, 30, 30, 200);
    else
        g_pRenderText->SetBgColor(50, 0, 0, 150);

    DWORD dwTextColor[2];
    BYTE byAlpha[2] = { 255, 255 };
    if ((c->LifeTime[0] > 0 && c->LifeTime[0] < 10))
        byAlpha[0] = 128;
    if ((c->LifeTime[1] > 0 && c->LifeTime[1] < 10))
        byAlpha[1] = 128;

    if (bGmMode)
    {
        dwTextColor[0] = RGBA(250, 200, 50, byAlpha[0]);
        dwTextColor[1] = RGBA(250, 200, 50, byAlpha[1]);
    }
    else
    {
        dwTextColor[0] = RGBA(230, 220, 200, byAlpha[0]);
        dwTextColor[1] = RGBA(230, 220, 200, byAlpha[1]);
    }

    if (c->LifeTime[1] > 0)
    {
        g_pRenderText->SetTextColor(dwTextColor[1]);
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->Text[1], RenderBoxSize.cx, iLineHeight, RT3_SORT_LEFT);
        RenderPos.y += iLineHeight;

        g_pRenderText->SetTextColor(dwTextColor[0]);
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->Text[0], RenderBoxSize.cx, iLineHeight);
    }
    else if (c->LifeTime[0] > 0)
    {
        g_pRenderText->SetTextColor(dwTextColor[0]);
        g_pRenderText->RenderText(RenderPos.x, RenderPos.y, c->Text[0], RenderBoxSize.cx, iLineHeight);
    }

    if (KIND_PLAYER == c->Owner->Object.Kind && MODEL_PLAYER == c->Owner->Object.Type)
    {
        const int nGensMarkHeight = 18;
        int nGensMarkPosY = (RenderPos.y - y - nGensMarkHeight) / 2 + y;

        if (c->LifeTime[1] > 0)
            RenderPos.y -= iLineHeight;

        if (1 == c->Owner->m_byGensInfluence)
            g_pNewUIGensRanking->RanderMark(x, y, (mu::ui::window::CGensRanking::GENS_TYPE)c->Owner->m_byGensInfluence, c->Owner->GensRanking, mu::ui::window::CGensRanking::MARK_BOOLEAN, (float)RenderPos.y);
        else if (2 == c->Owner->m_byGensInfluence)
            g_pNewUIGensRanking->RanderMark(x, y, (mu::ui::window::CGensRanking::GENS_TYPE)c->Owner->m_byGensInfluence, c->Owner->GensRanking, mu::ui::window::CGensRanking::MARK_BOOLEAN, (float)RenderPos.y);
    }
}
void AddChat(CHAT* c, const wchar_t* chat_text, int flag)
{
    float Time = 0;
    int Length = (int)wcslen(chat_text);
    switch (flag)
    {
    case 0:
        Time = Length * 2 + 160;
        break;
    case 1:
        Time = 1000;
        g_pChatListBox->AddText(c->ID, chat_text, mu::ui::window::TYPE_CHAT_MESSAGE);
        break;
    }

    if (Length >= 20)
    {
        CutText(chat_text, c->Text[1], c->Text[0], 256);
        c->LifeTime[0] = Time;
        c->LifeTime[1] = Time;
    }
    else
    {
        memset(c->Text[0], 0, sizeof(c->Text[0]));
        wcscpy(c->Text[0], chat_text);
        c->LifeTime[0] = Time;
    }
}

void AddGuildName(CHAT* c, CHARACTER* Owner)
{
    if (IsShopInViewport(Owner))
    {
        std::wstring summary;
        GetShopTitleSummary(Owner, summary);
        wcscpy(c->szShopTitle, summary.c_str());
    }
    else {
        c->szShopTitle[0] = '\0';
    }

    if (Owner->GuildMarkIndex >= 0 && GuildMark[Owner->GuildMarkIndex].UnionName[0])
    {
        if (Owner->GuildRelationShip == GR_UNION)
            mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::Alliance);
        if (Owner->GuildRelationShip == GR_UNIONMASTER)
        {
            if (Owner->GuildStatus == G_MASTER)
                mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::AllianceMaster);
            else
                mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::Alliance);
        }
        else if (Owner->GuildRelationShip == GR_RIVAL)
        {
            if (Owner->GuildStatus == G_MASTER)
                mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::OpposingMaster);
            else
                mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::Oppose);
        }
        else if (Owner->GuildRelationShip == GR_RIVALUNION)
            mu_swprintf(c->Union, L"<%ls> %ls", GuildMark[Owner->GuildMarkIndex].UnionName, I18N::Game::OpposingAllianceMaster);
        else
            mu_swprintf(c->Union, L"<%ls>", GuildMark[Owner->GuildMarkIndex].UnionName);
    }
    else
        c->Union[0] = 0;

    if (Owner->GuildMarkIndex >= 0)
    {
        c->GuildColor = Owner->GuildTeam;

        if (Owner->GuildStatus == G_PERSON)
            mu_swprintf(c->Guild, L"[%ls] %ls", GuildMark[Owner->GuildMarkIndex].GuildName, I18N::Game::Members);
        else if (Owner->GuildStatus == G_MASTER)
            mu_swprintf(c->Guild, L"[%ls] %ls", GuildMark[Owner->GuildMarkIndex].GuildName, I18N::Game::Master);
        else if (Owner->GuildStatus == G_SUB_MASTER)
            mu_swprintf(c->Guild, L"[%ls] %ls", GuildMark[Owner->GuildMarkIndex].GuildName, I18N::Game::AssistM);
        else if (Owner->GuildStatus == G_BATTLE_MASTER)
            mu_swprintf(c->Guild, L"[%ls] %ls", GuildMark[Owner->GuildMarkIndex].GuildName, I18N::Game::BattleM);
        else
            mu_swprintf(c->Guild, L"[%ls]", GuildMark[Owner->GuildMarkIndex].GuildName);
    }
    else
    {
        c->GuildColor = 0;
        c->Guild[0] = 0;
    }
}

void CreateChat(wchar_t* character_name, const wchar_t* chat_text, CHARACTER* Owner, int Flag, int SetColor)
{
    OBJECT* o = &Owner->Object;
    if (!o->Live || !o->Visible) return;

    int Color;
    if (SetColor != -1)
    {
        Color = SetColor;
    }
    else
    {
        Color = Owner->PK;
        if (o->Kind == KIND_NPC)
            Color = 0;
    }

    for (int i = 0; i < MAX_CHAT; i++)
    {
        CHAT* c = &Chat[i];
        if (c->Owner == Owner)
        {
            Core::Text::CopyWideString(c->ID, std::size(c->ID), character_name);
            c->Color = Color;
            AddGuildName(c, Owner);
            if (wcslen(chat_text) == 0)
            {
                c->IDLifeTime = 10;
            }
            else
            {
                if (c->LifeTime[0] > 0)
                {
                    wcscpy(c->Text[1], c->Text[0]);
                    c->LifeTime[1] = c->LifeTime[0];
                }
                c->Owner = Owner;
                AddChat(c, chat_text, Flag);
            }
            return;
        }
    }

    for (int i = 0; i < MAX_CHAT; i++)
    {
        CHAT* c = &Chat[i];
        if (c->IDLifeTime <= 0 && c->LifeTime[0] <= 0)
        {
            c->Owner = Owner;
            Core::Text::CopyWideString(c->ID, std::size(c->ID), character_name);
            c->Color = Color;
            AddGuildName(c, Owner);
            if (wcslen(chat_text) == 0)
            {
                c->IDLifeTime = 100;
            }
            else
            {
                AddChat(c, chat_text, Flag);
            }
            return;
        }
    }
}

int CreateChat(wchar_t* character_name, const wchar_t* chat_text, OBJECT* Owner, int Flag, int SetColor)
{
    OBJECT* o = Owner;
    if (!o->Live || !o->Visible) return 0;

    int Color = 0;

    if (SetColor != -1)
    {
        Color = SetColor;
    }

    for (int i = 0; i < MAX_CHAT; i++)
    {
        CHAT* c = &Chat[i];
        if (c->IDLifeTime <= 0 && c->LifeTime[0] <= 0)
        {
            c->Owner = NULL;
            Core::Text::CopyWideString(c->ID, std::size(c->ID), character_name);
            c->Color = Color;
            c->GuildColor = 0;
            c->Guild[0] = 0;
            AddChat(c, chat_text, 0);
            c->LifeTime[0] = Flag;

            Vector(o->Position[0], o->Position[1], o->Position[2] + o->BoundingBoxMax[2] + 60.f, c->Position);
            return c->LifeTime[0];
        }
    }

    return 0;
}

void AssignChat(wchar_t* character_name, const wchar_t* chat_text, int flag)
{
    for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
    {
        CHARACTER* c = &CharactersClient[i];
        OBJECT* o = &c->Object;
        if (o->Live && o->Kind == KIND_PLAYER)
        {
            if (wcscmp(c->ID, character_name) == 0)
            {
                CreateChat(character_name, chat_text, c, flag);
                return;
            }
        }
    }

    for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
    {
        CHARACTER* c = &CharactersClient[i];
        OBJECT* o = &c->Object;
        if (o->Live && o->Kind == KIND_MONSTER)
        {
            if (wcscmp(c->ID, character_name) == 0)
            {
                CreateChat(character_name, chat_text, c, flag);
                return;
            }
        }
    }
}

void UpdateShopTitleVisibility()
{
    // The bubble also draws a Store header while only the character name is visible.
    for (const auto& chat : Chat)
        if (chat.Owner) EnableShopTitleDraw(chat.Owner);
    for (const auto& chat : Chat)
        if (chat.Owner && (chat.IDLifeTime > 0 || chat.LifeTime[0] > 0))
            DisableShopTitleDraw(chat.Owner);
}

void MoveChat()
{
    for (int i = 0; i < MAX_CHAT; i++)
    {
        CHAT* c = &Chat[i];
        if (c->IDLifeTime > 0)
            c->IDLifeTime -= FPS_ANIMATION_FACTOR;
        if (c->LifeTime[0] > 0)
            c->LifeTime[0]-=FPS_ANIMATION_FACTOR;
        if (c->LifeTime[1] > 0)
            c->LifeTime[1]-=FPS_ANIMATION_FACTOR;
        if (c->Owner != NULL &&
            (!c->Owner->Object.Live || !c->Owner->Object.Visible || !HasCurrentOwnerName(c->ID, c->Owner->ID)))
        {
            c->IDLifeTime = 0;
            c->LifeTime[0] = 0;
            c->LifeTime[1] = 0;
        }
    }
    UpdateShopTitleVisibility();
}


std::array<CHAT*, MAX_CHAT> VisibleChats(std::size_t& count)
{
    std::array<CHAT*, MAX_CHAT> visible{};
    count = 0;
    for (auto& chat : Chat)
        if (UI::Character::HasVisibleLabel(ShowOwnerName(&chat), chat.IDLifeTime,
                                           chat.LifeTime[0], chat.LifeTime[1]))
            visible[count++] = &chat;
    return visible;
}

void ProjectChat(CHAT* chat)
{
    int screenX, screenY;
    if (chat->Owner)
    {
        const auto& object = chat->Owner->Object;
        constexpr float NameOffset = 60.f, SmallNpcOffset = 20.f;
        const bool smallNpc = (object.Type >= MODEL_LITTLESANTA && object.Type <= MODEL_LITTLESANTA_END) ||
            object.Type == MODEL_MERCHANT_MAN;
        vec3_t position;
        Vector(object.Position[0], object.Position[1],
               object.Position[2] + object.BoundingBoxMax[2] + (smallNpc ? SmallNpcOffset : NameOffset), position);
        CameraProjection::WorldToScreen(g_Camera, position, &screenX, &screenY);
    }
    else
        CameraProjection::WorldToScreen(g_Camera, chat->Position, &screenX, &screenY);
    SetBooleanPosition(chat);
    chat->x = screenX - chat->Width / 2;
    chat->y = screenY - chat->Height;
}

void RenderBooleans()
{
    g_pRenderText->SetFont(g_hFont);
    std::size_t count;
    const auto visible = VisibleChats(count);
    for (std::size_t i = 0; i < count; ++i)
        ProjectChat(visible[i]);

    // Preserve the original collision order, considering only labels with visible content.
    for (std::size_t i = 0; i < count; ++i)
    {
        CHAT* ci = visible[i];
        for (std::size_t j = 0; j < count; ++j)
        {
            CHAT* cj = visible[j];
            if (i == j || ci->x + ci->Width <= cj->x || ci->x >= cj->x + cj->Width ||
                ci->y + ci->Height <= cj->y || ci->y >= cj->y + cj->Height) continue;
            ci->y = ci->y < cj->y + cj->Height / 2 ? cj->y - ci->Height : cj->y + cj->Height;
        }
    }
    for (std::size_t i = 0; i < count; ++i)
    {
        CHAT* chat = visible[i];
        chat->x = std::clamp(chat->x, 0, std::max(0, static_cast<int>(WindowWidth) - chat->Width));
        chat->y = std::clamp(chat->y, 0, std::max(0, static_cast<int>(WindowHeight) - chat->Height));
        RenderBoolean(chat->x, chat->y, chat);
    }
}
}
