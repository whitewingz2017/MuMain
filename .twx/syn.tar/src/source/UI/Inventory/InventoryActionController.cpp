// NewUIInventoryActionController.cpp
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameLogic/Cosmetics/CosmeticArmor.h"
#include "UI/Inventory/InventoryActionController.h"
#include "UI/Inventory/MyInventory.h"
#include "UI/Inventory/InventoryCtrl.h"
#include "UI/Core/WindowSystem.h"
#include "UI/Dialogs/CustomMessageBox.h"
#include "UI/Dialogs/GenericConfirmDialog.h"
#include "Engine/Object/ZzzInventory.h"
#include "UI/Inventory/UIJewelHarmony.h"
#include "GameLogic/Items/CSItemOption.h"
#include "World/MapInfra/MapManager.h"
#include "Network/Server/SocketSystem.h"
#include "GameLogic/Social/MonkSystem.h"
#include "Character/CharacterManager.h"
#include "Audio/DSPlaySound.h"
#include "Engine/Object/ZzzInterface.h"
#include "UI/Core/UIManager.h"
#include "GameLogic/Items/ChangeRingManager.h"
#include "GameLogic/Items/ItemCategories.h"
#include "World/MapInfra/PortalMgr.h"
#include "GameLogic/Quests/CSQuest.h"
#include "I18N/All.h"
#include "GameLogic/Items/ShopRestrictions.h"
#include "GameLogic/Items/TradeRestrictions.h"

namespace mu::ui::window
{

CInventoryActionController::CInventoryActionController() : m_pContext(nullptr) {}

void CInventoryActionController::SetContext(SEASON3B::IInventoryActionContext* pContext)
{
    m_pContext = pContext;
}

bool CInventoryActionController::UseSelectedItem(CInventoryCtrl* control, DWORD key) const
{
    if (!m_pContext || !control || control->IsLocked() || CInventoryCtrl::GetPickedItem() || EquipmentItem || Hero->Dead) return false;
    auto* item = control->FindItemByKey(key);
    if (!item) return false;
    if (g_pNewUISystem->IsVisible(INTERFACE_STORAGE))
    {
        if (g_pStorageInventory->ProcessMyInvenItemAutoMove(control, item)) return true;
        return g_pNewUISystem->IsVisible(INTERFACE_STORAGE_EXT) && g_pStorageInventoryExt->ProcessMyInvenItemAutoMove(control, item);
    }
    if (g_pNewUISystem->IsVisible(INTERFACE_MIXINVENTORY)) return g_pMixInventory->ProcessMyInvenItemAutoMove(control, item);
    const int index = control->GetIndexByItem(item);
    return index >= 0 && (TryConsumeItem(control, item, index) || TryEquipItem(control, item, index));
}

bool CInventoryActionController::DropSelectedItem(CInventoryCtrl* control, DWORD key) const
{
    if (!control || control->IsLocked() || CInventoryCtrl::GetPickedItem() || EquipmentItem) return false;
    auto* item = control->FindItemByKey(key);
    return item && TryDropItem(control, item);
}

bool CInventoryActionController::SellSelectedItem(CInventoryCtrl* control, DWORD key) const
{
    if (!control || control->IsLocked() || EquipmentItem || !g_pNewUISystem->IsVisible(INTERFACE_NPCSHOP)) return false;
    auto* item = control->FindItemByKey(key);
    return item && HandleSellToNPC(control, item, true);
}

bool CInventoryActionController::HandleInventoryActions(CInventoryCtrl* targetControl) const
{
    if (m_pContext == nullptr || targetControl == nullptr)
    {
        return false;
    }

    const bool hasPickedItem = CInventoryCtrl::GetPickedItem() != nullptr;
    if (UI::Items::Drag::ShouldConsumePanelPress(hasPickedItem, IsPress(VK_LBUTTON)))
    {
        return true;
    }

    if (hasPickedItem && IsRelease(VK_LBUTTON))
    {
        return HandlePickedItemPlacement(targetControl);
    }

    if (m_pContext->GetRepairMode() == SEASON3B::REPAIR_MODE_OFF && IsPress(VK_RBUTTON))
    {
        return HandleRightClick(targetControl);
    }

    if (m_pContext->GetRepairMode() == SEASON3B::REPAIR_MODE_ON && IsPress(VK_LBUTTON))
    {
        return HandleRepairClick(targetControl);
    }

    return false;
}

bool CInventoryActionController::HandlePickedItemPlacement(CInventoryCtrl* targetControl) const
{
    CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
    if (pPickedItem == nullptr)
    {
        return false;
    }

    ITEM* pPickItem = pPickedItem->GetItem();
    if (pPickItem == nullptr)
    {
        return true;
    }

    const int iSourceIndex = pPickedItem->GetSourceLinealPos();
    const int iTargetIndex = pPickedItem->GetTargetLinealPos(targetControl);

    const bool bFromInventorySystem =
        (pPickedItem->GetOwnerInventory() == targetControl) ||
        (g_pMyInventoryExt != nullptr && g_pMyInventoryExt->GetOwnerOf(pPickedItem) != nullptr);

    if (bFromInventorySystem)
    {
        if (ApplyJewels(targetControl, pPickedItem, pPickItem, iSourceIndex, iTargetIndex))
        {
            return true;
        }

        if (iTargetIndex != -1 && TryStackItems(targetControl, pPickItem, iSourceIndex, iTargetIndex))
        {
            return true;
        }
    }

    if (TryMoveItem(targetControl, pPickedItem, pPickItem, iSourceIndex, iTargetIndex))
    {
        return true;
    }

    return false;
}

bool CInventoryActionController::TryApplyJewel(CInventoryCtrl* targetControl, CPickedItem* pPickedItem,
                                                    ITEM* pPickItem, int iSourceIndex, int iTargetIndex) const
{
    return ApplyJewels(targetControl, pPickedItem, pPickItem, iSourceIndex, iTargetIndex);
}

bool CInventoryActionController::TryStackItem(CInventoryCtrl* targetControl, ITEM* pPickItem,
                                                   int iSourceIndex, int iTargetIndex) const
{
    return TryStackItems(targetControl, pPickItem, iSourceIndex, iTargetIndex);
}

bool CInventoryActionController::TryMoveItem(CInventoryCtrl* targetControl, CPickedItem* pPickedItem,
                                                  ITEM* pPickItem, int iSourceIndex, int iTargetIndex) const
{
    if (iTargetIndex < 0 || !targetControl->CanMove(iTargetIndex, pPickItem))
    {
        return false;
    }

    const auto sourceStorageType = pPickedItem->GetSourceStorageType();
    const auto targetStorageType = targetControl->GetStorageType();

    if (iTargetIndex != iSourceIndex || sourceStorageType != targetStorageType)
    {
        return SendRequestEquipmentItem(sourceStorageType, iSourceIndex, pPickItem, targetStorageType, iTargetIndex);
    }

    CInventoryCtrl::BackupPickedItem();
    return false;
}

bool CInventoryActionController::HandleRepairClick(CInventoryCtrl* targetControl) const
{
    return RepairItemAtMousePoint(targetControl);
}

bool CInventoryActionController::HandleRightClick(CInventoryCtrl* targetControl) const
{
    m_pContext->ResetMouseRButton();

    if (g_pNewUISystem->IsVisible(INTERFACE_STORAGE))
    {
        return HandleStorageAutoMove(targetControl);
    }

    if (g_pNewUISystem->IsVisible(INTERFACE_NPCSHOP) && g_pNewUISystem->IsVisible(INTERFACE_INVENTORY))
    {
        return HandleSellToNPC(targetControl);
    }

    if (g_pNewUISystem->IsVisible(INTERFACE_MIXINVENTORY) && g_pNewUISystem->IsVisible(INTERFACE_INVENTORY))
    {
        return HandleMixAutoMove(targetControl);
    }

    if (g_pNewUISystem->IsVisible(INTERFACE_TRADE) && g_pNewUISystem->IsVisible(INTERFACE_INVENTORY))
    {
        return g_pTrade->ProcessMyInvenItemAutoMove(targetControl);
    }

    if (g_pNewUISystem->IsVisible(INTERFACE_INVENTORY)
        && !g_pNewUISystem->IsVisible(INTERFACE_NPCSHOP)
        && !g_pNewUISystem->IsVisible(INTERFACE_TRADE)
        && !g_pNewUISystem->IsVisible(INTERFACE_DEVILSQUARE)
        && !g_pNewUISystem->IsVisible(INTERFACE_BLOODCASTLE)
        && !g_pNewUISystem->IsVisible(INTERFACE_LUCKYITEMWND)
        && !g_pNewUISystem->IsVisible(INTERFACE_MIXINVENTORY)
        && !g_pNewUISystem->IsVisible(INTERFACE_MYSHOP_INVENTORY))
    {
        return HandleInventoryRightClickActions(targetControl);
    }

    return false;
}

bool CInventoryActionController::HandleStorageAutoMove(CInventoryCtrl* targetControl) const
{
    if (g_pStorageInventory->ProcessMyInvenItemAutoMove(targetControl))
    {
        return true;
    }

    if (g_pNewUISystem->IsVisible(INTERFACE_STORAGE_EXT))
    {
        return g_pStorageInventoryExt->ProcessMyInvenItemAutoMove(targetControl);
    }

    return false;
}

bool CInventoryActionController::HandleMixAutoMove(CInventoryCtrl* targetControl) const
{
    // All crafting NPCs share one mix window, so this covers every crafting NPC at once.
    return g_pMixInventory->ProcessMyInvenItemAutoMove(targetControl);
}

bool CInventoryActionController::HandleSellToNPC(CInventoryCtrl* targetControl, ITEM* selectedItem, bool confirmAll) const
{
    if (CInventoryCtrl::GetPickedItem())
    {
        return false;
    }

    if (!selectedItem && !targetControl->ContainsPointer())
    {
        return false;
    }

    if (targetControl->GetStorageType() != STORAGE_TYPE::INVENTORY)
    {
        return false;
    }

    ITEM* pItem = selectedItem ? selectedItem : targetControl->FindItemAtPointer();
    if (pItem == nullptr)
    {
        return false;
    }

    if (g_pNPCShop->IsSellingItem())
    {
        return false;
    }

    if (GameLogic::Items::IsSellingBan(pItem))
    {
        g_pSystemLogBox->AddText(I18N::Game::TheseItemsCannotBeTraded, TYPE_ERROR_MESSAGE);
        return true;
    }

    const int iIndex = targetControl->GetIndexByItem(pItem);
    if (iIndex < 0)
    {
        return false;
    }

    if (!CInventoryCtrl::CreatePickedItem(targetControl, pItem))
    {
        return false;
    }

    CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
    if (pPickedItem == nullptr)
    {
        return false;
    }

    const bool highValue = GameLogic::Items::IsHighValueItem(pItem);
    const DWORD itemKey = pPickedItem->GetItem()->Key;
    targetControl->RemoveItem(pItem);
    pPickedItem->HidePickedItem();

    const int sourceIndex = pPickedItem->GetSourceLinealPos();
    if (sourceIndex < MAX_EQUIPMENT_INDEX || sourceIndex >= MAX_MY_INVENTORY_EX_INDEX)
    {
        CInventoryCtrl::BackupPickedItem();
        return false;
    }

    if (confirmAll || highValue)
    {
        GenericDialogConfig cfg;
        cfg.showCancel = true;
        if (!confirmAll) if (ITEM* pPreviewItem = pPickedItem->GetItem())
        {
            cfg.item3D = *pPreviewItem;
        }
        cfg.lines = {
            { I18N::Game::AnExpensiveItem, true },
            { I18N::Game::CheckTheItemPlease, true },
            { I18N::Game::AreYouSureYouWantToSellIt, true },
        };
        if (confirmAll)
        {
            cfg.primaryLabel = L"Sell";
            cfg.lines = {{L"Are you sure to sell this?"}};
        }
        cfg.onPrimary = [itemKey, sourceIndex]
        {
            CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
            int iSourceIndex = pPickedItem ? pPickedItem->GetSourceLinealPos() : -1;
            if (GameLogic::Items::CanConfirmSale(pPickedItem ? pPickedItem->GetItem() : nullptr,
                iSourceIndex, sourceIndex, itemKey, g_pNewUISystem->IsVisible(INTERFACE_NPCSHOP), g_pNPCShop->IsSellingItem()))
            {
                SocketClient->ToGameServer()->SendSellItemToNpcRequest(iSourceIndex);
                g_pNPCShop->SetSellingItem(true);
            }
            else
            {
                CInventoryCtrl::BackupPickedItem();
            }
        };
        cfg.onCancel = []
        {
            CInventoryCtrl::BackupPickedItem();
        };
        g_pGenericConfirmDialog->Show(std::move(cfg));
        return true;
    }

    SocketClient->ToGameServer()->SendSellItemToNpcRequest(sourceIndex);
    g_pNPCShop->SetSellingItem(true);
    return true;
}

bool CInventoryActionController::HandleInventoryRightClickActions(CInventoryCtrl* targetControl) const
{
    if (g_pNewUISystem->IsVisible(INTERFACE_INVENTORY_EXT))
    {
        return TryTransferBetweenInventorySections(targetControl);
    }

    ITEM* pItem = targetControl->FindItemAtPointer();
    if (pItem == nullptr)
    {
        return false;
    }

    const int iIndex = targetControl->GetIndexByItem(pItem);

    if (iIndex >= 0 && TryConsumeItem(targetControl, pItem, iIndex))
    {
        return true;
    }

#ifdef LJH_ADD_SYSTEM_OF_EQUIPPING_ITEM_FROM_INVENTORY
    if (g_pMyInventory->IsInvenItem(pItem->Type))
    {
#ifdef LJH_FIX_APP_SHUTDOWN_WEQUIPPING_INVENITEM_WITH_CLICKING_MOUSELBTN
        if (MouseLButton || MouseLButtonPop || MouseLButtonPush)
        {
            return false;
        }
#endif
        if (pItem->Durability == 0)
        {
            return false;
        }

        int iChangeInvenItemStatus = 0;
        (pItem->Durability == 255) ? iChangeInvenItemStatus = 254 : iChangeInvenItemStatus = 255;
        SendRequestEquippingInventoryItem(iIndex, iChangeInvenItemStatus);
        return true;
    }
#endif

    if (!EquipmentItem)
    {
        if (TryEquipItem(targetControl, pItem, iIndex))
        {
            return true;
        }
    }

    if (TryDropItem(targetControl, pItem))
    {
        return true;
    }

    return false;
}

int CInventoryActionController::FindAlternateEquipSlot(int nOriginalSlot, ITEM* pItem) const
{
    if (nOriginalSlot == EQUIPMENT_WEAPON_RIGHT)
    {
        const auto baseClass = gCharacterManager.GetBaseClass(Hero->Class);
        if (baseClass == CLASS_KNIGHT || baseClass == CLASS_DARK || baseClass == CLASS_RAGEFIGHTER)
        {
            const ITEM_ATTRIBUTE* pItemAttr = &ItemAttribute[pItem->Type];
            if (!pItemAttr->TwoHand)
            {
                return EQUIPMENT_WEAPON_LEFT;
            }
        }
    }
    else if (nOriginalSlot == EQUIPMENT_RING_RIGHT)
    {
        return EQUIPMENT_RING_LEFT;
    }

    return -1;
}

bool CInventoryActionController::IsSlotOccupied(int nSlot) const
{
    if (nSlot < 0 || nSlot >= MAX_EQUIPMENT_INDEX)
    {
        return true;
    }

    const ITEM* pEquipment = &CharacterMachine->Equipment[nSlot];
    return (pEquipment->Type != -1);
}

bool CInventoryActionController::TryEquipItem(CInventoryCtrl* targetControl, ITEM* pItem, int iSrcIndex) const
{
    if (const int part = GameLogic::Cosmetics::ArmorPart(pItem->Type); part >= 0)
    {
        if (GameLogic::Cosmetics::IsFemaleArmor(pItem->Type)
            && gCharacterManager.GetBaseClass(Hero->Class) != CLASS_ELF
            && gCharacterManager.GetBaseClass(Hero->Class) != CLASS_SUMMONER)
            return true;
        const int destination = GameLogic::Cosmetics::AvailablePart(pItem->Type,
            GameLogic::Cosmetics::EquippedArmor(5) >= 0, GameLogic::Cosmetics::EquippedArmor(6) >= 0);
        GameLogic::Cosmetics::Request(1, iSrcIndex, destination);
        return true;
    }
    const ITEM_ATTRIBUTE* pItemAttr = &ItemAttribute[pItem->Type];
    int nDstIndex = pItemAttr->m_byItemSlot;

    if (nDstIndex < 0 || nDstIndex >= MAX_EQUIPMENT_INDEX)
    {
        return false;
    }

    if (!m_pContext->IsEquipable(nDstIndex, pItem))
    {
        return true;
    }

    if (IsSlotOccupied(nDstIndex))
    {
        const int nAltSlot = FindAlternateEquipSlot(nDstIndex, pItem);

        if (nAltSlot != -1 && !IsSlotOccupied(nAltSlot))
        {
            nDstIndex = nAltSlot;
        }
        else
        {
            return true;
        }
    }

    if (!m_pContext->IsEquipable(nDstIndex, pItem))
    {
        return true;
    }

    if (!CInventoryCtrl::CreatePickedItem(nullptr, pItem))
    {
        return false;
    }

    CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
    if (pPickedItem == nullptr)
    {
        return false;
    }

    targetControl->RemoveItem(pItem);
    pPickedItem->HidePickedItem();

    if (!SendRequestEquipmentItem(STORAGE_TYPE::INVENTORY, iSrcIndex, pPickedItem->GetItem(), STORAGE_TYPE::INVENTORY, nDstIndex))
        CInventoryCtrl::BackupPickedItem();
    return true;
}

bool CInventoryActionController::TryDropItem(CInventoryCtrl* targetControl, ITEM* pItem) const
{
    if (pItem->Jewel_Of_Harmony_Option != 0 || (pItem->Type == ITEM_LOST_MAP && gMapManager.IsCursedTemple()))
    {
        g_pSystemLogBox->AddText(I18N::Game::ThisItemCannotBeDropped, TYPE_ERROR_MESSAGE);
        return true;
    }
    if (Hero->Dead != 0)
    {
        return false;
    }

    if (GameLogic::Items::IsHighValueItem(pItem))
    {
        g_pSystemLogBox->AddText(I18N::Game::YouAreNotAllowedToDropThisExpensiveItem, TYPE_ERROR_MESSAGE);
        return true;
    }

    if (GameLogic::Items::IsDropBan(pItem))
    {
        g_pSystemLogBox->AddText(I18N::Game::ThisItemCannotBeDropped, TYPE_ERROR_MESSAGE);
        return true;
    }

    if (!CInventoryCtrl::CreatePickedItem(targetControl, pItem))
    {
        return false;
    }

    CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
    if (pPickedItem == nullptr)
    {
        return false;
    }

    targetControl->RemoveItem(pItem);
    pPickedItem->HidePickedItem();

    const int tx = Hero->PositionX;
    const int ty = Hero->PositionY;
    const int sourceIndex = pPickedItem->GetSourceLinealPos();

    SocketClient->ToGameServer()->SendDropItemRequest(tx, ty, sourceIndex);
    SendDropItem = sourceIndex;

    return true;
}

bool CInventoryActionController::RepairItemAtMousePoint(CInventoryCtrl* targetControl) const
{
    ITEM* pItem = targetControl->FindItemAtPointer();
    if (pItem == nullptr)
    {
        return true;
    }

    if (GameLogic::Items::IsRepairBan(pItem))
    {
        return true;
    }

    const int iIndex = targetControl->GetIndex(pItem->x, pItem->y);

    if (g_pNewUISystem->IsVisible(INTERFACE_NPCSHOP) && g_pNPCShop->IsRepairShop())
    {
        SocketClient->ToGameServer()->SendRepairItemRequest(iIndex, 0);
    }
    else
    {
        SocketClient->ToGameServer()->SendRepairItemRequest(iIndex, 1);
    }

    return true;
}

bool CInventoryActionController::ApplyJewels(CInventoryCtrl* targetControl, CPickedItem* pPickedItem,
                                                  ITEM* pPickItem, int iSourceIndex, int iTargetIndex) const
{
    const bool bIsJewelType = pPickItem->Type == ITEM_JEWEL_OF_BLESS || pPickItem->Type == ITEM_JEWEL_OF_SOUL ||
                              pPickItem->Type == ITEM_JEWEL_OF_LIFE || pPickItem->Type == ITEM_JEWEL_OF_HARMONY ||
                              GameLogic::Items::IsRefineStone(pPickItem) || pPickItem->Type == ITEM_POTION + 160 ||
                              pPickItem->Type == ITEM_POTION + 161;

    if (!bIsJewelType)
    {
        return false;
    }

    ITEM* pItem = targetControl->FindItem(iTargetIndex);
    if (!pItem)
    {
        return false;
    }

    const int iType = pItem->Type;
    const int iLevel = pItem->Level;
    const int iDurability = pItem->Durability;

    bool bSuccess = true;

    if (iType > ITEM_WINGS_OF_DARKNESS && !GameLogic::Items::IsWingItem(pItem))
    {
        bSuccess = false;
    }

    if (GameLogic::Items::IsAmmunitionType(iType))
    {
        bSuccess = false;
    }

    if ((pPickItem->Type == ITEM_JEWEL_OF_BLESS && iLevel >= 6) ||
        (pPickItem->Type == ITEM_JEWEL_OF_SOUL && iLevel >= 9))
    {
        bSuccess = false;
    }

    if (pPickItem->Type == ITEM_JEWEL_OF_BLESS && GameLogic::Cosmetics::HelperBehaviorItem(iType) == ITEM_HORN_OF_FENRIR && iDurability != 255)
    {
        const int iTargetIndex = targetControl->GetIndex(pItem->x, pItem->y);

        mu::ui::window::GenericDialogConfig cfg;
        cfg.showCancel = true;
        cfg.lines.push_back({ I18N::Game::WouldYouLikeToRepairFenrirSHorn, true });
        cfg.onPrimary = [iSourceIndex, iTargetIndex]
        {
            SendRequestUse(iSourceIndex, iTargetIndex);
            CInventoryCtrl::BackupPickedItem();
        };
        cfg.onCancel = [] { CInventoryCtrl::BackupPickedItem(); };
        mu::ui::window::g_pGenericConfirmDialog->Show(std::move(cfg));

        pPickedItem->HidePickedItem();
        return true;
    }

    if (pPickItem->Type == ITEM_JEWEL_OF_HARMONY)
    {
        if (g_SocketItemMgr.IsSocketItem(pItem))
        {
            bSuccess = false;
        }
        else if (pItem->Jewel_Of_Harmony_Option != 0)
        {
            bSuccess = false;
        }
        else
        {
            const StrengthenItem strengthitem = g_pUIJewelHarmonyinfo->GetItemType(static_cast<int>(pItem->Type));

            if (strengthitem == SI_None)
            {
                bSuccess = false;
            }
        }
    }

    if (GameLogic::Items::IsRefineStone(pPickItem))
    {
        if (g_SocketItemMgr.IsSocketItem(pItem))
        {
            bSuccess = false;
        }
        else if (pItem->Jewel_Of_Harmony_Option == 0)
        {
            bSuccess = false;
        }
    }

    if (GameLogic::Items::IsLuckyItemType(pItem->Type))
    {
        bSuccess = false;
        if (pPickItem->Type == ITEM_POTION + 161)
        {
            if (pItem->Jewel_Of_Harmony_Option == 0)
                bSuccess = true;
        }
        else if (pPickItem->Type == ITEM_POTION + 160)
        {
            if (pItem->Durability > 0)
                bSuccess = true;
        }
    }

    if (bSuccess)
    {
        const int targetIndex = targetControl->GetIndexByItem(pItem);
        SendRequestUse(iSourceIndex, targetIndex);
        PlayBuffer(SOUND_GET_ITEM01);
        return true;
    }

    return false;
}

bool CInventoryActionController::TryStackItems(CInventoryCtrl* targetControl, ITEM* pPickItem,
                                                    int iSourceIndex, int iTargetIndex) const
{
    if (ITEM* pItem = targetControl->FindItem(iTargetIndex))
    {
        if (targetControl->AreItemsStackable(pPickItem, pItem))
        {
            SendRequestEquipmentItem(STORAGE_TYPE::INVENTORY, iSourceIndex, pPickItem, STORAGE_TYPE::INVENTORY,
                                     iTargetIndex);
            return true;
        }
    }

    return false;
}

bool CInventoryActionController::TryConsumeItem(CInventoryCtrl* targetControl, ITEM* pItem, int iIndex) const
{
    if (pItem == nullptr)
    {
        return false;
    }

    if (pItem->Type == ITEM_TOWN_PORTAL_SCROLL)
    {
        SendRequestUse(iIndex, 0);
        return true;
    }

    const auto isApple = pItem->Type == ITEM_APPLE;
    const auto isPotion = (pItem->Type >= ITEM_APPLE && pItem->Type <= ITEM_ALE) ||
                          (pItem->Type >= ITEM_SMALL_SHIELD_POTION && pItem->Type <= ITEM_LARGE_COMPLEX_POTION);

    if (isApple || isPotion || (pItem->Type == ITEM_REMEDY_OF_LOVE && pItem->Level == 0) ||
        (pItem->Type >= ITEM_JACK_OLANTERN_BLESSINGS && pItem->Type <= ITEM_JACK_OLANTERN_DRINK) ||
        (pItem->Type == ITEM_BOX_OF_LUCK && pItem->Level == 14) ||
        GameLogic::Items::IsElitePotion(pItem) ||
        GameLogic::Items::IsBuffScroll(pItem) || pItem->Type == ITEM_INDULGENCE ||
        pItem->Type == ITEM_MEDIUM_ELITE_HEALING_POTION ||
        (pItem->Type >= ITEM_CHERRY_BLOSSOM_WINE && pItem->Type <= ITEM_CHERRY_BLOSSOM_FLOWER_PETAL) ||
        GameLogic::Items::IsBattleOrStrengthScroll(pItem) || pItem->Type == ITEM_TALISMAN_OF_GUARDIAN ||
        pItem->Type == ITEM_TALISMAN_OF_ITEM_PROTECTION || pItem->Type == ITEM_ELITE_SD_POTION)
    {
        SendRequestUse(iIndex, 0);
        if (isApple)
        {
            PlayBuffer(SOUND_EAT_APPLE01);
        }
        else if (isPotion)
        {
            PlayBuffer(SOUND_DRINK01);
        }

        return true;
    }

    if (GameLogic::Items::IsElixir(pItem))
    {
        std::list<eBuffState> secretPotionbufflist;
        secretPotionbufflist.push_back(eBuff_SecretPotion1);
        secretPotionbufflist.push_back(eBuff_SecretPotion2);
        secretPotionbufflist.push_back(eBuff_SecretPotion3);
        secretPotionbufflist.push_back(eBuff_SecretPotion4);
        secretPotionbufflist.push_back(eBuff_SecretPotion5);

        if (g_isCharacterBufflist((&Hero->Object), secretPotionbufflist) == eBuffNone)
        {
            SendRequestUse(iIndex, 0);
            return true;
        }

        CreateOkMessageBox(I18N::Game::YouCannotUseThisItemWhileThePotionEffectsRemainActive, RGBA(255, 30, 0, 255));
        return false;
    }

    if ((pItem->Type >= ITEM_RESET_FRUIT_STRENGTH && pItem->Type <= ITEM_RESET_FRUIT_ENERGY) ||
        (pItem->Type == ITEM_RESET_FRUIT_CONTROL && gCharacterManager.GetBaseClass(Hero->Class) == CLASS_DARK_LORD))
    {
        WORD point[5] = {
            0,
        };
        point[0] = CharacterAttribute->Strength + CharacterAttribute->AddStrength;
        point[1] = CharacterAttribute->Dexterity + CharacterAttribute->AddDexterity;
        point[2] = CharacterAttribute->Vitality + CharacterAttribute->AddVitality;
        point[3] = CharacterAttribute->Energy + CharacterAttribute->AddEnergy;
        point[4] = CharacterAttribute->Charisma + CharacterAttribute->AddCharisma;

        const unsigned char nStat[MAX_CLASS][5] = {
            18, 18, 15, 30, 0,  28, 20, 25, 10, 0,  22, 25, 20, 15, 0,  26, 26, 26,
            26, 0,  26, 20, 20, 15, 25, 21, 21, 18, 23, 0,  32, 27, 25, 20, 0,
        };

        const int attributeType = pItem->Type - (ITEM_RESET_FRUIT_STRENGTH);
        const int characterClass = gCharacterManager.GetBaseClass(Hero->Class);
        point[attributeType] -= nStat[characterClass][attributeType];

        if (point[attributeType] < (pItem->Durability * 10))
        {
            g_pMyInventory->SetStandbyItemKey(pItem->Key);

            wchar_t strName[50] = { 0, };
            if (pItem->Type == ITEM_RESET_FRUIT_STRENGTH)
                mu_swprintf(strName, L"%ls", I18N::Game::STR);
            else if (pItem->Type == ITEM_RESET_FRUIT_QUICKNESS)
                mu_swprintf(strName, L"%ls", I18N::Game::AGI);
            else if (pItem->Type == ITEM_RESET_FRUIT_HEALTH)
                mu_swprintf(strName, L"%ls", I18N::Game::STA);
            else if (pItem->Type == ITEM_RESET_FRUIT_ENERGY)
                mu_swprintf(strName, L"%ls", I18N::Game::ENG);
            else if (pItem->Type == ITEM_RESET_FRUIT_CONTROL)
                mu_swprintf(strName, L"%ls", I18N::Game::Command);

            GenericDialogConfig cfg;
            cfg.showCancel = true;
            cfg.item3D = *pItem;
            cfg.lines = {
                { strName, true },
                { I18N::Game::ThisIsMoreThanTheValueOfYourResettablePoints, true },
                { I18N::Game::WouldYouLikeToReset, true },
            };
            cfg.onPrimary = []
            {
                BYTE srcIndex = g_pMyInventory->GetStandbyItemIndex();
                SendRequestUse(srcIndex, 0);
            };
            g_pGenericConfirmDialog->Show(std::move(cfg));
            return false;
        }

        SendRequestUse(iIndex, 0);
        return true;
    }

    if (pItem->Type == ITEM_RESET_FRUIT_CONTROL && gCharacterManager.GetBaseClass(Hero->Class) != CLASS_DARK_LORD)
    {
        CreateOkMessageBox(I18N::Game::OnlyDarklordCanUseIt);
        return true;
    }

    if (pItem->Type == ITEM_ARMOR_OF_GUARDSMAN)
    {
        if (IsUnitedMarketPlace())
        {
            wchar_t szOutputText[512];
            mu_swprintf(szOutputText, L"%ls %ls", I18N::Game::YouCannotEnterChaosCastle, I18N::Game::FromTheMarketInLorencia);
            CreateOkMessageBox(szOutputText);
            return true;
        }

        if (Hero->SafeZone == false)
        {
            CreateOkMessageBox(I18N::Game::YouCanOnlyUseThisInASafeZone);
            return false;
        }

        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::ChaosCastle, pItem->Level);
        g_pMyInventory->SetStandbyItemKey(pItem->Key);
        return true;
    }

    if (pItem->Type == ITEM_DEVIL_SQUARE_TICKET)
    {
        const BYTE byPossibleLevel = CaculateFreeTicketLevel(FREETICKET_TYPE_DEVILSQUARE);
        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::DevilSquare, byPossibleLevel);
        return false;
    }

    if (pItem->Type == ITEM_BLOOD_CASTLE_TICKET)
    {
        const BYTE byPossibleLevel = CaculateFreeTicketLevel(FREETICKET_TYPE_BLOODCASTLE);
        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::BloodCastle, byPossibleLevel);
        return false;
    }

    if (pItem->Type == ITEM_KALIMA_TICKET)
    {
        if (Hero->SafeZone || gMapManager.InHellas())
        {
            g_pSystemLogBox->AddText(I18N::Game::CanTBeUsedInTheSafeZone, TYPE_ERROR_MESSAGE);
            return false;
        }

        SendRequestUse(iIndex, 0);
        return true;
    }

    if (pItem->Type == ITEM_ILLUSION_TEMPLE_TICKET)
    {
        const BYTE byPossibleLevel = CaculateFreeTicketLevel(FREETICKET_TYPE_CURSEDTEMPLE);
        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::CursedTemple, byPossibleLevel);
        return true;
    }

    if (pItem->Type == ITEM_OPEN_ACCESS_TICKET_TO_CHAOS_CASTLE)
    {
        if (Hero->SafeZone == false)
        {
            CreateOkMessageBox(I18N::Game::YouCanOnlyUseThisInASafeZone);
            return false;
        }

        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::ChaosCastle, pItem->Level);
        g_pMyInventory->SetStandbyItemKey(pItem->Key);
        return true;
    }

    if (pItem->Type == ITEM_SCROLL_OF_BLOOD)
    {
        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::CursedTemple, pItem->Level);
        return true;
    }

    if (pItem->Type == ITEM_DEVILS_INVITATION)
    {
        SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::DevilSquare, pItem->Level);
        return true;
    }

    if (pItem->Type == ITEM_INVISIBILITY_CLOAK)
    {
        if (pItem->Level == 0)
        {
            g_pSystemLogBox->AddText(I18N::Game::IncorrectItem, TYPE_ERROR_MESSAGE);
        }
        else
        {
            SocketClient->ToGameServer()->SendMiniGameOpeningStateRequest(MiniGameType::BloodCastle, pItem->Level - 1);
        }

        return true;
    }

    if ((pItem->Type >= ITEM_SCROLL_OF_POISON && pItem->Type < ITEM_ETC + MAX_ITEM_INDEX) ||
        (pItem->Type >= ITEM_ORB_OF_TWISTING_SLASH && pItem->Type <= ITEM_ORB_OF_GREATER_FORTITUDE) ||
        (pItem->Type >= ITEM_ORB_OF_FIRE_SLASH && pItem->Type <= ITEM_ORB_OF_DEATH_STAB) ||
        (pItem->Type == ITEM_WING + 20) ||
        (pItem->Type >= ITEM_SCROLL_OF_FIREBURST && pItem->Type <= ITEM_SCROLL_OF_ELECTRIC_SPARK) ||
        (pItem->Type == ITEM_SCROLL_OF_FIRE_SCREAM) || (pItem->Type == ITEM_CRYSTAL_OF_DESTRUCTION) ||
        (pItem->Type == ITEM_CRYSTAL_OF_FLAME_STRIKE) || (pItem->Type == ITEM_CRYSTAL_OF_RECOVERY) ||
        (pItem->Type == ITEM_CRYSTAL_OF_MULTI_SHOT) || (pItem->Type == ITEM_SCROLL_OF_CHAOTIC_DISEIER) ||
        (pItem->Type == ITEM_SCROLL_OF_GIGANTIC_STORM) || (pItem->Type == ITEM_SCROLL_OF_WIZARDRY_ENHANCE))
    {
        bool bReadBookGem = true;

        if (pItem->Type == ITEM_SCROLL_OF_NOVA || pItem->Type == ITEM_SCROLL_OF_WIZARDRY_ENHANCE ||
            pItem->Type == ITEM_CRYSTAL_OF_MULTI_SHOT || pItem->Type == ITEM_CRYSTAL_OF_RECOVERY ||
            pItem->Type == ITEM_CRYSTAL_OF_DESTRUCTION)
        {
            if (g_csQuest.getQuestState2(QUEST_CHANGE_UP_3) != QUEST_END)
            {
                bReadBookGem = false;
            }
        }

        if (pItem->Type == ITEM_SCROLL_OF_CHAOTIC_DISEIER)
        {
            if (CharacterAttribute->Level < 220)
            {
                bReadBookGem = false;
            }
        }

        if (bReadBookGem)
        {
            const WORD wStrength = CharacterAttribute->Strength + CharacterAttribute->AddStrength;
            const WORD wEnergy = CharacterAttribute->Energy + CharacterAttribute->AddEnergy;

            if (CharacterAttribute->Level >= ItemAttribute[pItem->Type].RequireLevel &&
                wEnergy >= pItem->RequireEnergy && wStrength >= pItem->RequireStrength)
            {
                SendRequestUse(iIndex, 0);
            }

            return true;
        }

        return false;
    }

    if (pItem->Type == ITEM_FRUITS)
    {
        if (CharacterAttribute->Level < 10)
        {
            CreateOkMessageBox(I18N::Game::MustBeOverLevel10ToUseFruits);
            return true;
        }

        bool bEquipmentEmpty = true;
        for (int i = 0; i < MAX_EQUIPMENT; i++)
        {
            if (CharacterMachine->Equipment[i].Type != -1)
            {
                bEquipmentEmpty = false;
                break;
            }
        }

        if (!bEquipmentEmpty)
        {
            CreateOkMessageBox(I18N::Game::ToDecreaseTheFruitWeaponsArmorsAndOthersMustBeRemoved);
            return true;
        }

        if (pItem->Level == 4) // Command Fruit
        {
            if (gCharacterManager.GetBaseClass(CharacterAttribute->Class) != CLASS_DARK_LORD)
            {
                CreateOkMessageBox(I18N::Game::OnlyDarklordCanUseIt);
                return true;
            }
        }

        g_pMyInventory->SetStandbyItemKey(pItem->Key);

        wchar_t strName[50] = { 0, };
        switch (pItem->Level)
        {
        case 0: mu_swprintf(strName, L"%ls", I18N::Game::ENG); break;
        case 1: mu_swprintf(strName, L"%ls", I18N::Game::STA); break;
        case 2: mu_swprintf(strName, L"%ls", I18N::Game::AGI); break;
        case 3: mu_swprintf(strName, L"%ls", I18N::Game::STR); break;
        case 4: mu_swprintf(strName, L"%ls", I18N::Game::Command); break;
        }

        GenericDialogConfig cfg;
        cfg.showCancel = true;
        cfg.item3D = *pItem;
        cfg.lines = {
            { strName, true },
            { I18N::Game::DoYouWantToUseTheFruit, true },
        };
        cfg.onPrimary = [item3D = *cfg.item3D, itemName = std::wstring(strName)]
        {
            // Chained follow-up confirm -- Create/Decrease/Cancel, matching native
            // CUseFruitCheckMsgBox exactly. item3D/itemName are the same values already computed
            // above (not re-read from pItem, which may not outlive this callback). byIndex is
            // looked up fresh in each callback (not captured here), same as native's own
            // AddBtnDown/MinusBtnDown -- the standby item key was already latched via
            // SetStandbyItemKey() above.
            wchar_t strText[128] = { 0, };
            mu_swprintf(strText, I18N::Game::FruitCaption, itemName.c_str());

            GenericDialogConfig fruitCfg;
            fruitCfg.item3D = item3D;
            fruitCfg.lines = {
                { strText, true },
                { I18N::Game::Choose, true },
            };
            fruitCfg.primaryLabel = I18N::Game::Create;
            fruitCfg.onPrimary = []
            {
                BYTE byIndex = g_pMyInventory->GetStandbyItemIndex();
                SendRequestUse(byIndex, 0, true);
            };
            fruitCfg.secondaryLabel = I18N::Game::Decrease;
            fruitCfg.onSecondary = []
            {
                BYTE byIndex = g_pMyInventory->GetStandbyItemIndex();
                SendRequestUse(byIndex, 0, false);
            };
            fruitCfg.showCancel = true;
            g_pGenericConfirmDialog->Show(std::move(fruitCfg));
        };
        g_pGenericConfirmDialog->Show(std::move(cfg));
        return true;
    }

    if (pItem->Type == ITEM_LIFE_STONE_ITEM)
    {
        bool bUse = false;
        switch (pItem->Level)
        {
        case 0:
            bUse = true;
            break;
        case 1:
            if (Hero->GuildStatus != G_MASTER)
                bUse = true;
            break;
        }

        if (bUse)
        {
            SendRequestUse(iIndex, 0);
            return true;
        }

        return false;
    }

    if (pItem->Type == ITEM_TALISMAN_OF_RESURRECTION)
    {
        if (g_PortalMgr.IsRevivePositionSaved())
        {
            if (g_PortalMgr.IsPortalUsable())
            {
                g_pMyInventory->SetStandbyItemKey(pItem->Key);
                mu::ui::window::GenericDialogConfig cfg;
                cfg.showCancel = true;
                cfg.lines.push_back({ I18N::Game::WouldYouLikeToSaveTheLocation, false });
                cfg.onPrimary = []
                {
                    BYTE srcIndex = g_pMyInventory->GetStandbyItemIndex();
                    SendRequestUse(srcIndex, 0);
                };
                mu::ui::window::g_pGenericConfirmDialog->Show(std::move(cfg));
            }
            else
            {
                CreateOkMessageBox(I18N::Game::YouCannotUseTheItemAtCertainApplicableLocations);
            }
        }

        return false;
    }

    if (pItem->Type == ITEM_TALISMAN_OF_MOBILITY)
    {
        if (g_PortalMgr.IsPortalUsable())
        {
            if (pItem->Durability == 2)
            {
                if (g_PortalMgr.IsPortalPositionSaved())
                {
                    CreateOkMessageBox(I18N::Game::ThisItemCannotBeUsedAlongWithAnItemThatSAlreadyInUse);
                }
                else
                {
                    g_pMyInventory->SetStandbyItemKey(pItem->Key);
                    mu::ui::window::GenericDialogConfig cfg;
                    cfg.showCancel = true;
                    cfg.lines.push_back({ I18N::Game::WouldYouLikeToSaveTheLocation, false });
                    cfg.onPrimary = []
                    {
                        g_PortalMgr.SavePortalPosition();
                        BYTE srcIndex = g_pMyInventory->GetStandbyItemIndex();
                        SendRequestUse(srcIndex, 0);
                    };
                    mu::ui::window::g_pGenericConfirmDialog->Show(std::move(cfg));
                }
            }
            else if (pItem->Durability == 1)
            {
                g_pMyInventory->SetStandbyItemKey(pItem->Key);
                mu::ui::window::GenericDialogConfig cfg;
                cfg.showCancel = true;
                cfg.lines.push_back({ I18N::Game::WouldYouLikeToSaveTheLocation, false });
                cfg.onPrimary = []
                {
                    BYTE srcIndex = g_pMyInventory->GetStandbyItemIndex();
                    SendRequestUse(srcIndex, 0);
                };
                mu::ui::window::g_pGenericConfirmDialog->Show(std::move(cfg));
            }
        }
        else
        {
            CreateOkMessageBox(I18N::Game::YouCannotUseTheItemAtCertainApplicableLocations);
        }

        return false;
    }

    if (pItem->Type == ITEM_INVITATION_TO_SANTA_VILLAGE)
    {
        g_pMyInventory->SetStandbyItemKey(pItem->Key);
        mu::ui::window::GenericDialogConfig cfg;
        cfg.showCancel = true;
        cfg.lines.push_back({ I18N::Game::WouldYouLikeToMoveToTheSantaSVillage, false });
        cfg.onPrimary = []
        {
            if (ITEM* pStandbyItem = g_pMyInventory->GetStandbyItem())
            {
                int iSrcIndex = g_pMyInventory->GetStandbyItemIndex();
                SendRequestUse(iSrcIndex, 0);
            }
        };
        mu::ui::window::g_pGenericConfirmDialog->Show(std::move(cfg));
    }

    return false;
}

bool CInventoryActionController::TryTransferBetweenInventorySections(CInventoryCtrl* sourceControl) const
{
    if (sourceControl == nullptr || g_pMyInventoryExt == nullptr)
    {
        return false;
    }

    ITEM* pItem = sourceControl->FindItemAtPointer();
    if (pItem == nullptr)
    {
        return false;
    }

    const int sourceIndex = sourceControl->GetIndexByItem(pItem);
    if (sourceIndex < 0)
    {
        return false;
    }

    const ITEM_ATTRIBUTE* itemAttribute = &ItemAttribute[pItem->Type];
    int destinationIndex = -1;

    if (sourceControl == g_pMyInventory->GetInventoryCtrl())
    {
        destinationIndex = g_pMyInventoryExt->FindEmptySlot(itemAttribute->Width, itemAttribute->Height);
    }
    else
    {
        destinationIndex = m_pContext->FindEmptySlot(pItem);
    }

    if (destinationIndex == -1 || destinationIndex == sourceIndex)
    {
        return true;
    }

    if (!CInventoryCtrl::CreatePickedItem(sourceControl, pItem))
    {
        return false;
    }

    sourceControl->RemoveItem(pItem);

    CPickedItem* pPickedItem = CInventoryCtrl::GetPickedItem();
    if (pPickedItem == nullptr || pPickedItem->GetItem() == nullptr)
    {
        CInventoryCtrl::BackupPickedItem();
        return false;
    }

    pPickedItem->HidePickedItem();

    if (!SendRequestEquipmentItem(STORAGE_TYPE::INVENTORY, sourceIndex, pPickedItem->GetItem(), STORAGE_TYPE::INVENTORY,
                                  destinationIndex))
    {
        CInventoryCtrl::BackupPickedItem();
        return false;
    }

    return true;
}

} // namespace mu::ui::window
