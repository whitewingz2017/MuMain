
#if !defined(AFX_NEWUICHAOSCASTLETIME_H__96004B21_205A_40BE_9B6B_3C099D8E41F6__INCLUDED_)
#define AFX_NEWUICHAOSCASTLETIME_H__96004B21_205A_40BE_9B6B_3C099D8E41F6__INCLUDED_

#pragma once

#include "UI/Core/WindowObject.h"
#include "UI/Events/EventTimerView.h"
#include "UI/Events/BloodCastleTime.h"
#include <chrono>

namespace mu::ui::window
{
// The Chaos Castle time HUD. chaos_castle_time.rml draws it (EventTimerView); C++ keeps the time, the kill
// count and when it is shown.
class CChaosCastleTime : public CObject
{
public:
    enum IMAGE_LIST
    {
        IMAGE_CHAOSCASTLE_TIME_WINDOW = CBloodCastle::IMAGE_BLOODCASTLE_TIME_WINDOW // newui_Figure_blood.tga (124, 81)
    };

private:
    enum BLOODCASTLE_TIME_WINDOW_SIZE
    {
        CHAOSCASTLE_TIME_WINDOW_WIDTH = 124,
        CHAOSCASTLE_TIME_WINDOW_HEIGHT = 81,
    };

    enum
    {
        CC_TIME_STATE_NORMAL = 1,
        CC_TIME_STATE_IMMINENCE,
    };

    enum
    {
        MAX_KILL_MONSTER = 65535,
    };

private:
    CManager* m_pNewUIMng;


    wchar_t m_szTime[256]; // 시간
    int m_iTime;           // 시간
    std::chrono::steady_clock::time_point m_TimeSampled = std::chrono::steady_clock::now();
    int m_iTimeState;      // 시간상태( 기본, 임박 )
    int m_iMaxKillMonster; // 죽여야하는 몬스터숫자
    int m_iKilledMonster;  // 현재 죽인 몬스터숫자
    EventTimerView m_View{"chaos_castle_time", "Data/Interface/RmlUi/chaos_castle_time.rml"};

public:
    CChaosCastleTime();
    virtual ~CChaosCastleTime();

    bool Create(CManager* pNewUIMng);
    void Release();


    bool UpdateMouseEvent();
    Rml::ElementDocument* GetPlacedDocument() const override { return m_View.Document(); }
    bool UpdateKeyEvent();
    bool Update();
    bool Render();

    bool BtnProcess();

    float GetLayerDepth(); //. 1.3f

    void OpenningProcess();
    void ClosingProcess();


private:
    void SyncView();

public:
    void SetTime(int m_iTime);
    void SetKillMonsterStatue(int iKilled, int iMaxKill);
};
};

#endif // !defined(AFX_NEWUICHAOSCASTLETIME_H__96004B21_205A_40BE_9B6B_3C099D8E41F6__INCLUDED_)
