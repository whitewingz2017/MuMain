#include "stdafx.h"
#include "UI/Chat/SystemMessageAnimation.h"
#include "UI/Chat/MessagePresentation.h"
#include "I18N/All.h"

#include "UI/HUD/ChatLogWindow.h"
#include "Data/GameConfig/GameConfig.h"
#include "UI/Core/WindowManager.h"
#include "UI/Core/WindowSystem.h"
#include "UI/Core/WindowGeometry.h"
#include "Audio/DSPlaySound.h"
#include "UI/Social/SocialWindowBase.h"
#include "Engine/Object/ZzzInterface.h"

// RmlUi migration -- see ChatLogRmlModel (ChatLogWindow.h).
#include "Render/RmlUi/RmlUiRuntime.h"
#include "UI/RmlBridge/RmlSyncField.h"
#include "UI/RmlBridge/RmlTheme.h"
#include "UI/RmlBridge/RmlDocumentVisibility.h"
#include "UI/RmlBridge/RmlWorkspaceParticipant.h"
#include "UI/RmlBridge/RmlElementStack.h"
#include "UI/Placement/WindowPlacement.h"
#include "UI/Scaling/UITransform.h"
#include "Core/Utilities/StringUtils.h"
#include "Render/Text/CUIRenderText.h"
#include <RmlUi/Core/ElementDocument.h>
#include <RmlUi/Core/Element.h>
#include <RmlUi/Core/ElementUtilities.h>

using namespace SEASON3B;
using namespace mu::ui::window;



mu::ui::window::CChatLogWindow::CChatLogWindow()
{
    Init();
}

mu::ui::window::CChatLogWindow::~CChatLogWindow()
{
    Release();
}

void mu::ui::window::CChatLogWindow::Init()
{
    m_pNewUIMng = nullptr;
    m_WndSize.cx = WND_WIDTH; m_WndSize.cy = 0;
    m_nShowingLines = 6;
    m_iCurrentRenderEndLine = -1;
    m_fBackAlpha = 0.6f;


    m_bShowFrame = false;

    m_CurrentRenderMsgType = TYPE_ALL_MESSAGE;
    m_bShowChatLog = true;

}

bool mu::ui::window::CChatLogWindow::Create(CManager* pNewUIMng, int nShowingLines /* = 6 */)
{
    Release();

    if (nullptr == pNewUIMng)
        return false;

    m_pNewUIMng = pNewUIMng;
    m_pNewUIMng->AddUIObj(mu::ui::window::INTERFACE_CHATLOGWINDOW, this);
    SetNumberOfShowingLines(nShowingLines);

    // Measure the styled box so compact typography keeps its bottom-left workspace anchor.
    UI::RmlBridge::RegisterWorkspaceDocument("chat_log", [this] { return m_RmlView.Document(); }, "panel");
    // No LoadImages() any more: every sprite this window used is referenced by chat_log.rcss and
    // loaded through RmlUi's own exclusive-slot path instead. CGuildInfoWindow/CGuardWindow alias
    // this class's IMAGE_LIST values but load their own copies, so nothing depended on it -- the
    // enum itself stays in the header for those aliases.
    return true;
}

void mu::ui::window::CChatLogWindow::Release()
{
    UI::Placement::UnregisterParticipant("chat_log");
    m_RmlView.Release();
    ResetFilter();
    ClearAll();

    if (m_pNewUIMng)
    {
        m_pNewUIMng->RemoveUIObj(this);
        m_pNewUIMng = nullptr;
    }

    Init();
}

void mu::ui::window::CChatLogWindow::AddText(const type_string& strID, const type_string& strText, MESSAGE_TYPE MsgType, MESSAGE_TYPE ErrMsgType /*= TYPE_ALL_MESSAGE*/)
{
    if (strID.empty() && strText.empty())
    {
        return;
    }

    if (GetNumberOfLines(MsgType) >= MAX_NUMBER_OF_LINES)
    {
        RemoveFrontLine(MsgType);
    }

    if (GetNumberOfLines(TYPE_ALL_MESSAGE) >= MAX_NUMBER_OF_LINES)
    {
        RemoveFrontLine(TYPE_ALL_MESSAGE);
    }

    if (m_vecFilters.empty())
    {
        ProcessAddText(strID, strText, MsgType, ErrMsgType);
    }
    else
    {
        if (MsgType != TYPE_CHAT_MESSAGE)
        {
            ProcessAddText(strID, strText, MsgType, ErrMsgType);
        }
        else if (CheckFilterText(strID) || CheckFilterText(strText))
        {
            ProcessAddText(strID, strText, MsgType, ErrMsgType);

            if (g_pOption->IsWhisperSound())
            {
                PlayBuffer(SOUND_WHISPER);
            }
        }
    }
}


void mu::ui::window::CChatLogWindow::ProcessAddText(const type_string& strID, const type_string& strText, MESSAGE_TYPE MsgType, MESSAGE_TYPE ErrMsgType)
{
    m_bLinesDirty = true;
    type_vector_msgs* pvecMsgs = GetMsgs(MsgType);
    if (pvecMsgs == nullptr)
    {
        assert(!"Empty Message");
        return;
    }

    // Keep the world-channel color on continuation rows after native text splitting.
    const bool globalPost = !UI::Chat::PresentMessage(strID, strText, MsgType).prefix.empty();
    int nScrollLines = 0;
    if (strText.size() >= 20)
    {
        type_string	strText1, strText2;
        SeparateText(strID, strText, MsgType, strText1, strText2);
        if (!strText1.empty())
        {
            const auto pMsgText = new CMessageText;
            if (!pMsgText->Create(strID, strText, MsgType, globalPost))
                delete pMsgText;
            else
            {
                pvecMsgs->push_back(pMsgText);
            }

            const auto pAllMsgText = new CMessageText;
            if (!pAllMsgText->Create(strID, strText1, MsgType, globalPost))
            {
                delete pAllMsgText;
            }
            else
            {
                m_vecAllMsgs.push_back(pAllMsgText);
            }

            if ((MsgType == TYPE_ERROR_MESSAGE) && (ErrMsgType != TYPE_ERROR_MESSAGE && ErrMsgType != TYPE_ALL_MESSAGE))
            {
                type_vector_msgs* pErrvecMsgs = GetMsgs(ErrMsgType);
                if (pErrvecMsgs == nullptr)
                {
                    assert(!"Error Chat");
                    return;
                }

                const auto pErrMsgText = new CMessageText;
                if (!pErrMsgText->Create(strID, strText1, MsgType, globalPost))
                    delete pErrMsgText;
                else
                {
                    pErrvecMsgs->push_back(pErrMsgText);
                }
            }

            if (GetCurrentMsgType() == TYPE_ALL_MESSAGE || GetCurrentMsgType() == MsgType)
            {
                nScrollLines++;
            }
        }
        if (!strText2.empty())
        {
            const auto pMsgText = new CMessageText;
            if (!pMsgText->Create(L"", strText2, MsgType, globalPost))
                delete pMsgText;
            else
            {
                pvecMsgs->push_back(pMsgText);
            }

            const auto pAllMsgText = new CMessageText;
            if (!pAllMsgText->Create(L"", strText2, MsgType, globalPost))
                delete pAllMsgText;
            else
            {
                m_vecAllMsgs.push_back(pAllMsgText);
            }

            if ((MsgType == TYPE_ERROR_MESSAGE) && (ErrMsgType != TYPE_ERROR_MESSAGE && ErrMsgType != TYPE_ALL_MESSAGE))
            {
                type_vector_msgs* pErrvecMsgs = GetMsgs(ErrMsgType);
                if (pErrvecMsgs == nullptr)
                {
                    assert(!"Error chat 2");
                    return;
                }

                const auto pErrMsgText = new CMessageText;
                if (!pErrMsgText->Create(L"", strText2, MsgType, globalPost))
                    delete pErrMsgText;
                else
                {
                    pErrvecMsgs->push_back(pErrMsgText);
                }
            }

            if (GetCurrentMsgType() == TYPE_ALL_MESSAGE || GetCurrentMsgType() == MsgType)
            {
                nScrollLines++;
            }
        }
    }
    else
    {
        const auto pMsgText = new CMessageText;
        if (!pMsgText->Create(strID, strText, MsgType, globalPost))
            delete pMsgText;
        else
        {
            pvecMsgs->push_back(pMsgText);
        }

        const auto pAllMsgText = new CMessageText;
        if (!pAllMsgText->Create(strID, strText, MsgType, globalPost))
            delete pAllMsgText;
        else
        {
            m_vecAllMsgs.push_back(pAllMsgText);
        }

        if ((MsgType == TYPE_ERROR_MESSAGE)
            && (ErrMsgType != TYPE_ERROR_MESSAGE && ErrMsgType != TYPE_ALL_MESSAGE))
        {
            type_vector_msgs* pErrvecMsgs = GetMsgs(ErrMsgType);
            if (pErrvecMsgs == nullptr)
            {
                assert(!"Error chat 3");
                return;
            }

            const auto pErrMsgText = new CMessageText;
            if (!pErrMsgText->Create(strID, strText, MsgType, globalPost))
                delete pErrMsgText;
            else
            {
                pErrvecMsgs->push_back(pErrMsgText);
            }
        }

        if (GetCurrentMsgType() == TYPE_ALL_MESSAGE || GetCurrentMsgType() == MsgType)
        {
            nScrollLines++;
        }
    }

    pvecMsgs = GetMsgs(GetCurrentMsgType());
    if (pvecMsgs == nullptr)
    {
        assert(!"Error chat 4");
        return;
    }

    //. Auto Scrolling
    if (nScrollLines > 0 && ((pvecMsgs->size() - (m_iCurrentRenderEndLine + 1) - nScrollLines) < 3))
        m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
    else if (!m_bShowFrame)
        m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
}

void mu::ui::window::CChatLogWindow::RemoveFrontLine(MESSAGE_TYPE MsgType)
{
    m_bLinesDirty = true;
    type_vector_msgs* pvecMsgs = GetMsgs(MsgType);

    if (pvecMsgs == nullptr)
    {
        assert(!"Empty Message RemoveFrontLine");
        return;
    }

    auto vi = pvecMsgs->begin();
    if (vi != pvecMsgs->end())
    {
        delete (*vi);
        vi = pvecMsgs->erase(vi);
    }

    if (MsgType == GetCurrentMsgType())
    {
        Scrolling(GetCurrentRenderEndLine());
    }
}

void mu::ui::window::CChatLogWindow::Clear(MESSAGE_TYPE MsgType)
{
    m_bLinesDirty = true;
    type_vector_msgs* pvecMsgs = GetMsgs(MsgType);
    if (pvecMsgs == nullptr)
    {
        assert(!"Empty Message CChatLogWindow");
        return;
    }

    auto vi_msg = pvecMsgs->begin();
    for (; vi_msg != pvecMsgs->end(); vi_msg++)
        delete (*vi_msg);
    pvecMsgs->clear();

    if (MsgType == GetCurrentMsgType())
    {
        m_iCurrentRenderEndLine = -1;
    }
}

size_t mu::ui::window::CChatLogWindow::GetNumberOfLines(MESSAGE_TYPE MsgType)
{
    type_vector_msgs* pvecMsgs = GetMsgs(MsgType);
    if (pvecMsgs == nullptr)
    {
        return 0;
    }

    return pvecMsgs->size();
}

int mu::ui::window::CChatLogWindow::GetCurrentRenderEndLine() const
{
    return m_iCurrentRenderEndLine;
}

void mu::ui::window::CChatLogWindow::Scrolling(int nRenderEndLine)
{
    type_vector_msgs* pvecMsgs = GetMsgs(m_CurrentRenderMsgType);
    if (pvecMsgs == nullptr)
    {
        assert(!"Empty message Scrolling");
        return;
    }

    if ((int)pvecMsgs->size() <= m_nShowingLines)
    {
        m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
    }
    else
    {
        if (nRenderEndLine < m_nShowingLines)
            m_iCurrentRenderEndLine = m_nShowingLines - 1;

        else if (nRenderEndLine >= (int)pvecMsgs->size())
            m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
        else
            m_iCurrentRenderEndLine = nRenderEndLine;
    }

    // Nothing renders from m_iCurrentRenderEndLine any more, so a caller that moves it (the chat
    // input box's PageUp/PageDown) has to have it pushed into RmlUi's own scroll offset.
    m_bScrollRequest = true;
}

void mu::ui::window::CChatLogWindow::SetFilterText(const type_string& strFilterText)
{
    m_bLinesDirty = true;
    bool bPrevFilter = false;

    if (!m_vecFilters.empty())
    {
        bPrevFilter = true;
        ResetFilter();
    }

    wchar_t szTemp[MAX_CHAT_BUFFER_SIZE + 1] = { 0, };
    strFilterText.copy(szTemp, MAX_CHAT_BUFFER_SIZE);
    szTemp[MAX_CHAT_BUFFER_SIZE] = '\0';

    wchar_t* context = nullptr;
	wchar_t* token = wcstok_s(szTemp, L" ", &context);
	token = wcstok_s(nullptr, L" ", &context);

    if (token == nullptr)
    {
        ResetFilter();
        AddText(L"", I18N::Game::FilteringHasBeenCanceled, TYPE_SYSTEM_MESSAGE);
    }
    else
    {
        for (int i = 0; i < 5; i++)
        {
            if (nullptr == token)
            {
                break;
            }
            AddFilterWord(token);
            token = wcstok_s(nullptr, L" ", &context);
        }

        AddText(L"", I18N::Game::FilteringHasBeenActivated, TYPE_SYSTEM_MESSAGE);
    }
}

void mu::ui::window::CChatLogWindow::ResetFilter()
{
    m_bLinesDirty = true;
    m_vecFilters.clear();
}

void mu::ui::window::CChatLogWindow::SetSizeAuto()
{
    SetNumberOfShowingLines(GetNumberOfShowingLines() + 3);
}

void mu::ui::window::CChatLogWindow::SetNumberOfShowingLines(int nShowingLines, OUT LPSIZE lpBoxSize/* = nullptr*/)
{
    m_nShowingLines = (int)(nShowingLines / 3) * 3;
    if (m_nShowingLines < 3)
        m_nShowingLines = 3;
    if (m_nShowingLines > 15)
        m_nShowingLines = 3;

    if (m_nShowingLines > GetCurrentRenderEndLine())
        Scrolling(m_nShowingLines - 1);

    UpdateWndSize();
    UpdateScrollPos();
    // Re-placed now, so a slot standing on the input grows upward in the same frame.
    UI::Placement::Arrange();

    if (lpBoxSize)
    {
        lpBoxSize->cx = WND_WIDTH;
        lpBoxSize->cy = (SCROLL_MIDDLE_PART_HEIGHT * GetNumberOfShowingLines()) + (SCROLL_TOP_BOTTOM_PART_HEIGHT * 2) + (WND_TOP_BOTTOM_EDGE * 2);
    }
}
size_t mu::ui::window::CChatLogWindow::GetNumberOfShowingLines() const
{
    return m_nShowingLines;
}

void mu::ui::window::CChatLogWindow::SetBackAlphaAuto()
{
    m_fBackAlpha += 0.2f;

    if (m_fBackAlpha > 0.9f)
    {
        m_fBackAlpha = 0.2f;
    }
}

void mu::ui::window::CChatLogWindow::SetBackAlpha(float fAlpha)
{
    if (fAlpha < 0.f)
        m_fBackAlpha = 0.f;
    else if (fAlpha > 1.f)
        m_fBackAlpha = 1.f;
    else
        m_fBackAlpha = fAlpha;
}

float mu::ui::window::CChatLogWindow::GetBackAlpha() const
{
    return m_fBackAlpha;
}

void mu::ui::window::CChatLogWindow::ShowFrame()
{
    m_bShowFrame = true;
}

void mu::ui::window::CChatLogWindow::HideFrame()
{
    m_bShowFrame = false;
}

bool mu::ui::window::CChatLogWindow::IsShowFrame()
{
    return m_bShowFrame;
}

bool mu::ui::window::CChatLogWindow::UpdateMouseEvent()
{
    // Everything this used to do belongs to RmlUi now: the wheel, the scrollbar and the per-line
    // hit tests are #lines' (base.rcss's .scroll-pane), and the resize is a drag on #resize_handle
    // (ResizeToPointer()).
    return true;
}

void mu::ui::window::CChatLogWindow::ResizeToPointer(float pointerYPx)
{
    auto* document = m_RmlView.Document();
    auto* well = document ? document->GetElementById("lines") : nullptr;
    if (!m_bShowFrame || !well || m_nShowingLines <= 0)
        return;

    Rml::Rectanglef bounds;
    if (!Rml::ElementUtilities::GetBoundingBox(bounds, well, Rml::BoxArea::Content))
        return;
    const float contentHeight = well->GetBox().GetSize(Rml::BoxArea::Content).y;
    if (contentHeight <= 0.f)
        return;
    const float rowHeight = well->GetLineHeight() * bounds.Size().y / contentHeight;
    if (rowHeight <= 0.f)
        return;
    constexpr int MinLines = 3, MaxLines = 15;
    int lines = static_cast<int>((bounds.BottomRight().y - pointerYPx) / rowHeight + 0.5f);
    constexpr int DesktopStep = 3;
    lines = ((lines + DesktopStep / 2) / DesktopStep) * DesktopStep;
    SetNumberOfShowingLines(std::clamp(lines, MinLines, MaxLines));
}

bool mu::ui::window::CChatLogWindow::UpdateKeyEvent()
{
    return true;
}

namespace
{
    void BindChatLine(Rml::DataModelConstructor& constructor)
    {
        auto line = constructor.RegisterStruct<ChatLogLineEntry>();
        line.RegisterMember("text", &ChatLogLineEntry::text);
        line.RegisterMember("sender", &ChatLogLineEntry::sender);
        line.RegisterMember("prefix", &ChatLogLineEntry::prefix);
        line.RegisterMember("kind", &ChatLogLineEntry::kind);
        line.RegisterMember("has_id", &ChatLogLineEntry::hasId);
        line.RegisterMember("opacity", &ChatLogLineEntry::opacity);
        line.RegisterMember("entry_progress", &ChatLogLineEntry::entryProgress);
        line.RegisterMember("exit_progress", &ChatLogLineEntry::exitProgress);
        constructor.RegisterArray<Rml::Vector<ChatLogLineEntry>>();
    }

    ChatLogLineEntry BuildChatLine(const CMessageText& message)
    {
        const auto presentation = UI::Chat::PresentMessage(message.GetID(), message.GetText(), message.GetType());
        ChatLogLineEntry entry;
        entry.kind = presentation.kind ? presentation.kind : "system";
        if (message.IsGlobalPost())
            entry.kind = "world";
        entry.sender = StringUtils::WideToNarrow(std::wstring(presentation.sender).c_str());
        entry.prefix = StringUtils::WideToNarrow(std::wstring(presentation.prefix).c_str());
        entry.text = StringUtils::WideToNarrow(std::wstring(presentation.text).c_str());
        entry.hasId = !message.GetID().empty();
        return entry;
    }

    bool SyncLineAnimation(ChatLogLineEntry& line, const CMessageText& message, std::uint64_t now, bool expires)
    {
        const auto created = message.GetCreatedMs();
        const auto age = now >= created ? now - created : 0;
        const auto state = expires ? UI::Chat::AnimateSystemMessage(age) : UI::Chat::AnimateChatMessage(age);
        if (line.opacity == state.opacity && line.entryProgress == state.entryProgress && line.exitProgress == state.exitProgress)
            return false;
        line.opacity = state.opacity;
        line.entryProgress = state.entryProgress;
        line.exitProgress = state.exitProgress;
        return true;
    }
}

bool mu::ui::window::CChatLogWindow::Update()
{
    BuildRmlUi();
    SyncRmlModel();

    return true;
}

bool mu::ui::window::CChatLogWindow::Render()
{
    // Nothing native left to draw -- RmlUi owns the fill, every message line and the scrollbar.
    // Kept because CObject requires the override.
    return true;
}

void mu::ui::window::CChatLogWindow::BindRmlModel(Rml::DataModelConstructor& c, ChatLogRmlModel& model)
{
    // Must re-run in full on every call, including on a theme switch -- same reason
    // CCharMakeWin::BindRmlModel() documents, so no guard here.
    BindChatLine(c);

    c.Bind("lines", &model.lines);
    c.Bind("text_scale", &model.textScale);
    c.Bind("visible_lines", &model.visibleLines);
    c.Bind("back_alpha", &model.backAlpha);
    c.Bind("show_frame", &model.showFrame);
    c.Bind("pointed_index", &model.pointedIndex);

    // RmlUi drag events supply the pointer directly; legacy button flags do not see panel presses.
    c.BindEventCallback("chat_resize_drag",
        [this](Rml::DataModelHandle, Rml::Event& event, const Rml::VariantList&)
        { ResizeToPointer(event.GetParameter<float>("mouse_y", 0.f)); });
}

void mu::ui::window::CChatLogWindow::OnRmlReloaded()
{
    // The next SyncRmlModel() fills the rebuilt document.
    m_bLinesDirty = true;
    UI::Placement::Invalidate();
}

void mu::ui::window::CChatLogWindow::BuildRmlUi()
{
    m_RmlView.Ensure();
}

void mu::ui::window::CChatLogWindow::SyncDocVisibility(bool sceneAllowsShow)
{
    m_bSceneAllowsShow = sceneAllowsShow;
    UI::RmlBridge::SyncDocumentVisibility(m_RmlView.Document(), IsVisible() && m_bShowChatLog && sceneAllowsShow);
}

void mu::ui::window::CChatLogWindow::SyncRmlModel()
{
    if (!m_RmlView.Document()) return;

    UI::RmlBridge::SyncDocumentVisibility(m_RmlView.Document(), IsVisible() && m_bShowChatLog && m_bSceneAllowsShow);

    ChatLogRmlModel& model = m_RmlView.GetModel();

    SyncField(m_RmlView.Binder(), &ChatLogRmlModel::textScale, "text_scale", GameConfig::GetInstance().GetChatTextScalePercent() / 100.f);
    SyncField(m_RmlView.Binder(), &ChatLogRmlModel::visibleLines, "visible_lines", m_nShowingLines);
    if (model.showFrame != m_bShowFrame)
    {
        model.showFrame = m_bShowFrame;
        m_RmlView.MarkDirty("show_frame");
    }

    // The user's cycled transparency setting, nothing else: whether the backdrop paints at all is
    // show_frame's job (.framed in the RCSS) and its colour is the theme's.
    const float backAlpha = std::clamp(GetBackAlpha(), 0.0f, 1.0f);
    if (model.backAlpha != backAlpha)
    {
        model.backAlpha = backAlpha;
        m_RmlView.MarkDirty("back_alpha");
    }


    if (m_bLinesDirty)
    {
        // Native's own rule, restated against scroll position: follow the tail while the frame is
        // hidden, or while the user is already at the bottom. ProcessAddText() expressed it as
        // "within 3 lines of the end" because it drove a line index; the DOM equivalent is
        // "scrolled to the bottom", and it has to be sampled HERE, against the pre-append layout,
        // not after the new lines exist.
        m_bFollowTail = !m_bShowFrame || IsScrolledToBottom();

        m_bLinesDirty = false;
        RebuildLineModel();
        m_RmlView.MarkDirty("lines");

        // Arms a one-shot pin, consumed after RmlUi layout. It must be a latch, not a per-frame call:
        // the new lines only have a resolved scroll height after RmlUi lays them out, so the pin
        // must happen after that update -- pinning every frame re-clamps the view
        // to the bottom continuously, which silently defeats the user's own scrollbar drag and
        // mouse wheel.
        m_bScrollPending = true;
    }

    UpdateLineAnimation();
    UpdatePointedLine();
}

void mu::ui::window::CChatLogWindow::AnchorAboveInput(Rml::Context* context)
{
    auto* panel = m_RmlView.Document()->GetElementById("panel");
    if (!panel)
        return;
    for (int index = 0; index < context->GetNumDocuments(); ++index)
    {
        auto* input = context->GetDocument(index);
        if (!input->IsVisible() || !input->GetSourceURL().ends_with("/chat_input.rml"))
            continue;
        if (auto* inputPanel = input->GetElementById("panel"))
            UI::RmlBridge::StackAbove(*panel, *inputPanel);
        return;
    }
}

void mu::ui::window::CChatLogWindow::AfterRmlLayout(Rml::Context* context)
{
    auto* document = m_RmlView.Document();
    if (!document || document->GetContext() != context || !document->IsVisible())
        return;


    auto* panel = document->GetElementById("panel");
    if (!panel)
        return;
    const float panelHeight = panel->GetBox().GetSize().y;
    if (panelHeight != m_LastPanelHeight)
    {
        m_LastPanelHeight = panelHeight;
        UI::Placement::Invalidate();
    }

    if (m_bScrollPending)
    {
        m_bScrollPending = false;
        ScrollToBottomIfFollowing();
    }

    // A pending request wins for one frame; otherwise the logical cursor follows the view, so the
    // next PageUp/PageDown starts from wherever the user actually scrolled to.
    if (m_bScrollRequest)
    {
        m_bScrollRequest = false;
        ApplyLogicalScroll();
    }
    SyncLogicalScrollFromView();
}

void mu::ui::window::CChatLogWindow::RebuildLineModel()
{
    ChatLogRmlModel& model = m_RmlView.GetModel();
    model.lines.clear();

    type_vector_msgs* pvecMsgs = GetMsgs(GetCurrentMsgType());
    if (pvecMsgs == nullptr)
        return;

    model.lines.reserve(pvecMsgs->size());
    for (const CMessageText* pMsgText : *pvecMsgs)
    {
        const char* slug = pMsgText ? UI::Chat::MessageKind(pMsgText->GetType()) : nullptr;
        if (slug == nullptr || pMsgText->GetText().empty())
        {
            // Native skipped drawing these (bRenderMessage stayed false), but an entry still has
            // to exist: chat_line_rightclick() looks its sender up by array index, so the model
            // and the message vector must stay index-aligned.
            model.lines.push_back(ChatLogLineEntry{});
            continue;
        }

        auto entry = BuildChatLine(*pMsgText);
        model.lines.push_back(std::move(entry));
    }
}

void mu::ui::window::CChatLogWindow::UpdateLineAnimation()
{
    auto* messages = GetMsgs(GetCurrentMsgType());
    if (!messages)
        return;
    auto& lines = m_RmlView.GetModel().lines;
    const auto now = GetTickCount64();
    bool changed = false;
    for (std::size_t index = 0; index < messages->size() && index < lines.size(); ++index)
    {
        const auto* message = (*messages)[index];
        if (message && SyncLineAnimation(lines[index], *message, now, false))
            changed = true;
    }
    if (changed)
        m_RmlView.MarkDirty("lines");
}

bool mu::ui::window::CChatLogWindow::IsScrolledToBottom() const
{
    if (!m_RmlView.Document())
        return true;

    Rml::Element* lines = m_RmlView.Document()->GetElementById("lines");
    if (lines == nullptr)
        return true;

    // One line of slack, so a partially-scrolled last row still counts as "at the bottom" -- the
    // same forgiveness native's own 3-line window gave.
    const float slack = SCROLL_MIDDLE_PART_HEIGHT;
    return lines->GetScrollTop() + lines->GetClientHeight() >= lines->GetScrollHeight() - slack;
}

void mu::ui::window::CChatLogWindow::UpdatePointedLine()
{
    ChatLogRmlModel& model = m_RmlView.GetModel();
    int pointed = -1;

    Rml::Element* lines = m_RmlView.Document() ? m_RmlView.Document()->GetElementById("lines") : nullptr;
    if (lines != nullptr && IsVisible() && m_bShowChatLog)
    {
        // Raw window pixels, the same space GetAbsoluteOffset() reports in -- deliberately NOT
        // MouseX/MouseY, which CManager has already remapped into this window's layout space.
        // Comparing the two directly is what keeps this immune to the UI scale.
        const float px = g_fWindowMouseX;
        const float py = g_fWindowMouseY;

        // Clip to the scrolling well first, so a line scrolled out of view is never pointed.
        const Rml::Vector2f wellPos = lines->GetAbsoluteOffset();
        const float wellW = lines->GetClientWidth();
        const float wellH = lines->GetClientHeight();
        if (px >= wellPos.x && px < wellPos.x + wellW && py >= wellPos.y && py < wellPos.y + wellH)
        {
            for (int i = 0; i < lines->GetNumChildren(); i++)
            {
                Rml::Element* child = lines->GetChild(i);
                if (child == nullptr)
                    continue;

                // The whole row (native tested SCROLL_MIDDLE_PART_HEIGHT), including the gap under
                // a line whose background is only as tall as its text (legacy chat_log.rml).
                const Rml::Vector2f pos = child->GetAbsoluteOffset();
                const float h =
                    child->GetOffsetHeight() + child->GetBox().GetEdge(Rml::BoxArea::Margin, Rml::BoxEdge::Bottom);
                if (py >= pos.y && py < pos.y + h)
                {
                    // Only a line carrying a sender is a target, matching native -- an
                    // unattributed system line has nothing to whisper to.
                    if (i < (int)model.lines.size() && model.lines[i].hasId)
                        pointed = i;
                    break;
                }
            }
        }
    }

    if (model.pointedIndex != pointed)
    {
        model.pointedIndex = pointed;
        m_RmlView.MarkDirty("pointed_index");
    }

    if (pointed >= 0 && mu::ui::window::IsPress(VK_RBUTTON))
    {
        type_vector_msgs* pvecMsgs = GetMsgs(GetCurrentMsgType());
        if (pvecMsgs != nullptr && pointed < (int)pvecMsgs->size())
        {
            const type_string& strID = (*pvecMsgs)[pointed]->GetID();
            if (!strID.empty() && g_pChatInputBox)
                g_pChatInputBox->SetWhsprID(strID.c_str());
        }
    }
}

void mu::ui::window::CChatLogWindow::ApplyLogicalScroll()
{
    Rml::Element* lines = m_RmlView.Document() ? m_RmlView.Document()->GetElementById("lines") : nullptr;
    if (lines == nullptr)
        return;

    // Native's own fPosRate, unchanged -- the fraction of the way down the list the current end
    // line represents.
    float fPosRate = 1.0f;
    const int total = (int)GetNumberOfLines(GetCurrentMsgType());
    const int showing = (int)GetNumberOfShowingLines();
    if (total > showing)
    {
        if (showing > GetCurrentRenderEndLine())
            fPosRate = 0.0f;
        else
            fPosRate = (float)(GetCurrentRenderEndLine() + 1 - showing) / (float)(total - showing);
    }

    const float range = lines->GetScrollHeight() - lines->GetClientHeight();
    if (range > 0.0f)
        lines->SetScrollTop(std::clamp(fPosRate, 0.0f, 1.0f) * range);
}

void mu::ui::window::CChatLogWindow::SyncLogicalScrollFromView()
{
    Rml::Element* lines = m_RmlView.Document() ? m_RmlView.Document()->GetElementById("lines") : nullptr;
    if (lines == nullptr)
        return;

    const int total = (int)GetNumberOfLines(GetCurrentMsgType());
    const int showing = (int)GetNumberOfShowingLines();
    if (total <= showing)
    {
        m_iCurrentRenderEndLine = total - 1;
        return;
    }

    const float range = lines->GetScrollHeight() - lines->GetClientHeight();
    const float fPosRate = range > 0.0f ? std::clamp(lines->GetScrollTop() / range, 0.0f, 1.0f) : 1.0f;
    m_iCurrentRenderEndLine = showing - 1 + (int)(fPosRate * (float)(total - showing) + 0.5f);
}

void mu::ui::window::CChatLogWindow::ScrollToBottomIfFollowing()
{
    if (!m_bFollowTail || !m_RmlView.Document())
        return;

    if (Rml::Element* lines = m_RmlView.Document()->GetElementById("lines"))
        lines->SetScrollTop(lines->GetScrollHeight());
}

float mu::ui::window::CChatLogWindow::GetLayerDepth()
{
    return 6.1f;
}

float mu::ui::window::CChatLogWindow::GetKeyEventOrder()
{
    return 8.0f;
}

void mu::ui::window::CChatLogWindow::SeparateText(IN const type_string& strID, IN const type_string& strText,
                                                 MESSAGE_TYPE MsgType, OUT type_string& strText1,
                                                 OUT type_string& strText2)
{
    g_pRenderText->SetFont(MsgType == TYPE_GM_MESSAGE ? g_hFontBold : g_hFont);
    int max_first_line_size = CLIENT_WIDTH;
    if (!strID.empty())
    {
        const type_string strIDPart = strID + L" : ";
        max_first_line_size -= g_pRenderText->MeasureText(
            strIDPart.c_str(), static_cast<int>(strIDPart.length())).cx;
    }

    int required_size = g_pRenderText->MeasureText(strText.c_str(), static_cast<int>(strText.length())).cx;

    if (required_size <= max_first_line_size)
    {
        strText1 = strText;
        strText2 = L"";
        return;
    }

    BOOL bSpaceExist = (strText.find_last_of(L" ") != std::wstring::npos) ? TRUE : FALSE;
    int iLocToken = strText.length();

    while ((required_size > max_first_line_size) && (iLocToken > -1))
    {
        iLocToken = (bSpaceExist) ? strText.find_last_of(L" ", iLocToken - 1) : iLocToken - 1;
        if (iLocToken <= 0)
        {
            strText1.clear();
            strText2 = strText;
            return;
        }
        required_size = g_pRenderText->MeasureText(strText.c_str(), iLocToken).cx;
    }

    strText1 = strText.substr(0, iLocToken);
    strText2 = strText.substr(iLocToken, strText.length() - iLocToken);
}

bool mu::ui::window::CChatLogWindow::CheckFilterText(const type_string& strTestText)
{
    auto vi_filters = m_vecFilters.begin();
    for (; vi_filters != m_vecFilters.end(); vi_filters++)
    {
        if (vi_filters->find(strTestText))
        {
            return true;
        }
    }

    return false;
}

void mu::ui::window::CChatLogWindow::UpdateWndSize()
{
    m_WndSize.cx = WND_WIDTH;
    m_WndSize.cy = (SCROLL_MIDDLE_PART_HEIGHT * GetNumberOfShowingLines()) + (SCROLL_TOP_BOTTOM_PART_HEIGHT * 2) + (WND_TOP_BOTTOM_EDGE * 2);
}

void mu::ui::window::CChatLogWindow::UpdateScrollPos()
{
    // Used to place the native scroll thumb. RmlUi owns the scrollbar now, so this just asks for
    // the logical position to be re-applied -- which is what its callers (CChatInputBox, right
    // after resizing the window) actually want.
    m_bScrollRequest = true;
}

void mu::ui::window::CChatLogWindow::AddFilterWord(const type_string& strWord)
{
    if (m_vecFilters.size() > 5)
        return;

    auto vi_filters = m_vecFilters.begin();
    for (; vi_filters != m_vecFilters.end(); vi_filters++)
    {
        if (0 == (*vi_filters).compare(strWord))
        {
            return;
        }
    }

    m_vecFilters.push_back(strWord);
}

void mu::ui::window::CChatLogWindow::ClearAll()
{
    m_bLinesDirty = true;
    for (int i = TYPE_ALL_MESSAGE; i < NUMBER_OF_TYPES; i++)
    {
        Clear((MESSAGE_TYPE)i);
    }

    m_iCurrentRenderEndLine = -1;
}

mu::ui::window::CChatLogWindow::type_vector_msgs* mu::ui::window::CChatLogWindow::GetMsgs(MESSAGE_TYPE MsgType)
{
    switch (MsgType)
    {
    case TYPE_ALL_MESSAGE:
        return &m_vecAllMsgs;
    case TYPE_CHAT_MESSAGE:
        return &m_VecChatMsgs;
    case TYPE_WHISPER_MESSAGE:
        return &m_vecWhisperMsgs;
    case TYPE_SYSTEM_MESSAGE:
        return &m_VecSystemMsgs;
    case TYPE_LOOT_MESSAGE:
        return &m_vecLootMsgs;
    case TYPE_EXPERIENCE_MESSAGE:
        return &m_vecExperienceMsgs;
    case TYPE_ERROR_MESSAGE:
        return &m_vecErrorMsgs;
    case TYPE_PARTY_MESSAGE:
        return &m_vecPartyMsgs;
    case TYPE_GUILD_MESSAGE:
        return &m_vecGuildMsgs;
    case TYPE_UNION_MESSAGE:
        return &m_vecUnionMsgs;
    case TYPE_GENS_MESSAGE:
        return &m_vecGensMsgs;
    case TYPE_GM_MESSAGE:
        return &m_vecGMMsgs;
    }

    return nullptr;
}

void mu::ui::window::CChatLogWindow::ChangeMessage(MESSAGE_TYPE MsgType)
{
    m_bLinesDirty = true;
    m_CurrentRenderMsgType = MsgType;

    type_vector_msgs* pvecMsgs = GetMsgs(GetCurrentMsgType());
    if (pvecMsgs == nullptr)
    {
        return;
    }

    m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
}

mu::ui::window::MESSAGE_TYPE mu::ui::window::CChatLogWindow::GetCurrentMsgType() const
{
    return m_CurrentRenderMsgType;
}

void mu::ui::window::CChatLogWindow::ShowChatLog()
{
    m_bShowChatLog = true;

    type_vector_msgs* pvecMsgs = GetMsgs(GetCurrentMsgType());
    if (pvecMsgs == nullptr)
    {
        return;
    }

    m_iCurrentRenderEndLine = pvecMsgs->size() - 1;
}

void mu::ui::window::CChatLogWindow::HideChatLog()
{
    m_bShowChatLog = false;
}

mu::ui::window::CSystemLogWindow::CSystemLogWindow()
{
    Init();
}

mu::ui::window::CSystemLogWindow::~CSystemLogWindow()
{
    Release();
}

void mu::ui::window::CSystemLogWindow::Init()
{
    m_pNewUIMng = nullptr;
    m_WndSize.cx = WND_WIDTH; m_WndSize.cy = 0;
    m_nShowingLines = 6;
    m_iCurrentRenderEndLine = -1;
    m_fBackAlpha = 0.6f;
    m_bShowMessages = true;
}


bool mu::ui::window::CSystemLogWindow::Create(CManager* pNewUIMng)
{
    Release();

    if (nullptr == pNewUIMng)
        return false;

    m_pNewUIMng = pNewUIMng;
    m_pNewUIMng->AddUIObj(mu::ui::window::INTERFACE_SYSTEMLOGWINDOW, this);
    UI::RmlBridge::WorkspaceDocumentOptions options;
    options.placedWhileHidden = true;
    UI::RmlBridge::RegisterWorkspaceDocument("system_log", [this] { return m_RmlView.Document(); }, "panel", std::move(options));
    return true;
}

void mu::ui::window::CSystemLogWindow::Release()
{
    UI::Placement::UnregisterParticipant("system_log");
    m_RmlView.Release();
    ClearAll();

    if (m_pNewUIMng)
    {
        m_pNewUIMng->RemoveUIObj(this);
        m_pNewUIMng = nullptr;
    }

    Init();
}

void mu::ui::window::CSystemLogWindow::AddText(const type_string& strText, MESSAGE_TYPE MsgType)
{
    m_bLinesDirty = true;
    if (strText.empty())
    {
        return;
    }

    type_vector_msgs* pvecMsgs = &m_vecAllMsgs;
    if (pvecMsgs == nullptr)
    {
        assert(!"Empty Message");
        return;
    }

    auto pMsgText = new CMessageText;
    if (!pMsgText->Create(L"", strText, MsgType))
    {
        delete pMsgText;
        return;
    }

    if (pvecMsgs->size() >= MAX_NUMBER_OF_LINES)
    {
        RemoveFrontLine();
    }

    pvecMsgs->push_back(pMsgText);

    m_iCurrentRenderEndLine = pvecMsgs->size() - 1;

}

void mu::ui::window::CSystemLogWindow::RemoveFrontLine()
{
    m_bLinesDirty = true;
    auto vi = m_vecAllMsgs.begin();
    if (vi != m_vecAllMsgs.end())
    {
        delete (*vi);
        vi = m_vecAllMsgs.erase(vi);
    }
}

int mu::ui::window::CSystemLogWindow::GetCurrentRenderEndLine() const
{
    return m_iCurrentRenderEndLine;
}

bool mu::ui::window::CSystemLogWindow::UpdateMouseEvent()
{
    return true;
}

bool mu::ui::window::CSystemLogWindow::UpdateKeyEvent()
{
    return true;
}

bool mu::ui::window::CSystemLogWindow::Update()
{
    BuildRmlUi();
    SyncRmlModel();

    return true;
}

bool mu::ui::window::CSystemLogWindow::Render()
{
    // RmlUi's own document draws every line now; kept because CObject requires the override.
    return true;
}

void mu::ui::window::CSystemLogWindow::BindRmlModel(Rml::DataModelConstructor& c, SystemLogRmlModel& model)
{
    // Re-registered in full on every call, including on a theme switch -- same reason
    // CCharMakeWin::BindRmlModel() documents. Registering ChatLogLineEntry here as well as
    // in the chat log's own model is fine: each RmlModelBinder owns its own
    // DataTypeRegister.
    BindChatLine(c);

    model.lines.resize(MAX_NUMBER_OF_LINES);
    c.Bind("lines", &model.lines);
    c.Bind("back_alpha", &model.backAlpha);
}

void mu::ui::window::CSystemLogWindow::OnRmlBuilt()
{
    UI::Placement::Invalidate();
}

void mu::ui::window::CSystemLogWindow::OnRmlReloaded()
{
    m_bLinesDirty = true;
}

void mu::ui::window::CSystemLogWindow::BuildRmlUi()
{
    m_RmlView.Ensure();
}

void mu::ui::window::CSystemLogWindow::SyncDocVisibility(bool sceneAllowsShow)
{
    m_bSceneAllowsShow = sceneAllowsShow;
    UI::RmlBridge::SyncDocumentVisibility(m_RmlView.Document(), IsVisible() && m_bShowMessages && sceneAllowsShow);
}

void mu::ui::window::CSystemLogWindow::UpdateLineAnimation()
{
    auto& lines = m_RmlView.GetModel().lines;
    const auto now = GetTickCount64();
    bool changed = false;
    for (size_t i = 0; i < m_vecAllMsgs.size() && i < lines.size(); ++i)
    {
        if (m_vecAllMsgs[i] && SyncLineAnimation(lines[i], *m_vecAllMsgs[i], now, true))
            changed = true;
    }
    if (changed) m_RmlView.MarkDirty("lines");
}

void mu::ui::window::CSystemLogWindow::SyncRmlModel()
{
    if (!m_RmlView.Document()) return;
    TrackPanelSize();

    // m_bShowMessages is the input box's own "system messages" toggle; IsVisible() is the window's.
    UI::RmlBridge::SyncDocumentVisibility(m_RmlView.Document(), IsVisible() && m_bShowMessages && m_bSceneAllowsShow);

    SystemLogRmlModel& model = m_RmlView.GetModel();

    SyncField(m_RmlView.Binder(), &SystemLogRmlModel::backAlpha, "back_alpha",
              std::clamp(m_fBackAlpha, 0.0f, 1.0f));


    if (m_bLinesDirty)
    {
        m_bLinesDirty = false;
        RebuildLineModel();
        m_RmlView.MarkDirty("lines");
    }
    UpdateLineAnimation();
}

void mu::ui::window::CSystemLogWindow::TrackPanelSize()
{
    auto* panel = m_RmlView.Document()->GetElementById("panel");
    if (!panel)
        return;
    const float height = panel->GetBox().GetSize(Rml::BoxArea::Border).y;
    if (height != m_LastPanelHeight)
    {
        m_LastPanelHeight = height;
        UI::Placement::Invalidate();
    }
}

void mu::ui::window::CSystemLogWindow::RebuildLineModel()
{
    SystemLogRmlModel& model = m_RmlView.GetModel();
    model.lines.clear();
    model.lines.reserve(m_vecAllMsgs.size());

    for (const CMessageText* pMsgText : m_vecAllMsgs)
    {
        if (pMsgText == nullptr)
            continue;

        auto entry = BuildChatLine(*pMsgText);
        const auto& text = pMsgText->GetText();
        if (text.starts_with(L"Congratulations,") && text.find(L"Level") != std::wstring::npos)
            entry.kind = "level-up";
        model.lines.push_back(std::move(entry));
    }
    // Empty rows preserve the six-line workspace reservation without drawing a backdrop.
    model.lines.resize(MAX_NUMBER_OF_LINES);
}

float mu::ui::window::CSystemLogWindow::GetLayerDepth()
{
    return 6.05f;
}

float mu::ui::window::CSystemLogWindow::GetKeyEventOrder()
{
    return 8.0f;
}

void mu::ui::window::CSystemLogWindow::ClearAll()
{
    m_bLinesDirty = true;
    auto vi_msg = m_vecAllMsgs.begin();
    for (; vi_msg != m_vecAllMsgs.end(); vi_msg++)
        delete (*vi_msg);
    m_vecAllMsgs.clear();

    m_iCurrentRenderEndLine = -1;
}

bool mu::ui::window::CSystemLogWindow::CheckChatRedundancy(const type_string& strText, int iSearchLine/* = 1*/)
{
    if (m_vecAllMsgs.empty()) return false;
    auto vri_msgs = m_vecAllMsgs.rbegin();
    for (int i = 0; (i < iSearchLine) || (vri_msgs != m_vecAllMsgs.rend()); vri_msgs++, i++)
        if (0 == (*vri_msgs)->GetText().compare(strText)) return true;
    return false;
}
