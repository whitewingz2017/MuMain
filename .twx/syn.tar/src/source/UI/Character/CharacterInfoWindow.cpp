
#include "stdafx.h"
#include "Core/Text/GroupedNumbers.h"
#include "UI/Chat/Chat.h"
#include "UI/Character/CharacterInfoWindow.h"
#include "UI/Core/WindowSystem.h"
#include "UI/Core/WindowGeometry.h"
#include "Character/CharacterManager.h"
#include "GameLogic/Items/CSItemOption.h"
#include "Audio/DSPlaySound.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Engine/Object/ZzzInterface.h"
#include "Scenes/SceneCore.h"
#include "Engine/Object/ZzzInventory.h"
#include "GameLogic/Skills/SkillManager.h"
#include "UI/Inventory/UIJewelHarmony.h"
#include "UI/Core/UIManager.h"
#include "Network/Server/ServerListManager.h"
#include "I18N/All.h"
#include "GameLogic/Items/ItemCategories.h"
#include "Core/Utilities/StringUtils.h"
#include "UI/Scaling/UITransform.h"
#include "Render/RmlUi/RmlUiRuntime.h"
#include "UI/RmlBridge/RmlSyncField.h"
#include "UI/RmlBridge/RmlPointer.h"
#include "UI/RmlBridge/RmlWindowClose.h"
#include "UI/RmlBridge/RmlNativeTextSize.h"
#include "UI/RmlBridge/RmlTheme.h"
#include "UI/Dialogs/GenericConfirmDialog.h"

#include <RmlUi/Core/DataModelHandle.h>
#include <RmlUi/Core/ElementDocument.h>
#include <RmlUi/Core/Event.h>

#include <algorithm>

using namespace SEASON3B;
using namespace mu::ui::window;

namespace
{
    // The stats in CharacterStatAttribute order (strength, agility, vitality, energy, command):
    // their label, and the stat's name in the server's "/add <stat> <amount>" chat command, which
    // adds several points at once (OpenMU's AddStatChatCommandPlugIn, enabled by default).
    constexpr int StatCount = 5;
    const wchar_t* StatLabel(int stat)
    {
        const wchar_t* labels[StatCount] = {I18N::Game::STR, I18N::Game::AGI, I18N::Game::STA, I18N::Game::ENG,
                                            I18N::Game::Command};
        return labels[stat];
    }
    constexpr const wchar_t* StatCommandNames[StatCount] = {L"str", L"agi", L"vit", L"ene", L"cmd"};

    // One point is the stat packet; more go as one chat command, which the server's stat
    // increase answers with the whole amount (ReceiveAddPointExtended()).
    void AddStatPoints(int stat, int amount)
    {
        if (amount == 1)
        {
            SocketClient->ToGameServer()->SendIncreaseCharacterStatPoint(static_cast<CharacterStatAttribute>(stat));
            return;
        }
        wchar_t command[32];
        mu_swprintf(command, L"/add %ls %d", StatCommandNames[stat], amount);
        SocketClient->ToGameServer()->SendPublicChatMessage(MU_C16(Hero->ID), MU_C16(command));
    }

    constexpr int MaximumPointsPerRequest = 65535; // the server's amount is 16 bits

    // Asks how many of the free points go into the stat, the free points offered as Max.
    void AskStatPoints(int stat)
    {
        wchar_t freePoints[64];
        mu_swprintf(freePoints, I18N::Game::PointD, CharacterAttribute->LevelUpPoint);

        GenericDialogConfig cfg;
        cfg.title = StatLabel(stat);
        cfg.lines = {{freePoints, false}};
        cfg.showCancel = true;
        cfg.input = GenericDialogConfig::InputField{};
        cfg.input->mode = GenericDialogConfig::InputField::Mode::Text;
        cfg.input->maxLength = 5;
        cfg.input->numericOnly = true;
        cfg.input->initialText = L"1";
        cfg.input->maxValue = []
        { return static_cast<std::uint64_t>(std::min<int>(CharacterAttribute->LevelUpPoint, MaximumPointsPerRequest)); };
        cfg.onPrimary = [stat]
        {
            const std::wstring typed = g_pGenericConfirmDialog->GetInputText();
            const int amount = std::min({typed.empty() ? 0 : _wtoi(typed.c_str()),
                                         static_cast<int>(CharacterAttribute->LevelUpPoint), MaximumPointsPerRequest});
            if (amount <= 0)
            {
                g_pGenericConfirmDialog->KeepOpen();
                return;
            }
            AddStatPoints(stat, amount);
            PlayBuffer(SOUND_CLICK01);
        };
        g_pGenericConfirmDialog->Show(std::move(cfg));
    }

    float GetMasterSkillValue(ActionSkillType skill)
    {
        return CharacterAttribute->MasterSkillInfo[skill].GetSkillValue();
    }

    float GetMasterSkillValue(ActionSkillType firstSkill, ActionSkillType secondSkill)
    {
        const auto firstSkillInfo = CharacterAttribute->MasterSkillInfo[firstSkill];
        const auto secondSkillInfo = CharacterAttribute->MasterSkillInfo[secondSkill];

        if (secondSkillInfo.GetSkillLevel() > firstSkillInfo.GetSkillLevel())
        {
            return secondSkillInfo.GetSkillValue();
        }

        return firstSkillInfo.GetSkillValue();
    }

    int GetMasterSkillValueAsInt(ActionSkillType skill)
    {
        return static_cast<int>(GetMasterSkillValue(skill));
    }

    int GetMasterSkillValueAsInt(ActionSkillType firstSkill, ActionSkillType secondSkill)
    {
        return static_cast<int>(GetMasterSkillValue(firstSkill, secondSkill));
    }

    float ClampDefenseSuccessRateMultiplier(float multiplier)
    {
        if (multiplier < 1.0f)
        {
            return 1.0f;
        }

        return multiplier;
    }

    // Which of the three states RenderAttribute() coloured an attribute's value for. The states
    // are the meaning; each theme's character_info.rcss decides what they look like.
    const char* AttributeSource(bool potionBuffed, bool boosted)
    {
        if (potionBuffed)
            return "potion";
        return boosted ? "boosted" : "base";
    }

    // The derived rows use the same vocabulary: "boosted" is the pale blue an item or set adds
    // (the primary stats' own .attr-boosted), "buffed" the colour a consumable buff sets, and
    // each theme's character_info.rcss decides what they look like.
}

mu::ui::window::CCharacterInfoWindow::CCharacterInfoWindow()
{
    m_pNewUIMng = NULL;
}

mu::ui::window::CCharacterInfoWindow::~CCharacterInfoWindow()
{
    Release();
}

bool mu::ui::window::CCharacterInfoWindow::Create(CManager* pNewUIMng)
{
    if (NULL == pNewUIMng)
        return false;

    m_pNewUIMng = pNewUIMng;
    m_pNewUIMng->AddUIObj(mu::ui::window::INTERFACE_CHARACTER, this);

    LoadImages();

    if (RmlUiRuntime::Instance().IsCreated())
    {
        BuildRmlUi();
    }

    Show(false);

    return true;
}

void mu::ui::window::CCharacterInfoWindow::BindRmlModel(Rml::DataModelConstructor& c, CharacterInfoRmlModel& model)
{
    model.textPx = UI::Scaling::NativeTextPixelSize(UI::Scaling::FontRole::Normal, static_cast<int>(WindowWidth),
                                                    static_cast<int>(WindowHeight));
    c.Bind("text_px", &model.textPx);

    c.BindEventCallback("chainfo_statistics", [](Rml::DataModelHandle, Rml::Event&, const Rml::VariantList&)
    {
        g_pNewUISystem->Show(INTERFACE_COMBAT_STATISTICS);
    });
    c.Bind("can_level_up", &model.canLevelUp);
    c.Bind("show_charisma", &model.showCharisma);

    c.Bind("name_text", &model.nameText);
    c.Bind("pk_level", &model.pkLevel);
    c.Bind("classname_text", &model.classNameText);
    c.Bind("servername_text", &model.serverNameText);
    c.Bind("classname_opacity", &model.classNameOpacity);
    c.Bind("servername_opacity", &model.serverNameOpacity);

    c.Bind("level_text", &model.levelText);
    c.Bind("levelup_point_text", &model.levelUpPointText);
    c.Bind("exp_text", &model.expText);
    c.Bind("point_probability_text", &model.pointProbabilityText);
    c.Bind("point_text", &model.pointText);

    c.Bind("str_label", &model.strLabel);
    c.Bind("agi_label", &model.agiLabel);
    c.Bind("vit_label", &model.vitLabel);
    c.Bind("ene_label", &model.eneLabel);
    c.Bind("cmd_label", &model.cmdLabel);
    c.Bind("str_value_text", &model.strValueText);
    c.Bind("str_value_source", &model.strValueSource);
    c.Bind("agi_value_text", &model.agiValueText);
    c.Bind("agi_value_source", &model.agiValueSource);
    c.Bind("vit_value_text", &model.vitValueText);
    c.Bind("vit_value_source", &model.vitValueSource);
    c.Bind("ene_value_text", &model.eneValueText);
    c.Bind("ene_value_source", &model.eneValueSource);
    c.Bind("cmd_value_text", &model.cmdValueText);
    c.Bind("cmd_value_source", &model.cmdValueSource);

    auto statLine = c.RegisterStruct<StatLine>();
    statLine.RegisterMember("text", &StatLine::text);
    statLine.RegisterMember("source", &StatLine::source);
    c.RegisterArray<std::vector<StatLine>>();
    c.Bind("str_lines", &model.strLines);
    c.Bind("agi_lines", &model.agiLines);
    c.Bind("vit_lines", &model.vitLines);
    c.Bind("ene_lines", &model.eneLines);

    c.Bind("master_level_enabled", &model.masterLevelEnabled);

    c.Bind("exit_tooltip", &model.exitTooltip);
    c.Bind("quest_tooltip", &model.questTooltip);
    c.Bind("pet_tooltip", &model.petTooltip);
    c.Bind("masterlevel_tooltip", &model.masterLevelTooltip);

    c.BindEventCallback("chainfo_increase_stat",
        [this](Rml::DataModelHandle, Rml::Event&, const Rml::VariantList& arguments)
        {
            if (arguments.size() == 1)
                RmlClickIncreaseStat(arguments[0].Get<int>(-1));
        });
    UI::RmlBridge::BindWindowClose(c, mu::ui::window::INTERFACE_CHARACTER);
    c.BindEventCallback("chainfo_click_quest",
        [this](Rml::DataModelHandle, Rml::Event&, const Rml::VariantList&) { RmlClickQuest(); });
    c.BindEventCallback("chainfo_click_pet",
        [this](Rml::DataModelHandle, Rml::Event&, const Rml::VariantList&) { RmlClickPet(); });
    c.BindEventCallback("chainfo_click_masterlevel",
        [this](Rml::DataModelHandle, Rml::Event&, const Rml::VariantList&) { RmlClickMasterLevel(); });
    model.strLabel = StringUtils::WideToNarrow(I18N::Game::STR);
    model.agiLabel = StringUtils::WideToNarrow(I18N::Game::AGI);
    model.vitLabel = StringUtils::WideToNarrow(I18N::Game::STA);
    model.eneLabel = StringUtils::WideToNarrow(I18N::Game::ENG);
    model.cmdLabel = StringUtils::WideToNarrow(I18N::Game::Command);

    wchar_t strText[256];
    mu_swprintf(strText, I18N::Game::CloseS, L"C");
    model.exitTooltip = StringUtils::WideToNarrow(strText);
    mu_swprintf(strText, L"%ls(%ls)", I18N::Game::Quest, L"T");
    model.questTooltip = StringUtils::WideToNarrow(strText);
    model.petTooltip = StringUtils::WideToNarrow(I18N::Game::Pet);
    model.masterLevelTooltip = StringUtils::WideToNarrow(I18N::Game::MasterSkillTreeA);
}

void mu::ui::window::CCharacterInfoWindow::BuildRmlUi()
{
    m_RmlView.Ensure();
}

void mu::ui::window::CCharacterInfoWindow::Release()
{
    UnloadImages();

    m_RmlView.Release();

    if (m_pNewUIMng)
    {
        m_pNewUIMng->RemoveUIObj(this);
        m_pNewUIMng = NULL;
    }

}

void mu::ui::window::CCharacterInfoWindow::Show(bool bShow)
{
    mu::ui::window::CObject::Show(bShow);
    if (m_RmlView.Document())
    {
        // A hidden window skips its sync, so it catches up before its document shows.
        if (bShow)
        {
            SyncRmlModel();
            m_RmlView.Document()->Show();
        }
        else
            m_RmlView.Document()->Hide();
    }
}

bool mu::ui::window::CCharacterInfoWindow::UpdateMouseEvent()
{
    // RmlUi handles both close targets; over the panel, the windows below get no mouse.
    return !UI::RmlBridge::IsPointerOver(m_RmlView.Document());
}

bool mu::ui::window::CCharacterInfoWindow::UpdateKeyEvent()
{
    if (g_pNewUISystem->IsVisible(mu::ui::window::INTERFACE_CHARACTER) == true)
    {
        if (mu::ui::window::IsPress(VK_ESCAPE) == true)
        {
            g_pNewUISystem->Hide(mu::ui::window::INTERFACE_CHARACTER);
            PlayBuffer(SOUND_CLICK01);

            return false;
        }
    }

    return true;
}

bool mu::ui::window::CCharacterInfoWindow::Update()
{
    SyncRmlModel();
    return true;
}

bool mu::ui::window::CCharacterInfoWindow::Render()
{
    // RmlUi's #panel owns all chrome/text/button rendering now; nothing left to draw natively.
    return true;
}

float mu::ui::window::CCharacterInfoWindow::GetLayerDepth()
{
    return 5.1f;
}

void mu::ui::window::CCharacterInfoWindow::OpenningProcess()
{
    ResetEquipmentLevel();

    const bool masterLevelEnabled = gCharacterManager.IsMasterLevel(Hero->Class) == true && Hero->Class != CLASS_TEMPLENIGHT;
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::masterLevelEnabled, "master_level_enabled",
              masterLevelEnabled);

    g_csItemOption.init();

    if (CharacterMachine->IsZeroDurability())
    {
        CharacterMachine->CalculateAll();
    }

    if (g_QuestMng.IsIndexInCurQuestIndexList(0x10009))
    {
        if (g_QuestMng.IsEPRequestRewardState(0x10009))
        {
            g_pMyQuestInfoWindow->UnselectQuestList();
            SocketClient->ToGameServer()->SendQuestClientActionRequest(1, 9);
            g_QuestMng.SetEPRequestRewardState(0x10009, false);
        }
    }
}

void mu::ui::window::CCharacterInfoWindow::RmlClickIncreaseStat(int stat)
{
    if (CharacterAttribute->LevelUpPoint <= 0)
        return;

    const int iBaseClass = gCharacterManager.GetBaseClass(Hero->Class);
    const int iCount = (iBaseClass == CLASS_DARK_LORD) ? 5 : 4;
    if (stat < 0 || stat >= iCount)
        return;

    PlayBuffer(SOUND_CLICK01);
    if (CharacterAttribute->LevelUpPoint == 1)
    {
        AddStatPoints(stat, 1);
        return;
    }
    AskStatPoints(stat);
}

void mu::ui::window::CCharacterInfoWindow::RmlClickQuest()
{
    g_pNewUISystem->Toggle(mu::ui::window::INTERFACE_MYQUEST);
}

void mu::ui::window::CCharacterInfoWindow::RmlClickPet()
{
    g_pNewUISystem->Toggle(mu::ui::window::INTERFACE_PET);
}

void mu::ui::window::CCharacterInfoWindow::RmlClickMasterLevel()
{
    if (gCharacterManager.IsMasterLevel(Hero->Class) && Hero->Class != CLASS_TEMPLENIGHT)
        g_pNewUISystem->Toggle(mu::ui::window::INTERFACE_MASTER_LEVEL);
}

void mu::ui::window::CCharacterInfoWindow::LoadImages()
{
    LoadBitmap(L"Interface\\newui_msgbox_back.jpg", IMAGE_CHAINFO_BACK, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_back04.tga", IMAGE_CHAINFO_TOP, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_back02-L.tga", IMAGE_CHAINFO_LEFT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_back02-R.tga", IMAGE_CHAINFO_RIGHT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_back03.tga", IMAGE_CHAINFO_BOTTOM, GL_LINEAR);

    LoadBitmap(L"Interface\\newui_item_table01(L).tga", IMAGE_CHAINFO_TABLE_TOP_LEFT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table01(R).tga", IMAGE_CHAINFO_TABLE_TOP_RIGHT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table02(L).tga", IMAGE_CHAINFO_TABLE_BOTTOM_LEFT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table02(R).tga", IMAGE_CHAINFO_TABLE_BOTTOM_RIGHT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table03(Up).tga", IMAGE_CHAINFO_TABLE_TOP_PIXEL, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table03(Dw).tga", IMAGE_CHAINFO_TABLE_BOTTOM_PIXEL, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table03(L).tga", IMAGE_CHAINFO_TABLE_LEFT_PIXEL, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_item_table03(R).tga", IMAGE_CHAINFO_TABLE_RIGHT_PIXEL, GL_LINEAR);

    LoadBitmap(L"Interface\\newui_exit_00.tga", IMAGE_CHAINFO_BTN_EXIT, GL_LINEAR);

    LoadBitmap(L"Interface\\newui_cha_textbox02.tga", IMAGE_CHAINFO_TEXTBOX, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_chainfo_btn_level.tga", IMAGE_CHAINFO_BTN_STAT, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_chainfo_btn_quest.tga", IMAGE_CHAINFO_BTN_QUEST, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_chainfo_btn_pet.tga", IMAGE_CHAINFO_BTN_PET, GL_LINEAR);
    LoadBitmap(L"Interface\\newui_chainfo_btn_master.tga", IMAGE_CHAINFO_BTN_MASTERLEVEL, GL_LINEAR);
}

void mu::ui::window::CCharacterInfoWindow::UnloadImages()
{
    DeleteBitmap(IMAGE_CHAINFO_BTN_MASTERLEVEL);
    DeleteBitmap(IMAGE_CHAINFO_BTN_PET);
    DeleteBitmap(IMAGE_CHAINFO_BTN_QUEST);
    DeleteBitmap(IMAGE_CHAINFO_BTN_STAT);
    DeleteBitmap(IMAGE_CHAINFO_TEXTBOX);

    DeleteBitmap(IMAGE_CHAINFO_BTN_EXIT);

    DeleteBitmap(IMAGE_CHAINFO_BOTTOM);
    DeleteBitmap(IMAGE_CHAINFO_RIGHT);
    DeleteBitmap(IMAGE_CHAINFO_LEFT);
    DeleteBitmap(IMAGE_CHAINFO_TOP);
    DeleteBitmap(IMAGE_CHAINFO_BACK);

    DeleteBitmap(IMAGE_CHAINFO_TABLE_RIGHT_PIXEL);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_LEFT_PIXEL);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_BOTTOM_PIXEL);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_TOP_PIXEL);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_BOTTOM_RIGHT);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_BOTTOM_LEFT);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_TOP_RIGHT);
    DeleteBitmap(IMAGE_CHAINFO_TABLE_TOP_LEFT);
}

void mu::ui::window::CCharacterInfoWindow::ResetEquipmentLevel()
{
    ITEM* pItem = CharacterMachine->Equipment;
    Hero->Weapon[0].Level = pItem[EQUIPMENT_WEAPON_RIGHT].Level;
    Hero->Weapon[1].Level = pItem[EQUIPMENT_WEAPON_LEFT].Level;
    Hero->BodyPart[BODYPART_HELM].Level = pItem[EQUIPMENT_HELM].Level;
    Hero->BodyPart[BODYPART_ARMOR].Level = pItem[EQUIPMENT_ARMOR].Level;
    Hero->BodyPart[BODYPART_PANTS].Level = pItem[EQUIPMENT_PANTS].Level;
    Hero->BodyPart[BODYPART_GLOVES].Level = pItem[EQUIPMENT_GLOVES].Level;
    Hero->BodyPart[BODYPART_BOOTS].Level = pItem[EQUIPMENT_BOOTS].Level;

    CheckFullSet(Hero);
}

void mu::ui::window::CCharacterInfoWindow::SyncRmlModel()
{
    if (!m_RmlView.Document() || !IsVisible())
        return;

    UI::RmlBridge::SyncNativeTextSize(m_RmlView.Binder());

    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::canLevelUp, "can_level_up", CharacterAttribute->LevelUpPoint > 0);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::showCharisma, "show_charisma",
              gCharacterManager.GetBaseClass(Hero->Class) == CLASS_DARK_LORD);

    BuildSubjectTexts();
    BuildTableTexts();
    BuildAttributeLines();
}

void mu::ui::window::CCharacterInfoWindow::BuildSubjectTexts()
{
    auto& model = m_RmlView.GetModel();

    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::nameText, "name_text",
              StringUtils::WideToNarrow(CharacterAttribute->Name));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::pkLevel, "pk_level", static_cast<int>(Hero->PK));

    wchar_t strClassName[256];
    mu_swprintf(strClassName, L"(%ls)", gCharacterManager.GetCharacterClassText(CharacterAttribute->Class));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::classNameText, "classname_text",
              StringUtils::WideToNarrow(strClassName));

    wchar_t strServerName[MAX_TEXT_LENGTH];
    const wchar_t* apszGlobalText[4]
        = { I18N::Game::SDServer, I18N::Game::SDNonPvPServer, I18N::Game::SDGoldPvPServer, I18N::Game::SDGoldServer };
    mu_swprintf(strServerName, apszGlobalText[g_ServerListManager->GetNonPVPInfo()],
        g_ServerListManager->GetSelectServerName(), g_ServerListManager->GetSelectServerIndex());
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::serverNameText, "servername_text",
              StringUtils::WideToNarrow(strServerName));

    const float fAlpha = sinf(WorldTime * 0.001f) + 1.f;
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::classNameOpacity, "classname_opacity",
              (127 * (2.f - fAlpha)) / 255.f);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::serverNameOpacity, "servername_opacity", (127 * fAlpha) / 255.f);
}

void mu::ui::window::CCharacterInfoWindow::BuildTableTexts()
{
    auto& model = m_RmlView.GetModel();

    wchar_t strLevel[128];
    wchar_t strExp[128];
    wchar_t strPoint[128];

    mu_swprintf(strLevel, I18N::Game::LevelUResetsU, CharacterAttribute->Level, CharacterAttribute->Resets);
    mu_swprintf(strExp, I18N::Game::EXPI64dI64d, static_cast<unsigned long long>(CharacterAttribute->Experience),
                static_cast<unsigned long long>(CharacterAttribute->NextExperience));

    if (CharacterAttribute->Level > 9)
    {
        int iMinus, iMaxMinus;
        if (CharacterAttribute->wMinusPoint == 0)
        {
            iMinus = 0;
        }
        else
        {
            iMinus = -CharacterAttribute->wMinusPoint;
        }

        iMaxMinus = -CharacterAttribute->wMaxMinusPoint;

        mu_swprintf(strPoint, L"%ls %d/%d | %ls %d/%d", I18N::Game::StatPointsAdded, CharacterAttribute->AddPoint,
                    CharacterAttribute->MaxAddPoint, I18N::Game::StatPointsRemoved, iMinus, iMaxMinus);
    }
    else
    {
        mu_swprintf(strPoint, L"%ls %d/%d | %ls %d/%d", I18N::Game::StatPointsAdded, 0, 0,
                    I18N::Game::StatPointsRemoved, 0, 0);
    }

    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::levelText, "level_text", StringUtils::WideToNarrow(strLevel));

    // Empty when there is nothing to spend, which is what the else branch used to clear it to.
    Rml::String levelUpPointText;
    if (CharacterAttribute->LevelUpPoint > 0)
    {
        wchar_t strLevelUpPoint[128];
        mu_swprintf(strLevelUpPoint, I18N::Game::PointD, CharacterAttribute->LevelUpPoint);
        levelUpPointText = StringUtils::WideToNarrow(strLevelUpPoint);
    }
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::levelUpPointText, "levelup_point_text",
              std::move(levelUpPointText));

    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::expText, "exp_text", StringUtils::WideToNarrow(Core::Text::GroupedNumbers(strExp).c_str()));

    int iAddPoint, iMinusPoint;

    if (CharacterAttribute->AddPoint <= 10)
    {
        iAddPoint = 100;
    }
    else
    {
        int iTemp = 0;
        if (CharacterAttribute->MaxAddPoint != 0)
        {
            iTemp = (CharacterAttribute->AddPoint * 100) / CharacterAttribute->MaxAddPoint;
        }
        if (iTemp <= 10)
        {
            iAddPoint = 70;
        }
        else if (iTemp > 10 && iTemp <= 30)
        {
            iAddPoint = 60;
        }
        else if (iTemp > 30 && iTemp <= 50)
        {
            iAddPoint = 50;
        }
        else if (iTemp > 50)
        {
            iAddPoint = 40;
        }
    }

    if (CharacterAttribute->wMinusPoint <= 10)
    {
        iMinusPoint = 100;
    }
    else
    {
        int iTemp = 0;
        if (CharacterAttribute->wMaxMinusPoint != 0)
        {
            iTemp = (CharacterAttribute->wMinusPoint * 100) / CharacterAttribute->wMaxMinusPoint;
        }

        if (iTemp <= 10)
        {
            iMinusPoint = 70;
        }
        else if (iTemp > 10 && iTemp <= 30)
        {
            iMinusPoint = 60;
        }
        else if (iTemp > 30 && iTemp <= 50)
        {
            iMinusPoint = 50;
        }
        else if (iTemp > 50)
        {
            iMinusPoint = 40;
        }
    }

    wchar_t strPointProbability[128];
    mu_swprintf(strPointProbability, I18N::Game::DD1907, iAddPoint, iMinusPoint);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::pointProbabilityText, "point_probability_text",
              StringUtils::WideToNarrow(strPointProbability));

    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::pointText, "point_text", StringUtils::WideToNarrow(strPoint));
}

void mu::ui::window::CCharacterInfoWindow::BuildAttributeLines()
{
    auto& model = m_RmlView.GetModel();

    WORD wStrength;

    wStrength = CharacterAttribute->Strength + CharacterAttribute->AddStrength;

    const char* strengthSource = AttributeSource(g_isCharacterBuff((&Hero->Object), eBuff_SecretPotion1),
                                                 CharacterAttribute->AddStrength != 0);

    wchar_t strStrength[32];
    mu_swprintf(strStrength, L"%d", wStrength);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::strValueText, "str_value_text",
              StringUtils::WideToNarrow(strStrength));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::strValueSource, "str_value_source", Rml::String(strengthSource));

    wchar_t strAttakMamage[256];
    int iAttackDamageMin = 0;
    int iAttackDamageMax = 0;

    bool bAttackDamage = GetAttackDamage(&iAttackDamageMin, &iAttackDamageMax);

    int add_attack_success_rate_pvm = 0;
    int add_attack_success_rate_pvp = 0;
    float add_defense_success_rate_pvm = 0.0f;
    int add_defense_success_rate_pvp = 0;
    int add_attack_dmg_max = 0;
    int add_attack_dmg_min = 0;
    int add_defense = 0;
    int add_magic_damage_min = 0;
    int add_magic_damage_max = 0;

    add_attack_success_rate_pvm = GetMasterSkillValueAsInt(AT_SKILL_AttackSuccRateInc, AT_SKILL_IncreaseAttackSuccessRate);
    add_attack_success_rate_pvp = GetMasterSkillValueAsInt(AT_SKILL_PvPAttackRate, AT_SKILL_IncreasePvPAttackRate);
    add_defense_success_rate_pvm = GetMasterSkillValue(AT_SKILL_DefenseSuccessRateInc, AT_SKILL_IncreaseDefenseSuccessRate);
    add_defense_success_rate_pvp = GetMasterSkillValueAsInt(AT_SKILL_PvPDefenceRateInc, AT_SKILL_IncreasePvPDefenseRate);
    add_defense = GetMasterSkillValueAsInt(AT_SKILL_DefenseIncrease, AT_SKILL_IncreasesDefense);
    add_magic_damage_min = GetMasterSkillValueAsInt(AT_SKILL_MinimumWizardryInc);

    ITEM* pWeaponRight = &CharacterMachine->Equipment[EQUIPMENT_WEAPON_RIGHT];
    ITEM* pWeaponLeft = &CharacterMachine->Equipment[EQUIPMENT_WEAPON_LEFT];

    int iAttackRating = CharacterAttribute->AttackRating + add_attack_success_rate_pvm;
    int iAttackRatingPK = CharacterAttribute->AttackRatingPK + add_attack_success_rate_pvp;
    iAttackDamageMax += add_attack_dmg_max;
    iAttackDamageMin += add_attack_dmg_min;

    if (g_isCharacterBuff((&Hero->Object), eBuff_AddAG))
    {
        WORD wDexterity = CharacterAttribute->Dexterity + CharacterAttribute->AddDexterity;
        iAttackRating += wDexterity;
        iAttackRatingPK += wDexterity;
        if (PartyNumber >= 3)
        {
            int iPlusRating = (wDexterity * ((PartyNumber - 2) * 0.01f));
            iAttackRating += iPlusRating;
            iAttackRatingPK = iPlusRating;
        }
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_HelpNpc))
    {
        int iTemp = 0;
        if (CharacterAttribute->Level > 180)
        {
            iTemp = (180 / 3) + 45;
        }
        else
        {
            iTemp = (CharacterAttribute->Level / 3) + 45;
        }

        iAttackDamageMin += iTemp;
        iAttackDamageMax += iTemp;
    }

    if (g_isCharacterBuff((&Hero->Object), eBuff_Berserker))
    {
        int nTemp = CharacterAttribute->Strength + CharacterAttribute->AddStrength
            + CharacterAttribute->Dexterity + CharacterAttribute->AddDexterity;
        float fTemp = int(CharacterAttribute->Energy / 30) / 100.f;
        iAttackDamageMin += nTemp / 7 * fTemp;
        iAttackDamageMax += nTemp / 4 * fTemp;
    }

    int iMinIndex = 0, iMaxIndex = 0, iMagicalIndex = 0;

    StrengthenCapability SC_r, SC_l;

    int rlevel = pWeaponRight->Level;

    if (rlevel >= pWeaponRight->Jewel_Of_Harmony_OptionLevel)
    {
        g_pUIJewelHarmonyinfo->GetStrengthenCapability(&SC_r, pWeaponRight, 1);

        if (SC_r.SI_isSP)
        {
            iMinIndex = SC_r.SI_SP.SI_minattackpower;
            iMaxIndex = SC_r.SI_SP.SI_maxattackpower;
            iMagicalIndex = SC_r.SI_SP.SI_magicalpower;
        }
    }

    int llevel = pWeaponLeft->Level;

    if (llevel >= pWeaponLeft->Jewel_Of_Harmony_OptionLevel)
    {
        g_pUIJewelHarmonyinfo->GetStrengthenCapability(&SC_l, pWeaponLeft, 1);

        if (SC_l.SI_isSP)
        {
            iMinIndex += SC_l.SI_SP.SI_minattackpower;
            iMaxIndex += SC_l.SI_SP.SI_maxattackpower;
            iMagicalIndex += SC_l.SI_SP.SI_magicalpower;
        }
    }

    int iDefenseRate = 0, iAttackPowerRate = 0;

    StrengthenCapability rightinfo, leftinfo;

    int iRightLevel = pWeaponRight->Level;

    if (iRightLevel >= pWeaponRight->Jewel_Of_Harmony_OptionLevel)
    {
        g_pUIJewelHarmonyinfo->GetStrengthenCapability(&rightinfo, pWeaponRight, 1);
    }

    int iLeftLevel = pWeaponLeft->Level;

    if (iLeftLevel >= pWeaponLeft->Jewel_Of_Harmony_OptionLevel)
    {
        g_pUIJewelHarmonyinfo->GetStrengthenCapability(&leftinfo, pWeaponLeft, 1);
    }

    if (rightinfo.SI_isSP)
    {
        iAttackPowerRate += rightinfo.SI_SP.SI_attackpowerRate;
    }
    if (leftinfo.SI_isSP)
    {
        iAttackPowerRate += leftinfo.SI_SP.SI_attackpowerRate;
    }

    for (int k = EQUIPMENT_WEAPON_LEFT; k < MAX_EQUIPMENT; ++k)
    {
        StrengthenCapability defenseinfo;

        ITEM* pItem = &CharacterMachine->Equipment[k];

        int eqlevel = pItem->Level;

        if (eqlevel >= pItem->Jewel_Of_Harmony_OptionLevel)
        {
            g_pUIJewelHarmonyinfo->GetStrengthenCapability(&defenseinfo, pItem, 2);
        }

        if (defenseinfo.SI_isSD)
        {
            iDefenseRate += defenseinfo.SI_SD.SI_defenseRate;
        }
    }

    int itemoption380Attack = 0;
    int itemoption380Defense = 0;

    for (int j = 0; j < MAX_EQUIPMENT; ++j)
    {
        bool is380item = CharacterMachine->Equipment[j].option_380;
        int i380type = CharacterMachine->Equipment[j].Type;

        if (is380item && i380type > -1 && i380type < MAX_ITEM)
        {
            ITEM_ADD_OPTION item380option;

            item380option = g_pItemAddOptioninfo->GetItemAddOtioninfo(CharacterMachine->Equipment[j].Type);

            if (item380option.m_byOption1 == 1)
            {
                itemoption380Attack += item380option.m_byValue1;
            }

            if (item380option.m_byOption2 == 1)
            {
                itemoption380Attack += item380option.m_byValue2;
            }

            if (item380option.m_byOption1 == 3)
            {
                itemoption380Defense += item380option.m_byValue1;
            }

            if (item380option.m_byOption2 == 3)
            {
                itemoption380Defense += item380option.m_byValue2;
            }
        }
    }

    ITEM* pItemRingLeft, * pItemRingRight;

    pItemRingLeft = &CharacterMachine->Equipment[EQUIPMENT_RING_LEFT];
    pItemRingRight = &CharacterMachine->Equipment[EQUIPMENT_RING_RIGHT];
    if (pItemRingLeft && pItemRingRight)
    {
        int iNonExpiredLRingType = -1;
        int iNonExpiredRRingType = -1;
        if (!pItemRingLeft->bPeriodItem || !pItemRingLeft->bExpiredPeriod)
        {
            iNonExpiredLRingType = pItemRingLeft->Type;
        }
        if (!pItemRingRight->bPeriodItem || !pItemRingRight->bExpiredPeriod)
        {
            iNonExpiredRRingType = pItemRingRight->Type;
        }

        int maxIAttackDamageMin = 0;
        int maxIAttackDamageMax = 0;
        if (iNonExpiredLRingType == ITEM_CHRISTMAS_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_CHRISTMAS_TRANSFORMATION_RING)
        {
            maxIAttackDamageMin = std::max<int>(maxIAttackDamageMin, 20);
            maxIAttackDamageMax = std::max<int>(maxIAttackDamageMax, 20);
        }
        if (iNonExpiredLRingType == ITEM_PANDA_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_PANDA_TRANSFORMATION_RING)
        {
            maxIAttackDamageMin = std::max<int>(maxIAttackDamageMin, 30);
            maxIAttackDamageMax = std::max<int>(maxIAttackDamageMax, 30);
        }
        if (iNonExpiredLRingType == ITEM_SKELETON_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_SKELETON_TRANSFORMATION_RING)
        {
            maxIAttackDamageMin = std::max<int>(maxIAttackDamageMin, 40);
            maxIAttackDamageMax = std::max<int>(maxIAttackDamageMax, 40);
        }

        iAttackDamageMin += maxIAttackDamageMin;
        iAttackDamageMax += maxIAttackDamageMax;
    }

    ITEM* pItemHelper = &CharacterMachine->Equipment[EQUIPMENT_HELPER];
    if (pItemHelper)
    {
        if (pItemHelper->Type == ITEM_HORN_OF_FENRIR && pItemHelper->ExcellentFlags == 0x04)
        {
            WORD wLevel = CharacterAttribute->Level;
            iAttackDamageMin += (wLevel / 12);
            iAttackDamageMax += (wLevel / 12);
        }
        if (pItemHelper->Type == ITEM_DEMON)
        {
            if (false == pItemHelper->bExpiredPeriod)
            {
                iAttackDamageMin += int(float(iAttackDamageMin) * 0.4f);
                iAttackDamageMax += int(float(iAttackDamageMax) * 0.4f);
            }
        }
        if (pItemHelper->Type == ITEM_PET_SKELETON)
        {
            if (false == pItemHelper->bExpiredPeriod)
            {
                iAttackDamageMin += int(float(iAttackDamageMin) * 0.2f);
                iAttackDamageMax += int(float(iAttackDamageMax) * 0.2f);
            }
        }
        if (pItemHelper->Type == ITEM_IMP)
        {
            iAttackDamageMin += int(float(iAttackDamageMin) * 0.3f);
            iAttackDamageMax += int(float(iAttackDamageMax) * 0.3f);
        }
    }

    if (iAttackRating > 0)
    {
        if (iAttackDamageMin + iMinIndex >= iAttackDamageMax + iMaxIndex)
        {
            mu_swprintf(strAttakMamage, I18N::Game::DmgRateDDD, iAttackDamageMax + iMaxIndex, iAttackDamageMax + iMaxIndex, iAttackRating);
        }
        else
        {
            mu_swprintf(strAttakMamage, I18N::Game::DmgRateDDD, iAttackDamageMin + iMinIndex, iAttackDamageMax + iMaxIndex, iAttackRating);
        }
    }
    else
    {
        if (iAttackDamageMin + iMinIndex >= iAttackDamageMax + iMaxIndex)
        {
            mu_swprintf(strAttakMamage, I18N::Game::DmgDD, iAttackDamageMax + iMaxIndex, iAttackDamageMax + iMaxIndex);
        }
        else
        {
            mu_swprintf(strAttakMamage, I18N::Game::DmgDD, iAttackDamageMin + iMinIndex, iAttackDamageMax + iMaxIndex);
        }
    }

    const char* attackDamageSource = bAttackDamage ? "boosted" : "base";

    if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin2))
    {
        attackDamageSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll3))
    {
        attackDamageSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_CherryBlossom_Petal))
    {
        attackDamageSource = "buffed";
    }

    model.strLines.clear();
    model.strLines.push_back({ StringUtils::WideToNarrow(strAttakMamage), attackDamageSource });

    if (iAttackRatingPK > 0)
    {
        if (itemoption380Attack != 0 || iAttackPowerRate != 0)
        {
            mu_swprintf(strAttakMamage, I18N::Game::AttackRateDD, iAttackRatingPK, itemoption380Attack + iAttackPowerRate);
        }
        else
        {
            mu_swprintf(strAttakMamage, I18N::Game::AttackRateD, iAttackRatingPK);
        }

        model.strLines.push_back({ StringUtils::WideToNarrow(strAttakMamage), attackDamageSource });
    }
    m_RmlView.MarkDirty("str_lines");

    const char* dexteritySource = AttributeSource(g_isCharacterBuff((&Hero->Object), eBuff_SecretPotion2),
                                                  CharacterAttribute->AddDexterity != 0);

    wchar_t strDexterity[32];
    WORD wDexterity = CharacterAttribute->Dexterity + CharacterAttribute->AddDexterity;
    mu_swprintf(strDexterity, L"%d", wDexterity);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::agiValueText, "agi_value_text",
              StringUtils::WideToNarrow(strDexterity));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::agiValueSource, "agi_value_source", Rml::String(dexteritySource));

    bool bDexSuccess = true;
    int iBaseClass = gCharacterManager.GetBaseClass(Hero->Class);

    for (int i = EQUIPMENT_HELM; i <= EQUIPMENT_BOOTS; ++i)
    {
        if (iBaseClass == CLASS_DARK)
        {
            if ((CharacterMachine->Equipment[i].Type == -1 && (i != EQUIPMENT_HELM && iBaseClass == CLASS_DARK))
                || (CharacterMachine->Equipment[i].Type != -1 && CharacterMachine->Equipment[i].Durability <= 0))
            {
                bDexSuccess = false;
                break;
            }
        }
        else if (iBaseClass == CLASS_RAGEFIGHTER)
        {
            if ((CharacterMachine->Equipment[i].Type == -1 && (i != EQUIPMENT_GLOVES && iBaseClass == CLASS_RAGEFIGHTER))
                || (CharacterMachine->Equipment[i].Type != -1 && CharacterMachine->Equipment[i].Durability <= 0))
            {
                bDexSuccess = false;
                break;
            }
        }
        else
        {
            if ((CharacterMachine->Equipment[i].Type == -1) ||
                (CharacterMachine->Equipment[i].Type != -1 && CharacterMachine->Equipment[i].Durability <= 0))
            {
                bDexSuccess = false;
                break;
            }
        }
    }

    if (bDexSuccess)
    {
        int iType;
        if (iBaseClass == CLASS_DARK)
        {
            iType = CharacterMachine->Equipment[EQUIPMENT_ARMOR].Type;

            if (
                (iType != ITEM_STORM_CROW_ARMOR)
                && (iType != ITEM_THUNDER_HAWK_ARMOR)
                && (iType != ITEM_HURRICANE_ARMOR)
                && (iType != ITEM_VOLCANO_ARMOR)
                && (iType != ITEM_VALIANT_ARMOR)
                && (iType != ITEM_DESTORY_ARMOR)
                && (iType != ITEM_PHANTOM_ARMOR)
                )
            {
                bDexSuccess = false;
            }

            iType = iType % MAX_ITEM_INDEX;
        }
        else
        {
            iType = CharacterMachine->Equipment[EQUIPMENT_HELM].Type % MAX_ITEM_INDEX;
        }

        if (bDexSuccess)
        {
            for (int i = EQUIPMENT_ARMOR; i <= EQUIPMENT_BOOTS; ++i)
            {
                if (iBaseClass == CLASS_RAGEFIGHTER && i == EQUIPMENT_GLOVES)
                    continue;
                if (iType != CharacterMachine->Equipment[i].Type % MAX_ITEM_INDEX)
                {
                    bDexSuccess = false;
                    break;
                }
            }
        }
    }

    int t_adjdef = CharacterAttribute->Defense + add_defense;

    if (g_isCharacterBuff((&Hero->Object), eBuff_HelpNpc))
    {
        if (CharacterAttribute->Level > 180)
        {
            t_adjdef += 180 / 5 + 50;
        }
        else
        {
            t_adjdef += (CharacterAttribute->Level / 5 + 50);
        }
    }

    if (g_isCharacterBuff((&Hero->Object), eBuff_Berserker))
    {
        int nTemp = CharacterAttribute->Dexterity + CharacterAttribute->AddDexterity;
        float fTemp = (40 - int(CharacterAttribute->Energy / 60)) / 100.f;
        fTemp = MAX(fTemp, 0.1f);
        t_adjdef -= nTemp / 3 * fTemp;
    }

    int maxdefense = 0;

    for (int j = 0; j < MAX_EQUIPMENT; ++j)
    {
        int TempLevel = CharacterMachine->Equipment[j].Level;
        if (TempLevel >= CharacterMachine->Equipment[j].Jewel_Of_Harmony_OptionLevel)
        {
            StrengthenCapability SC;

            g_pUIJewelHarmonyinfo->GetStrengthenCapability(&SC, &CharacterMachine->Equipment[j], 2);

            if (SC.SI_isSD)
            {
                maxdefense += SC.SI_SD.SI_defense;
            }
        }
    }

    int iChangeRingAddDefense = 0;

    pItemRingLeft = &CharacterMachine->Equipment[EQUIPMENT_RING_LEFT];
    pItemRingRight = &CharacterMachine->Equipment[EQUIPMENT_RING_RIGHT];
    if (pItemRingLeft->Type == ITEM_ELITE_TRANSFER_SKELETON_RING || pItemRingRight->Type == ITEM_ELITE_TRANSFER_SKELETON_RING)
    {
        iChangeRingAddDefense = (t_adjdef + maxdefense) / 10;
    }

    if (Hero->Helper.Type == MODEL_PET_PANDA)
        iChangeRingAddDefense += 50;

    if (Hero->Helper.Type == MODEL_PET_UNICORN)
        iChangeRingAddDefense += 50;

    wchar_t strBlocking[256];

    const float defenseSuccessRateMultiplier = ClampDefenseSuccessRateMultiplier(add_defense_success_rate_pvm);
    const int defenseSuccessRate = static_cast<int>(CharacterAttribute->SuccessfulBlocking * defenseSuccessRateMultiplier);

    int nAdd_FulBlocking = 0;
    if (g_isCharacterBuff((&Hero->Object), eBuff_Def_up_Ourforces))
    {
        int _AddStat = (10 + (float)(CharacterAttribute->Energy - 80) / 10);
        if (_AddStat > 100)
            _AddStat = 100;

        _AddStat = defenseSuccessRate * _AddStat / 100;
        nAdd_FulBlocking += _AddStat;
    }

    if (bDexSuccess)
    {
        // memorylock
        if (defenseSuccessRate > 0)
        {
            if (nAdd_FulBlocking)
            {
                mu_swprintf(strBlocking, I18N::Game::DefenseRateDDD, t_adjdef + maxdefense + iChangeRingAddDefense,
                    defenseSuccessRate, (defenseSuccessRate) / 10 + nAdd_FulBlocking);
            }
            else
            {
                mu_swprintf(strBlocking, I18N::Game::DefenseRateDDD, t_adjdef + maxdefense + iChangeRingAddDefense,
                    defenseSuccessRate, (defenseSuccessRate) / 10);
            }
        }
        else
        {
            mu_swprintf(strBlocking, I18N::Game::DefenseDD, t_adjdef + maxdefense + iChangeRingAddDefense, (t_adjdef + iChangeRingAddDefense) / 10);
        }
    }
    else
    {
        if (defenseSuccessRate > 0)
        {
            if (nAdd_FulBlocking)
            {
                mu_swprintf(strBlocking, I18N::Game::DefenseRateDDD, t_adjdef + maxdefense + iChangeRingAddDefense, defenseSuccessRate, nAdd_FulBlocking);
            }
            else
            {
                mu_swprintf(strBlocking, I18N::Game::DefenseRateDD, t_adjdef + maxdefense + iChangeRingAddDefense, defenseSuccessRate);
            }
        }
        else
        {
            mu_swprintf(strBlocking, I18N::Game::DefenseD, t_adjdef + maxdefense + iChangeRingAddDefense);
        }
    }

    model.agiLines.clear();

    const char* defenseSource = "base";
    if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin3))
    {
        defenseSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll2))
    {
        defenseSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_Def_up_Ourforces))
    {
        defenseSource = "boosted";
    }
    model.agiLines.push_back({ StringUtils::WideToNarrow(strBlocking), defenseSource });

    WORD wAttackSpeed = CLASS_WIZARD == iBaseClass || CLASS_SUMMONER == iBaseClass
        ? CharacterAttribute->MagicSpeed : CharacterAttribute->AttackSpeed;

    mu_swprintf(strBlocking, I18N::Game::AttackSpeedD, wAttackSpeed);

    const char* attackSpeedSource = "base";
    if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin1))
    {
        attackSpeedSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll1))
    {
        attackSpeedSource = "buffed";
    }

    ITEM* phelper = &CharacterMachine->Equipment[EQUIPMENT_HELPER];
    if (phelper->Durability != 0 &&
        (phelper->Type == ITEM_DEMON || phelper->Type == ITEM_PET_SKELETON))
    {
        if (IsRequireEquipItem(phelper))
        {
            if (false == pItemHelper->bExpiredPeriod)
            {
                attackSpeedSource = "buffed";
            }
        }
    }
    model.agiLines.push_back({ StringUtils::WideToNarrow(strBlocking), attackSpeedSource });

    if (itemoption380Defense != 0 || iDefenseRate != 0)
    {
        mu_swprintf(strBlocking, I18N::Game::DefenseRateDD2110, CharacterAttribute->SuccessfulBlockingPK + add_defense_success_rate_pvp, itemoption380Defense + iDefenseRate);
    }
    else
    {
        mu_swprintf(strBlocking, I18N::Game::DefenseRateD, CharacterAttribute->SuccessfulBlockingPK + add_defense_success_rate_pvp);
    }
    model.agiLines.push_back({ StringUtils::WideToNarrow(strBlocking), "base" });
    m_RmlView.MarkDirty("agi_lines");

    WORD wVitality = CharacterAttribute->Vitality + CharacterAttribute->AddVitality;

    // The Our-Forces HP buff counts as boosted like an item bonus does, but it also has to
    // recompute the total first, so this one keeps its branches rather than folding into
    // AttributeSource()'s two conditions.
    const char* vitalitySource = "base";
    if (g_isCharacterBuff((&Hero->Object), eBuff_SecretPotion3))
    {
        vitalitySource = "potion";
    }
    else if (g_isCharacterBuff((&Hero->Object), eBuff_Hp_up_Ourforces))
    {
        CharacterMachine->CalculateAll();
        wVitality = CharacterAttribute->Vitality + CharacterAttribute->AddVitality;
        vitalitySource = "boosted";
    }
    else if (CharacterAttribute->AddVitality)
    {
        vitalitySource = "boosted";
    }

    wchar_t strVitality[256];
    mu_swprintf(strVitality, L"%d", wVitality);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::vitValueText, "vit_value_text",
              StringUtils::WideToNarrow(strVitality));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::vitValueSource, "vit_value_source", Rml::String(vitalitySource));

    if (gCharacterManager.IsMasterLevel(Hero->Class) == true)
    {
        mu_swprintf(strVitality, I18N::Game::HPDD, CharacterAttribute->Life, Master_Level_Data.wMaxLife);
    }
    else
    {
        mu_swprintf(strVitality, I18N::Game::HPDD, CharacterAttribute->Life, CharacterAttribute->LifeMax);
    }

    const char* hpSource = "base";
    if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin4))
    {
        hpSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll5))
    {
        hpSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_CherryBlossom_RiceCake))
    {
        hpSource = "buffed";
    }
    if (phelper->Durability != 0 && phelper->Type == ITEM_SPIRIT_OF_GUARDIAN)
    {
        if (IsRequireEquipItem(phelper))
        {
            if (false == pItemHelper->bExpiredPeriod)
            {
                hpSource = "buffed";
            }
        }
    }

    model.vitLines.clear();
    model.vitLines.push_back({ StringUtils::WideToNarrow(strVitality), hpSource });

    if (iBaseClass == CLASS_RAGEFIGHTER)
    {
        mu_swprintf(strVitality, I18N::Game::MeleeDamageD, 50 + (wVitality / 10));
        model.vitLines.push_back({ StringUtils::WideToNarrow(strVitality), "base" });
    }
    m_RmlView.MarkDirty("vit_lines");

    WORD wEnergy = CharacterAttribute->Energy + CharacterAttribute->AddEnergy;

    const char* energySource = AttributeSource(g_isCharacterBuff((&Hero->Object), eBuff_SecretPotion4),
                                               CharacterAttribute->AddEnergy != 0);

    wchar_t strEnergy[256];
    mu_swprintf(strEnergy, L"%d", wEnergy);
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::eneValueText, "ene_value_text",
              StringUtils::WideToNarrow(strEnergy));
    SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::eneValueSource, "ene_value_source", Rml::String(energySource));

    model.eneLines.clear();

    if (gCharacterManager.IsMasterLevel(Hero->Class) == true)
    {
        mu_swprintf(strEnergy, I18N::Game::ManaDD, CharacterAttribute->Mana, Master_Level_Data.wMaxMana);
    }
    else
        mu_swprintf(strEnergy, I18N::Game::ManaDD, CharacterAttribute->Mana, CharacterAttribute->ManaMax);

    const char* manaSource = "base";
    if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin5))
    {
        manaSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll6))
    {
        manaSource = "buffed";
    }
    if (g_isCharacterBuff((&Hero->Object), eBuff_CherryBlossom_Liguor))
    {
        manaSource = "buffed";
    }
    model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), manaSource });

    if (iBaseClass == CLASS_WIZARD || iBaseClass == CLASS_DARK || iBaseClass == CLASS_SUMMONER)
    {
        int iMagicDamageMin;
        int iMagicDamageMax;

        gCharacterManager.GetMagicSkillDamage(CharacterAttribute->Skill[Hero->CurrentSkill], &iMagicDamageMin, &iMagicDamageMax);

        int iMagicDamageMinInitial = iMagicDamageMin;
        int iMagicDamageMaxInitial = iMagicDamageMax;

        iMagicDamageMin += add_magic_damage_min;
        iMagicDamageMax += add_magic_damage_max;

        if (CharacterAttribute->Ability & ABILITY_PLUS_DAMAGE)
        {
            iMagicDamageMin += 10;
            iMagicDamageMax += 10;
        }

        int maxMg = 0;

        for (int j = 0; j < MAX_EQUIPMENT; ++j)
        {
            int TempLevel = CharacterMachine->Equipment[j].Level;

            if (TempLevel >= CharacterMachine->Equipment[j].Jewel_Of_Harmony_OptionLevel)
            {
                StrengthenCapability SC;
                g_pUIJewelHarmonyinfo->GetStrengthenCapability(&SC, &CharacterMachine->Equipment[j], 1);

                if (SC.SI_isSP)
                {
                    maxMg += SC.SI_SP.SI_magicalpower;
                }
            }
        }

        pItemRingLeft = &CharacterMachine->Equipment[EQUIPMENT_RING_LEFT];
        pItemRingRight = &CharacterMachine->Equipment[EQUIPMENT_RING_RIGHT];

        int iNonExpiredLRingType = -1;
        int iNonExpiredRRingType = -1;

        if (!pItemRingLeft->bPeriodItem || !pItemRingLeft->bExpiredPeriod)
        {
            iNonExpiredLRingType = pItemRingLeft->Type;
        }
        if (!pItemRingRight->bPeriodItem || !pItemRingRight->bExpiredPeriod)
        {
            iNonExpiredRRingType = pItemRingRight->Type;
        }

        int maxIMagicDamageMin = 0;
        int maxIMagicDamageMax = 0;

        if (iNonExpiredLRingType == ITEM_CHRISTMAS_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_CHRISTMAS_TRANSFORMATION_RING)
        {
            maxIMagicDamageMin = std::max<int>(maxIMagicDamageMin, 20);
            maxIMagicDamageMax = std::max<int>(maxIMagicDamageMax, 20);
        }
        if (iNonExpiredLRingType == ITEM_PANDA_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_PANDA_TRANSFORMATION_RING)
        {
            maxIMagicDamageMin = std::max<int>(maxIMagicDamageMin, 30);
            maxIMagicDamageMax = std::max<int>(maxIMagicDamageMax, 30);
        }
        if (iNonExpiredLRingType == ITEM_SKELETON_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_SKELETON_TRANSFORMATION_RING)
        {
            maxIMagicDamageMin = std::max<int>(maxIMagicDamageMin, 40);
            maxIMagicDamageMax = std::max<int>(maxIMagicDamageMax, 40);
        }

        iMagicDamageMin += maxIMagicDamageMin;
        iMagicDamageMax += maxIMagicDamageMax;

        pItemHelper = &CharacterMachine->Equipment[EQUIPMENT_HELPER];
        if (pItemHelper)
        {
            if (pItemHelper->Type == ITEM_HORN_OF_FENRIR && pItemHelper->ExcellentFlags == 0x04)
            {
                WORD wLevel = CharacterAttribute->Level;
                iMagicDamageMin += (wLevel / 25);
                iMagicDamageMax += (wLevel / 25);
            }

            if (pItemHelper->Type == ITEM_DEMON)
            {
                if (false == pItemHelper->bExpiredPeriod)
                {
                    iMagicDamageMin += int(float(iMagicDamageMin) * 0.4f);
                    iMagicDamageMax += int(float(iMagicDamageMax) * 0.4f);
                }
            }
            if (pItemHelper->Type == ITEM_PET_SKELETON)
            {
                if (false == pItemHelper->bExpiredPeriod)
                {
                    iMagicDamageMin += int(float(iMagicDamageMin) * 0.2f);
                    iMagicDamageMax += int(float(iMagicDamageMax) * 0.2f);
                }
            }
            if (pItemHelper->Type == ITEM_IMP)
            {
                iMagicDamageMin += int(float(iMagicDamageMin) * 0.3f);
                iMagicDamageMax += int(float(iMagicDamageMax) * 0.3f);
            }
        }

        if (g_isCharacterBuff((&Hero->Object), eBuff_Berserker))
        {
            int nTemp = CharacterAttribute->Energy + CharacterAttribute->AddEnergy;
            float fTemp = int(CharacterAttribute->Energy / 30) / 100.f;
            iMagicDamageMin += nTemp / 9 * fTemp;
            iMagicDamageMax += nTemp / 4 * fTemp;
        }

        if (GameLogic::Items::IsStaffOrBookType(pWeaponRight->Type) ||
            GameLogic::Items::IsMagicSwordType(pWeaponRight->Type))
        {
            float magicPercent = (float)(pWeaponRight->MagicPower) / 100;

            ITEM_ATTRIBUTE* p = &ItemAttribute[pWeaponRight->Type];
            float   percent = CalcDurabilityPercent(pWeaponRight->Durability, p->MagicDur, pWeaponRight->Level, pWeaponRight->ExcellentFlags, pWeaponRight->AncientDiscriminator);

            magicPercent = magicPercent - magicPercent * percent;
            mu_swprintf(strEnergy, I18N::Game::WizardryDmgDDD, iMagicDamageMin + maxMg, iMagicDamageMax + maxMg, (int)((iMagicDamageMaxInitial + maxMg) * magicPercent));
        }
        else
        {
            mu_swprintf(strEnergy, I18N::Game::WizardryDmgDD216, iMagicDamageMin + maxMg, iMagicDamageMax + maxMg);
        }

        const char* magicDamageSource = "base";
        if (g_isCharacterBuff((&Hero->Object), eBuff_Hellowin2))
        {
            magicDamageSource = "buffed";
        }
        if (g_isCharacterBuff((&Hero->Object), eBuff_EliteScroll4))
        {
            magicDamageSource = "buffed";
        }
        if (g_isCharacterBuff((&Hero->Object), eBuff_CherryBlossom_Petal))
        {
            magicDamageSource = "buffed";
        }
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), magicDamageSource });
    }

    if (iBaseClass == CLASS_SUMMONER)
    {
        int iCurseDamageMin = 0;
        int iCurseDamageMax = 0;

        gCharacterManager.GetCurseSkillDamage(CharacterAttribute->Skill[Hero->CurrentSkill], &iCurseDamageMin, &iCurseDamageMax);

        if (g_isCharacterBuff((&Hero->Object), eBuff_Berserker))
        {
            int nTemp = CharacterAttribute->Energy + CharacterAttribute->AddEnergy;
            float fTemp = int(CharacterAttribute->Energy / 30) / 100.f;
            iCurseDamageMin += nTemp / 9 * fTemp;
            iCurseDamageMax += nTemp / 4 * fTemp;
        }

        int iNonExpiredLRingType = -1;
        int iNonExpiredRRingType = -1;

        if (!pItemRingLeft->bPeriodItem || !pItemRingLeft->bExpiredPeriod)
        {
            iNonExpiredLRingType = pItemRingLeft->Type;
        }
        if (!pItemRingRight->bPeriodItem || !pItemRingRight->bExpiredPeriod)
        {
            iNonExpiredRRingType = pItemRingRight->Type;
        }

        int maxICurseDamageMin = 0;
        int maxICurseDamageMax = 0;

        if (iNonExpiredLRingType == ITEM_PANDA_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_PANDA_TRANSFORMATION_RING)
        {
            maxICurseDamageMin = std::max<int>(maxICurseDamageMin, 30);
            maxICurseDamageMax = std::max<int>(maxICurseDamageMax, 30);
        }
        if (iNonExpiredLRingType == ITEM_SKELETON_TRANSFORMATION_RING || iNonExpiredRRingType == ITEM_SKELETON_TRANSFORMATION_RING)
        {
            maxICurseDamageMin = std::max<int>(maxICurseDamageMin, 40);
            maxICurseDamageMax = std::max<int>(maxICurseDamageMax, 40);
        }

        iCurseDamageMin += maxICurseDamageMin;
        iCurseDamageMax += maxICurseDamageMax;

        pItemHelper = &CharacterMachine->Equipment[EQUIPMENT_HELPER];
        if (pItemHelper)
        {
            if (pItemHelper->Type == ITEM_DEMON)
            {
                if (false == pItemHelper->bExpiredPeriod)
                {
                    iCurseDamageMin += int(float(iCurseDamageMin) * 0.4f);
                    iCurseDamageMax += int(float(iCurseDamageMax) * 0.4f);
                }
            }
            if (pItemHelper->Type == ITEM_PET_SKELETON)
            {
                if (false == pItemHelper->bExpiredPeriod)
                {
                    iCurseDamageMin += int(float(iCurseDamageMin) * 0.2f);
                    iCurseDamageMax += int(float(iCurseDamageMax) * 0.2f);
                }
            }
        }

        if (GameLogic::Items::IsSummonerBook(pWeaponLeft))
        {
            float fCursePercent = (float)(pWeaponLeft->MagicPower) / 100;

            ITEM_ATTRIBUTE* p = &ItemAttribute[pWeaponLeft->Type];
            float fPercent = ::CalcDurabilityPercent(pWeaponLeft->Durability,
                p->MagicDur, pWeaponLeft->Level, pWeaponLeft->ExcellentFlags,
                pWeaponLeft->AncientDiscriminator);

            fCursePercent -= fCursePercent * fPercent;
            mu_swprintf(strEnergy, I18N::Game::CurseSpellDDD,
                iCurseDamageMin, iCurseDamageMax,
                (int)((iCurseDamageMax)*fCursePercent));
        }
        else
        {
            mu_swprintf(strEnergy, I18N::Game::CurseSpellDD1694,
                iCurseDamageMin, iCurseDamageMax);
        }

        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
    }

    if (iBaseClass == CLASS_KNIGHT)
    {
        mu_swprintf(strEnergy, I18N::Game::SkillDamageD, 200 + (wEnergy / 10));
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
    }
    if (iBaseClass == CLASS_DARK)
    {
        mu_swprintf(strEnergy, I18N::Game::SkillDamageD, 200);
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
    }
    if (iBaseClass == CLASS_DARK_LORD)
    {
        mu_swprintf(strEnergy, I18N::Game::SkillDamageD, 200 + (wEnergy / 20));
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
    }

    if (iBaseClass == CLASS_RAGEFIGHTER)
    {
        mu_swprintf(strEnergy, I18N::Game::DivineDamageRoarSlasherD, 50 + (wEnergy / 10));
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
        mu_swprintf(strEnergy, I18N::Game::AOEDamageDarkSideD, 100 + (wDexterity / 8 + wEnergy / 10));
        model.eneLines.push_back({ StringUtils::WideToNarrow(strEnergy), "base" });
    }
    m_RmlView.MarkDirty("ene_lines");

    if (iBaseClass == CLASS_DARK_LORD)
    {
        WORD wCharisma;

        wCharisma = CharacterAttribute->Charisma + CharacterAttribute->AddCharisma;

        const char* charismaSource = AttributeSource(g_isCharacterBuff((&Hero->Object), eBuff_SecretPotion5),
                                                     CharacterAttribute->AddCharisma != 0);

        wchar_t strCharisma[256];
        mu_swprintf(strCharisma, L"%d", wCharisma);
        SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::cmdValueText, "cmd_value_text",
                  StringUtils::WideToNarrow(strCharisma));
        SyncField(m_RmlView.Binder(), &CharacterInfoRmlModel::cmdValueSource, "cmd_value_source", Rml::String(charismaSource));
    }
}
