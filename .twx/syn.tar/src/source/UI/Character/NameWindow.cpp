
#include "stdafx.h"
#include "Core/Utilities/FrameProfiler.h"
#include "UI/Scaling/UITransform.h"
#include "UI/Chat/Chat.h"
#include "UI/Character/NameWindow.h"
#include "UI/Character/WorldNameRules.h"
#include "MUHelper/MuHelper.h"
#include "Render/Models/ZzzBMD.h"
#include "Engine/Object/ZzzObject.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Engine/Object/ZzzInterface.h"
#include "Engine/Object/ZzzInventory.h"
#include "GameLogic/Events/CSChaosCastle.h"
#include "GameLogic/Items/PersonalShopTitleImp.h"
#include "GameLogic/Events/MatchEvent.h"
#include "World/MapInfra/MapManager.h"
#include "Camera/CameraProjection.h"
#include "Camera/CameraState.h"
#include "UI/Combat/MonsterHealthBar.h"
#include "UI/HUD/HudStatus.h"
#include "World/GameMaps/GMBattleCastle.h"
#include "World/GameMaps/GMHellas.h"
#include "World/GameMaps/GM_Kanturu_3rd.h"
#include "Render/Text/CUIRenderText.h"

// DevEditor forward declarations (must be at global scope)
#ifdef _EDITOR
extern "C" bool DevEditor_ShouldRenderItemLabels();
#endif

using namespace SEASON3B;
using namespace mu::ui::window;

namespace
{

// Draws a segmented monster HP bar centered on centerX/topY; steps sets segment count, scale compresses width.
void DrawHealthBar(int centerX, int topY, float health, int steps, float scale)
{
    const float borderHeight = 2.f;                  // vertical inset (unscaled)
    const float borderWidth = 2.f * scale;           // horizontal inset
    const float stepSeparatorWidth = 1.f * scale;    // gap between segments
    const float segmentSpan = 80.f * scale;          // total span of the segment track
    const float widthPerStep = segmentSpan / steps;  // derived: fewer steps -> wider segments
    const float stepsWidth = segmentSpan - 2.f * stepSeparatorWidth;
    const float totalWidth = stepsWidth + borderWidth * 2.f;

    const int x = centerX - (int)(totalWidth / 2);
    const int y = topY;

    // Drop shadow.
    EnableAlphaTest();
    RenderColorQuadARGB((float)(x + 1), (float)(y + 1), totalWidth, 5.f, 0x80000000u);

    // Dark backing.
    EnableAlphaBlend();
    RenderColorQuadARGB((float)x, (float)y, totalWidth, 5.f, 0xFF330000u);

    // Inner track.
    RenderColorQuadARGB((float)(x + borderWidth), (float)(y + borderHeight), stepsWidth, 1.f,
        0xFF320A00u);

    // HealthStatus < 0 is the "unknown HP" sentinel; render a full bar for it instead of empty.
    const float clampedHealth = (health < 0.f) ? 1.f : health;
    const int stepHP = (int)(clampedHealth * steps);

    // Filled health segments.
    for (int k = 0; k < stepHP; ++k)
    {
        RenderColorQuadARGB(
            (float)(x + borderWidth + (k * widthPerStep)),
            (float)(y + borderHeight),
            widthPerStep - stepSeparatorWidth,
            2.f,
            0xFFFA0A00u);
    }
    DisableAlphaBlend();
}
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

mu::ui::window::CNameWindow::CNameWindow()
{
    m_pNewUIMng = NULL;

    m_bShowItemName = false;
    m_bShowMonsterHealthBar = false;
}

mu::ui::window::CNameWindow::~CNameWindow()
{
    Release();
}

bool mu::ui::window::CNameWindow::Create(CManager* pNewUIMng)
{
    if (NULL == pNewUIMng)
        return false;

    m_pNewUIMng = pNewUIMng;
    m_pNewUIMng->AddUIObj(mu::ui::window::INTERFACE_NAME_WINDOW, this);

    m_labelLayer.Create();

    Show(true);

    return true;
}

void mu::ui::window::CNameWindow::Release()
{
    m_labelLayer.Release();
    m_statusTexts.Release();
    m_matchStatus.Release();

    if (m_pNewUIMng)
    {
        m_pNewUIMng->RemoveUIObj(this);
        m_pNewUIMng = NULL;
    }
}

bool mu::ui::window::CNameWindow::UpdateMouseEvent()
{
    return true;
}

bool mu::ui::window::CNameWindow::UpdateKeyEvent()
{
    if (mu::ui::window::IsPress(VK_MENU) == true)
    {
        ToggleDropNames();
    }

    if (mu::ui::window::IsPress(VK_F8) == true)
    {
        m_bShowMonsterHealthBar = !m_bShowMonsterHealthBar;
    }

    return true;
}

bool mu::ui::window::CNameWindow::Update()
{
    return true;
}

void mu::ui::window::CNameWindow::Show(bool bShow)
{
    CObject::Show(bShow);
    if (!bShow)
    {
        m_labelLayer.Hide();
        m_statusTexts.Hide();
        m_matchStatus.Hide();
    }
}

void mu::ui::window::CNameWindow::PrepareFrame()
{
    FRAME_PROFILE(WorldLabels);
    m_statusTexts.Sync(IsVisible(), g_Camera.TopViewEnable == false);
    m_matchStatus.Sync(IsVisible());

    // Recorded before the windows render, with this frame's camera and selection; the document
    // sits under every window, as the original's depth-1.0 window did.
    if (!m_labelLayer.Create())
        return;

    m_labelLayer.BeginFrame();
    {
        // Everything here stands over the world, in the original's screen stretched over the window.
        const UI::Scaling::ScopedScreenStretch screen(static_cast<int>(WindowWidth), static_cast<int>(WindowHeight));
        Render::Renderer::Overlay2DRecordScope record(&m_labelLayer);
        // The main scene's overlays first, in its order: the original drew the Kalima object
        // labels and then RenderInterface()'s overlays (top view off only) before this window's
        // labels.
        RenderObjectDescription();
        if (g_Camera.TopViewEnable == false)
        {
            RenderPartyHP();
            battleCastle::RenderBuildTimes();
            M39Kanturu3rd::RenderKanturu3rdinterface();
        }
        RenderLabels();
    }
    m_labelLayer.EndFrame();
}

bool mu::ui::window::CNameWindow::RecordsInterfaceOverlays() const
{
    return IsVisible() && m_labelLayer.IsAvailable();
}

bool mu::ui::window::CNameWindow::Render()
{
    if (!m_labelLayer.IsAvailable())
        RenderLabels();
    return true;
}

void mu::ui::window::CNameWindow::RenderLabels()
{
    // Names and bars stand over the characters, in the original's screen stretched over the window.
    const UI::Scaling::ScopedScreenStretch screen(static_cast<int>(WindowWidth), static_cast<int>(WindowHeight));
    EnableAlphaTest();
    RenderName();
    matchEvent::RenderMatchTimes();
    UI::Chat::RenderBooleans();
    RenderMonsterHealthBars();
    DrawPersonalShopTitleImp();
    DisableAlphaBlend();
}

void mu::ui::window::CNameWindow::SyncMonsterTarget()
{
    const auto monsterKey = [](int index)
    {
        return index >= 0 && index < MAX_CHARACTERS_CLIENT && CharactersClient[index].Object.Kind == KIND_MONSTER
            ? CharactersClient[index].Key : -1;
    };
    m_monsterTargetKey = UI::Character::MonsterTargetKey(MUHelper::g_MuHelper.GetTargetKey(),
        monsterKey(SelectedCharacter), Attacking > 0 ? monsterKey(ActionTarget) : -1, m_monsterTargetKey);
    m_monsterTargetIndex = -1;
    for (int i = 0; i < MAX_CHARACTERS_CLIENT; ++i)
    {
        const auto& character = CharactersClient[i];
        if (character.Key == m_monsterTargetKey && character.Object.Kind == KIND_MONSTER &&
            character.Object.Live && character.Object.Visible && character.Dead == 0)
        { m_monsterTargetIndex = i; break; }
    }
    if (m_monsterTargetIndex < 0) m_monsterTargetKey = -1;
}

bool mu::ui::window::CNameWindow::IsMonsterNameShown(const CHARACTER* character) const
{
    return m_ShowMonsterNames && m_monsterTargetIndex >= 0 && character == &CharactersClient[m_monsterTargetIndex];
}

void mu::ui::window::CNameWindow::RenderMonsterTarget()
{
    if (!m_ShowMonsterNames || m_monsterTargetIndex < 0) return;
    const auto& target = CharactersClient[m_monsterTargetIndex];
    g_pRenderText->SetTextColor(255, 230, 200, 255);
    g_pRenderText->SetBgColor(100, 0, 0, 255);
    g_pRenderText->RenderText(320, 2, target.ID, 0, 0, RT3_WRITE_CENTER);
    if (UI::Combat::HealthBar::ShouldRenderSelected(target.HealthStatus))
        DrawHealthBar(320, 15, target.HealthStatus, 20, 1.f);
}

void mu::ui::window::CNameWindow::RenderCharacterNames()
{
    for (int index = 0; index < MAX_CHARACTERS_CLIENT; ++index)
    {
        auto& character = CharactersClient[index];
        const auto& object = character.Object;
        if (!object.Live || !object.Visible) continue;
        if ((object.Kind == KIND_PLAYER && m_ShowPlayerNames) || (object.Kind == KIND_MONSTER && IsMonsterNameShown(&character)))
            UI::Chat::CreateChat(character.ID, L"", &character);
    }

}

void mu::ui::window::CNameWindow::RenderGroundItemName(int index, bool sorted)
{
    m_labelLayer.SetGroundItems(true);
    RenderItemName(index, &Items[index].Object, &Items[index].Item, sorted);
    m_labelLayer.SetGroundItems(false);
}

void mu::ui::window::CNameWindow::RenderName()
{
    SyncMonsterTarget();
    RenderCharacterNames();
    RenderMonsterTarget();

    if (g_bGMObservation == true)
    {
        for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
        {
            CHARACTER* c = &CharactersClient[i];
            OBJECT* o = &c->Object;
            if (o->Live && o->Kind == KIND_PLAYER)
            {
                if (IsShopTitleVisible(c) == false)
                {
                    UI::Chat::CreateChat(c->ID, L"", c);
                }
            }
        }
    }

#ifndef GUILD_WAR_EVENT
    if (gMapManager.InChaosCastle() == true && (SelectedNpc != -1 || SelectedCharacter != -1))
    {
        return;
    }
#endif//GUILD_WAR_EVENT

    if (SelectedItem != -1 || SelectedNpc != -1 || SelectedCharacter != -1)
    {
        if (SelectedNpc != -1)
        {
            CHARACTER* c = &CharactersClient[SelectedNpc];
            OBJECT* o = &c->Object;
            UI::Chat::CreateChat(c->ID, L"", c);
        }
        else if (SelectedCharacter != -1)
        {
            CHARACTER* c = &CharactersClient[SelectedCharacter];

            OBJECT* o = &c->Object;
            if (o->Kind != KIND_MONSTER)
#ifdef ASG_ADD_GENS_SYSTEM
#ifndef PBG_MOD_STRIFE_GENSMARKRENDER
                if (!::IsStrifeMap(World) || Hero->m_byGensInfluence == c->m_byGensInfluence)
#endif //PBG_MOD_STRIFE_GENSMARKRENDER
#endif	// ASG_ADD_GENS_SYSTEM
                {
                    if (IsShopTitleVisible(c) == false)
                    {
                        UI::Chat::CreateChat(c->ID, L"", c);
                    }
                }
        }
        else if (SelectedItem != -1)
        {
#ifdef _EDITOR
            if (DevEditor_ShouldRenderItemLabels())
#endif
                RenderGroundItemName(SelectedItem, false);
        }
    }

    if (m_bShowItemName || mu::ui::window::IsRepeat(VK_MENU))
    {
#ifdef _EDITOR
        bool renderLabels = DevEditor_ShouldRenderItemLabels();
#else
        bool renderLabels = true;
#endif

        if (renderLabels)
        {
            for (int i = 0; i < MAX_ITEMS; i++)
            {
                OBJECT* o = &Items[i].Object;
                if (o->Live)
                {
                    if (o->Visible && i != SelectedItem)
                    {
                        RenderGroundItemName(i, true);
                    }
                }
            }
        }
    }
}

void mu::ui::window::CNameWindow::RenderMonsterHealthBars()
{
    if (!m_bShowMonsterHealthBar)
        return;

    for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
    {
        CHARACTER* c = &CharactersClient[i];
        OBJECT* o = &c->Object;

        if (!o->Live || !o->Visible || o->Alpha <= 0.f || c->Dead > 0 || o->Kind != KIND_MONSTER)
            continue;

        vec3_t Position;
        Vector(o->Position[0], o->Position[1], o->Position[2] + o->BoundingBoxMax[2] + 60.f, Position);

        int ScreenX, ScreenY;
        vec3_t transformPos;
        VectorTransform(Position, g_Camera.Matrix, transformPos);
        if (transformPos[2] >= 0)
            continue;

        CameraProjection::WorldToScreen(g_Camera, Position, &ScreenX, &ScreenY);

        if (ScreenX < -100 || ScreenY < -100
            || ScreenX > (REFERENCE_WIDTH + 100)
            || ScreenY > (REFERENCE_HEIGHT + 100))
            continue;

        // Fixed at ~3/7 width with 8 segments so each stays close to the original thickness.
        DrawHealthBar(ScreenX, ScreenY, c->HealthStatus, 8, 3.f / 7.f);
    }
}

float mu::ui::window::CNameWindow::GetLayerDepth()
{
    return 1.0f;
}
