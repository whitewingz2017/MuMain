#pragma once

// Story 5.1.1: MuAudio Abstraction Layer [VS1-AUDIO-ABSTRACT-CORE]
// Concrete miniaudio backend implementing IPlatformAudio.
// Uses ma_engine for mixing and ma_sound for individual sound/music playback.
//
// INCLUDE ISOLATION NOTE (MEDIUM-2 fix, code-review-finalize 2026-03-19):
// miniaudio.h (95k lines) is included directly in this header because ma_engine
// and ma_sound require full type definitions for stack-allocated private members.
// A true PIMPL pattern (std::unique_ptr<Impl>) would isolate the include but
// requires heap allocation. That refactor is deferred to Story 5.2.x (future).
// Current workaround: MiniAudioImpl.cpp (Story 5.1.1) isolates MINIAUDIO_IMPLEMENTATION
// via SKIP_PRECOMPILE_HEADERS ON so the 95k-line implementation block is not
// included by the PCH. The header include below is intentional and known.
// Do NOT add #include "miniaudio.h" to callers of MiniAudioBackend.h.

#include "Core/Platform/IPlatformAudio.h"

// miniaudio.h required for ma_engine and ma_sound full type definitions.
// See isolation note above — this include is the known limitation tracked for 5.2.x.
#include "miniaudio.h"

#include <array>
#include <string>
#include <vector>

namespace mu
{

// [Story 7-6-7: AC-6] Enumerate playback device names via miniaudio.
// Isolated here to keep miniaudio.h out of ErrorReport.cpp.
std::vector<std::string> GetAudioDeviceNames();

class MiniAudioBackend : public IPlatformAudio
{
public:
    MiniAudioBackend() = default;
    ~MiniAudioBackend() override;

    // Lifecycle
    [[nodiscard]] bool Initialize() override;
    void Shutdown() override;

    // Sound effects
    void LoadSound(ESound buffer, const wchar_t* filename, int channels = MAX_CHANNEL, bool enable3D = false) override;
    [[nodiscard]] bool PlaySound(ESound buffer, const void* pObject = nullptr, bool looped = false) override;
    void StopSound(ESound buffer, bool resetPosition) override;
    void AllStopSound() override;
    void ReleaseSound(ESound buffer) override;
    void Set3DSoundPosition(const void* listener = nullptr) override;
    void SetVolume(ESound buffer, long vol) override;
    void SetMasterVolume(long vol) override;

    // Music
    void PlayMusic(const char* name, bool enforce) override;
    void StopMusic(const char* name, bool enforce) override;
    [[nodiscard]] bool IsEndMusic() override;
    [[nodiscard]] int GetMusicPosition() override;

    // Volume controls (Story 5.4.1)
    void SetBGMVolume(float level) override;
    void SetSFXVolume(float level) override;
    [[nodiscard]] float GetBGMVolume() const override;
    [[nodiscard]] float GetSFXVolume() const override;

private:
    // Convert DirectSound volume (dB * 100, range -10000..0) to linear 0.0..1.0
    static float DbToLinear(long dsVol);
    void PositionSound(int buffer, ma_sound* sound, const void* object);

    bool HasFailedMusicTrack(const char* name) const;
    bool StartMusicStream(const std::string& identity);
    void ReleaseMusicStream();

    ma_engine m_engine{};

    // Per-sound polyphonic slots: [ESound index][channel index]
    // MAX_BUFFER is the last ESound enum entry — used as the array size.
    std::array<std::array<ma_sound, MAX_CHANNEL>, MAX_BUFFER> m_sounds{};
    std::array<bool, MAX_BUFFER> m_soundLoaded{};
    std::array<int, MAX_BUFFER> m_activeChannel{};
    std::array<bool, MAX_BUFFER> m_sound3DEnabled{};
    // CRITICAL-1 fix: tracks how many polyphonic slots were actually initialised by
    // LoadSound(). PlaySound/StopSound/AllStopSound must iterate only these slots —
    // iterating all MAX_CHANNEL slots when numChannels < MAX_CHANNEL calls miniaudio
    // APIs on uninitialized ma_sound handles (UB).
    std::array<int, MAX_BUFFER> m_loadedChannels{};

    // Per-slot object pointer for per-frame 3D position updates (Story 5.2.2).
    // Stores the most recent pObject passed to PlaySound() for each 3D-enabled buffer slot.
    // Lifetime: game engine guarantees object outlives the attached sound (same assumption
    // as DirectSoundManager::attachedObjects in DSplaysound.cpp). Raw pointer is intentional —
    // adding lifetime management here would require an engine-wide refactor.
    // nullptr = no object attached to this slot (safe — Set3DSoundPosition() checks before deref).
    // Story 7.8.1: Changed from const OBJECT* to const void* for cross-platform portability.
    // Cast back to const OBJECT* in Set3DSoundPosition() when accessing position data.
    std::array<const void*, MAX_BUFFER> m_soundObjects{};

    float m_bgmVolume = 1.0f; // BGM volume: 0.0 (mute) to 1.0 (full) — Story 5.4.1
    float m_sfxVolume = 1.0f; // SFX volume: 0.0 (mute) to 1.0 (full) — Story 5.4.1

    ma_sound m_musicSound{};
    bool m_musicLoaded = false;
    // Separators-normalized track name, not the resolved path — see IsSameMusicTrack().
    std::string m_currentMusicName;
    // Session failures survive stop calls and track changes; enforced playback retries them.
    std::vector<std::string> m_failedMusicNames;
    bool m_initialized = false;
};

} // namespace mu
