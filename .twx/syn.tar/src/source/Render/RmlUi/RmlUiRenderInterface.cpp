#include "stdafx.h"
#include "RmlUiRenderInterface.h"

#include "Render/Renderer/MuRenderer.h"
#include "Render/Sprites/GlobalBitmap.h"
#include "Core/Globals/_TextureIndex.h"
#include "Core/Utilities/StringUtils.h"
#include <algorithm>
#include <filesystem>

namespace
{
std::wstring BitmapPath(std::string path)
{
    std::replace(path.begin(), path.end(), '/', '\\');
    return StringUtils::NarrowToWide(path);
}
} // namespace

RmlUiRenderInterface::RmlUiRenderInterface(SDL_GPUDevice* device, SDL_Window* window)
    : RenderInterface_SDL_GPU(device, window)
{
}

Rml::TextureHandle RmlUiRenderInterface::LoadTexture(Rml::Vector2i& texture_dimensions, const Rml::String& source)
{
    // Native drawing rendered into a texture this engine owns, not a file.
    void* raw = nullptr;
    int width = 0;
    int height = 0;
    if (m_ResolveTextureSource && m_ResolveTextureSource(source, raw, width, height))
    {
        if (!raw)
            return 0;
        texture_dimensions = {width, height};
        const auto handle = reinterpret_cast<Rml::TextureHandle>(raw);
        m_RenderTargetHandles.insert(handle);
        return handle;
    }

    return LoadFileTexture(texture_dimensions, source);
}

Rml::TextureHandle RmlUiRenderInterface::LoadFileTexture(Rml::Vector2i& texture_dimensions, const Rml::String& source)
{
    const std::string normalized = m_ResolveTextureFile ? m_ResolveTextureFile(source) : source;
    if (normalized.empty())
        return 0;

    // SDL_image decodes plain PNGs and premultiplies their alpha; the legacy cache only reads OZJ/OZT.
    const std::string extension = std::filesystem::path(normalized).extension().string();
    if (SDL_strcasecmp(extension.c_str(), ".png") == 0)
        return RenderInterface_SDL_GPU::LoadTexture(texture_dimensions, normalized);

    // Routed through CGlobalBitmap (the same ref-counted, OZJ/OZT-aware pipeline every other
    // texture in the game uses -- GlobalBitmap.cpp) rather than the base class's own LoadTexture
    // (which reads the file directly via Rml::FileInterface + SDL_image's generic format
    // sniffing). This is required, not just a cache-sharing convenience: this game's actual art
    // assets are almost entirely OZT/OZJ, a custom container format SDL_image has no reader for,
    // so the base class's own LoadTexture cannot load any of this game's existing images at all.
    //
    // RML/RCSS conventionally author asset paths with forward slashes; every existing in-tree
    // caller of Bitmaps.LoadImage passes backslash-separated paths (e.g. "Interface\\Foo.jpg"),
    // matching this codebase's own path-handling convention -- normalize rather than assume
    // forward-slash tolerance extends to this legacy loader too.
    const std::wstring wpath = BitmapPath(normalized); // Rml::String is std::string (RmlUi/Config/Config.h)
    // LoadImageExclusive, NOT LoadImage: this handle is cached indefinitely (by RmlUi's compiled
    // geometry, and by m_FileBackedBitmapIndexByHandle below) for as long as the document lives,
    // which today is the whole process -- but plain LoadImage() would find-and-share an existing
    // numbered-slot entry if the same file is already resident there (e.g. login_back.tga at
    // BITMAP_LOG_IN+7, preloaded unconditionally by ZzzOpenData.cpp). That slot gets *force*-
    // reassigned to a completely different file whenever another scene claims it
    // (ReleaseLogoSceneData() -> OpenCharacterSceneData() both touch BITMAP_LOG_IN.. BITMAP_LOG_IN_END
    // unconditionally) -- invalidating this cached raw SDL_GPUTexture* out from under RmlUi with
    // no notification, and no way for RmlUi to know to recompile the geometry that references it
    // (symptom: return to the login screen and the panel renders garbled, then crashes).
    // LoadImageExclusive always creates its own independent entry, immune to any other scene's
    // slot churn, at the cost of a small amount of duplicate VRAM for these two small UI textures.
    //
    // RmlUi composites premultiplied (RenderInterface_SDL_GPU's blend state is ONE,
    // ONE_MINUS_SRC_ALPHA, and its own LoadTexture premultiplies every file before
    // GenerateTexture()); the game's files are straight alpha, so a transparent pixel with a
    // non-black colour would be added at full strength (the mini map's markers drew white squares).
    // The loader premultiplies this exclusive copy -- native rendering never samples it -- before
    // the upload: for upscaled art the uploaded image is larger than bmp->Width x bmp->Height, so
    // it cannot be premultiplied here.
    constexpr bool PadToPowerOfTwo = false;
    constexpr bool PremultiplyAlpha = true;
    const GLuint bitmapIndex =
        Bitmaps.LoadImageExclusive(wpath, GL_LINEAR, GL_CLAMP_TO_EDGE, PadToPowerOfTwo, PremultiplyAlpha);
    if (bitmapIndex == BITMAP_UNKNOWN) return 0;

    BITMAP_t* bmp = Bitmaps.GetTexture(bitmapIndex);
    if (!bmp) return 0;

    // BITMAP_t::TextureNumber is GLuint-typed for legacy naming continuity, but on this backend
    // it holds CGlobalBitmap's own logical texture id (set from CreateTexture()'s return value,
    // GlobalBitmap.cpp) -- not a real GL name. Resolve it to the raw SDL_GPUTexture* the base
    // class's RenderGeometry/command-replay code expects as a TextureHandle.
    void* rawTexture = mu::GetRenderer().GetRawTexture(static_cast<std::uint32_t>(bmp->TextureNumber));
    if (!rawTexture) return 0;

    texture_dimensions = { static_cast<int>(bmp->Width), static_cast<int>(bmp->Height) };
    const auto handle = reinterpret_cast<Rml::TextureHandle>(rawTexture);
    m_FileBackedBitmapIndexByHandle.emplace(handle, static_cast<std::uint32_t>(bitmapIndex));
    return handle;
}

void RmlUiRenderInterface::ReleaseTexture(Rml::TextureHandle texture_handle)
{
    if (m_RenderTargetHandles.erase(texture_handle) != 0)
        return;

    auto it = m_FileBackedBitmapIndexByHandle.find(texture_handle);
    if (it != m_FileBackedBitmapIndexByHandle.end())
    {
        // Ref-counted; frees the shared bitmap (and its GPU texture, via CGlobalBitmap's own
        // teardown path) only once every other reference has also released it. Must NOT also
        // queue the base class's SDL_ReleaseGPUTexture command below -- that texture is owned
        // by this engine's shared cache, not by this RenderInterface.
        Bitmaps.UnloadImage(static_cast<GLuint>(it->second), /*bForce=*/false);
        m_FileBackedBitmapIndexByHandle.erase(it);
        return;
    }

    // Not a FileBacked handle -- one of the base class's own textures (GenerateTexture's font/
    // glyph atlases). Let it manage that lifetime itself.
    RenderInterface_SDL_GPU::ReleaseTexture(texture_handle);
}
