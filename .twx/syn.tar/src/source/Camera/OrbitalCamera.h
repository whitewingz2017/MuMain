#pragma once

#include "ICamera.h"
#include "CameraState.h"
#include "DefaultCamera.h"
#include "Engine/Object/CullingConstants.h"
#include <memory>

/**
 * @brief Orbital camera - spherical coordinates around character
 *
 * Features:
 * - Middle mouse drag to rotate (yaw + pitch)
 * - Mouse wheel to zoom (radius)
 * - Maintains character focus
 * - Available in all builds
 */
class OrbitalCamera : public ICamera
{
public:
    OrbitalCamera(CameraState& state);
    ~OrbitalCamera() override = default;

    // ICamera interface
    bool Update() override;
    void Reset() override;
    void OnActivate(const CameraState& previousState) override;
    void OnDeactivate() override;
    void ResetView() override;
    const char* GetName() const override { return "Orbital"; }
    bool DescribeState(wchar_t* text, std::size_t textSize) const override;

    // Phase 5: Scene-specific reset
    void ResetForScene(EGameScene scene);

    // Public accessors for UI
    void ApplyTouchGesture(float zoomRatio, float yawDegrees, float pitchDegrees);
    float GetRadius() const { return m_Radius; }
    float GetTotalYaw() const { return m_BaseYaw + m_DeltaYaw; }
    float GetTotalPitch() const { return m_BasePitch + m_DeltaPitch; }

    // Phase 5: Public accessor for debug display
    void GetTargetPosition(vec3_t outTarget) const;

    // Phase 1: Configuration & Frustum Management
    const CameraConfig& GetConfig() const override { return m_Config; }
    void SetConfig(const CameraConfig& config) override;
    const Frustum& GetFrustum() const override { return m_Frustum; }

    bool ShouldCullObject(const vec3_t position, float radius) const override
    {
        return !m_Frustum.TestSphere(position, radius);
    }

    bool ShouldCullTerrain(int tileX, int tileY) const override
    {
        // Use cheap 2D ground-plane projection test for terrain
        // (same algorithm as original TestFrustrum2D, ~4 cross-products vs 6-plane sphere test)
        return !m_Frustum.TestPoint2D(tileX + 0.5f, tileY + 0.5f, -40.0f);
    }

    bool ShouldCullObject2D(float x, float y, float radius) const override
    {
        // Use 3D frustum sphere test instead of 2D ground projection
        vec3_t position;
        position[0] = x;
        position[1] = y;
        position[2] = 0.0f;  // Objects on ground
        return !m_Frustum.TestSphere(position, radius);
    }

private:
    CameraState& m_State;
    std::unique_ptr<DefaultCamera> m_pDefaultCamera;  // Internal default camera for base calculation

    // Phase 1: Configuration and frustum
    CameraConfig m_Config;
    Frustum m_Frustum;

    // Orbital parameters
    vec3_t m_InitialCameraOffset;  // Saved offset from character on first frame
    bool m_bInitialOffsetSet;      // Has initial offset been captured?
    vec3_t m_Target;              // Orbit center (character position)
    float m_BaseYaw;              // Initial yaw when activated
    float m_BasePitch;            // Initial pitch when activated
    float m_DeltaYaw;             // User rotation delta from base
    float m_DeltaPitch;           // User pitch delta from base
    float m_Radius;               // Distance from target

    // Phase 5: Scene transition tracking
    int m_LastSceneFlag;          // Track scene changes to reset target
    bool m_bJustActivated;        // Skip DefaultCamera update on first frame after activation

    // Mount offset that was baked into the inherited position at activation time.
    // We subtract this so only the DELTA is applied, avoiding double-offset.
    float m_ActivationMountOffset = 0.0f;

    // Constraints
    static constexpr float MIN_PITCH = -80.0f;  // Look down limit
    static constexpr float MAX_PITCH = 80.0f;   // Look up limit
    // Radius values are absolute camera-to-Hero distances in world units.
    // ComputeCameraTransform normalizes the captured offset direction and
    // scales it to m_Radius, so what you set here is what you get on screen.
    // DEFAULT_RADIUS is also the "neutral" radius for UpdateConfigForView's
    // far-plane / zoom-lift scaling — at this radius, scale = 1.
    // Default cam at level 3 (1300 body distance + 1150 Z-lift) gives an
    // actual camera-to-Hero distance of ~sqrt(919² + 919² + 1150²) ≈ 1735.
    // DEFAULT matches that so orbital starts at exactly the Default cam's
    // position. MIN/MAX bracket how far the player can move from there.
    static constexpr float MIN_RADIUS = 600.0f;
    static constexpr float MAX_RADIUS = 3000.0f;
    static constexpr float DEFAULT_RADIUS = 1735.0f;

    // Input state (middle-mouse drag tracking)
    struct InputState
    {
        bool Rotating = false;             // Middle mouse button held?
        int LastMouseX = 0;
        int LastMouseY = 0;
        float LastEffectivePitch = 0.0f;   // Last effective pitch applied (after constraints)
    } m_Input;

    // Helper methods
    void HandleInput();
    void UpdateTarget();
    void ComputeCameraTransform();
    void UpdateFrustum();  // Phase 1: Rebuild frustum from current state
    void UpdateConfigForView();  // Phase 1: Adjust config based on zoom level and pitch

    // OnActivate / ResetForScene helpers
    void LoadConfigForScene(EGameScene scene);
    void ApplyConfigToState();
    void CalculateOrbitOriginForStaticScene(EGameScene scene, const CameraState& previousState);
    void CalculateLookAtPoint(EGameScene scene, vec3_t outLookAt) const;
    void InitializeOrbitalFromCurrentState(const vec3_t lookAtPoint, const CameraState& previousState);
    void SyncStateToGlobalCamera();

    // Phase 5: Hero validity check (private)
    bool IsHeroValid() const;
};
