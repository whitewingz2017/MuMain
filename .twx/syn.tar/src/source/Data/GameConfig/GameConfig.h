#pragma once

#include <filesystem>
#include <string>
#include <vector>
#include <utility>
#include "Core/Platform/WinCompat.h"
#include "Data/GameConfig/GameConfigValidation.h"

class GameConfig
{
public:
    static GameConfig& GetInstance();

    void Load();
    void Save();

    // config.ini beside the executable. Its [EnhancedTuning] section is read and written on its own
    // (Data/GameConfig/PersonalTuning.h); Save() leaves it as it is.
    const std::filesystem::path& GetConfigPath() const
    {
        return m_configPath;
    }

    // Window
    int  GetWindowWidth()  const { return m_windowWidth; }
    int  GetWindowHeight() const { return m_windowHeight; }
    bool GetWindowMode()   const { return m_windowMode; }

    void SetWindowSize(int width, int height);
    void SetWindowMode(bool windowed);

    // Audio — volume 0 = off, >0 = on. No separate Enabled flag.
    int  GetSoundVolume()  const { return m_soundVolume; }
    int  GetMusicVolume()  const { return m_musicVolume; }

    void SetSoundVolume(int level);
    void SetMusicVolume(int level);

    // Login
    bool GetRememberMe() const { return m_rememberMe; }
    void SetRememberMe(bool remember);

    // Whether the password (not just the username) may be persisted. Off by
    // default: "remember me" saves only the username unless the player opts in
    // on a machine they trust.
    bool GetSavePassword() const { return m_savePassword; }
    void SetSavePassword(bool save);

    // Drops the saved username and password from config.ini and revokes the
    // save-password consent. Used when the player edits the credentials.
    void ClearCredentials();
    std::vector<std::wstring> GetSavedAccountNames();
    bool SelectSavedAccount(std::size_t index, std::wstring& user, std::wstring& password);
    void ForgetSavedAccount(const std::wstring& user, bool passwordOnly = false);

    std::wstring GetLanguageSelection() const { return m_languageSelection; }
    void SetLanguageSelection(const std::wstring& lang);

    void SetEncryptedUsername(const std::wstring& encryptedUsername);
    std::wstring GetEncryptedUsername() const { return m_encryptedUsername; }

    void SetEncryptedPassword(const std::wstring& encryptedPassword);
    std::wstring GetEncryptedPassword() const { return m_encryptedPassword; }

    // Connection
    std::wstring GetServerIP() const { return m_serverIP; }
    int GetServerPort() const { return m_serverPort; }

    void SetServerIP(const std::wstring& ip);
    void SetServerPort(int port);

    // UI — I18N locale code ("en", "de", ...) for the typed translation
    // accessors. Distinct from GetLanguageSelection above, which is the
    // legacy "Eng"/"Por"/"Spn" data-dir prefix used by .bmd asset loaders.
    std::wstring GetUILocale() const { return m_uiLocale; }
    void SetUILocale(const std::wstring& locale);

    // Whether item names are shown in the UI language (GetUILocale); off keeps them English
    // while the rest of the UI stays translated.
    bool GetTranslateItemNames() const
    {
        return m_translateItemNames;
    }
    void SetTranslateItemNames(bool translate);

    // UI font family name (GDI face name). Empty = platform default.
    std::wstring GetFontSelection() const { return m_fontSelection; }
    void SetFontSelection(const std::wstring& font);

    // Active RmlUi theme name ("legacy"/"modern") -- see UI::RmlBridge::RmlTheme.
    std::wstring GetRmlTheme() const { return m_rmlTheme; }
    void SetRmlTheme(const std::wstring& theme);

    // Global RmlUi UI scale, as a percentage (100 = normal). Drives RmlUiRuntime's
    // Context::SetDensityIndependentPixelRatio() call; only RCSS authored in `dp` responds. The
    // setter clamps to [CfgDefaults::CfgMinUIScalePercent, CfgDefaults::CfgMaxUIScalePercent];
    // a value read from disk is taken as-is, so a hand-edited config.ini stays authoritative
    // until something writes the setting back.
    int GetUIScalePercent() const { return m_uiScalePercent; }
    void SetUIScalePercent(int percent);
    int GetChatTextScalePercent() const { return m_chatTextScalePercent; }
    void SetChatTextScalePercent(int percent);

    // Chat commands - the favourites and the named templates of the command
    // window. They belong to the installation, not to a character.
    // A template is stored as "name|command|value|value|...".
    const std::vector<std::wstring>& GetChatCommandFavourites() const
    {
        return m_chatCommandFavourites;
    }
    void SetChatCommandFavourites(const std::vector<std::wstring>& favourites);

    const std::vector<std::wstring>& GetChatCommandTemplates() const
    {
        return m_chatCommandTemplates;
    }
    void SetChatCommandTemplates(const std::vector<std::wstring>& templates);

    // Camera
    int GetZoom() const { return m_zoom; }
    void SetZoom(int zoom);

    // Render
    bool GetSortParticleDraws() const { return m_sortParticleDraws; }
    bool GetVSyncEnabled() const { return m_vsyncEnabled; }
    void SetVSyncEnabled(bool enabled);
    // The look preset ([Render] Look).
    LookPreset GetLook() const
    {
        return m_look;
    }
    void SetLook(LookPreset look);
    int GetAnisotropy() const
    {
        return m_anisotropy;
    }
    void SetAnisotropy(int anisotropy);
    // Samples per pixel: 0 (off), 2, 4 or 8.
    int GetAntialiasing() const
    {
        return m_antialiasing;
    }
    void SetAntialiasing(int samples);
    bool GetLowWorldTextures() const { return m_lowWorldTextures; }
    void SetLowWorldTextures(bool enabled) { m_lowWorldTextures = enabled; }
    bool GetEnhancedLighting() const { return m_enhancedLighting; }
    void SetEnhancedLighting(bool enabled) { m_enhancedLighting = enabled; }
    bool GetDynamicLights() const { return m_dynamicLights; }
    void SetDynamicLights(bool enabled) { m_dynamicLights = enabled; }
    bool GetLightMood() const { return m_lightMood; }
    void SetLightMood(bool enabled) { m_lightMood = enabled; }
    bool GetPostProcessing() const { return m_postProcessing; }
    void SetPostProcessing(bool enabled) { m_postProcessing = enabled; }

    // DXP-23's per-system effect-cost toggles, promoted from console-only ($effects ...)
    // diagnostics to persisted, in-game-options-exposed settings -- see MainScene.h's
    // SetDisableEffects/SetDisableParticles/SetDisableSkillEffectModels/SetDisableBoids/
    // SetDisableWingShadow for what each one actually gates.
    bool GetDisableEffects() const { return m_disableEffects; }
    void SetDisableEffects(bool disabled);
    bool GetDisableParticles() const { return m_disableParticles; }
    void SetDisableParticles(bool disabled);
    bool GetDisableSkillEffectModels() const { return m_disableSkillEffectModels; }
    void SetDisableSkillEffectModels(bool disabled);
    bool GetDisableBoids() const { return m_disableBoids; }
    void SetDisableBoids(bool disabled);
    bool GetDisableWingShadow() const { return m_disableWingShadow; }
    void SetDisableWingShadow(bool disabled);
    bool GetDisableBodyShadows() const { return m_disableBodyShadows; }
    void SetDisableBodyShadows(bool disabled);

    // User-chosen FPS cap when VSync is off; -1 = uncapped. Same promotion story as the toggles
    // above, this time for the console-only `$fps <N>` diagnostic (SceneManager::SetTargetFps).
    int GetFpsCap() const { return m_fpsCap; }
    void SetFpsCap(int fps);

    // Active texture pack (a folder in Data/TexturePacks), empty for the original textures. The
    // loader reads it once at startup, so a change takes effect after a restart.
    std::wstring GetTexturePack() const
    {
        return m_texturePack;
    }
    void SetTexturePack(const std::wstring& pack);

    // GPU backend override -- "default"/"vulkan"/"direct3d12"/"metal". Manual config.ini edit
    // only, same as GetSortParticleDraws() above: no setter, no in-game options-window exposure.
    std::wstring GetRenderBackend() const { return m_renderBackend; }

    // [UI] EnableAnimationTaskPool: manual config.ini edit only, like the two above.
    bool GetEnableAnimationTaskPool() const { return m_enableAnimationTaskPool; }

    // Helpers
    static std::wstring BinaryToHex(const BYTE* data, DWORD size);
    static std::vector<BYTE> HexToBinary(const std::wstring& hex);

    void DecryptCredentials(wchar_t* outUser, wchar_t* outPass, size_t userBufSize, size_t passBufSize);
    void EncryptAndSaveCredentials(const wchar_t* user, const wchar_t* pass);

private:
    GameConfig();
    GameConfig(const GameConfig&) = delete;
    GameConfig& operator=(const GameConfig&) = delete;

    void LoadSavedAccounts();
    void SaveSavedAccounts();
    void RememberCurrentAccount();
    std::vector<std::pair<std::wstring, std::wstring>> m_savedAccounts;
    std::filesystem::path m_configPath;

    int  m_windowWidth;
    int  m_windowHeight;
    bool m_windowMode;

    int  m_soundVolume;
    int  m_musicVolume;

    std::vector<std::wstring> m_chatCommandFavourites;
    std::vector<std::wstring> m_chatCommandTemplates;

    bool m_rememberMe;
    bool m_savePassword;
    std::wstring m_languageSelection;
    std::wstring m_encryptedUsername;
    std::wstring m_encryptedPassword;

    std::wstring m_serverIP;
    int m_serverPort;

    std::wstring m_uiLocale;
    bool m_translateItemNames;
    std::wstring m_fontSelection;
    std::wstring m_rmlTheme;
    int m_uiScalePercent;
    int m_chatTextScalePercent;
    bool m_enableAnimationTaskPool;

    int m_zoom;
    bool m_sortParticleDraws;
    bool m_vsyncEnabled;
    LookPreset m_look;
    bool m_lowWorldTextures = false;
    int m_anisotropy;
    int m_antialiasing;
    bool m_enhancedLighting;
    bool m_dynamicLights;
    bool m_lightMood;
    bool m_postProcessing;
    std::wstring m_renderBackend;
    bool m_disableEffects;
    bool m_disableParticles;
    bool m_disableSkillEffectModels;
    bool m_disableBoids;
    bool m_disableWingShadow;
    bool m_disableBodyShadows;
    int m_fpsCap;
    std::wstring m_texturePack;

    int ReadInt(const wchar_t* section, const wchar_t* key, int defaultValue) const;
    void WriteInt(const wchar_t* section, const wchar_t* key, int value);

    bool ReadBool(const wchar_t* section, const wchar_t* key, bool defaultValue) const;
    void WriteBool(const wchar_t* section, const wchar_t* key, bool value);

    std::vector<std::wstring> ReadStringList(const wchar_t* section, const wchar_t* keyPrefix);
    void WriteStringList(const wchar_t* section, const wchar_t* keyPrefix, const std::vector<std::wstring>& values);
    std::wstring ReadString(const wchar_t* section, const wchar_t* key, const std::wstring& defaultValue);
    void WriteString(const wchar_t* section, const wchar_t* key, const std::wstring& value);

    void RemoveObsoleteKey(const wchar_t* section, const wchar_t* key);
    void RemoveObsoleteSection(const wchar_t* section);

    std::wstring DecryptSetting(const std::wstring& hexInput);
    std::wstring EncryptSetting(const wchar_t* input);
};

// The [Render] Look of a config.ini as GameConfig::Load reads it.
LookPreset ReadLookPreset(const std::filesystem::path& configFile);
