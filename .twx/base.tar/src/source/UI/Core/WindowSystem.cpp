#include "stdafx.h"
#include "UI/Core/WindowSystem.h"
#include "UI/Dialogs/MessageBox.h"
#include "UI/RmlBridge/RmlTheme.h"
#include "UI/Scaling/UITransform.h"

#include "GameLogic/Items/PersonalShopTitleImp.h"
#include "World/MapInfra/MapManager.h"
#include "Scenes/SceneCore.h"
#include "UI/Placement/WindowPlacement.h"
#include "UI/Social/SocialWorkspace.h"
#include "UI/Inventory/CursorItemLayer.h"

// Defined in Winmain.cpp; only ever declared at file scope (see MainScene.cpp).
extern int LoadingWorld;

using namespace SEASON3B;
using namespace mu::ui::window;

namespace
{
    bool IsHeroPositionLayoutInterface(DWORD dwKey)
    {
        switch (dwKey)
        {
        case INTERFACE_INVENTORY:
        case INTERFACE_INVENTORY_EXT:
        case INTERFACE_STORAGE:
        case INTERFACE_STORAGE_EXT:
        case INTERFACE_CHARACTER:
        case INTERFACE_NPCSHOP:
        case INTERFACE_MIXINVENTORY:
        case INTERFACE_TRADE:
        case INTERFACE_MYSHOP_INVENTORY:
        case INTERFACE_PURCHASESHOP_INVENTORY:
            return true;
        default:
            return false;
        }
    }
}

CSystem::CSystem()
{
    m_pNewUIMng = nullptr;
    m_pNewUIHotKey = nullptr;
    m_pNewChatLogWindow = nullptr;
    m_pNewSystemLogWindow = nullptr;
    m_pNewSlideWindow = nullptr;
    m_pNewGuildMakeWindow = nullptr;
    m_pNewFriendWindow = nullptr;
    m_pNewMainFrameWindow = nullptr;
    m_pNewSkillList = nullptr;
    m_pNewChatInputBox = nullptr;
    m_pNewItemMng = nullptr;
    m_pNewMyInventory = nullptr;
    m_pNewMyInventoryExt = nullptr;
    m_pNewNPCShop = nullptr;
    m_pNewPetInfoWindow = nullptr;
    m_pNewMixInventory = nullptr;
    m_pNewCastleWindow = nullptr;
    m_pNewGuardWindow = nullptr;
    m_pNewGatemanWindow = nullptr;
    m_pNewGateSwitchWindow = nullptr;
    m_pNewStorageInventory = nullptr;
    m_pNewStorageInventoryExt = nullptr;
    m_pNewGuildInfoWindow = nullptr;
    m_pNewMyShopInventory = nullptr;
    m_pNewCharacterInfoWindow = nullptr;
    m_pNewPartyInfoWindow = nullptr;
    m_pNewPartyListWindow = nullptr;
    m_pNewNPCQuest = nullptr;
    m_pNewEnterBloodCastle = nullptr;
    m_pNewEnterDevilSquare = nullptr;
    m_pNewBloodCastle = nullptr;
    m_pNewTrade = nullptr;
    m_pNewKanturu2ndEnterNpc = nullptr;
    m_pNewCatapultWindow = nullptr;
    m_pNewChaosCastleTime = nullptr;
    m_pNewBattleSoccerScore = nullptr;
    m_pNewCommandWindow = nullptr;
    m_pNewWindowMenu = nullptr;
    m_pNewOptionWindow = nullptr;
    m_pMuHelperBar = nullptr;
    m_pMuHelperConfig = nullptr;
    m_pMuHelperSkillPicker = nullptr;
    m_pMuHelperDetail = nullptr;
    m_pNewHelpWindow = nullptr;
    m_pNewChatCommandWindow = nullptr;
    m_pNewItemExplanationWindow = nullptr;
    m_pNewSetItemExplanation = nullptr;
    m_pNewQuickCommandWindow = nullptr;
    m_pNewMoveCommandWindow = nullptr;
    m_pNewSiegeWarfare = nullptr;
    m_pNewItemEnduranceInfo = nullptr;
    m_pBuffStrip = nullptr;
    m_pNewCryWolfInterface = nullptr;
    m_pNewMaster_Level_Interface = nullptr;
    m_pNewCursedTempleResultWindow = nullptr;
    m_pNewCursedTempleWindow = nullptr;
    m_pNewCursedTempleEnterWindow = nullptr;
    m_pNewGoldBowman = nullptr;
    m_pNewGoldBowmanLena = nullptr;
    m_pNewLuckyCoinRegistration = nullptr;
    m_pNewExchangeLuckyCoinWindow = nullptr;
    m_pNewDuelWatchWindow = nullptr;
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    m_pNewInGameShop = nullptr;
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
    m_pNewDoppelGangerWindow = nullptr;
    m_pNewDoppelGangerFrame = nullptr;
    m_pNewNPCDialogue = nullptr;
    m_pNewQuestProgress = nullptr;
    m_pNewQuestProgressByEtc = nullptr;
    m_pNewEmpireGuardianNPC = nullptr;
    m_pNewEmpireGuardianTimer = nullptr;
    m_pNewMiniMap = nullptr;
#ifdef PBG_ADD_GENSRANKING
    m_pNewGensRanking = nullptr;
#endif //PBG_ADD_GENSRANKING
    m_pNewUnitedMarketPlaceWindow = nullptr;
}

CSystem::~CSystem()
{
    Release();
}

bool CSystem::Create()
{
    m_pNewUIMng = new CManager;

    m_pNewChatLogWindow = new CChatLogWindow;
    if (false == m_pNewChatLogWindow->Create(m_pNewUIMng, 6))
        return false;

    m_pNewSystemLogWindow = new CSystemLogWindow;
    if (false == m_pNewSystemLogWindow->Create(m_pNewUIMng))
        return false;

    m_pNewOptionWindow = new COptionWindow;
    if (m_pNewOptionWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewSlideWindow = new CSlideWindow;
    if (m_pNewSlideWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    if (g_MessageBox->Create(m_pNewUIMng) == false)
        return false;

    return true;
}

void CSystem::Release()
{
    if (m_pNewUIMng == nullptr)
    {
        return;
    }

    UnloadMainSceneInterface();
    UI::Items::ReleaseCursorItemLayer();
    UI::Placement::Release();
    g_MessageBox->Release();

    SAFE_DELETE(m_pNewSlideWindow);
    SAFE_DELETE(m_pNewOptionWindow);
    SAFE_DELETE(m_pNewChatLogWindow);
    SAFE_DELETE(m_pNewSystemLogWindow);

    m_pNewUIMng->RemoveAllUIObjs();

    SAFE_DELETE(m_pNewUIMng);
}

bool CSystem::CreateChatCommandWindow()
{
    m_pNewChatCommandWindow = new CChatCommandWindow;
    if (m_pNewChatCommandWindow->Create(m_pNewUIMng))
    {
        return true;
    }

    SAFE_DELETE(m_pNewChatCommandWindow);
    return false;
}

bool CSystem::LoadMainSceneInterface()
{
    g_MessageBox->Show(true);
    m_pNewChatLogWindow->Show(true);
    m_pNewSystemLogWindow->Show(true);
    m_pNewSlideWindow->Show(true);

    m_pNewItemMng = new CItemMng;

    m_pNewChatInputBox = new CChatInputBox;

    if (false == m_pNewChatInputBox->Create(m_pNewUIMng, m_pNewChatLogWindow, m_pNewSystemLogWindow))
    {
        return false;
    }

    SetFocus(g_hWnd);

    m_pNewUIHotKey = new CHotKey;
    if (false == m_pNewUIHotKey->Create(m_pNewUIMng))
        return false;

    m_pNewMainFrameWindow = new CMainFrameWindow;
    if (m_pNewMainFrameWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewSkillList = new CSkillList;
    if (m_pNewSkillList->Create(m_pNewUIMng) == false)
        return false;

    m_pNewFriendWindow = new CFriendWindow;
    if (m_pNewFriendWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewMyInventory = new CMyInventory;
    if (false == m_pNewMyInventory->Create(m_pNewUIMng))
        return false;

    m_pNewMyInventoryExt = new CInventoryExtension;
    if (false == m_pNewMyInventoryExt->Create(m_pNewUIMng))
        return false;

    m_pNewNPCShop = new CNPCShop;
    if (false == m_pNewNPCShop->Create(m_pNewUIMng))
        return false;

    m_pNewPetInfoWindow = new CPetInfoWindow;
    if (false == m_pNewPetInfoWindow->Create(m_pNewUIMng))
        return false;

    m_pNewMixInventory = new CMixInventory;
    if (m_pNewMixInventory->Create(m_pNewUIMng) == false)
        return false;

    m_pNewCastleWindow = new CCastleWindow;
    if (m_pNewCastleWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGuardWindow = new CGuardWindow;
    if (m_pNewGuardWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGatemanWindow = new CGatemanWindow;
    if (m_pNewGatemanWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGateSwitchWindow = new CGateSwitchWindow;
    if (m_pNewGateSwitchWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewStorageInventory = new CStorageInventory;
    if (m_pNewStorageInventory->Create(m_pNewUIMng) == false)
        return false;

    m_pNewStorageInventoryExt = new CStorageInventoryExt;
    if (m_pNewStorageInventoryExt->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGuildInfoWindow = new CGuildInfoWindow;
    if (m_pNewGuildInfoWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGuildMakeWindow = new CGuildMakeWindow;
    if (m_pNewGuildMakeWindow->Create(m_pNewUIMng) == false)
        return false;

    CreatePersonalItemTable();

    m_pNewMyShopInventory = new CMyShopInventory;
    if (m_pNewMyShopInventory->Create(m_pNewUIMng) == false)
        return false;

    m_pNewPurchaseShopInventory = new CPurchaseShopInventory;
    if (m_pNewPurchaseShopInventory->Create(m_pNewUIMng) == false)
        return false;

    m_pNewCharacterInfoWindow = new CCharacterInfoWindow;
    if (m_pNewCharacterInfoWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewMyQuestInfoWindow = new CMyQuestInfoWindow;
    if (m_pNewMyQuestInfoWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewPartyInfoWindow = new CPartyInfoWindow;
    if (m_pNewPartyInfoWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewPartyListWindow = new CPartyListWindow;
    if (m_pNewPartyListWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewNPCQuest = new CNPCQuest;
    if (m_pNewNPCQuest->Create(m_pNewUIMng) == false)
        return false;

    m_pNewEnterBloodCastle = new CEnterBloodCastle;
    if (m_pNewEnterBloodCastle->Create(m_pNewUIMng) == false)
        return false;

    m_pNewEnterDevilSquare = new CEnterDevilSquare;
    if (m_pNewEnterDevilSquare->Create(m_pNewUIMng) == false)
        return false;

    m_pNewBloodCastle = new CBloodCastle;
    if (m_pNewBloodCastle->Create(m_pNewUIMng) == false)
        return false;

    m_pNewTrade = new CTrade;
    if (m_pNewTrade->Create(m_pNewUIMng) == false)
        return false;

    m_pNewKanturu2ndEnterNpc = new CKanturu2ndEnterNpc;
    if (m_pNewKanturu2ndEnterNpc->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewKanturuInfoWindow = new CKanturuInfoWindow;
    if (m_pNewKanturuInfoWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewChaosCastleTime = new CChaosCastleTime;
    if (m_pNewChaosCastleTime->Create(m_pNewUIMng) == false)
        return false;

    m_pNewBattleSoccerScore = new CBattleSoccerScore;
    if (m_pNewBattleSoccerScore->Create(m_pNewUIMng) == false)
        return false;

    m_pNewCommandWindow = new CCommandWindow;
    if (m_pNewCommandWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewCatapultWindow = new CCatapultWindow;
    if (m_pNewCatapultWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewWindowMenu = new CWindowMenu;
    if (m_pNewWindowMenu->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pMuHelperBar = new CMuHelperBar;
    if (m_pMuHelperBar->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    if (!CreateChatCommandWindow())
    {
        return false;
    }

    m_pNewHelpWindow = new CHelpWindow;
    if (m_pNewHelpWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewItemExplanationWindow = new CItemExplanationWindow;
    if (m_pNewItemExplanationWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewSetItemExplanation = new CSetItemExplanation;
    if (m_pNewSetItemExplanation->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewQuickCommandWindow = new CQuickCommandWindow;
    if (m_pNewQuickCommandWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewMoveCommandWindow = new CMoveCommandWindow;

    if (m_pNewMoveCommandWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewDuelWindow = new CDuelWindow;
    if (m_pNewDuelWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewNameWindow = new CNameWindow;
    if (m_pNewNameWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewSiegeWarfare = new CSiegeWarfare;
    if (m_pNewSiegeWarfare->Create(m_pNewUIMng) == false)
        return false;

    m_pNewItemEnduranceInfo = new CItemEnduranceInfo;
    if (m_pNewItemEnduranceInfo->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pBuffStrip = new CBuffStrip;
    if (m_pBuffStrip->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewCursedTempleEnterWindow = new CCursedTempleEnter;
    if (m_pNewCursedTempleEnterWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }
    m_pNewCursedTempleWindow = new CCursedTempleSystem;
    if (m_pNewCursedTempleWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }
    m_pNewCursedTempleResultWindow = new CCursedTempleResult;
    if (m_pNewCursedTempleResultWindow->Create(m_pNewUIMng) == false)
    {
        return false;
    }

    m_pNewCryWolfInterface = new CCryWolf;
    if (m_pNewCryWolfInterface->Create(m_pNewUIMng) == false)
        return false;

    m_pNewMaster_Level_Interface = new CMasterLevel;
    if (m_pNewMaster_Level_Interface->Create(m_pNewUIMng) == false)
        return false;

    m_pNewMiniMap = new CMiniMap;
    if (m_pNewMiniMap->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGoldBowman = new CGoldBowmanWindow;
    if (m_pNewGoldBowman->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGoldBowmanLena = new CGoldBowmanLena;
    if (m_pNewGoldBowmanLena->Create(m_pNewUIMng) == false)
        return false;

    m_pNewLuckyCoinRegistration = new CRegistrationLuckyCoin;
    if (m_pNewLuckyCoinRegistration->Create(m_pNewUIMng) == false)
        return false;

    m_pNewExchangeLuckyCoinWindow = new CExchangeLuckyCoin;
    if (m_pNewExchangeLuckyCoinWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewDuelWatchWindow = new CDuelWatchWindow;
    if (m_pNewDuelWatchWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewDuelWatchMainFrameWindow = new CDuelWatchMainFrameWindow;
    if (m_pNewDuelWatchMainFrameWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewDuelWatchUserListWindow = new CDuelWatchUserListWindow;
    if (m_pNewDuelWatchUserListWindow->Create(m_pNewUIMng) == false)
        return false;

#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    m_pNewInGameShop = new CInGameShop;
    if (m_pNewInGameShop->Create(m_pNewUIMng) == false)
        return false;
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME

    m_pNewDoppelGangerWindow = new CDoppelGangerWindow;
    if (m_pNewDoppelGangerWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewDoppelGangerFrame = new CDoppelGangerFrame;
    if (m_pNewDoppelGangerFrame->Create(m_pNewUIMng) == false)
        return false;

    m_pNewNPCDialogue = new CNPCDialogue;
    if (m_pNewNPCDialogue->Create(m_pNewUIMng) == false)
        return false;

    m_pNewQuestProgress = new CQuestProgress;
    if (m_pNewQuestProgress->Create(m_pNewUIMng) == false)
        return false;

    m_pNewQuestProgressByEtc = new CQuestProgressByEtc;
    if (m_pNewQuestProgressByEtc->Create(m_pNewUIMng) == false)
        return false;

    m_pNewEmpireGuardianNPC = new CEmpireGuardianNPC;
    if (m_pNewEmpireGuardianNPC->Create(m_pNewUIMng) == false)
        return false;

    m_pNewEmpireGuardianTimer = new CEmpireGuardianTimer;
    if (m_pNewEmpireGuardianTimer->Create(m_pNewUIMng) == false)
        return false;

    m_pNewGensRanking = new CGensRanking;
    if (m_pNewGensRanking->Create(m_pNewUIMng) == false)
        return false;

    m_pNewUnitedMarketPlaceWindow = new CUnitedMarketPlaceWindow;
    if (m_pNewUnitedMarketPlaceWindow->Create(m_pNewUIMng) == false)
        return false;

    m_pNewUILuckyItemWnd = new CLuckyItemWnd;
    if (m_pNewUILuckyItemWnd->Create(m_pNewUIMng) == false)
        return false;

    m_pGenericConfirmDialog = new CGenericConfirmDialog;
    m_pGenericConfirmDialog->Create(m_pNewUIMng);
    g_pGenericConfirmDialog = m_pGenericConfirmDialog;

    m_pGenericMenuDialog = new CGenericMenuDialog;
    m_pGenericMenuDialog->Create(m_pNewUIMng);
    g_pGenericMenuDialog = m_pGenericMenuDialog;

    m_pMuHelperConfig = new CMuHelperConfigWindow;
    if (m_pMuHelperConfig->Create(m_pNewUIMng) == false)
        return false;

    m_pMuHelperDetail = new CMuHelperDetailWindow;
    if (m_pMuHelperDetail->Create(m_pNewUIMng) == false)
        return false;

    m_pMuHelperSkillPicker = new CMuHelperSkillPicker;
    if (m_pMuHelperSkillPicker->Create(m_pNewUIMng) == false)
        return false;

    // Windows the theme's workspace places. The members are re-created per main scene, so each
    // getter reads the member when it runs.
    const auto slot = [](DWORD windowId, const char* slotName, auto*& window, const char* document = nullptr)
    {
        UI::Placement::RegisterWindow(windowId, slotName, [&window]() -> CObject* { return window; }, document);
    };
    slot(INTERFACE_CHARACTER, "character", m_pNewCharacterInfoWindow, "character_info.rml");
    slot(INTERFACE_MUHELPER, "mu_helper", m_pMuHelperConfig, "mu_helper_config.rml");
    slot(INTERFACE_MUHELPER_EXT, "mu_helper_detail", m_pMuHelperDetail, "mu_helper_detail.rml");
    slot(INTERFACE_PARTY, "party", m_pNewPartyInfoWindow, "party_info.rml");
    slot(INTERFACE_GUILDINFO, "guild_info", m_pNewGuildInfoWindow, "guild_info.rml");
    slot(INTERFACE_COMMAND, "command", m_pNewCommandWindow, "command_window.rml");
    slot(INTERFACE_COMMAND_LIST, "command_list", m_pNewChatCommandWindow, "chat_command.rml");
    slot(INTERFACE_GOLD_BOWMAN, "gold_bowman", m_pNewGoldBowman, "gold_bowman.rml");
    slot(INTERFACE_GOLD_BOWMAN_LENA, "gold_bowman_lena", m_pNewGoldBowmanLena, "gold_bowman_lena.rml");
    slot(INTERFACE_NPC_DIALOGUE, "npc_dialogue", m_pNewNPCDialogue, "npc_dialogue.rml");
    slot(INTERFACE_QUEST_PROGRESS, "quest_progress", m_pNewQuestProgress, "quest_progress.rml");
    slot(INTERFACE_NPCQUEST, "npc_quest", m_pNewNPCQuest, "npc_quest.rml");
    slot(INTERFACE_BLOODCASTLE, "blood_castle_entry", m_pNewEnterBloodCastle, "blood_castle_enter.rml");
    slot(INTERFACE_DEVILSQUARE, "devil_square_entry", m_pNewEnterDevilSquare, "devil_square_enter.rml");
    slot(INTERFACE_SENATUS, "castle", m_pNewCastleWindow, "castle_window.rml");
    slot(INTERFACE_GUARDSMAN, "guard", m_pNewGuardWindow, "guard_window.rml");
    slot(INTERFACE_GATEKEEPER, "gatekeeper", m_pNewGatemanWindow, "gateman.rml");
    slot(INTERFACE_GATESWITCH, "gate_switch", m_pNewGateSwitchWindow, "gate_switch.rml");
    slot(INTERFACE_NPCGUILDMASTER, "guild_make", m_pNewGuildMakeWindow, "guild_make.rml");
    slot(INTERFACE_CATAPULT, "catapult", m_pNewCatapultWindow, "catapult.rml");
    slot(INTERFACE_DUELWATCH, "duel_watch", m_pNewDuelWatchWindow, "duel_watch.rml");
    slot(INTERFACE_DOPPELGANGER_NPC, "doppelganger_entry", m_pNewDoppelGangerWindow, "doppelganger_enter.rml");
    slot(INTERFACE_EMPIREGUARDIAN_NPC, "empire_guardian_entry", m_pNewEmpireGuardianNPC, "empire_guardian_enter.rml");
    slot(INTERFACE_UNITEDMARKETPLACE_NPC_JULIA, "united_marketplace", m_pNewUnitedMarketPlaceWindow, "united_market_place.rml");
    slot(INTERFACE_MYQUEST, "my_quest", m_pNewMyQuestInfoWindow, "my_quest_info.rml");
    slot(INTERFACE_PET, "pet", m_pNewPetInfoWindow, "pet_info.rml");
    slot(INTERFACE_QUEST_PROGRESS_ETC, "quest_progress_etc", m_pNewQuestProgressByEtc, "quest_progress_etc.rml");
    slot(INTERFACE_INVENTORY, "inventory", m_pNewMyInventory, "my_inventory.rml");
    slot(INTERFACE_INVENTORY_EXT, "inventory_extension", m_pNewMyInventoryExt, "inventory_extension.rml");
    slot(INTERFACE_STORAGE, "storage", m_pNewStorageInventory, "storage.rml");
    slot(INTERFACE_STORAGE_EXT, "storage_extension", m_pNewStorageInventoryExt, "storage_ext.rml");
    slot(INTERFACE_NPCSHOP, "npc_shop", m_pNewNPCShop, "npc_shop.rml");
    slot(INTERFACE_MIXINVENTORY, "mix", m_pNewMixInventory, "mix_inventory.rml");
    slot(INTERFACE_TRADE, "trade", m_pNewTrade, "trade.rml");
    slot(INTERFACE_MYSHOP_INVENTORY, "my_shop", m_pNewMyShopInventory, "my_shop.rml");
    slot(INTERFACE_PURCHASESHOP_INVENTORY, "purchase_shop", m_pNewPurchaseShopInventory, "purchase_shop.rml");
    slot(INTERFACE_LUCKYCOIN_REGISTRATION, "lucky_coin_registration", m_pNewLuckyCoinRegistration, "lucky_coin_registration.rml");
    slot(INTERFACE_EXCHANGE_LUCKYCOIN, "lucky_coin_exchange", m_pNewExchangeLuckyCoinWindow, "lucky_coin_exchange.rml");
    slot(INTERFACE_LUCKYITEMWND, "lucky_item", m_pNewUILuckyItemWnd, "lucky_item.rml");
    slot(INTERFACE_GENSRANKING, "gens_ranking", m_pNewGensRanking, "gens_ranking.rml");
    slot(INTERFACE_MOVEMAP, "move_map", m_pNewMoveCommandWindow, "move_command.rml");
    slot(INTERFACE_KANTURU2ND_ENTERNPC, "kanturu_entry", m_pNewKanturu2ndEnterNpc, "kanturu_enter.rml");
    slot(INTERFACE_CURSEDTEMPLE_NPC, "cursed_temple_entry", m_pNewCursedTempleEnterWindow, "cursed_temple_enter.rml");
    slot(INTERFACE_CURSEDTEMPLE_RESULT, "cursed_temple_result", m_pNewCursedTempleResultWindow,
         "cursed_temple_result.rml");
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    slot(INTERFACE_INGAMESHOP, "in_game_shop", m_pNewInGameShop, "in_game_shop.rml");
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME

    // Event HUDs the workspace places; sizes are each window's own constants, in HUD units.
    const auto hudSlot = [](DWORD windowId, const char* slotName, auto*& window, float width, float height)
    {
        UI::Placement::RegisterHudWindow(slotName, windowId, [&window]() -> CObject* { return window; }, width, height);
    };
    hudSlot(INTERFACE_BLOODCASTLE_TIME, "blood_castle_time", m_pNewBloodCastle, 124.f, 81.f);
    hudSlot(INTERFACE_CHAOSCASTLE_TIME, "chaos_castle_time", m_pNewChaosCastleTime, 124.f, 81.f);
    hudSlot(INTERFACE_BATTLE_SOCCER_SCORE, "battle_soccer", m_pNewBattleSoccerScore, 131.f, 70.f);
    hudSlot(INTERFACE_DUEL_WINDOW, "duel", m_pNewDuelWindow, 131.f, 70.f);
    hudSlot(INTERFACE_KANTURU_INFO, "kanturu_info", m_pNewKanturuInfoWindow, 99.f, 78.f);
    hudSlot(INTERFACE_EMPIREGUARDIAN_TIMER, "empire_guardian_timer", m_pNewEmpireGuardianTimer, 124.f, 81.f);
    hudSlot(INTERFACE_DOPPELGANGER_FRAME, "doppelganger_frame", m_pNewDoppelGangerFrame, 227.f, 87.f);
    // The duel watcher's HUD replaces the main HUD.
    hudSlot(INTERFACE_DUELWATCH_MAINFRAME, "duel_watch_hud", m_pNewDuelWatchMainFrameWindow, 640.f, 51.f);
    // Its slot is the list's bottom-left corner; the spectators stack upwards from it.
    hudSlot(INTERFACE_DUELWATCH_USERLIST, "duel_watch_users", m_pNewDuelWatchUserListWindow, 57.f, 0.f);
    // Named only in data-closes.
    UI::Placement::RegisterName(INTERFACE_MUHELPER_SKILL_LIST, "mu_helper_skill_list");
    // Places itself; its slot is only where it first opens (UI::Placement::InitialPosition()).
    UI::Placement::RegisterName(INTERFACE_FRIEND, "friends");

    return true;
}

void CSystem::UnloadMainSceneInterface()
{
    if (g_pNewUIMng)
    {
        g_pNewUIMng->ShowAllInterfaces(false);
    }

    SAFE_DELETE(m_pNewHelpWindow);
    SAFE_DELETE(m_pNewChatCommandWindow);
    SAFE_DELETE(m_pNewItemExplanationWindow);
    SAFE_DELETE(m_pNewSetItemExplanation);
    SAFE_DELETE(m_pNewQuickCommandWindow);
    SAFE_DELETE(m_pNewWindowMenu);
    SAFE_DELETE(m_pNewBattleSoccerScore);
    SAFE_DELETE(m_pNewCatapultWindow);
    SAFE_DELETE(m_pNewKanturu2ndEnterNpc);
    SAFE_DELETE(m_pNewKanturuInfoWindow);
    SAFE_DELETE(m_pNewTrade);
    SAFE_DELETE(m_pNewNPCQuest);
    SAFE_DELETE(m_pNewMyQuestInfoWindow);
    SAFE_DELETE(m_pNewCharacterInfoWindow);
    SAFE_DELETE(m_pNewPurchaseShopInventory);
    SAFE_DELETE(m_pNewMyShopInventory);
    SAFE_DELETE(m_pNewGuildMakeWindow);
    SAFE_DELETE(m_pNewGuildInfoWindow);
    SAFE_DELETE(m_pNewStorageInventory);
    SAFE_DELETE(m_pNewMixInventory);
    SAFE_DELETE(m_pNewCastleWindow);
    SAFE_DELETE(m_pNewGuardWindow);
    SAFE_DELETE(m_pNewGatemanWindow);
    SAFE_DELETE(m_pNewGateSwitchWindow);
    SAFE_DELETE(m_pNewNPCShop);
    SAFE_DELETE(m_pNewPetInfoWindow);
    SAFE_DELETE(m_pNewMyInventory);
    SAFE_DELETE(m_pNewFriendWindow);
    SAFE_DELETE(m_pNewChatInputBox);
    SAFE_DELETE(m_pNewNameWindow);
    SAFE_DELETE(m_pNewSkillList);
    SAFE_DELETE(m_pNewMainFrameWindow);
    SAFE_DELETE(m_pNewPartyInfoWindow);
    SAFE_DELETE(m_pNewPartyListWindow);
    SAFE_DELETE(m_pNewEnterBloodCastle);
    SAFE_DELETE(m_pNewEnterDevilSquare);
    SAFE_DELETE(m_pNewBloodCastle);
    SAFE_DELETE(m_pNewChaosCastleTime);
    SAFE_DELETE(m_pNewCommandWindow);
    SAFE_DELETE(m_pMuHelperBar);
    SAFE_DELETE(m_pMuHelperConfig);
    SAFE_DELETE(m_pMuHelperSkillPicker);
    SAFE_DELETE(m_pMuHelperDetail);
    SAFE_DELETE(m_pNewMoveCommandWindow);
    SAFE_DELETE(m_pNewUIHotKey);
    SAFE_DELETE(m_pNewSiegeWarfare);
    SAFE_DELETE(m_pNewItemEnduranceInfo);
    SAFE_DELETE(m_pBuffStrip);
    SAFE_DELETE(m_pNewCursedTempleResultWindow);
    SAFE_DELETE(m_pNewCursedTempleWindow);
    SAFE_DELETE(m_pNewCursedTempleEnterWindow);
    SAFE_DELETE(m_pNewCryWolfInterface);
    SAFE_DELETE(m_pNewMaster_Level_Interface);
    SAFE_DELETE(m_pNewGoldBowman);
    SAFE_DELETE(m_pNewGoldBowmanLena);
    SAFE_DELETE(m_pNewLuckyCoinRegistration);
    SAFE_DELETE(m_pNewExchangeLuckyCoinWindow);
    SAFE_DELETE(m_pNewDuelWatchWindow);
    SAFE_DELETE(m_pNewDuelWindow);
    SAFE_DELETE(m_pNewDuelWatchMainFrameWindow);
    SAFE_DELETE(m_pNewDuelWatchUserListWindow);
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    SAFE_DELETE(m_pNewInGameShop);
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
    SAFE_DELETE(m_pNewDoppelGangerWindow);
    SAFE_DELETE(m_pNewDoppelGangerFrame);
    SAFE_DELETE(m_pNewNPCDialogue);
    SAFE_DELETE(m_pNewQuestProgress);
    SAFE_DELETE(m_pNewQuestProgressByEtc);
    SAFE_DELETE(m_pNewEmpireGuardianNPC);
    SAFE_DELETE(m_pNewEmpireGuardianTimer);
    SAFE_DELETE(m_pNewMiniMap);
    SAFE_DELETE(m_pNewItemMng);
    SAFE_DELETE(m_pNewGensRanking);
    SAFE_DELETE(m_pNewUnitedMarketPlaceWindow);
#ifdef LEM_FIX_LUCKYITEM_UICLASS_SAFEDELETE
    SAFE_DELETE(m_pNewUILuckyItemWnd);
#endif // LEM_FIX_LUCKYITEM_UICLASS_SAFEDELETE
    g_pGenericConfirmDialog = nullptr;
    SAFE_DELETE(m_pGenericConfirmDialog);

    g_pGenericMenuDialog = nullptr;
    SAFE_DELETE(m_pGenericMenuDialog);

    ReleasePersonalItemTable();
}

bool CSystem::IsVisible(DWORD dwKey)
{
    if (m_pNewUIMng)
    {
        return m_pNewUIMng->IsInterfaceVisible(dwKey);
    }

    return false;
}

void CSystem::Show(DWORD dwKey)
{
#ifdef PBG_ADD_INGAMESHOP_UI_ITEMSHOP
    if (g_pInGameShop->IsInGameShop())
        return;
#endif //PBG_ADD_INGAMESHOP_UI_ITEMSHOP
    if (!m_pNewUIMng)
    {
        return;
    }

    UI::Placement::CloseForOpening(dwKey);

    if (dwKey == INTERFACE_FRIEND)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_FRIEND, true);

        m_pNewFriendWindow->OpenMainWnd(UI::Social::WorkspaceWidth() - 250, UI::Social::FreeAreaBottom() - 170);
    }
    else if (dwKey == INTERFACE_INVENTORY)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
        g_pMyInventory->OpenningProcess();
    }
    else if (dwKey == INTERFACE_INVENTORY_EXT)
    {
        if (IsVisible(INTERFACE_STORAGE))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }

        if (IsVisible(INTERFACE_MYSHOP_INVENTORY))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        if (IsVisible(INTERFACE_NPCSHOP))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        if (IsVisible(INTERFACE_MIXINVENTORY))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        if (IsVisible(INTERFACE_TRADE))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }
    }
    else if (dwKey == INTERFACE_CHARACTER)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_CHAINFO, true);

        if (IsVisible(INTERFACE_INVENTORY) && IsVisible(INTERFACE_INVENTORY_EXT))
        {
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        g_pCharacterInfoWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_PET)
    {
        m_pNewUIMng->ShowInterface(INTERFACE_CHARACTER);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_CHAINFO, true);
        m_pNewPetInfoWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_MYQUEST)
    {
        g_pMyQuestInfoWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_MIXINVENTORY)
    {
        HideAllGroupA();
        g_pMixInventory->OpeningProcess();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_NPCSHOP)
    {
        HideAllGroupA();
        g_pNPCShop->OpenningProcess();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_STORAGE)
    {
        const bool isExtendedInventoryOpen = IsVisible(INTERFACE_INVENTORY_EXT);
        HideAllGroupA();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        if (isExtendedInventoryOpen)
        {
            Show(INTERFACE_INVENTORY_EXT);
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        else
        {
            Show(INTERFACE_MU_HELPER_BAR);
        }

        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_STORAGE_EXT)
    {
        if (IsVisible(INTERFACE_INVENTORY_EXT))
        {
            m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY_EXT, false);
        }

        Hide(INTERFACE_MU_HELPER_BAR);

        m_pNewUIMng->ShowInterface(INTERFACE_STORAGE_EXT);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_MYSHOP_INVENTORY)
    {
        const bool isExtendedInventoryOpen = IsVisible(INTERFACE_INVENTORY_EXT);
        HideAllGroupA();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        if (isExtendedInventoryOpen)
        {
            Show(INTERFACE_INVENTORY_EXT);
            Hide(INTERFACE_MU_HELPER_BAR);
        }
        else
        {
            Show(INTERFACE_MU_HELPER_BAR);
        }

        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
        if (gMapManager.IsCursedTemple() == true)
        {
            g_pMyShopInventory->OpenButtonLock();
        }
        else if (!g_pMyShopInventory->IsEnablePersonalShop())
        {
            g_pMyShopInventory->OpenButtonUnLock();
        }
    }
    else if (dwKey == INTERFACE_PURCHASESHOP_INVENTORY)
    {
        HideAllGroupA();
    }
    else if (dwKey == INTERFACE_PARTY)
    {
        HideAllGroupA();
        m_pNewPartyInfoWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_NPCQUEST)
    {
        HideAllGroupA();
        g_pNPCQuest->ProcessOpening();
    }
    else if (dwKey == INTERFACE_TRADE)
    {
        HideAllGroupA();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_BLOODCASTLE)
    {
        HideAllGroupA();
        g_pEnterBloodCastle->OpenningProcess();
    }
    else if (dwKey == INTERFACE_DEVILSQUARE)
    {
        HideAllGroupA();
        g_pEnterDevilSquare->OpenningProcess();
    }
    else if (dwKey == INTERFACE_CATAPULT)
    {
        HideAllGroupA();
        g_pCatapultWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_COMMAND)
    {
        HideAllGroupA();
        m_pNewCommandWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_COMMAND_LIST)
    {
        HideAllGroupA();
        m_pNewChatCommandWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_GUILDINFO)
    {
        HideAllGroupA();
        g_pGuildInfoWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_WINDOW_MENU)
    {
        g_pWindowMenu->OpenningProcess();
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_WINDOW, true);
    }
    else if (dwKey == INTERFACE_SENATUS)
    {
        HideAllGroupA();
        g_pCastleWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_GUARDSMAN)
    {
        HideAllGroupA();
        g_pGuardWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_GATEKEEPER)
    {
        HideAllGroupA();
        g_pGatemanWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_GATESWITCH)
    {
        HideAllGroupA();
        g_pGateSwitchWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_NPCGUILDMASTER)
    {
        HideAllGroupA();
    }
    else if (dwKey == INTERFACE_MASTER_LEVEL)
    {
        HideAllGroupA();
    }
    else if (dwKey == INTERFACE_KANTURU2ND_ENTERNPC)
    {
        HideAllGroupB();
    }
    else if (dwKey == INTERFACE_MU_HELPER_BAR)
    {
        m_pMuHelperBar->OpenningProcess();
    }
    else if (dwKey == INTERFACE_CHAOSCASTLE_TIME)
    {
        if (IsVisible(INTERFACE_CHATINPUTBOX))
        {
            Hide(INTERFACE_CHATINPUTBOX);
        }
        m_pNewChaosCastleTime->OpenningProcess();
    }
    else if (dwKey == INTERFACE_BLOODCASTLE_TIME)
    {
        g_pBloodCastle->OpenningProcess();
    }
    else if (dwKey == INTERFACE_OPTION)
    {
        g_pOption->OpenningProcess();
    }
    else if (dwKey == INTERFACE_HELP)
    {
        Hide(INTERFACE_MOVEMAP);
        Hide(INTERFACE_ITEM_EXPLANATION);
        Hide(INTERFACE_SETITEM_EXPLANATION);
        g_pHelp->OpenningProcess();
    }
    else if (dwKey == INTERFACE_ITEM_EXPLANATION)
    {
        Hide(INTERFACE_MOVEMAP);
        Hide(INTERFACE_HELP);
        Hide(INTERFACE_SETITEM_EXPLANATION);
        g_pItemExplanation->OpenningProcess();
    }
    else if (dwKey == INTERFACE_SETITEM_EXPLANATION)
    {
        Hide(INTERFACE_MOVEMAP);
        Hide(INTERFACE_HELP);
        Hide(INTERFACE_ITEM_EXPLANATION);
        g_pSetItemExplanation->OpenningProcess();
    }
    else if (dwKey == INTERFACE_QUICK_COMMAND)
    {
        g_pQuickCommand->OpenningProcess();
    }
    else if (dwKey == INTERFACE_MOVEMAP)
    {
        Hide(INTERFACE_HELP);
        Hide(INTERFACE_ITEM_EXPLANATION);
        Hide(INTERFACE_SETITEM_EXPLANATION);
        m_pNewMoveCommandWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_CHATINPUTBOX)
    {
        m_pNewChatInputBox->OpenningProcess();
    }
    else if (dwKey == INTERFACE_SIEGEWARFARE)
    {
        m_pNewSiegeWarfare->OpenningProcess();
    }
    else if (dwKey == INTERFACE_ITEM_ENDURANCE_INFO)
    {
        m_pNewItemEnduranceInfo->OpenningProcess();
    }
    else if (dwKey == INTERFACE_BUFF_WINDOW)
    {
        m_pBuffStrip->OpenningProcess();
    }
    else if (dwKey == INTERFACE_CRYWOLF)
    {
        m_pNewCryWolfInterface->OpenningProcess();
    }
    else if (dwKey == INTERFACE_GOLD_BOWMAN)
    {
        m_pNewGoldBowman->OpeningProcess();
    }
    else if (dwKey == INTERFACE_GOLD_BOWMAN_LENA)
    {
        m_pNewGoldBowmanLena->OpeningProcess();
    }
    else if (dwKey == INTERFACE_LUCKYCOIN_REGISTRATION)
    {
        HideAllGroupA();
        g_pLuckyCoinRegistration->OpeningProcess();
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY);
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, true);
    }
    else if (dwKey == INTERFACE_EXCHANGE_LUCKYCOIN)
    {
        HideAllGroupA();
        g_pExchangeLuckyCoinWindow->OpenningProcess();
    }
    else if (dwKey == INTERFACE_DUELWATCH)
    {
        m_pNewDuelWatchWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_DUELWATCH_MAINFRAME)
    {
        m_pNewDuelWatchMainFrameWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_DUELWATCH_USERLIST)
    {
        m_pNewDuelWatchUserListWindow->OpeningProcess();
    }
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    else if (dwKey == INTERFACE_INGAMESHOP)
    {
        g_ConsoleDebug->Write(MCD_NORMAL, L"InGameShopStatue.Txt CallStack - CSystem.Show()\r\n");
        HideAll();
        g_pInGameShop->OpeningProcess();
#ifndef KJH_MOD_SHOP_SCRIPT_DOWNLOAD
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_PARTCHARGE, true);
#endif // KJH_MOD_SHOP_SCRIPT_DOWNLOAD
    }
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
    else if (dwKey == INTERFACE_DOPPELGANGER_NPC)
    {
        m_pNewDoppelGangerWindow->OpeningProcess();
    }
    else if (dwKey == INTERFACE_DOPPELGANGER_FRAME)
    {
        m_pNewDoppelGangerFrame->OpenningProcess();
    }
    else if (dwKey == INTERFACE_NPC_DIALOGUE)
    {
        HideAllGroupA();
        g_pNPCDialogue->ProcessOpening();
    }
    else if (dwKey == INTERFACE_QUEST_PROGRESS)
    {
        HideAllGroupA();
        g_pQuestProgress->ProcessOpening();
    }
    else if (dwKey == INTERFACE_QUEST_PROGRESS_ETC)
    {
        g_pQuestProgressByEtc->ProcessOpening();
    }
    else if (dwKey == INTERFACE_EMPIREGUARDIAN_NPC)
    {
        m_pNewEmpireGuardianNPC->OpenningProcess();
    }
    else if (dwKey == INTERFACE_EMPIREGUARDIAN_TIMER)
    {
        m_pNewEmpireGuardianTimer->OpenningProcess();
    }
    else if (dwKey == INTERFACE_MINI_MAP)
    {
        m_pNewMiniMap->OpenningProcess();
    }
    else if (dwKey == INTERFACE_GENSRANKING)
    {
        HideAllGroupA();
        g_pNewUIGensRanking->OpenningProcess();
    }
    else if (dwKey == INTERFACE_UNITEDMARKETPLACE_NPC_JULIA)
    {
        m_pNewUnitedMarketPlaceWindow->OpeningProcess();
    }
    else if (dwKey == mu::ui::window::INTERFACE_LUCKYITEMWND)
    {
        HideAllGroupA();
        g_pLuckyItemWnd->OpeningProcess();
        m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_INVENTORY);
    }
    else if (dwKey == INTERFACE_MUHELPER)
    {
        HideAllGroupA();
    }

    m_pNewUIMng->ShowInterface(dwKey);
    UI::Placement::Arrange();

    UpdateMuHelperBarVisibilityForLayoutChange(dwKey);

}

void CSystem::Hide(DWORD dwKey)
{
    if (!m_pNewUIMng)
    {
        return;
    }

    if (dwKey == INTERFACE_FRIEND)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_FRIEND, false);
        m_pNewFriendWindow->HideAllWindow(TRUE, TRUE);
    }
    else if (dwKey == INTERFACE_CHARACTER)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_CHAINFO, false);
        if (IsVisible((INTERFACE_PET)))
        {
            Hide(INTERFACE_PET);
        }
    }
    else if (dwKey == INTERFACE_INVENTORY_EXT)
    {
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_INVENTORY)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, false);

        if (IsVisible(INTERFACE_INVENTORY_EXT))
        {
            Hide(INTERFACE_INVENTORY_EXT);
        }

        if (IsVisible(INTERFACE_MIXINVENTORY))
        {
            if (g_pMixInventory->ClosingProcess() == false)
                return;
            m_pNewUIMng->ShowInterface(INTERFACE_MIXINVENTORY, false);
        }
        if (IsVisible(mu::ui::window::INTERFACE_LUCKYITEMWND))
        {
            if (g_pLuckyItemWnd->ClosingProcess() == false)
                return;
            m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_LUCKYITEMWND, false);
        }
        if (IsVisible(INTERFACE_NPCSHOP))
        {
            g_pNPCShop->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_NPCSHOP, false);
        }
        if (IsVisible(INTERFACE_MYSHOP_INVENTORY))
        {
            m_pNewUIMng->ShowInterface(INTERFACE_MYSHOP_INVENTORY, false);
        }
        if (IsVisible(INTERFACE_PURCHASESHOP_INVENTORY))
        {
            g_pPurchaseShopInventory->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_PURCHASESHOP_INVENTORY, false);
        }
        if (IsVisible(INTERFACE_STORAGE))
        {
            g_pStorageInventoryExt->ProcessClosing();
            if (!g_pStorageInventory->ProcessClosing())
                return;

            m_pNewUIMng->ShowInterface(INTERFACE_STORAGE_EXT, false);
            m_pNewUIMng->ShowInterface(INTERFACE_STORAGE, false);
        }
        if (IsVisible(INTERFACE_TRADE))
        {
            g_pTrade->ProcessCloseBtn();
            m_pNewUIMng->ShowInterface(INTERFACE_TRADE, false);
        }

        if (IsVisible(INTERFACE_LUCKYCOIN_REGISTRATION))
        {
            m_pNewLuckyCoinRegistration->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_LUCKYCOIN_REGISTRATION, false);
        }
        if (IsVisible(INTERFACE_EXCHANGE_LUCKYCOIN))
        {
            m_pNewExchangeLuckyCoinWindow->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_EXCHANGE_LUCKYCOIN, false);
        }

        if (IsVisible(mu::ui::window::INTERFACE_LUCKYITEMWND))
        {
            m_pNewUILuckyItemWnd->ClosingProcess();
            m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_LUCKYITEMWND, false);
        }

        g_pMyInventory->ClosingProcess();
    }
    else if (dwKey == INTERFACE_MIXINVENTORY)
    {
        if (g_pMixInventory->ClosingProcess() == false)
        {
            return;
        }
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, false);
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_NPCSHOP)
    {
        if (IsVisible(INTERFACE_INVENTORY_EXT))
        {
            Hide(INTERFACE_INVENTORY_EXT);
        }
        g_pNPCShop->ClosingProcess();
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, false);
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
    }
    else if (dwKey == INTERFACE_MYSHOP_INVENTORY
        || dwKey == INTERFACE_PURCHASESHOP_INVENTORY)
    {
        if (dwKey == INTERFACE_MYSHOP_INVENTORY)
        {
            g_pMyShopInventory->ClosingProcess();
        }
        else if (dwKey == INTERFACE_PURCHASESHOP_INVENTORY)
        {
            g_pPurchaseShopInventory->ClosingProcess();
        }
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_STORAGE)
    {
        g_pStorageInventoryExt->ProcessClosing();
        if (!g_pStorageInventory->ProcessClosing())
            return;
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, false);
        if (IsVisible(INTERFACE_INVENTORY_EXT))
        {
            Hide(INTERFACE_INVENTORY_EXT);
        }
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_STORAGE_EXT)
    {
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_PET)
    {
        m_pNewPetInfoWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_PARTY)
    {
        m_pNewPartyInfoWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_MYQUEST)
    {
        m_pNewMyQuestInfoWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_SENATUS)
    {
        m_pNewCastleWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GUARDSMAN)
    {
        m_pNewGuardWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GATEKEEPER)
    {
        m_pNewGatemanWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GATESWITCH)
    {
        m_pNewGateSwitchWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_NPCQUEST)
    {
        m_pNewNPCQuest->ProcessClosing();
    }
    else if (dwKey == INTERFACE_BLOODCASTLE)
    {
        g_pEnterBloodCastle->ClosingProcess();
    }
    else if (dwKey == INTERFACE_DEVILSQUARE)
    {
        g_pEnterDevilSquare->ClosingProcess();
    }
    // NOTE: no INTERFACE_KANTURU2ND_ENTERNPC hook here by design. Hide() runs
    // on the Enter path (BtnProcess hides the dialog before the NPC animation
    // sends the enter at frame 42); a Close there would make the server drop
    // the enter. Closes live at the explicit call sites, at the NPC-click
    // site before SendTalkToNpcRequest, and in the animation-end guard.
    else if (dwKey == INTERFACE_BLOODCASTLE_TIME)
    {
        g_pBloodCastle->ClosingProcess();
    }
    else if (dwKey == INTERFACE_TRADE)
    {
        if (IsVisible(INTERFACE_INVENTORY_EXT))
        {
            Hide(INTERFACE_INVENTORY_EXT);
        }
        g_pTrade->ProcessClosing();
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_MYINVEN, false);
        m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
        Show(INTERFACE_MU_HELPER_BAR);
    }
    else if (dwKey == INTERFACE_CATAPULT)
    {
        g_pCatapultWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_CHAOSCASTLE_TIME)
    {
        m_pNewChaosCastleTime->ClosingProcess();
    }
    else if (dwKey == INTERFACE_COMMAND)
    {
        m_pNewCommandWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_COMMAND_LIST)
    {
        m_pNewChatCommandWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_WINDOW_MENU)
    {
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_WINDOW, false);
    }
    else if (dwKey == INTERFACE_OPTION)
    {
    }
    else if (dwKey == INTERFACE_MU_HELPER_BAR)
    {
        m_pMuHelperBar->ClosingProcess();
    }
    else if (dwKey == INTERFACE_HELP)
    {
        g_pHelp->ClosingProcess();
    }
    else if (dwKey == INTERFACE_ITEM_EXPLANATION)
    {
        g_pItemExplanation->ClosingProcess();
    }
    else if (dwKey == INTERFACE_SETITEM_EXPLANATION)
    {
        g_pSetItemExplanation->ClosingProcess();
    }
    else if (dwKey == INTERFACE_QUICK_COMMAND)
    {
        g_pQuickCommand->ClosingProcess();
    }
    else if (dwKey == INTERFACE_MOVEMAP)
    {
        m_pNewCommandWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_CHATINPUTBOX)
    {
        m_pNewChatInputBox->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GUILDINFO)
    {
        m_pNewGuildInfoWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_NPCGUILDMASTER)
    {
        m_pNewGuildMakeWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_SIEGEWARFARE)
    {
        m_pNewSiegeWarfare->ClosingProcess();
    }
    else if (dwKey == INTERFACE_ITEM_ENDURANCE_INFO)
    {
        m_pNewItemEnduranceInfo->ClosingProcess();
    }
    else if (dwKey == INTERFACE_BUFF_WINDOW)
    {
        m_pBuffStrip->ClosingProcess();
    }
    else if (dwKey == INTERFACE_CURSEDTEMPLE_RESULT)
    {
        m_pNewCursedTempleResultWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_CRYWOLF)
    {
        m_pNewCryWolfInterface->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GOLD_BOWMAN)
    {
        m_pNewGoldBowman->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GOLD_BOWMAN_LENA)
    {
        m_pNewGoldBowmanLena->ClosingProcess();
    }
    else if (dwKey == INTERFACE_LUCKYCOIN_REGISTRATION)
    {
        m_pNewLuckyCoinRegistration->ClosingProcess();

        if (IsVisible(INTERFACE_INVENTORY))
        {
            m_pNewMyInventory->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
        }
    }
    else if (dwKey == INTERFACE_EXCHANGE_LUCKYCOIN)
    {
        m_pNewExchangeLuckyCoinWindow->ClosingProcess();

        if (IsVisible(INTERFACE_INVENTORY))
        {
            m_pNewMyInventory->ClosingProcess();
            m_pNewUIMng->ShowInterface(INTERFACE_INVENTORY, false);
        }
    }
    else if (dwKey == INTERFACE_DUELWATCH)
    {
        m_pNewDuelWatchWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_DUELWATCH_MAINFRAME)
    {
        m_pNewDuelWatchMainFrameWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_DUELWATCH_USERLIST)
    {
        m_pNewDuelWatchUserListWindow->ClosingProcess();
    }
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
    else if (dwKey == INTERFACE_INGAMESHOP)
    {
        g_pInGameShop->ClosingProcess();
        g_pMainFrame->SetBtnState(MAINFRAME_BTN_PARTCHARGE, false);
    }
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
    else if (dwKey == INTERFACE_DOPPELGANGER_NPC)
    {
        m_pNewDoppelGangerWindow->ClosingProcess();
    }
    else if (dwKey == INTERFACE_DOPPELGANGER_FRAME)
    {
        m_pNewDoppelGangerFrame->ClosingProcess();
    }
    else if (dwKey == INTERFACE_NPC_DIALOGUE)
    {
        m_pNewNPCDialogue->ProcessClosing();
    }
    else if (dwKey == INTERFACE_QUEST_PROGRESS)
    {
        m_pNewQuestProgress->ProcessClosing();
    }
    else if (dwKey == INTERFACE_QUEST_PROGRESS_ETC)
    {
        m_pNewQuestProgressByEtc->ProcessClosing();
    }
    else if (dwKey == INTERFACE_EMPIREGUARDIAN_NPC)
    {
        m_pNewEmpireGuardianNPC->ClosingProcess();
    }
    else if (dwKey == INTERFACE_EMPIREGUARDIAN_TIMER)
    {
        m_pNewEmpireGuardianTimer->ClosingProcess();
    }
    else if (dwKey == INTERFACE_MINI_MAP)
    {
        m_pNewMiniMap->ClosingProcess();
    }
    else if (dwKey == INTERFACE_GENSRANKING)
    {
        g_pNewUIGensRanking->ClosingProcess();
    }
    else if (dwKey == INTERFACE_UNITEDMARKETPLACE_NPC_JULIA)
    {
        m_pNewUnitedMarketPlaceWindow->ClosingProcess();
    }
    else if (dwKey == mu::ui::window::INTERFACE_LUCKYITEMWND)
    {
        if (g_pLuckyItemWnd->ClosingProcess() == false)
            return;
        if (IsVisible(mu::ui::window::INTERFACE_INVENTORY))
        {
            m_pNewMyInventory->ClosingProcess();
            m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_INVENTORY, false);
        }
    }
    else if (dwKey == INTERFACE_MUHELPER)
    {
        m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_MUHELPER_SKILL_LIST, false);
        m_pNewUIMng->ShowInterface(mu::ui::window::INTERFACE_MUHELPER_EXT, false);
    }

    m_pNewUIMng->ShowInterface(dwKey, false);
    UI::Placement::Arrange();

    UpdateMuHelperBarVisibilityForLayoutChange(dwKey);

}

void CSystem::Toggle(DWORD dwKey)
{
    IsVisible(dwKey) ? Hide(dwKey) : Show(dwKey);
}

void CSystem::HideAll()
{
    if (m_pNewUIMng)
    {
        for (int i = INTERFACE_BEGIN + 1; i < INTERFACE_END; i++)
        {
            if (IsImpossibleHideInterface(i) == false)
            {
                if (IsVisible(i) == true)
                {
                    Hide(i);
                }
            }
        }
    }
}

void CSystem::HideAllGroupA()
{
    Hide(INTERFACE_INVENTORY);
    Hide(INTERFACE_CHARACTER);

    DWORD dwGroupA[] = {
        INTERFACE_MUHELPER,
        INTERFACE_MUHELPER_EXT,
        INTERFACE_MUHELPER_SKILL_LIST,
        INTERFACE_MIXINVENTORY,
        INTERFACE_STORAGE,
        INTERFACE_NPCSHOP,
        INTERFACE_MYSHOP_INVENTORY,
        INTERFACE_PURCHASESHOP_INVENTORY,
        INTERFACE_PET,
        INTERFACE_MYQUEST,
        INTERFACE_NPCQUEST,
        INTERFACE_PARTY,
        INTERFACE_SENATUS,
        INTERFACE_GUARDSMAN,
        INTERFACE_COMMAND,
        INTERFACE_COMMAND_LIST,
        INTERFACE_GUILDINFO,
        INTERFACE_KANTURU2ND_ENTERNPC,
        INTERFACE_DUELWATCH,
        INTERFACE_DOPPELGANGER_NPC,
        INTERFACE_GOLD_BOWMAN,
        INTERFACE_GOLD_BOWMAN_LENA,
        INTERFACE_NPC_DIALOGUE,
        INTERFACE_QUEST_PROGRESS,
        INTERFACE_QUEST_PROGRESS_ETC,
        INTERFACE_EMPIREGUARDIAN_NPC,
#ifdef PBG_ADD_GENSRANKING
        INTERFACE_GENSRANKING,
#endif //PBG_ADD_GENSRANKING
        INTERFACE_UNITEDMARKETPLACE_NPC_JULIA,

        mu::ui::window::INTERFACE_LUCKYITEMWND,

        0,
    };

    if (m_pNewUIMng)
    {
        for (int i = 0; dwGroupA[i] != 0; i++)
        {
            m_pNewUIMng->ShowInterface(dwGroupA[i], false);
        }
    }
}

void CSystem::HideAllGroupB()
{
    Hide(INTERFACE_FRIEND);
    Hide(INTERFACE_INVENTORY);
    Hide(INTERFACE_CHARACTER);

    DWORD dwGroupB[] = {
        INTERFACE_MIXINVENTORY,
        INTERFACE_STORAGE,
        INTERFACE_NPCSHOP,
        INTERFACE_MYSHOP_INVENTORY,
        INTERFACE_PURCHASESHOP_INVENTORY,
        INTERFACE_PET,
        INTERFACE_MYQUEST,
        INTERFACE_NPCQUEST,
        INTERFACE_PARTY,
        INTERFACE_SENATUS,
        INTERFACE_GUARDSMAN,
        INTERFACE_COMMAND,
        INTERFACE_COMMAND_LIST,
        INTERFACE_GUILDINFO,
        INTERFACE_KANTURU2ND_ENTERNPC,
        INTERFACE_CURSEDTEMPLE_NPC,
        INTERFACE_DUELWATCH,
        INTERFACE_DOPPELGANGER_NPC,
        INTERFACE_GOLD_BOWMAN,
        INTERFACE_GOLD_BOWMAN_LENA,
        INTERFACE_NPC_DIALOGUE,
        INTERFACE_QUEST_PROGRESS,
        INTERFACE_QUEST_PROGRESS_ETC,
        INTERFACE_EMPIREGUARDIAN_NPC,
#ifdef PBG_ADD_GENSRANKING
        INTERFACE_GENSRANKING,
#endif //PBG_ADD_GENSRANKING
        INTERFACE_UNITEDMARKETPLACE_NPC_JULIA,
        mu::ui::window::INTERFACE_LUCKYITEMWND,

        0,
    };

    if (m_pNewUIMng)
    {
        for (int i = 0; dwGroupB[i] != 0; i++)
        {
            m_pNewUIMng->ShowInterface(dwGroupB[i], false);
        }
    }
}

void CSystem::SyncMainSceneHudVisibility()
{
    // Also gate on LoadingWorld < 30: SceneFlag flips to MAIN_SCENE before the server-sent
    // world/hero data is actually ready, so this mirrors MainScene.cpp's own "not really in
    // MAIN_SCENE yet" check to avoid showing the HUD documents too early.
    const bool sceneAllowsShow = (SceneFlag == MAIN_SCENE) && (LoadingWorld < 30);

    if (m_pMuHelperBar)
        m_pMuHelperBar->SyncDocVisibility(sceneAllowsShow);
    if (m_pBuffStrip)
        m_pBuffStrip->SyncDocVisibility(sceneAllowsShow);
    if (m_pNewItemEnduranceInfo)
        m_pNewItemEnduranceInfo->SyncDocVisibility(sceneAllowsShow);
    if (m_pNewMainFrameWindow)
        m_pNewMainFrameWindow->SyncDocVisibility(sceneAllowsShow);
    if (m_pNewChatLogWindow)
        m_pNewChatLogWindow->SyncDocVisibility(sceneAllowsShow);
    if (m_pNewSystemLogWindow)
        m_pNewSystemLogWindow->SyncDocVisibility(sceneAllowsShow);
}

void CSystem::UpdateMuHelperBarVisibilityForLayoutChange(DWORD dwKey)
{
    if (IsHeroPositionLayoutInterface(dwKey))
    {
        SyncMuHelperBarVisibility();
    }
}

void CSystem::SyncMuHelperBarVisibility()
{
    if (!m_pNewUIMng)
    {
        return;
    }

    m_pNewUIMng->ShowInterface(INTERFACE_MU_HELPER_BAR, !ShouldHideMuHelperBar());
}

bool CSystem::ShouldHideMuHelperBar()
{
    if (!m_pNewUIMng)
    {
        return false;
    }

    if (IsVisible(INTERFACE_STORAGE_EXT))
    {
        return true;
    }

    if (!IsVisible(INTERFACE_INVENTORY_EXT))
    {
        return false;
    }

    return IsVisible(INTERFACE_CHARACTER)
        || IsVisible(INTERFACE_STORAGE)
        || IsVisible(INTERFACE_MYSHOP_INVENTORY)
        || IsVisible(INTERFACE_NPCSHOP)
        || IsVisible(INTERFACE_MIXINVENTORY)
        || IsVisible(INTERFACE_TRADE);
}

void CSystem::Enable(DWORD dwKey)
{
    if (m_pNewUIMng)
    {
        m_pNewUIMng->EnableInterface(dwKey);
    }
}

void CSystem::Disable(DWORD dwKey)
{
    if (m_pNewUIMng)
    {
        m_pNewUIMng->EnableInterface(dwKey, false);
    }
}

bool CSystem::CheckMouseUse()
{
    if (m_mouseInputCaptured)
    {
        return true;
    }

    if (m_pNewUIMng)
    {
        if (m_pNewUIMng->GetActiveMouseUIObj())
            return true;
    }
    return false;
}

bool CSystem::CheckKeyUse()
{
    if (m_pNewUIMng)
    {
        if (m_pNewUIMng->GetActiveKeyUIObj())
            return true;
    }
    return false;
}

bool CSystem::Update()
{
    // Before any window syncs its document: see ResumeMainSceneDocuments().
    UI::RmlBridge::ResumeMainSceneDocuments();
    UI::Placement::Update();

    if (m_pNewItemMng)
    {
        m_pNewItemMng->Update();
    }

    bool result = false;
    if (m_pNewUIMng)
    {
        if (!MouseLButton)
        {
            m_mouseInputCaptured = false;
        }
        else if (m_pNewUIMng->GetActiveMouseUIObj())
        {
            m_mouseInputCaptured = true;
        }

        m_pNewUIMng->UpdateMouseEvent();

        if (MouseLButton && m_pNewUIMng->GetActiveMouseUIObj())
        {
            m_mouseInputCaptured = true;
        }

        m_pNewUIMng->UpdateKeyEvent();
        result = m_pNewUIMng->Update();
    }

    return result;
}

bool CSystem::Render()
{
    bool bResult = false;

    BeginBitmap();
    if (m_pNewUIMng)
        bResult = m_pNewUIMng->Render();
    EndBitmap();
    UI::Items::SyncCursorItemLayer();

    return bResult;
}

CManager* CSystem::GetNewUIManager() const
{
    return m_pNewUIMng;
}

CHotKey* CSystem::GetNewUIHotKey() const
{
    return m_pNewUIHotKey;
}

bool CSystem::IsImpossibleSendMoveInterface()
{
    if (IsVisible(INTERFACE_MIXINVENTORY)
        || IsVisible(INTERFACE_KANTURU2ND_ENTERNPC)
        || IsVisible(mu::ui::window::INTERFACE_LUCKYITEMWND)
        )
    {
        return true;
    }

    return false;
}

bool CSystem::IsImpossibleTradeInterface()
{
    if (IsVisible(INTERFACE_MIXINVENTORY)
        || IsVisible(INTERFACE_KANTURU2ND_ENTERNPC)
        || IsVisible(INTERFACE_STORAGE)
        || IsVisible(INTERFACE_INGAMESHOP)
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
        || IsVisible(INTERFACE_INGAMESHOP)
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
        || IsVisible(mu::ui::window::INTERFACE_LUCKYITEMWND)
        )
    {
        return true;
    }

    return false;
}

bool CSystem::IsImpossibleDuelInterface()
{
    if (IsVisible(INTERFACE_MIXINVENTORY)
        || IsVisible(INTERFACE_KANTURU2ND_ENTERNPC)
        || IsVisible(INTERFACE_STORAGE)
        || IsVisible(INTERFACE_INGAMESHOP)
#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
        || IsVisible(INTERFACE_INGAMESHOP)
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME
        || IsVisible(mu::ui::window::INTERFACE_LUCKYITEMWND)
        )
    {
        return true;
    }

    return false;
}

bool CSystem::IsImpossibleHideInterface(DWORD dwKey)
{
    if (dwKey == INTERFACE_MAINFRAME
        || dwKey == INTERFACE_SKILL_LIST
        || dwKey == INTERFACE_SLIDEWINDOW
        || dwKey == INTERFACE_MESSAGEBOX
        || dwKey == INTERFACE_CHATLOGWINDOW
        || dwKey == INTERFACE_SYSTEMLOGWINDOW
        || dwKey == INTERFACE_PARTY_INFO_WINDOW
        || dwKey == INTERFACE_KANTURU_INFO
        || dwKey == INTERFACE_BLOODCASTLE_TIME
        || dwKey == INTERFACE_CHAOSCASTLE_TIME
        || dwKey == INTERFACE_BATTLE_SOCCER_SCORE
        || dwKey == INTERFACE_DUEL_WINDOW
        || dwKey == INTERFACE_CRYWOLF
        || dwKey == INTERFACE_MU_HELPER_BAR
        || dwKey == INTERFACE_NAME_WINDOW
        || dwKey == INTERFACE_SIEGEWARFARE
        || dwKey == INTERFACE_ITEM_TOOLTIP
        || dwKey == INTERFACE_HOTKEY
        || dwKey == INTERFACE_CURSEDTEMPLE_GAMESYSTEM
        || dwKey == INTERFACE_ITEM_ENDURANCE_INFO
        || dwKey == INTERFACE_BUFF_WINDOW
        || (dwKey >= INTERFACE_3DRENDERING_CAMERA_BEGIN && dwKey <= INTERFACE_3DRENDERING_CAMERA_END)
        || dwKey == INTERFACE_DUELWATCH_MAINFRAME
        || dwKey == INTERFACE_DUELWATCH_USERLIST
        || dwKey == INTERFACE_DOPPELGANGER_FRAME
        || dwKey == INTERFACE_GOLD_BOWMAN
        || dwKey == INTERFACE_GOLD_BOWMAN_LENA
        || dwKey == INTERFACE_EMPIREGUARDIAN_TIMER
        )
    {
        return true;
    }

    return false;
}

//---------------------------------------------------------------------------------------------

void CSystem::UpdateSendMoveInterface()
{
    if (IsVisible(INTERFACE_TRADE))
    {
        SocketClient->ToGameServer()->SendTradeCancel();
        Hide(INTERFACE_TRADE);
    }
    if (IsVisible(INTERFACE_STORAGE_EXT))
    {
        Hide(INTERFACE_STORAGE_EXT);
    }
    if (IsVisible(INTERFACE_STORAGE))
    {
        Hide(INTERFACE_STORAGE);
    }
    if (IsVisible(INTERFACE_NPCGUILDMASTER))
    {
        Hide(INTERFACE_NPCGUILDMASTER);
    }
    if (IsVisible(INTERFACE_MYQUEST))
    {
        Hide(INTERFACE_MYQUEST);
    }
    if (IsVisible(INTERFACE_NPCQUEST))
    {
        Hide(INTERFACE_NPCQUEST);
    }
    if (IsVisible(INTERFACE_NPCSHOP))
    {
        Hide(INTERFACE_NPCSHOP);
    }
    if (IsVisible(INTERFACE_GUARDSMAN))
    {
        Hide(INTERFACE_GUARDSMAN);
    }
    if (IsVisible(INTERFACE_GUARDSMAN))
    {
        Hide(INTERFACE_GUARDSMAN);
    }
    if (IsVisible(INTERFACE_DEVILSQUARE))
    {
        Hide(INTERFACE_DEVILSQUARE);
    }
    if (IsVisible(INTERFACE_BLOODCASTLE))
    {
        Hide(INTERFACE_BLOODCASTLE);
    }
    if (IsVisible(INTERFACE_CURSEDTEMPLE_NPC))
    {
        Hide(INTERFACE_CURSEDTEMPLE_NPC);
    }
    if (IsVisible(INTERFACE_MYSHOP_INVENTORY))
    {
        Hide(INTERFACE_MYSHOP_INVENTORY);
    }
    if (IsVisible(INTERFACE_PURCHASESHOP_INVENTORY))
    {
        Hide(INTERFACE_PURCHASESHOP_INVENTORY);
    }
    if (IsVisible(INTERFACE_DUELWATCH))
    {
        Hide(INTERFACE_DUELWATCH);
    }
    if (IsVisible(INTERFACE_DOPPELGANGER_NPC))
    {
        Hide(INTERFACE_DOPPELGANGER_NPC);
    }
    if (IsVisible(INTERFACE_NPC_DIALOGUE))
    {
        Hide(INTERFACE_NPC_DIALOGUE);
    }
    if (IsVisible(INTERFACE_QUEST_PROGRESS))
    {
        Hide(INTERFACE_QUEST_PROGRESS);
    }
    if (IsVisible(INTERFACE_QUEST_PROGRESS_ETC))
    {
        Hide(INTERFACE_QUEST_PROGRESS_ETC);
    }
    if (IsVisible(INTERFACE_EMPIREGUARDIAN_NPC))
    {
        Hide(INTERFACE_EMPIREGUARDIAN_NPC);
    }
    if (IsVisible(INTERFACE_LUCKYCOIN_REGISTRATION))
    {
        Hide(INTERFACE_LUCKYCOIN_REGISTRATION);
    }
    if (IsVisible(INTERFACE_EXCHANGE_LUCKYCOIN))
    {
        Hide(INTERFACE_EXCHANGE_LUCKYCOIN);
    }
    if (IsVisible(INTERFACE_UNITEDMARKETPLACE_NPC_JULIA))
    {
        Hide(INTERFACE_UNITEDMARKETPLACE_NPC_JULIA);
    }
}

CSystem* CSystem::GetInstance()
{
    static CSystem s_NewUISystem;
    return &s_NewUISystem;
}

CChatLogWindow* CSystem::GetUI_NewChatLogWindow() const
{
    return m_pNewChatLogWindow;
}

CSystemLogWindow* CSystem::GetUI_NewSystemLogWindow() const
{
    return m_pNewSystemLogWindow;
}

CSlideWindow* CSystem::GetUI_NewSlideWindow() const
{
    return m_pNewSlideWindow;
}

CFriendWindow* CSystem::GetUI_NewFriendWindow() const
{
    return m_pNewFriendWindow;
}

CMainFrameWindow* CSystem::GetUI_NewMainFrameWindow() const
{
    return m_pNewMainFrameWindow;
}

CSkillList* CSystem::GetUI_NewSkillList() const
{
    return m_pNewSkillList;
}

CChatInputBox* CSystem::GetUI_NewChatInputBox() const
{
    return m_pNewChatInputBox;
}

CItemMng* CSystem::GetUI_NewItemMng() const
{
    return m_pNewItemMng;
}

CMyInventory* CSystem::GetUI_NewMyInventory() const
{
    return m_pNewMyInventory;
}

CInventoryExtension* CSystem::GetUI_NewMyInventoryExt() const
{
    return m_pNewMyInventoryExt;
}

CNPCShop* CSystem::GetUI_NewNpcShop() const
{
    return m_pNewNPCShop;
}

CPetInfoWindow* CSystem::GetUI_NewPetInfoWindow() const
{
    return m_pNewPetInfoWindow;
}

CMixInventory* CSystem::GetUI_NewMixInventory() const
{
    return m_pNewMixInventory;
}

CCastleWindow* CSystem::GetUI_NewCastleWindow() const
{
    return m_pNewCastleWindow;
}

CGuardWindow* CSystem::GetUI_NewGuardWindow() const
{
    return m_pNewGuardWindow;
}

CGatemanWindow* CSystem::GetUI_NewGatemanWindow() const
{
    return m_pNewGatemanWindow;
}

CGateSwitchWindow* CSystem::GetUI_NewGateSwitchWindow() const
{
    return m_pNewGateSwitchWindow;
}

CStorageInventory* CSystem::GetUI_NewStorageInventory() const
{
    return m_pNewStorageInventory;
}

CStorageInventoryExt* CSystem::GetUI_NewStorageInventoryExt() const
{
    return m_pNewStorageInventoryExt;
}

CGuildMakeWindow* CSystem::GetUI_NewGuildMakeWindow() const
{
    return m_pNewGuildMakeWindow;
}

CGuildInfoWindow* CSystem::GetUI_NewGuildInfoWindow() const
{
    return m_pNewGuildInfoWindow;
}

CCryWolf* CSystem::GetUI_NewCryWolfInterface() const
{
    return m_pNewCryWolfInterface;
}

CMasterLevel* CSystem::GetUI_NewMasterLevelInterface() const
{
    return m_pNewMaster_Level_Interface;
}

CMyShopInventory* CSystem::GetUI_NewMyShopInventory() const
{
    return m_pNewMyShopInventory;
}

CPurchaseShopInventory* CSystem::GetUI_NewPurchaseShopInventory() const
{
    return m_pNewPurchaseShopInventory;
}

CCharacterInfoWindow* CSystem::GetUI_NewCharacterInfoWindow() const
{
    return m_pNewCharacterInfoWindow;
}

CMyQuestInfoWindow* CSystem::GetUI_NewMyQuestInfoWindow() const
{
    return m_pNewMyQuestInfoWindow;
}

CPartyInfoWindow* CSystem::GetUI_NewPartyInfoWindow() const
{
    return m_pNewPartyInfoWindow;
}

CPartyListWindow* CSystem::GetUI_NewPartyListWindow() const
{
    return m_pNewPartyListWindow;
}

CNPCQuest* CSystem::GetUI_NewNPCQuest() const
{
    return m_pNewNPCQuest;
}

CEnterBloodCastle* CSystem::GetUI_NewEnterBloodCastle() const
{
    return m_pNewEnterBloodCastle;
}

CEnterDevilSquare* CSystem::GetUI_NewEnterDevilSquare() const
{
    return m_pNewEnterDevilSquare;
}

CBloodCastle* CSystem::GetUI_NewBloodCastle() const
{
    return m_pNewBloodCastle;
}

CTrade* CSystem::GetUI_NewTrade() const
{
    return m_pNewTrade;
}

CKanturu2ndEnterNpc* CSystem::GetUI_NewKanturu2ndEnterNpc() const
{
    return m_pNewKanturu2ndEnterNpc;
}

CKanturuInfoWindow* CSystem::GetUI_NewKanturuInfoWindow() const
{
    return m_pNewKanturuInfoWindow;
}

CCatapultWindow* CSystem::GetUI_NewCatapultWindow() const
{
    return m_pNewCatapultWindow;
}

CChaosCastleTime* CSystem::GetUI_NewChaosCastleTime() const
{
    return m_pNewChaosCastleTime;
}

CCommandWindow* CSystem::GetUI_NewCommandWindow() const
{
    return m_pNewCommandWindow;
}

CWindowMenu* CSystem::GetUI_NewWindowMenu() const
{
    return m_pNewWindowMenu;
}

COptionWindow* CSystem::GetUI_NewOptionWindow() const
{
    return m_pNewOptionWindow;
}

CMuHelperBar* CSystem::GetUI_MuHelperBar() const
{
    return m_pMuHelperBar;
}

CHelpWindow* CSystem::GetUI_NewHelpWindow() const
{
    return m_pNewHelpWindow;
}

CChatCommandWindow* CSystem::GetUI_NewChatCommandWindow() const
{
    return m_pNewChatCommandWindow;
}

CItemExplanationWindow* CSystem::GetUI_NewItemExplanationWindow() const
{
    return m_pNewItemExplanationWindow;
}

CSetItemExplanation* CSystem::GetUI_NewSetItemExplanation() const
{
    return m_pNewSetItemExplanation;
}

CQuickCommandWindow* CSystem::GetUI_NewQuickCommandWindow() const
{
    return m_pNewQuickCommandWindow;
}

CMoveCommandWindow* CSystem::GetUI_NewMoveCommandWindow() const
{
    return m_pNewMoveCommandWindow;
}

CBattleSoccerScore* CSystem::GetUI_NewBattleSoccerScore() const
{
    return m_pNewBattleSoccerScore;
}

CDuelWindow* CSystem::GetUI_NewDuelWindow() const
{
    return m_pNewDuelWindow;
}

CSiegeWarfare* CSystem::GetUI_NewSiegeWarfare() const
{
    return m_pNewSiegeWarfare;
}

CItemEnduranceInfo* CSystem::GetUI_NewItemEnduranceInfo() const
{
    return m_pNewItemEnduranceInfo;
}

CNameWindow* CSystem::GetUI_NewNameWindow() const
{
    return m_pNewNameWindow;
}

CBuffStrip* CSystem::GetUI_BuffStrip() const
{
    return m_pBuffStrip;
}

CCursedTempleEnter* CSystem::GetUI_NewCursedTempleEnterWindow() const
{
    return m_pNewCursedTempleEnterWindow;
}

CCursedTempleSystem* CSystem::GetUI_NewCursedTempleWindow() const
{
    return m_pNewCursedTempleWindow;
}

CCursedTempleResult* CSystem::GetUI_NewCursedTempleResultWindow() const
{
    return m_pNewCursedTempleResultWindow;
}

CGoldBowmanWindow* CSystem::GetUI_pNewGoldBowman() const
{
    return m_pNewGoldBowman;
}

CGoldBowmanLena* CSystem::GetUI_pNewGoldBowmanLena() const
{
    return m_pNewGoldBowmanLena;
}

CRegistrationLuckyCoin* CSystem::GetUI_pNewLuckyCoinRegistration() const
{
    return m_pNewLuckyCoinRegistration;
}

CExchangeLuckyCoin* CSystem::GetUI_pNewExchangeLuckyCoin() const
{
    return m_pNewExchangeLuckyCoinWindow;
}

CMiniMap* CSystem::GetUI_pNewUIMiniMap() const
{
    return m_pNewMiniMap;
}

CDuelWatchWindow* CSystem::GetUI_pNewDuelWatch() const
{
    return m_pNewDuelWatchWindow;
}

CDuelWatchMainFrameWindow* CSystem::GetUI_pNewDuelWatchMainFrame() const
{
    return m_pNewDuelWatchMainFrameWindow;
}

CDuelWatchUserListWindow* CSystem::GetUI_pNewDuelWatchUserList() const
{
    return m_pNewDuelWatchUserListWindow;
}

#ifdef PBG_ADD_INGAMESHOP_UI_MAINFRAME
CInGameShop* CSystem::GetUI_pNewInGameShop() const
{
    return m_pNewInGameShop;
}
#endif //PBG_ADD_INGAMESHOP_UI_MAINFRAME

CDoppelGangerWindow* CSystem::GetUI_pNewDoppelGangerWindow() const
{
    return m_pNewDoppelGangerWindow;
}

CDoppelGangerFrame* CSystem::GetUI_pNewDoppelGangerFrame() const
{
    return m_pNewDoppelGangerFrame;
}

CNPCDialogue* CSystem::GetUI_NewNPCDialogue() const
{
    return m_pNewNPCDialogue;
}

CQuestProgress* CSystem::GetUI_NewQuestProgress() const
{
    return m_pNewQuestProgress;
}

CQuestProgressByEtc* CSystem::GetUI_NewQuestProgressByEtc() const
{
    return m_pNewQuestProgressByEtc;
}

CEmpireGuardianNPC* CSystem::GetUI_pNewEmpireGuardianNPC() const
{
    return m_pNewEmpireGuardianNPC;
}

CEmpireGuardianTimer* CSystem::GetUI_pNewEmpireGuardianTimer() const
{
    return m_pNewEmpireGuardianTimer;
}


#ifdef PBG_ADD_GENSRANKING
CGensRanking* CSystem::GetUI_NewGensRanking() const
{
    return m_pNewGensRanking;
}
#endif //PBG_ADD_GENSRANKING

CUnitedMarketPlaceWindow* CSystem::GetUI_pNewUnitedMarketPlaceWindow() const
{
    return m_pNewUnitedMarketPlaceWindow;
}

CLuckyItemWnd* mu::ui::window::CSystem::Get_pNewUILuckyItemWnd() const
{
    return m_pNewUILuckyItemWnd;
}

CMuHelperConfigWindow* CSystem::GetUI_MuHelperConfig() const
{
    return m_pMuHelperConfig;
}

CMuHelperDetailWindow* CSystem::GetUI_MuHelperDetail() const
{
    return m_pMuHelperDetail;
}

CMuHelperSkillPicker* CSystem::GetUI_MuHelperSkillPicker() const
{
    return m_pMuHelperSkillPicker;
}
