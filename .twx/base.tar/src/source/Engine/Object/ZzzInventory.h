#ifndef __ZZZINVENTORY_H__
#define __ZZZINVENTORY_H__

enum _COLUMN_TYPE
{
    _COLUMN_TYPE_LEVEL = 0,
    _COLUMN_TYPE_CAN_EQUIP,
    _COLUMN_TYPE_ATTMIN,
    _COLUMN_TYPE_ATTMAX,
    _COLUMN_TYPE_MAGIC,
    _COLUMN_TYPE_CURSE,
    _COLUMN_TYPE_PET_ATTACK,
    _COLUMN_TYPE_DEFENCE,
    _COLUMN_TYPE_DEFRATE,
    _COLUMN_TYPE_REQSTR,
    _COLUMN_TYPE_REQDEX,
    _COLUMN_TYPE_REQENG,
    _COLUMN_TYPE_A_SET,
    _COLUMN_TYPE_B_SET,
    _COLUMN_TYPE_REQCHA,
    _COLUMN_TYPE_REQVIT,
    _COLUMN_TYPE_REQNLV,
    _COLUMN_TYPE_COUNT
};

enum SKILL_TOOLTIP_RENDER_POINT
{
    STRP_NONE = 0,
    STRP_TOPLEFT,
    STRP_TOPCENTER,
    STRP_TOPRIGHT,
    STRP_LEFTCENTER,
    STRP_CENTER,
    STRP_RIGHTCENTER,
    STRP_BOTTOMLEFT,
    STRP_BOTTOMCENTER,
    STRP_BOOTOMRIGHT
};

// 세율정보

extern int		g_nTaxRate;
extern int		g_nChaosTaxRate;

// The item help table (/<item name> in the chat): ComputeItemInfo fills a row for each + level of
// the item it is given, with a column for each _COLUMN_TYPE.
inline constexpr int iMaxLevel = 15;
extern int g_iItemInfo[iMaxLevel + 1][_COLUMN_TYPE_COUNT];

// The hero's level and stats, the stats with the bonuses of items and buffs: what the item help
// table compares with each level's requirements.
struct ItemInfoHeroStats
{
    WORD level;
    WORD strength;
    WORD dexterity;
    WORD energy;
    WORD vitality;
    WORD charisma;

    bool operator==(const ItemInfoHeroStats&) const = default;
};

ItemInfoHeroStats GetItemInfoHeroStats();

///////////////////////////////////////////////////////////////////////////////
// guild
///////////////////////////////////////////////////////////////////////////////

extern wchar_t         g_GuildNotice[3][128];
extern GUILD_LIST_t GuildList[MAX_GUILDS];
extern int          g_nGuildMemberCount;
extern int          GuildListPage;
extern MARK_t		GuildMark[MAX_MARKS];
extern int			SelectMarkColor;
extern int			GuildPlayerKey;
extern int			GuildNumber;
extern int			GuildTotalScore;

extern int AllRepairGold;

//////////////////////////////////////////////////////////////////////////
// text 관련
//////////////////////////////////////////////////////////////////////////
// The rows an item's description may write into a tooltip, on top of the original client's 50: the description
// gets rows of its own, so it never takes the room the rest of the tooltip needs.
constexpr int MaxItemDescriptionRows = 32;
constexpr int MaxTextListRows = 50 + MaxItemDescriptionRows;

extern wchar_t TextList[MaxTextListRows][100];
extern int TextListColor[MaxTextListRows];
extern int TextBold[MaxTextListRows];
extern SIZE Size[MaxTextListRows];

namespace Data::Items
{
struct ItemDefinition;
}

// How wide a text is in the tooltip's text units.
using ItemTooltipTextMeasure = int (*)(const wchar_t* text, size_t length);
// Writes the item data's description in the UI's language, with its placeholders filled in for the item's level, into
// TextList, TextListColor and TextBold from TextNum on: each line wrapped to the tooltip's width and at its line
// breaks, the pieces in the line's color, a blank line or piece as the tooltip's own blank rows. At most
// MaxItemDescriptionRows rows.
void WriteItemDescriptionLines(const Data::Items::ItemDefinition& definition, int level,
                               ItemTooltipTextMeasure measure);

///////////////////////////////////////////////////////////////////////////////
// party
///////////////////////////////////////////////////////////////////////////////

extern PARTY_t Party[MAX_PARTYS];
extern int     PartyKey;
extern int     PartyNumber;

///////////////////////////////////////////////////////////////////////////////
// inventory
///////////////////////////////////////////////////////////////////////////////

extern ITEM Inventory[MAX_INVENTORY];
extern ITEM InventoryExt[MAX_INVENTORY_EXT];
extern ITEM ShopInventory[MAX_SHOP_INVENTORY];
extern int  InventoryType;
extern ITEM g_PersonalShopInven[MAX_PERSONALSHOP_INVEN];
extern ITEM g_PersonalShopBackup[MAX_PERSONALSHOP_INVEN];
extern bool g_bEnablePersonalShop;
extern int g_iPShopWndType;
extern int g_iPersonalShopMsgType;
extern wchar_t g_szPersonalShopTitle[MAX_SHOPTITLE + 1];
extern CHARACTER g_PersonalShopSeller;

extern bool EnableRenderInventory;
extern int  g_bEventChipDialogEnable;
extern int  g_shEventChipCount;
extern short g_shMutoNumber[3];
extern bool g_bServerDivisionAccept;
extern wchar_t g_strGiftName[64];

extern bool RepairShop;
extern int  RepairEnable;
extern int AskYesOrNo;
extern char OkYesOrNo;

extern int  SommonTable[];
extern int  StorageGoldFlag;
extern ITEM* SrcInventory;
extern int  SrcInventoryIndex;
extern int  DstInventoryIndex;
extern int  CheckSkill;
extern ITEM* CheckInventory;
extern ITEM* CheckInvenParent;
extern BYTE BuyItem[4];
extern int  EnableUse;
extern bool EquipmentItem;
extern wchar_t	g_lpszKeyPadInput[2][MAX_KEYPADINPUT + 1];

#ifdef ASG_ADD_GENS_SYSTEM
bool IsStrifeMap(int nMapIndex);
#endif	// ASG_ADD_GENS_SYSTEM
void CreateShiny(OBJECT* o);
void ClearInventory();
bool CheckEmptyInventory(ITEM* Inv, int InvWidth, int InvHeight);
#ifdef  AUTO_CHANGE_ITEM
void AutoEquipmentChange(int sx, int sy, ITEM* Inv, int InvWidth, int InvHeight);
#endif // AUTO_CHANGE_ITEM

int CompareItem(ITEM item1, ITEM item2);
void ConvertGold(double dGold, wchar_t* szText, int iDecimals = 0);
void ConvertGold64(__int64 Gold, wchar_t* Text);
void ConvertTaxGold(DWORD Gold, wchar_t* Text);
void ConvertChaosTaxGold(DWORD Gold, wchar_t* Text);
int64_t CalcSelfRepairCost(int64_t ItemValue, int Durability, int MaxDurability, short Type);
int64_t ConvertRepairGold(int64_t Gold, int Durability, int MaxDurability, short Type, wchar_t* Text);
void RepairAllGold(void);
WORD CalcMaxDurability(const ITEM* ip, ITEM_ATTRIBUTE* p, int Level);
void RenderTipTextList(const int sx, const int sy, int TextNum, int Tab, int iSort = RT3_SORT_CENTER, int iRenderPoint = STRP_NONE, BOOL bUseBG = TRUE);

void SendRequestUse(int Index, int Target, bool addPoints = true);
bool SendRequestEquipmentItem(STORAGE_TYPE iSrcType, int iSrcIndex, ITEM* pItem, STORAGE_TYPE iDstType, int iDstIndex);
bool IsCanUseItem();
bool IsCanTrade();
//  Party.
void InitPartyList();
void OpenPersonalShop(int iType);
void ClosePersonalShop();
void ClearPersonalShop();
bool IsExistUndecidedPrice();

void CreateGuildMark(int nMarkIndex, bool blend = true);
void CreateCastleMark(int Type, BYTE* buffer = NULL, bool blend = true);

namespace UI::Items
{
bool ShouldAnimatePreview(bool pointerInside, bool pickedItemActive, bool renderingPickedItem);
}

// The box in window pixels; the item animates while the pointer is over it.
void RenderItem3D(float sx, float sy, float Width, float Height, int Type, int Level, int excellentFlags, int ancientDiscriminator, bool PickUp = false);
// For a slot that already knows whether it is hovered -- an RmlUi element -- instead of testing the
// legacy mouse globals against the rectangle, which need not be where the item is shown.
void RenderItem3DWithHover(float sx, float sy, float Width, float Height, int Type, int Level, int excellentFlags, int ancientDiscriminator, bool hovered);
void RenderObjectScreen(int Type, int ItemLevel, int excellentFlags, int ancientDiscriminator, vec3_t Target, int Select, bool PickUp);
bool GetAttackDamage(int* iMinDamage, int* iMaxDamage);
void GetItemName(int iType, int iLevel, wchar_t* Text);
std::wstring GetItemName(int iType, int iLevel);
std::wstring GetItemDisplayName(ITEM* pItem);
void GetSpecialOptionText(int Type, wchar_t* Text, WORD Option, BYTE Value, int iMana);
// The item's information and repair tooltips, anchored in window pixels: their layout runs in the
// screen's 640x480 stretch, the space the original computed it in, whichever window asks.
void RenderItemInfoAtPx(float x, float y, ITEM* ip, bool Sell, int Inventype = 0, bool bItemTextListBoxUse = false);
void RenderRepairInfoAtPx(float x, float y, ITEM* ip, bool Sell);
void RenderSkillInfo(int sx, int sy, int Type, int SkillNum = 0, int iRenderPoint = STRP_NONE);
void RequireClass(ITEM_ATTRIBUTE* p);
bool IsRequireClassRenderItem(const short sType);
unsigned int getGoldColor(DWORD Gold);

bool IsExcellentItem(ITEM* pItem);
bool IsAncientItem(ITEM* pItem);
bool IsMoneyItem(ITEM* pItem);

void ComputeItemInfo(int iHelpItem);
void SetGroundItemLabelBuildBudget(int buildBudget);
void RenderItemName(int i, OBJECT* o, ITEM* ip, bool Sort);

BYTE CaculateFreeTicketLevel(int iType);

#endif //__ZZZINVENTORY_H__
