// w_PetProcess.cpp: implementation of the PetProcess class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameLogic/Pets/Muun.h"
#include "w_PetActionStand.h"
#include "w_PetActionRound.h"
#include "w_PetActionDemon.h"
#include "w_PetActionCollecter.h"
#include "w_PetActionCollecter_Add.h"
#include "w_PetActionUnicorn.h"
#include "w_PetProcess.h"
#include "GameLogic/Cosmetics/CosmeticArmor.h"
#include "Core/Utilities/ReadScript.h"
#include "GameLogic/Pets/CompanionCleanup.h"
#include <algorithm>

PetInfoPtr PetInfo::Make()
{
    PetInfoPtr petInfo(new PetInfo);
    return petInfo;
}

PetInfo::PetInfo() :
    m_scale(0.0f),
    m_actions(NULL),
    m_speeds(NULL),
    m_count(0)
{
}

PetInfo::~PetInfo()
{
    Destroy();
}

void PetInfo::Destroy()
{

    delete[] m_actions;
    m_actions = NULL;
    delete[] m_speeds;
    m_speeds = NULL;
}

void PetInfo::SetActions(int count, int* actions, float* speeds)
{
    constexpr int MAX_PET_ACTIONS = 100;

    if (NULL == actions || NULL == speeds || count <= 0 || count > MAX_PET_ACTIONS)
    {
        return;
    }

    Destroy();

    m_count = count;
    m_actions = new int[count]();
    memcpy(m_actions, actions, sizeof(int) * m_count);

    m_speeds = new float[count];
    memcpy(m_speeds, speeds, sizeof(float) * m_count);
}

PetProcessPtr g_petProcess;

PetProcess& ThePetProcess()
{
    assert(g_petProcess);
    return *g_petProcess;
}

PetProcessPtr PetProcess::Make()
{
    PetProcessPtr petprocess(new PetProcess);
    petprocess->Init();
    return petprocess;
}

PetProcess::PetProcess()
{
}

PetProcess::~PetProcess()
{
    Destroy();
}

void PetProcess::Init()
{
    PetActionStandPtr actionStand = PetActionStand::Make();
    m_petsAction.insert(make_pair(PC4_ELF, actionStand));
    //m_petsAction.insert( make_pair( 4, actionStand ) );

    PetActionRoundPtr actionRound = PetActionRound::Make();
    m_petsAction.insert(make_pair(PC4_TEST, actionRound));

    PetActionDemonPtr actionTest = PetActionDemon::Make();
    m_petsAction.insert(make_pair(PC4_SATAN, actionTest));

    PetActionCollecterPtr actionCollecter = PetActionCollecter::Make();
    m_petsAction.insert(make_pair(XMAS_RUDOLPH, actionCollecter));

#ifdef PJH_ADD_PANDA_PET
    PetActionCollecterAddPtr actionCollecter_Add = PetActionCollecterAdd::Make();
    m_petsAction.insert(make_pair(PANDA, actionCollecter_Add));
#endif //#ifdef PJH_ADD_PANDA_PET

    PetActionUnicornPtr actionUnicorn = PetActionUnicorn::Make();
    m_petsAction.insert(make_pair(UNICORN, actionUnicorn));

    PetActionCollecterSkeletonPtr actionCollecter_Skeleton = PetActionCollecterSkeleton::Make();
    m_petsAction.insert(make_pair(SKELETON, actionCollecter_Skeleton));

    LoadData();
    const auto addCosmetic = [this](int itemType, float scale)
    {
        auto cosmetic = PetInfo::Make();
        constexpr int ActionCount = PetObject::eAction_End;
        int actions[ActionCount];
        float speeds[ActionCount];
        std::fill_n(actions, ActionCount, PC4_TEST);
        std::fill_n(speeds, ActionCount, 0.3f);
        cosmetic->SetScale(scale);
        cosmetic->SetBlendMesh(-1);
        cosmetic->SetActions(ActionCount, actions, speeds);
        m_petsInfo.emplace(itemType, cosmetic);
    };
    for (int i = 0; i < 6; ++i) addCosmetic(GameLogic::Pets::Muun::FirstType + i, 0.65f);
    addCosmetic(ITEM_HELPER, 0.8f);
    addCosmetic(ITEM_IMP, 0.8f);
    addCosmetic(GameLogic::Cosmetics::CosmeticPetItemType, 0.5f);
    addCosmetic(GameLogic::Pets::DarkHorseItem, 1.f);
    addCosmetic(GameLogic::Pets::FenrirItem, 0.9f);
    for (const auto& skin : GameLogic::Cosmetics::FinalMuSkins)
        if (skin.part == 8) addCosmetic(skin.type, skin.scale);
}

void PetProcess::Destroy()
{
    for (auto iter = m_petsList.begin(); iter != m_petsList.end(); )
    {
        auto tempiter = iter;
        ++iter;
        Weak_Ptr(PetObject) basepet = *tempiter;

        if (basepet.expired() == FALSE)
        {
            basepet.lock()->Release();
            m_petsList.erase(tempiter);
        }
    }
    m_petsList.clear();

    m_petsAction.clear();
}

Weak_Ptr(PetAction) PetProcess::Find(int key)
{
    auto iter = m_petsAction.find(key);

    if (iter != m_petsAction.end())
    {
        return (*iter).second;
    }

    Weak_Ptr(PetAction) temp;

    return temp;
}

void PetProcess::Register(Smart_Ptr(PetObject) pPet)
{
    m_petsList.push_back(pPet);
}

std::size_t PetProcess::CountPets(CHARACTER* owner) const
{
    if (owner == nullptr)
        return 0;
    return std::count_if(m_petsList.begin(), m_petsList.end(), [owner](const auto& pet)
                         { return pet && pet->GetObject() != nullptr && pet->IsSameOwner(&owner->Object); });
}

void PetProcess::UnRegister(CHARACTER* Owner, int itemType, bool isUnregistAll, int equipmentSlot)
{
    GameLogic::Pets::RemovePetObjects(m_petsList, Owner, itemType, isUnregistAll, equipmentSlot);
}

bool PetProcess::LoadData()
{
    wchar_t FileName[100];
    mu_swprintf(FileName, L"Data\\Local\\pet.bmd");

    int _ver;
    int _array;

    FILE* fp = _wfopen(FileName, L"rb");
    if (fp == NULL)
    {
        wchar_t Text[256];
        mu_swprintf(Text, L"%ls - File not exist.", FileName);
        g_ErrorReport.Write(Text);
        MessageBox(g_hWnd, Text, NULL, MB_OK);
        SendMessage(g_hWnd, WM_DESTROY, 0, 0);

        return FALSE;
    }

    fread(&_ver, sizeof(int), 1, fp);
    fread(&_array, sizeof(int), 1, fp);

    int _type;
    int _blendMesh;
    float _scale;
    int _count;
    int* _action = new int[_array];
    float* _speed = new float[_array];

    int _listSize = 0;
    fread(&_listSize, sizeof(DWORD), 1, fp);

    int Size = sizeof(int) + sizeof(int) + sizeof(float) + sizeof(int) + ((sizeof(int) + sizeof(float)) * _array);
    BYTE* Buffer = new BYTE[Size * _listSize];

    fread(Buffer, Size * _listSize, 1, fp);

    DWORD dwCheckSum;
    fread(&dwCheckSum, sizeof(DWORD), 1, fp);

    if (dwCheckSum != GenerateCheckSum2(Buffer, Size * _listSize, 0x7F1D))
    {
        wchar_t Text[256];
        mu_swprintf(Text, L"%ls - File corrupted.", FileName);
        g_ErrorReport.Write(Text);
        MessageBox(g_hWnd, Text, NULL, MB_OK);
        SendMessage(g_hWnd, WM_DESTROY, 0, 0);

        return FALSE;
    }
    else
    {
        BYTE* pSeek = Buffer;
        for (int i = 0; i < _listSize; i++)
        {
            _type = 0;
            _scale = 0.0f;
            _blendMesh = -1;
            _count = 0;
            ZeroMemory(_action, sizeof(int) * _array);
            ZeroMemory(_speed, sizeof(float) * _array);

            BuxConvert(pSeek, Size);

            memcpy(&_type, pSeek, sizeof(_type));
            pSeek += sizeof(_type);

            memcpy(&_blendMesh, pSeek, sizeof(_blendMesh));
            pSeek += sizeof(_blendMesh);

            memcpy(&_scale, pSeek, sizeof(_scale));
            pSeek += sizeof(_scale);

            memcpy(&_count, pSeek, sizeof(_count));
            pSeek += sizeof(_count);

            memcpy(_action, pSeek, sizeof(int) * _array);
            pSeek += sizeof(int) * _array;

            // sizeof(float), not sizeof(_speed): _speed is a pointer, and on a
            // 64-bit build its size (8) overruns the 4-bytes-per-entry record
            // layout `Size` was computed with, overflowing the allocation.
            memcpy(_speed, pSeek, sizeof(float) * _array);
            pSeek += sizeof(float) * _array;

            constexpr int MAX_PET_ACTIONS = 100;
            if (_type < 0 || _type > 10000 || _count <= 0 || _count > _array || _count > MAX_PET_ACTIONS)
            {
                continue;
            }

            PetInfoPtr petInfo = PetInfo::Make();
            petInfo->SetBlendMesh(_blendMesh);
            petInfo->SetScale(_scale);
            petInfo->SetActions(_count, _action, _speed);

            m_petsInfo.insert(make_pair(ITEM_HELPER + _type, petInfo));
        }
    }
    delete[] _action;
    delete[] _speed;
    delete[] Buffer;

    return TRUE;
}

bool PetProcess::IsPet(int itemType)
{
    auto iter = m_petsInfo.find(itemType);
    if (iter == m_petsInfo.end()) return FALSE;

    Weak_Ptr(PetInfo) petInfo = (*iter).second;
    if (petInfo.expired()) return FALSE;

    return TRUE;
}

bool PetProcess::CreatePet(int itemType, int modelType, vec3_t Position, CHARACTER* Owner, int SubType, int LinkBone, int equipmentSlot)
{
    if (NULL == Owner) return FALSE;
    // Inventory, appearance and Muun refreshes can announce the same follower.
    if (HasPet(Owner, itemType, equipmentSlot)) return TRUE;

    PetObjectPtr _tempPet = PetObject::Make();
    _tempPet->SetEquipmentSlot(equipmentSlot);
    if (_tempPet->Create(itemType, modelType, Position, Owner, SubType, LinkBone))
    {
        auto iter = m_petsInfo.find(itemType);
        if (iter == m_petsInfo.end()) return FALSE;

        Weak_Ptr(PetInfo) petInfo = (*iter).second;

        int _count = 0;
        int* action = NULL;
        float* speed = NULL;
        if (petInfo.expired() == FALSE)
        {
            _count = petInfo.lock()->GetActionsCount();
            action = petInfo.lock()->GetActions();
            speed = petInfo.lock()->GetSpeeds();

            _tempPet->SetScale(petInfo.lock()->GetScale());
            _tempPet->SetBlendMesh(petInfo.lock()->GetBlendMesh());
        }

        for (int i = 0; i < _count; i++)
        {
            _tempPet->SetActions((PetObject::ActionType)i, Find(action[i]), speed[i]);
        }
        Register(_tempPet);
        return TRUE;
    }

    return FALSE;
}

bool PetProcess::HasPet(CHARACTER* owner, int itemType, int equipmentSlot) const
{
    return owner && std::any_of(m_petsList.begin(), m_petsList.end(),
        [owner, itemType, equipmentSlot](const auto& pet) { return pet && pet->IsAlive()
            && pet->EquipmentSlot() == equipmentSlot && pet->IsSameObject(&owner->Object, itemType); });
}

void PetProcess::DeletePet(CHARACTER* Owner, int itemType, bool allDelete, int equipmentSlot)
{
    if (NULL == Owner) return;

    UnRegister(Owner, itemType, allDelete, equipmentSlot);
}

void PetProcess::SetCommandPet(CHARACTER* Owner, int targetKey, PetObject::ActionType cmdType)
{
    if (NULL == Owner) return;

    for (auto iter = m_petsList.begin(); iter != m_petsList.end(); )
    {
        auto tempiter = iter;
        ++iter;
        Weak_Ptr(PetObject) basepet = *tempiter;

        if (basepet.expired() == FALSE)
        {
            if (basepet.lock()->IsSameOwner(&Owner->Object))
            {
                basepet.lock()->SetCommand(targetKey, cmdType);
            }
        }
    }
}

void PetProcess::UpdatePets()
{
    for (auto iter = m_petsList.begin(); iter != m_petsList.end(); )
    {
        auto tempiter = iter;
        ++iter;
        Weak_Ptr(PetObject) basepet = *tempiter;

        if (basepet.expired() == false)
        {
            basepet.lock()->Update();
        }
    }
    // A dead entry would make HasPet/CreatePet treat the reused owner slot as already having its pet.
    m_petsList.remove_if([](const auto& pet) { return !pet || !pet->IsAlive(); });
}

void PetProcess::CullPets()
{
    for (const auto& pet : m_petsList)
    {
        if (pet)
            pet->Cull();
    }
}

void PetProcess::RenderPets()
{
    for (auto iter = m_petsList.begin(); iter != m_petsList.end(); )
    {
        auto tempiter = iter;
        ++iter;
        Weak_Ptr(PetObject) basepet = *tempiter;

        if (basepet.expired() == FALSE)
        {
            basepet.lock()->Render();
        }
    }
}

void PetProcess::AttackMuun(CHARACTER* owner, int type, int targetIndex)
{
    for (const auto& pet : m_petsList)
        if (pet->IsSameObject(&owner->Object, type)) pet->ShowMuunAttack(targetIndex);
}
