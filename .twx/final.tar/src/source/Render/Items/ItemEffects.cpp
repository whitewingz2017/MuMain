#include "stdafx.h"
#include "Core/Utilities/Random.h"

#include "ItemEffects.h"
#include "ScopedItemEffects.h"
#include "ItemModelTable.h"
#include "UI/Core/WindowSystem.h"
#include "Scenes/MainScene.h"

#include "Core/Globals/_enum.h"
#include "Engine/Object/w_ObjectInfo.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Render/Effects/ZzzEffect.h"
#include "Render/Models/ZzzBMD.h"
#include "Render/Textures/ZzzTexture.h"
#include "Render/Textures/ZzzOpenglUtil.h"

#include <algorithm>
#include <string_view>
#include <vector>

namespace Render
{
DrawLook DrawLook::Of(const OBJECT& o)
{
    return {o.Alpha, o.BlendMesh, o.BlendMeshLight, o.BlendMeshTexCoordU, o.BlendMeshTexCoordV, o.HiddenMesh};
}
} // namespace Render

namespace Render::Items::ItemEffects
{
namespace
{
// An effect runs before the model is drawn, and may change the level the
// model glows like and the alpha it is drawn with. Drawn: it drew the model
// itself, nothing more is drawn.
using EffectFunction = Result (*)(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level);
// Spawns the effect's sprites, particles and lightning from the model's pose, in the update.
using SpawnFunction = void (*)(BMD* b, OBJECT* o, vec34_t* bones);

struct ItemEffect
{
    const char* name;
    EffectFunction apply;
    SpawnFunction spawn = nullptr;
};

// ------------------------------------------------ the effects

// For effects that only spawn: the model is drawn as usual.
Result ApplyNothing(BMD*, const OBJECT*, DrawLook&, int, float&, int&)
{
    return Result::Applied;
}

Result ApplyBillOfBalrog(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    Vector(0.5f, 0.5f, 1.5f, b->BodyLight);
    b->StreamMesh = 0;
    b->RenderBody(RENDER_TEXTURE, look.alpha, look.blendMesh, look.blendMeshLight, look.blendMeshU, look.blendMeshV,
                  look.hiddenMesh, BITMAP_CHROME);
    b->StreamMesh = -1;
    return Result::Applied;
}

Result ApplyMeshesPerLevel(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    Vector(1.f, 1.f, 1.f, b->BodyLight);
    b->StreamMesh = 0;
    b->RenderMesh(0, RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
    switch (Level)
    {
    case 2:
        b->RenderMesh(1, RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
        Vector(0.75f, 0.65f, 0.5f, b->BodyLight);
        b->RenderMesh(1, RENDER_BRIGHT | RENDER_CHROME, look.alpha, -1, look.blendMeshLight, look.blendMeshU,
                      look.blendMeshV, BITMAP_CHROME);
        break;
    case 3:
        b->RenderMesh(1, RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
        b->RenderMesh(2, RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
        Vector(0.75f, 0.65f, 0.5f, b->BodyLight);
        b->RenderMesh(1, RENDER_BRIGHT | RENDER_CHROME, look.alpha, -1, look.blendMeshLight, look.blendMeshU,
                      look.blendMeshV, BITMAP_CHROME);
        b->RenderMesh(2, RENDER_BRIGHT | RENDER_CHROME, look.alpha, -1, look.blendMeshLight, look.blendMeshU,
                      look.blendMeshV, BITMAP_CHROME);
        break;
    }
    b->StreamMesh = -1;
    return Result::Drawn;
}

Result ApplyFirecracker(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    b->StreamMesh = 0;
    look.blendMeshLight = 1.f;
    Vector(1.f, 1.f, 1.f, b->BodyLight);
    b->RenderMesh(0, RENDER_TEXTURE, look.alpha, look.blendMesh, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
    Vector(1.f, 0.f, 0.f, b->BodyLight);
    b->LightEnable = true;
    b->RenderMesh(1, RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
    b->RenderMesh(1, RENDER_BRIGHT | RENDER_CHROME, look.alpha, -1, look.blendMeshLight, look.blendMeshU,
                  look.blendMeshV);
    b->StreamMesh = -1;
    return Result::Drawn;
}

Result ApplyGmGift(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    Vector(1.f, 1.f, 1.f, b->BodyLight);
    b->RenderBody(RENDER_TEXTURE, look.alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
    b->LightEnable = true;
    Vector(0.1f, 0.6f, 0.4f, b->BodyLight);
    b->RenderMesh(0, RENDER_BRIGHT | RENDER_CHROME, 0.5f, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV);
    return Result::Drawn;
}

Result ApplyDarkLordScroll(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    b->BeginRender(look.alpha);
    look.blendMeshLight = 1.f;
    b->RenderMesh(0, RENDER_TEXTURE, Alpha, -1, look.blendMeshLight, look.blendMeshU, look.blendMeshV, look.hiddenMesh);
    look.blendMeshLight = sinf(WorldTime * 0.001f) * 0.5f + 0.5f;
    b->RenderMesh(1, RENDER_BRIGHT | RENDER_TEXTURE, Alpha, 1, look.blendMeshLight, look.blendMeshU, look.blendMeshV,
                  look.hiddenMesh);
    b->RenderMesh(2, RENDER_BRIGHT | RENDER_TEXTURE, Alpha, 2, 1 - look.blendMeshLight, look.blendMeshU,
                  look.blendMeshV, look.hiddenMesh);
    b->EndRender();
    return Result::Drawn;
}

Result ApplySpirit(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    b->RenderBody(RENDER_TEXTURE, Alpha, look.blendMesh, look.blendMeshLight, look.blendMeshU, look.blendMeshV,
                  look.hiddenMesh);
    switch (Level)
    {
    case 0:
        b->RenderMesh(0, RENDER_BRIGHT | RENDER_TEXTURE, Alpha, 0, look.blendMeshLight, look.blendMeshU,
                      look.blendMeshV, look.hiddenMesh);
        break;

    case 1:
        Vector(0.3f, 0.8f, 1.f, b->BodyLight);
        b->RenderMesh(0, RENDER_BRIGHT | RENDER_TEXTURE, Alpha, 0, look.blendMeshLight, look.blendMeshU,
                      look.blendMeshV, look.hiddenMesh);
        break;
    }
    return Result::Drawn;
}

Result ApplyPotion(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    if (Level > 0)
        Level = 7;
    return Result::Applied;
}

Result ApplyFruits(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    switch (Level)
    {
    case 0:
        Vector(0.0f, 0.5f, 1.0f, b->BodyLight);
        break;
    case 1:
        Vector(1.0f, 0.2f, 0.0f, b->BodyLight);
        break;
    case 2:
        Vector(1.0f, 0.8f, 0.0f, b->BodyLight);
        break;
    case 3:
        Vector(0.6f, 0.8f, 0.4f, b->BodyLight);
        break;
    }
    b->RenderBody(RENDER_METAL, look.alpha, look.blendMesh, look.blendMeshLight, look.blendMeshU, look.blendMeshV,
                  look.hiddenMesh, BITMAP_CHROME + 1);
    b->RenderBody(RENDER_BRIGHT | RENDER_CHROME, look.alpha, look.blendMesh, look.blendMeshLight, look.blendMeshU,
                  look.blendMeshV, look.hiddenMesh, BITMAP_CHROME + 1);
    return Result::Drawn;
}

Result ApplyDevilsEye(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    float sine = (float)sinf(WorldTime * 0.002f) * 10.f + 15.65f;

    look.blendMesh = 1;
    look.blendMeshLight = sine;
    look.blendMeshV = (int)WorldTime % 2000 * 0.0005f;
    Alpha = 2.0f;
    return Result::Applied;
}

// The eye's pulse, which the ground item's next draw adds to its light.
void SpawnDevilsEye(BMD* b, OBJECT* o, vec34_t* bones)
{
    float Luminosity = (float)sinf(WorldTime * 0.002f) * 10.f + 15.65f;
    Vector(Luminosity / 5.0f, Luminosity / 5.0f, Luminosity / 5.0f, o->Light);
}

void SpawnDevilsKey(BMD* b, OBJECT* o, vec34_t* bones)
{
    float Luminosity = (float)sinf((WorldTime) * 0.002f) * 0.35f + 0.65f;
    vec3_t p, Position, EffLight;
    Vector(0.f, 0.f, 0.f, p);

    float Scale = Luminosity * 0.8f;
    Vector(Luminosity * 2, Luminosity * 0.32f, Luminosity * 0.32f, EffLight);

    b->TransformPosition(bones[1], p, Position);
    VectorAdd(Position, o->Position, Position);
    CreateSprite(BITMAP_SPARK + 1, Position, Scale, EffLight, o);

    b->TransformPosition(bones[2], p, Position);
    VectorAdd(Position, o->Position, Position);
    CreateSprite(BITMAP_SPARK + 1, Position, Scale, EffLight, o);
}

void SpawnDevilsInvitation(BMD* b, OBJECT* o, vec34_t* bones)
{
    float Luminosity = (float)sinf((WorldTime) * 0.002f) * 0.35f + 0.65f;
    vec3_t p, Position, EffLight;
    Vector(0.f, 0.f, 0.f, p);

    float Scale = Luminosity * 0.8f;
    Vector(Luminosity * 2, Luminosity * 0.32f, Luminosity * 0.32f, EffLight);

    b->TransformPosition(bones[9], p, Position);
    VectorAdd(Position, o->Position, Position);
    CreateSprite(BITMAP_SPARK + 1, Position, Scale, EffLight, o);

    b->TransformPosition(bones[10], p, Position);
    VectorAdd(Position, o->Position, Position);
    CreateSprite(BITMAP_SPARK + 1, Position, Scale, EffLight, o);
}

void SpawnRena(BMD* b, OBJECT* o, vec34_t* bones)
{
    float Luminosity = (float)sinf((WorldTime) * 0.002f) * 0.25f + 0.75f;
    vec3_t EffLight;

    Vector(Luminosity * 1.f, Luminosity * 0.5f, Luminosity * 0.f, EffLight);
    CreateSprite(BITMAP_SPARK + 1, o->Position, 2.5f, EffLight, o);
}

Result ApplyWingsOfDragon(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.blendMeshLight = (float)(sinf(WorldTime * 0.001f) + 1.f) / 4.f;
    return Result::Applied;
}

Result ApplyWingsOfSoul(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.blendMeshLight = (float)sinf(WorldTime * 0.001f) + 1.1f;
    return Result::Applied;
}

Result ApplyRedSpirit(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.blendMeshLight = sinf(WorldTime * 0.001f) * 0.4f + 0.6f;
    return Result::Applied;
}

Result ApplyStaffOfKundun(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.blendMeshLight = sinf(WorldTime * 0.004f) * 0.3f + 0.7f;
    return Result::Applied;
}

Result ApplyDivineSet(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.blendMeshLight = 1.f;
    return Result::Applied;
}

Result ApplyHiddenMeshByLevel(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    switch (Level)
    {
    case 0:
        look.hiddenMesh = 1;
        break;
    case 1:
        look.hiddenMesh = 0;
        break;
    }
    return Result::Applied;
}

Result ApplyHideMesh1(BMD* b, const OBJECT* o, DrawLook& look, int Type, float& Alpha, int& Level)
{
    look.hiddenMesh = 1;
    return Result::Applied;
}

void SpawnWingsOfDarkness(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t posCenter, p, Position, Light;
    float Scale = sinf(WorldTime * 0.004f) * 0.3f + 0.3f;

    Scale = (Scale * 10.f) + 20.f;

    Vector(0.6f, 0.3f, 0.8f, Light);

    Vector(0.f, 0.f, 0.f, p);

    for (int i = 0; i < 5; ++i)
    {
        b->TransformPosition(bones[22 - i], p, posCenter, true);
        b->TransformPosition(bones[30 - i], p, Position, true);
        if (rand_fps_check(1))
        {
            CreateJoint(BITMAP_JOINT_THUNDER, Position, posCenter, o->Angle, 14, o, Scale);
            CreateJoint(BITMAP_JOINT_SPIRIT, posCenter, Position, o->Angle, 4, o, Scale + 5);
        }

        CreateSprite(BITMAP_FLARE_BLUE, posCenter, Scale / 28.f, Light, o);
    }

    for (int i = 0; i < 5; ++i)
    {
        b->TransformPosition(bones[7 - i], p, posCenter, true);
        b->TransformPosition(bones[11 + i], p, Position, true);
        if (rand_fps_check(1))
        {
            CreateJoint(BITMAP_JOINT_THUNDER, Position, posCenter, o->Angle, 14, o, Scale);
            CreateJoint(BITMAP_JOINT_SPIRIT, posCenter, Position, o->Angle, 4, o, Scale + 5);
        }

        CreateSprite(BITMAP_FLARE_BLUE, posCenter, Scale / 28.f, Light, o);
    }
}

void SpawnWingOfStorm(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t vRelativePos, vPos, vLight;
    Vector(0.f, 0.f, 0.f, vRelativePos);
    Vector(0.f, 0.f, 0.f, vPos);
    Vector(0.f, 0.f, 0.f, vLight);

    float fLuminosity = absf(sinf(WorldTime * 0.0004f)) * 0.4f;
    Vector(0.5f + fLuminosity, 0.5f + fLuminosity, 0.5f + fLuminosity, vLight);
    int iBone[] = {9, 20, 19, 10, 18, 28, 27, 36, 35, 38, 37, 53, 48, 62, 70, 72, 71, 78, 79, 80, 87, 90, 91, 106, 102};
    float fScale = 0.f;

    for (int i = 0; i < 25; ++i)
    {
        b->TransformPosition(bones[iBone[i]], vRelativePos, vPos, true);
        fScale = 0.5f; // (Random::Rand()%10) * 0.05f + 0.3f;
        CreateSprite(BITMAP_CLUD64, vPos, fScale, vLight, o, WorldTime * 0.01f, 1);
    }

    int iBoneThunder[] = {11, 21, 29, 63, 81, 89};
    if (rand_fps_check(2))
    {
        for (int i = 0; i < 6; ++i)
        {
            b->TransformPosition(bones[iBoneThunder[i]], vRelativePos, vPos, true);
            if (Random::Rand() % 20 == 0)
            {
                Vector(0.6f, 0.6f, 0.9f, vLight);
                CreateEffect(MODEL_FENRIR_THUNDER, vPos, o->Angle, vLight, 1, o);
            }
        }
    }

    int iBoneLight[] = {64, 61, 69, 77, 86, 98, 97, 99, 104, 103, 105, 12, 8, 17, 26, 34, 52, 44, 51, 50, 49, 45};

    fScale = absf(sinf(WorldTime * 0.003f)) * 0.2f;

    for (int i = 0; i < 22; ++i)
    {
        b->TransformPosition(bones[iBoneLight[i]], vRelativePos, vPos, true);
        if (iBoneLight[i] == 12 || iBoneLight[i] == 64 || iBoneLight[i] == 98 || iBoneLight[i] == 52)
        {
            Vector(0.9f, 0.0f, 0.0f, vLight);
            CreateSprite(BITMAP_LIGHT, vPos, fScale + 1.4f, vLight, o);
        }
        else
        {
            Vector(0.8f, 0.5f, 0.2f, vLight);
            CreateSprite(BITMAP_LIGHT, vPos, fScale + 0.3f, vLight, o);
        }
    }
}

void SpawnWingOfEternal(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t p, Position, Light;
    Vector(0.f, 0.f, 0.f, p);
    float Scale = absf(sinf(WorldTime * 0.003f)) * 0.2f;
    float Luminosity = absf(sinf(WorldTime * 0.003f)) * 0.3f;

    Vector(0.5f + Luminosity, 0.5f + Luminosity, 0.6f + Luminosity, Light);
    // int iRedFlarePos[] = { 25, 32, 53, 15, 9, 35 };
    int iRedFlarePos[] = {24, 31, 15, 8, 53, 35};
    for (int i = 0; i < 6; ++i)
    {
        b->TransformPosition(bones[iRedFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_LIGHT, Position, Scale + 1.3f, Light, o);
    }

    Vector(0.1f, 0.1f, 0.9f, Light);
    // int iGreenFlarePos[] = { 23, 22, 24, 34, 5, 31, 14, 12, 27, 8, 6, 7, 16, 13, 56, 37, 58, 40, 39, 38 };
    int iGreenFlarePos[] = {22, 23, 25, 29, 30, 28, 32, 13, 16, 14, 12, 9, 7, 6, 57, 58, 40, 39};

    for (int i = 0; i < 18; ++i)
    {
        b->TransformPosition(bones[iGreenFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_LIGHT, Position, Scale + 1.5f, Light, o);
    }
    int iGreenFlarePos2[] = {56, 38, 51, 45};

    for (int i = 0; i < 4; ++i)
    {
        b->TransformPosition(bones[iGreenFlarePos2[i]], p, Position, true);
        CreateSprite(BITMAP_LIGHT, Position, Scale + 0.5f, Light, o);
    }
}

void SpawnWingOfIllusion(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t p, Position, Light;
    Vector(0.f, 0.f, 0.f, p);
    float Scale = absf(sinf(WorldTime * 0.002f)) * 0.2f;
    float Luminosity = absf(sinf(WorldTime * 0.002f)) * 0.4f;

    Vector(0.5f + Luminosity, 0.0f + Luminosity, 0.0f + Luminosity, Light);
    int iRedFlarePos[] = {5, 6, 7, 8, 18, 19, 23, 24, 25, 27, 37, 38};
    for (int i = 0; i < 12; ++i)
    {
        b->TransformPosition(bones[iRedFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_FLARE, Position, Scale + 0.6f, Light, o);
    }

    Vector(0.0f + Luminosity, 0.5f + Luminosity, 0.0f + Luminosity, Light);
    int iGreenFlarePos[] = {4, 9, 13, 14, 26, 32, 31, 33};

    for (int i = 0; i < 8; ++i)
    {
        b->TransformPosition(bones[iGreenFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_LIGHT, Position, 1.3f, Light, o);
    }

    Vector(1.0f, 1.0f, 1.0f, Light);
    float fLumi = (sinf(WorldTime * 0.004f) + 1.0f) * 0.05f;
    Vector(0.8f + fLumi, 0.8f + fLumi, 0.3f + fLumi, Light);
    CreateSprite(BITMAP_LIGHT, Position, 0.4f, Light, o, 0.5f);
    if (rand_fps_check(2))
    {
        b->TransformPosition(bones[13], p, Position, true);
        CreateParticle(BITMAP_SHINY, Position, o->Angle, Light, 5, 0.5f);
        b->TransformPosition(bones[31], p, Position, true);
        CreateParticle(BITMAP_SHINY, Position, o->Angle, Light, 5, 0.5f);
    }
}

void SpawnWingOfRuin(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t p, Position, Light;
    Vector(0.f, 0.f, 0.f, p);
    float Scale = absf(sinf(WorldTime * 0.003f)) * 0.2f;
    float Luminosity = absf(sinf(WorldTime * 0.003f)) * 0.3f;

    Vector(0.7f + Luminosity, 0.5f + Luminosity, 0.8f + Luminosity, Light);
    int iRedFlarePos[] = {6, 15, 24, 56, 47, 38};
    for (int i = 0; i < 6; ++i)
    {
        b->TransformPosition(bones[iRedFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_LIGHT, Position, Scale + 1.5f, Light, o);
    }

    Vector(0.6f, 0.4f, 0.7f, Light);
    int iSparkPos[] = {7,  16, 25, 57, 48, 39, 11, 22, 31, 63, 54, 40, 10, 21, 30, 62, 53, 41, 9,
                       20, 29, 61, 52, 42, 8,  19, 28, 60, 51, 43, 18, 27, 59, 50, 17, 26, 58, 49};
    int iNumParticle = 1;

    for (int i = 0; i < 6; ++i)
    {
        b->TransformPosition(bones[iSparkPos[i]], p, Position, true);
        for (int j = 0; j < iNumParticle; ++j)
            if (rand_fps_check(1))
                CreateParticle(BITMAP_CHROME_ENERGY2, Position, o->Angle, Light, 0, 0.1f);
    }

    for (int i = 6; i < 18; ++i)
    {
        b->TransformPosition(bones[iSparkPos[i]], p, Position, true);
        for (int j = 0; j < iNumParticle; ++j)
            if (rand_fps_check(1))
                CreateParticle(BITMAP_CHROME_ENERGY2, Position, o->Angle, Light, 0, 0.3f);
    }

    for (int i = 18; i < 30; ++i)
    {
        b->TransformPosition(bones[iSparkPos[i]], p, Position, true);
        for (int j = 0; j < iNumParticle; ++j)
            if (rand_fps_check(1))
                CreateParticle(BITMAP_CHROME_ENERGY2, Position, o->Angle, Light, 0, 0.5f);
    }

    for (int i = 30; i < 38; ++i)
    {
        b->TransformPosition(bones[iSparkPos[i]], p, Position, true);
        for (int j = 0; j < iNumParticle; ++j)
            if (rand_fps_check(1))
                CreateParticle(BITMAP_CHROME_ENERGY2, Position, o->Angle, Light, 0, 0.7f);
    }
}

void SpawnWingOfDimension(BMD* b, OBJECT* o, vec34_t* bones)
{
    vec3_t p, Position, Light;
    Vector(0.f, 0.f, 0.f, p);
    float Scale = absf(sinf(WorldTime * 0.002f)) * 0.2f;
    float Luminosity = absf(sinf(WorldTime * 0.002f)) * 0.4f;

    Vector((1.0f + Luminosity) / 2.f, (0.7f + Luminosity) / 2.f, (0.2f + Luminosity) / 2.f, Light);
    int iFlarePos0[] = {7, 30, 31, 43, 8, 20};

    int icnt;
    for (icnt = 0; icnt < 2; ++icnt)
    {
        b->TransformPosition(bones[iFlarePos0[icnt]], p, Position, true);
        CreateSprite(BITMAP_FLARE, Position, Scale + 2.0f, Light, o);
    }
    Vector((1.0f + Luminosity) / 4.f, (0.7f + Luminosity) / 4.f, (0.2f + Luminosity) / 4.f, Light);
    for (; icnt < 6; ++icnt)
    {
        b->TransformPosition(bones[iFlarePos0[icnt]], p, Position, true);
        CreateSprite(BITMAP_FLARE, Position, Scale + 0.5f, Light, o);
    }

    Vector((0.5f + Luminosity) / 2.f, (0.1f + Luminosity) / 2.f, (0.4f + Luminosity) / 2.f, Light);
    int iGreenFlarePos[] = {29, 38, 42, 19, 15, 6};

    for (int i = 0; i < 6; ++i)
    {
        b->TransformPosition(bones[iGreenFlarePos[i]], p, Position, true);
        CreateSprite(BITMAP_FLARE, Position, Scale + 2.0f, Light, o);
    }
}

// ------------------------------------------------ the names

const ItemEffect ItemEffects[] = {
    {"billOfBalrog", ApplyBillOfBalrog},
    {"meshesPerLevel", ApplyMeshesPerLevel},
    {"firecracker", ApplyFirecracker},
    {"gmGift", ApplyGmGift},
    {"darkLordScroll", ApplyDarkLordScroll},
    {"spirit", ApplySpirit},
    {"potion", ApplyPotion},
    {"fruits", ApplyFruits},
    {"devilsEye", ApplyDevilsEye, SpawnDevilsEye},
    {"devilsKey", ApplyNothing, SpawnDevilsKey},
    {"devilsInvitation", ApplyNothing, SpawnDevilsInvitation},
    {"rena", ApplyNothing, SpawnRena},
    {"wingsOfDragon", ApplyWingsOfDragon},
    {"wingsOfSoul", ApplyWingsOfSoul},
    {"redSpirit", ApplyRedSpirit},
    {"staffOfKundun", ApplyStaffOfKundun},
    {"divineSet", ApplyDivineSet},
    {"hiddenMeshByLevel", ApplyHiddenMeshByLevel},
    {"hideMesh1", ApplyHideMesh1},
    {"wingsOfDarkness", ApplyNothing, SpawnWingsOfDarkness},
    {"wingOfStorm", ApplyNothing, SpawnWingOfStorm},
    {"wingOfEternal", ApplyNothing, SpawnWingOfEternal},
    {"wingOfIllusion", ApplyNothing, SpawnWingOfIllusion},
    {"wingOfRuin", ApplyNothing, SpawnWingOfRuin},
    {"wingOfDimension", ApplyNothing, SpawnWingOfDimension},
};

const ItemEffect* FindEffect(std::string_view name)
{
    const auto found = std::find_if(std::begin(ItemEffects), std::end(ItemEffects),
                                    [name](const ItemEffect& effect) { return effect.name == name; });
    return found != std::end(ItemEffects) ? found : nullptr;
}

// The effect of every item type, taken from the item model database after
// each build of it.
ItemModelTable<const ItemEffect*> g_itemEffects{[](const Data::Items::ItemModelDefinition& model)
                                                {
                                                    // Names that are not effects are drawn without one; the
                                                    // model loader reports them.
                                                    return model.itemEffect.empty() ? nullptr
                                                                                    : FindEffect(model.itemEffect);
                                                }};
ItemModelTable<const Data::Items::ItemModelDefinition*> g_staticEffects{
    [](const Data::Items::ItemModelDefinition& model) { return &model; }};

void ApplyStaticEffects(BMD* b, const OBJECT* o, int modelType, float alpha)
{
    const auto* effects = g_staticEffects.Find(modelType);
    if (!effects || alpha <= 0.f) return;
    vec3_t originalLight;
    VectorCopy(b->BodyLight, originalLight);
    for (const auto& effect : effects->meshEffects)
    {
        if (effect.mesh < 0 || effect.mesh >= b->NumMeshs) continue;
        for (int channel = 0; channel < 3; ++channel)
            b->BodyLight[channel] = static_cast<float>(effect.color[channel]);
        b->RenderMesh(effect.mesh, effect.flags, alpha, -1, 1.f);
    }
    VectorCopy(originalLight, b->BodyLight);
}

bool TransformAttachment(BMD* b, int bone, const std::array<double, 3>& color, const std::array<double, 3>& offset, float alpha,
                         vec3_t position, vec3_t light)
{
    if (bone < 0 || bone >= b->NumBones || !b->Bones || b->Bones[bone].Dummy) return false;
    vec3_t origin{};
    for (int axis = 0; axis < 3; ++axis) origin[axis] = static_cast<float>(offset[axis]);
    b->TransformPosition(BoneTransform[bone], origin, position, true);
    for (int channel = 0; channel < 3; ++channel)
        light[channel] = static_cast<float>(color[channel]) * alpha;
    return true;
}

void DrawAttachmentSprite(int textureId, double size, vec3_t position, vec3_t light, double rotation = 0.0)
{
    const auto* texture = Bitmaps.FindTexture(textureId);
    if (!texture || texture->Width <= 0 || texture->Height <= 0) return;
    const float scale = static_cast<float>(size);
    EnableAlphaBlend(false);
    RenderSprite(textureId, position, texture->Width * scale, texture->Height * scale, light, static_cast<float>(rotation));
}

double AttachmentParticlePreviewSize(const Data::Items::ItemParticleEffect& effect)
{
    constexpr double HikPreviewSize = 0.35;
    constexpr double ShinyPreviewSize = 0.3;
    constexpr double SparkPreviewSize = 1.2;
    if (effect.texture == BITMAP_FIRE_HIK2_MONO) return HikPreviewSize;
    if (effect.texture == BITMAP_SHINY + 6 && effect.subType == 1) return ShinyPreviewSize;
    if (effect.texture == BITMAP_SPARK + 1) return SparkPreviewSize;
    return std::abs(effect.size);
}

void RenderParticleAttachments(BMD* b, OBJECT* o, const Data::Items::ItemModelDefinition& model, float alpha)
{
    if (IsParticlesDisabledDebug()) return;
    for (const auto& effect : model.particleEffects)
    {
        // HIK2 and sparkle particles initialize their own scale, including zero-size source rows.
        const bool initializesScale = effect.texture == BITMAP_FIRE_HIK2_MONO
            || (effect.texture == BITMAP_SHINY + 6 && effect.subType == 1)
            || effect.texture == BITMAP_SPARK + 1;
        if (effect.size == 0.0 && !initializesScale) continue;
        if (!Bitmaps.FindTexture(effect.texture)) continue;
        vec3_t position, light;
        if (!TransformAttachment(b, effect.bone, effect.color, effect.offset, alpha, position, light)) continue;
        if (ScopedItemEffects::LocalParticles())
        {
            DrawAttachmentSprite(effect.texture, AttachmentParticlePreviewSize(effect), position, light);
            continue;
        }
        CreateParticleFpsChecked(effect.texture, position, o->Angle, light, effect.subType,
                                 static_cast<float>(effect.size));
    }
}

} // namespace

void RenderAttachments(BMD* b, OBJECT* o, int modelType, float alpha)
{
    if (!ScopedItemEffects::Enabled() || o->EnableShadow || alpha <= 0.f
        || !g_pOption->GetRenderAllEffects()) return;
    const auto* effects = g_staticEffects.Find(modelType);
    if (!effects || (effects->staticEffects.empty() && effects->particleEffects.empty())) return;
    // Attached colors belong to this draw, not the finite world-particle queue.
    RenderWithSpriteCamera([&]
    {
        if (!IsSpritesDisabledDebug())
        {
            for (const auto& effect : effects->staticEffects)
            {
                vec3_t position, light;
                if (!TransformAttachment(b, effect.bone, effect.color, effect.offset, alpha, position, light)) continue;
                DrawAttachmentSprite(effect.texture, effect.size, position, light, effect.rotation);
            }
        }
        RenderParticleAttachments(b, o, *effects, alpha);
    });
}

void RenderPetEffects(BMD* b, OBJECT* o, int modelType, float alpha, bool defaultGlow)
{
    if (!ScopedItemEffects::Enabled() || o->EnableShadow || alpha <= 0.f
        || !g_pOption->GetRenderAllEffects()) return;
    if (defaultGlow && b->NumMeshs > 0)
    {
        constexpr int FinalMuFollowerGlowFlags = 70;
        vec3_t originalLight;
        VectorCopy(b->BodyLight, originalLight);
        Vector(1.f, 1.f, 1.f, b->BodyLight);
        b->RenderMesh(0, FinalMuFollowerGlowFlags, alpha, -1, 1.f);
        VectorCopy(originalLight, b->BodyLight);
    }
    ApplyStaticEffects(b, o, modelType, alpha);
    RenderAttachments(b, o, modelType, alpha);
}

bool Exists(std::string_view name)
{
    return FindEffect(name) != nullptr;
}

std::span<const std::string_view> GetNames()
{
    static const std::vector<std::string_view> names = []
    {
        std::vector<std::string_view> sorted;
        for (const ItemEffect& effect : ItemEffects)
        {
            sorted.emplace_back(effect.name);
        }
        std::ranges::sort(sorted);
        return sorted;
    }();
    return names;
}

Result Apply(BMD* b, const OBJECT* o, DrawLook& look, int modelType, float& alpha, int& level)
{
    // The item model's own colored mesh layers (TwinMU item models), unless a preview turned them off.
    if (ScopedItemEffects::Enabled())
        ApplyStaticEffects(b, o, modelType, alpha);
    const ItemEffect* effect = g_itemEffects.Find(modelType);
    return effect != nullptr ? effect->apply(b, o, look, modelType, alpha, level) : Result::None;
}

bool Spawns(int modelType)
{
    const ItemEffect* effect = g_itemEffects.Find(modelType);
    return effect != nullptr && effect->spawn != nullptr;
}

void Spawn(BMD* b, OBJECT* o, int modelType, float (*bones)[3][4])
{
    const ItemEffect* effect = g_itemEffects.Find(modelType);
    if (effect != nullptr && effect->spawn != nullptr)
        effect->spawn(b, o, bones);
}
} // namespace Render::Items::ItemEffects
