﻿///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Core/Utilities/Random.h"
#include "Render/Effects/EffectDraw.h"
#include "Core/Utilities/DrawSpawnCheck.h"
#include "Render/Textures/ZzzOpenglUtil.h"
#include "Render/Models/ZzzBMD.h"
#include "Render/Models/CosmeticArmor.h"
#include "Engine/Object/ZzzInfomation.h"
#include "Engine/Object/ZzzObject.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Render/Terrain/ZzzLodTerrain.h"
#include "Render/Textures/ZzzTexture.h"
#include "Engine/AI/ZzzAI.h"
#include "ZzzEffect.h"
#include "Render/Effects/EffectRegistry.h"
#include "Render/Effects/Behaviors/MoveHandlers.h"
#include "Data/GameData/ItemData/ItemModelSlots.h"
#include "Audio/DSPlaySound.h"
#include "UI/Core/UIManager.h"
#include "GameLogic/Events/Cinematic/CDirection.h"
#include "World/MapInfra/MapManager.h"
#include "GameLogic/Skills/SkillEffectMgr.h"
#include "GameLogic/Skills/SkillManager.h"
#include "Character/CharacterManager.h"
#include "UI/Core/WindowSystem.h"
#include "Engine/Object/ZzzInterface.h"
#include "Scenes/MainScene.h"

PARTICLE  Particles[MAX_PARTICLES];
#ifdef DEVIAS_XMAS_EVENT
PARTICLE  Leaves[MAX_LEAVES_DOUBLE];
#else // DEVIAS_XMAS_EVENT
PARTICLE  Leaves[MAX_LEAVES];
#endif // DEVIAS_XMAS_EVENT
JOINT     Joints[MAX_JOINTS];

BYTE    g_byUpperBoneLocation[7] = { 25, 26, 27, 20, 34, 35, 36 };

OBJECT Effects[MAX_EFFECTS];

bool CheckCharacterRange(OBJECT* so, float Range, short PKKey, BYTE Kind = 0)
{
    for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
    {
        CHARACTER* c = &CharactersClient[i];
        OBJECT* o = &c->Object;

        if (!o->Live || (Kind != 0 && Kind == o->Kind)) continue;

        if (so->Owner != o)
        {
            float dx = so->Position[0] - o->Position[0];
            float dy = so->Position[1] - o->Position[1];
            float Distance = sqrtf(dx * dx + dy * dy);

            if (o->Live && o->Visible && (c != Hero || (Kind == KIND_MONSTER)) && c->Dead == 0 && Distance <= Range)
            {
                return true;
            }
        }
    }
    return false;
}

bool AttackCharacterRange(int Index, vec3_t Position, float Range, BYTE Serial, short PKKey, WORD SkillSerialNum)
{
    return false; // we don't send this packet anymore
}

void CreateHealing(OBJECT* o)
{
    vec3_t Angle, p, Position;
    float Matrix[3][4];
    Vector(0.f, -200.f, 0.f, p);
    for (int j = 0; j < 3; j++)
    {
        Vector((float)(Random::Rand() % 90), 0.f, (float)(Random::Rand() % 360), Angle);
        AngleMatrix(Angle, Matrix);
        VectorRotate(p, Matrix, Position);
        VectorSubtract(o->Position, Position, Position);
        Position[2] += 120.f;
        if (o->SubType == 5)
        {
            CreateJoint(BITMAP_JOINT_HEALING, Position, o->Position, Angle, 11, o->Owner, 5.f);
        }
        else
        {
            CreateJoint(BITMAP_JOINT_HEALING, Position, o->Position, Angle, o->SubType, o->Owner, 5.f);
        }
    }
}

void CreateForce(OBJECT* o, vec3_t Pos)
{
    vec3_t Angle, p, Position;
    float Matrix[3][4];
    Vector(0.f, -500.f, 0.f, p);
    for (int j = 0; j < 3; j++)
    {
        Vector((float)(Random::Rand() % 90), 0.f, (float)(Random::Rand() % 360), Angle);
        AngleMatrix(Angle, Matrix);
        VectorRotate(p, Matrix, Position);
        VectorSubtract(Pos, Position, Position);
        Position[2] += 120.f;
        CreateJoint(BITMAP_JOINT_HEALING, Position, Pos, Angle, 8, o, 10.f);
    }
}

void EffectDestructor(OBJECT* o)
{
    switch (o->Type)
    {
    case MODEL_EFFECT_FLAME_STRIKE:
        RemoveObjectBlurs(o, 1);
        RemoveObjectBlurs(o, 2);
        RemoveObjectBlurs(o, 3);
        break;
    case MODEL_SUMMONER_SUMMON_LAGUL:
        for (int i = 48; i <= 53; ++i)
        {
            DeleteJoint(BITMAP_JOINT_ENERGY, o, i);
        }
        break;
    }

    o->Live = false;
    o->Owner = NULL;
}

void TerminateOwnerEffectObject(int iOwnerObjectType)
{
    if (iOwnerObjectType < 0)
    {
        return;
    }

    for (int i = 0; i < MAX_EFFECTS; i++)
    {
        OBJECT* o = &Effects[i];

        if (o->Owner != NULL &&
            o->Type == MODEL_AIR_FORCE &&
            o->Owner->Type == iOwnerObjectType)
        {
            o->Owner = NULL;
        }
    }
}

bool DeleteEffect(int Type, OBJECT* Owner, int iSubType)
{
    Diagnostics::DrawSpawnCheck::Note("delete-effect");
    bool bDelete = false;
    for (int i = 0; i < MAX_EFFECTS; i++)
    {
        OBJECT* o = &Effects[i];
        if (o->Live && o->Type == Type)
        {
            if (iSubType == -1 || iSubType == o->SubType)
            {
                if (o->Owner == Owner)
                {
                    EffectDestructor(o);
                    bDelete = true;
                }
            }
        }
    }

    if (bDelete == false)
    {
        bDelete = g_SkillEffects.DeleteEffect(Type, Owner, iSubType);
    }

    return bDelete;
}

void DeleteEffect(int efftype)
{
    for (int i = 0; i < MAX_EFFECTS; i++)
    {
        OBJECT* o = &Effects[i];
        if (o->Live && o->Type == efftype)
        {
            EffectDestructor(o);
        }
    }

    g_SkillEffects.DeleteEffect(efftype);
}

bool DeleteParticle(int iType)
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return false;
    }

    for (int i = 0; i < MAX_PARTICLES; ++i)
    {
        PARTICLE* o = &Particles[i];
        if (o->Live && o->Type == iType)
        {
            o->Live = false;
            o->Target = NULL;
            return true;
        }
    }

    return false;
}

bool SearchEffect(int iType, OBJECT* pOwner, int iSubType)
{
    for (int i = 0; i < MAX_EFFECTS; ++i)
    {
        OBJECT* o = &Effects[i];
        if (o->Live && o->Type == iType && o->Owner == pOwner)
        {
            if (iSubType == -1 || o->SubType == iSubType)
            {
                return true;
            }
        }
    }

    return g_SkillEffects.SearchEffect(iType, pOwner, iSubType);
    return false;
}

BOOL FindSameEffectOfSameOwner(int iType, OBJECT* pOwner)
{
    for (int i = 0; i < MAX_EFFECTS; i++)
    {
        OBJECT* o = &Effects[i];
        if (o->Live)
        {
            if (o->Type == iType && o->Owner == pOwner)
            {
                return (TRUE);
            }
        }
    }

    return g_SkillEffects.FindSameEffectOfSameOwner(iType, pOwner);
    return (FALSE);
}

void CheckTargetRange(OBJECT* o)
{
    OBJECT* to = o->Owner;
    if (to != NULL && to->Live && to->Visible)
    {
        float dx = o->Position[0] - to->Position[0];
        float dy = o->Position[1] - to->Position[1];
        float Range = sqrtf(dx * dx + dy * dy);
        if (Range <= 100.f)
        {
            o->LifeTime = 1;
            vec3_t Light;
            Vector(1.f, 1.f, 1.f, Light);
            switch (o->Type)
            {
            case MODEL_ARROW:
            case MODEL_ARROW_STEEL:
            case MODEL_ARROW_THUNDER:
            case MODEL_ARROW_LASER:
            case MODEL_ARROW_V:
            case MODEL_ARROW_SAW:
            case MODEL_ARROW_NATURE:
            case MODEL_ARROW_WING:
            case MODEL_ARROW_BOMB:
            case MODEL_LACEARROW:
            case MODEL_DARK_SCREAM:
            case MODEL_DARK_SCREAM_FIRE:
            case MODEL_ARROW_SPARK:
            case MODEL_ARROW_RING:
            case MODEL_ARROW_TANKER:
            case MODEL_ARROW_DARKSTINGER:
            case MODEL_ARROW_GAMBLE:
                break;
            case MODEL_FIRE:
                if (o->SubType == 1)
                {
                    for (int j = 0; j < 2; j++)
                        CreateEffectFpsChecked(MODEL_STONE1 + Random::Rand() % 2, o->Position, o->Angle, o->Light);
                }
                break;

            case BITMAP_ENERGY:
                CreateParticleFpsChecked(BITMAP_SPARK + 1, o->Position, o->Angle, Light, 1, 6.f);
                break;

            case MODEL_LIGHTNING_ORB:
            {
                CreateEffectFpsChecked(MODEL_LIGHTNING_ORB, o->Position, o->Angle, o->Light, 1);
            }
            break;

            case MODEL_SNOW1:
            {
                for (int j = 0; j < 2; j++)
                {
                    CreateEffectFpsChecked(MODEL_SNOW2 + Random::Rand() % 2, o->Position, o->Angle, o->Light);
                    CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, o->Light);
                }
                PlayBuffer(SOUND_BREAK01);
            }
            break;
            case MODEL_WOOSISTONE:
                if (Range <= 30.f)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        CreateEffectFpsChecked(MODEL_WOOSISTONE, o->Position, o->Angle, o->Light, 1);
                        CreateParticleFpsChecked(BITMAP_FIRE, o->Position, o->Angle, o->Light, 0, 1, o);
                    }
                    PlayBuffer(SOUND_BREAK01);
                }
                else
                {
                    o->LifeTime = 100;
                }
                break;
            }
        }
    }
}

void CreateEffectFpsChecked(int Type, vec3_t Position, vec3_t Angle, vec3_t Light, int SubType, OBJECT* Owner, short PKKey, WORD SkillIndex, WORD Skill, WORD SkillSerialNum, float Scale, short int sTargetIndex)
{
    if (rand_fps_check(1))
    {
        CreateEffect(Type, Position, Angle, Light, SubType, Owner, PKKey, SkillIndex, Skill, SkillSerialNum, Scale, sTargetIndex);
    }
}

void CreateEffect(int Type, vec3_t Position, vec3_t Angle, vec3_t Light, int SubType, OBJECT* Owner, short PKKey, WORD SkillIndex, WORD Skill, WORD SkillSerialNum, float Scale, short int sTargetIndex)
{
    Diagnostics::DrawSpawnCheck::Note("effect");
    for (int icntEffect = 0; icntEffect < MAX_EFFECTS; icntEffect++)
    {
        OBJECT* o = &Effects[icntEffect];

        if (g_SkillEffects.IsSkillEffect(Type, Position, Angle, Light, SubType, Owner, PKKey, SkillIndex, Skill, SkillSerialNum, Scale, sTargetIndex))
        {
            o = g_SkillEffects.CreateEffect();
        }

        if (!o->Live)
        {
            o->Live = true;
            // Not tested yet: a reused slot must not draw in a pass that trusts last frame's visibility.
            o->Visible = false;
            o->Type = Type;
            o->SubType = SubType;
            o->LightEnable = true;
            o->HiddenMesh = -1;
            o->BlendMesh = -1;
            o->BlendMeshLight = 1.f;
            o->BlendMeshTexCoordU = 0.f;
            o->BlendMeshTexCoordV = 0.f;
            o->AnimationFrame = 0.f;
            o->AlphaEnable = false;
            o->Alpha = 1.f;
            o->PriorAnimationFrame = 0.f;

            if (Scale <= 0.0f)
                o->Scale = 0.9f;
            else
                o->Scale = Scale;

            if (Owner)
                o->Owner = Owner;
            else
                o->Owner = NULL;

            o->Velocity = 0.3f;
            o->PKKey = PKKey;
            o->Kind = Skill;
            o->Skill = SkillIndex;
            o->RenderType = 0;
            o->AttackPoint[0] = 0;
            o->CurrentAction = 0;
            o->m_bySkillSerialNum = (BYTE)SkillSerialNum;
            o->m_sTargetIndex = sTargetIndex;

            //Vector(1.f,1.f,1.f,o->Light);
            VectorCopy(Light, o->Light);
            VectorCopy(Angle, o->Angle);
            VectorCopy(Position, o->Position);
            Vector(0.f, 0.f, 0.f, o->Direction);
            float Matrix[3][4];
            vec3_t p1, p2;

            // Data-driven effects: apply their parameter table row and any
            // one-shot creation hook, then we're done. Types whose creation is
            // not registry-driven fall through to the legacy switch below.
            if (const Render::Effects::EffectDescriptor* desc = Render::Effects::Lookup(Type); desc && (desc->create || desc->onCreate))
            {
                if (const Render::Effects::CreateParams* params = desc->CreateParamsFor(SubType))
                    Render::Effects::ApplyCreateParams(o, *params,
                                                       {{Light[0], Light[1], Light[2]},
                                                        Scale,
                                                        {Position[0], Position[1], Position[2]},
                                                        {Angle[0], Angle[1], Angle[2]}});
                if (desc->onCreate)
                    desc->onCreate(o);
                return;
            }

            switch (Type)
            {
            case MODEL_INFINITY_ARROW:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;
                    CreateEffect(MODEL_INFINITY_ARROW, Owner->Position, o->Angle, o->Light, 1, Owner);
                    CreateEffect(MODEL_INFINITY_ARROW1, Owner->Position, o->Angle, o->Light, 0, Owner);
                    CreateEffect(MODEL_INFINITY_ARROW2, Owner->Position, o->Angle, o->Light, 0, Owner);
                    CreateEffect(MODEL_INFINITY_ARROW3, Owner->Position, o->Angle, o->Light, 0, Owner);
                    CreateEffect(MODEL_INFINITY_ARROW4, Owner->Position, o->Angle, o->Light, 0, Owner);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 40;
                    o->Scale = 1.0f;
                    Vector(1.f, 1.f, 1.f, o->Light);
                    VectorCopy(o->Light, o->Direction);
                }
            }
            break;


            case MODEL_SHIELD_CRASH:
            {
                o->LifeTime = 24;
                o->Scale = 1.1f;
                o->Gravity = o->Velocity;
                Vector(0.5f, 0.5f, 1.f, o->Light);
                VectorCopy(o->Light, o->Direction);

                if (o->SubType == 0)
                {
                    CreateEffect(MODEL_SHIELD_CRASH2, Owner->Position, Owner->Angle, o->Light, 0, o->Owner);
                }
                else
                {
                    if (o->SubType == 2)
                    {
                        o->Scale = 0.7;
                    }
                    o->HiddenMesh = 0;
                }
            }
            break;


            case MODEL_IRON_RIDER_ARROW:
            {
                o->LifeTime = 12;
                o->Scale = 0.5f;
                o->Velocity = 70.f;
                Vector(0.8f, 1.0f, 0.8f, o->Light);

                vec3_t vDir;
                vec34_t vMat;
                Vector(0.f, -1.f, 0.f, vDir);
                AngleMatrix(o->Angle, vMat);
                VectorRotate(vDir, vMat, o->Direction);
                CreateJoint(BITMAP_JOINT_HEALING, o->Position, o->Position, o->Angle, 14, o, 30.f);
            }
            break;
            case MODEL_WARP2:
            case MODEL_WARP:
            case MODEL_WARP5:
            case MODEL_WARP4:
            {
                Vector(0.0f, 0.0f, 0.0f, Light);
                o->BlendMesh = -2;
                o->LifeTime = 0xffffff;
                o->Scale = 1.3f + (float)(Random::Rand() % 50) / 100.f;
                o->Gravity = (float)(Random::Rand() % 80) / 10.f;
                o->Velocity = (float)(Random::Rand() % 100) / 1000.f + 0.01f;
            }
            break;
            case MODEL_GHOST:
            {
                o->Kind = 0;
                o->BlendMeshLight = 1.0f;
                o->Velocity = 1.0f;
                o->LifeTime = 1000;
                o->Gravity = 1.0f;
                o->Distance = 1.0f;
                o->Position[2] += (float)(Random::Rand() % 200) - 100.f;
                o->Position[1] += (float)(Random::Rand() % 200) - 100.f;
                o->Position[0] += (float)(Random::Rand() % 200) - 100.f;
                o->Angle[2] += (float)(Random::Rand() % 360);
                Vector(0.f, (float)(Random::Rand() % 8) * 0.1f - 5.0f, 0.f, o->Direction);
                o->Scale = o->Scale + (float)(Random::Rand() % 5) / 40.f;
                VectorCopy(o->Position, o->StartPosition);
                Vector(0.01f, 0.01f, 0.03f, o->Light);
            }
            break;
            case MODEL_BUTTERFLY01:
                if (SceneFlag == CHARACTER_SCENE)
                    o->HiddenMesh = -2;
                o->LifeTime = 250;
                o->Velocity = 0.3f;
                o->LightEnable = false;
                o->Kind = Random::Rand() % 2;

                Vector(0.f, -5.f * o->Owner->Scale, 0.f, o->Direction);

                if (o->SubType == 3)
                    o->Scale = 0.9f;
                else
                    o->Scale = 0.25f;
                break;
            case 9:
                o->LifeTime = 30;
                o->Scale = (Random::Rand() % 3) / 10.f + 0.6f;
                o->Velocity = 10.f;
                o->PKKey = 0;
                Vector(-0.1f, -0.1f, -0.5f, o->Direction);
                break;

            case MODEL_SPEARSKILL:
                o->LifeTime = 20;
                o->Scale = 1.5f;
                o->BlendMeshLight = 1.f;
                o->Direction[0] = 5.0f * sinf(o->Angle[2] * Q_PI / 180.0f);
                o->Direction[1] = -5.0f * cosf(o->Angle[2] * Q_PI / 180.0f);
                break;
            case MODEL_SWELL_OF_MAGICPOWER_BUFF_EFF:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 999;
                    o->Timer = WorldTime;
                }
            }break;
            case MODEL_SUMMONER_EQUIP_HEAD_SAHAMUTT:
                if (o->SubType == 0)
                {
                    o->LifeTime = 100;
                    o->Scale = 0.8f;
                    Vector(0.f, 0.f, 0.f, o->Direction);
                    o->Alpha = 0.0f;
                    OBJECT* pObject = o->Owner;
                    o->Position[0] = pObject->Position[0] + cosf(WorldTime * 0.003f) * 40.0f;
                    o->Position[1] = pObject->Position[1] + sinf(WorldTime * 0.003f) * 40.0f;
                    o->Position[2] = pObject->Position[2] + (sinf(WorldTime * 0.0010f) + 2.0f) * 80.0f - 60.0f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 100000;
                }
                break;
            case MODEL_SUMMONER_EQUIP_HEAD_NEIL:
                if (o->SubType == 0)
                {
                    o->LifeTime = 100;
                    o->Scale = 0.8f;
                    o->Alpha = 0.0f;
                    Vector(0.f, 0.f, 0.f, o->Direction);
                    OBJECT* pObject = o->Owner;
                    o->Position[0] = pObject->Position[0] + cosf(WorldTime * 0.003f) * 40.0f;
                    o->Position[1] = pObject->Position[1] + sinf(WorldTime * 0.003f) * 40.0f;
                    o->Position[2] = pObject->Position[2] + (sinf(WorldTime * 0.0010f) + 2.0f) * 80.0f - 60.0f;
                    CreateJoint(MODEL_SPEARSKILL, o->Position, o->Position, o->Angle, 15, o, 40.0f, -1, 0, 0);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 100000;
                }
                break;
            case MODEL_SUMMONER_EQUIP_HEAD_LAGUL:
            {
                o->LifeTime = 100;
                o->Scale = 0.8f;
                Vector(0.f, 0.f, 0.f, o->Direction);
                o->Alpha = 0.0f;
                OBJECT* pObject = o->Owner;
                o->Position[0] = pObject->Position[0] + cosf(WorldTime * 0.003f) * 40.0f;
                o->Position[1] = pObject->Position[1] + sinf(WorldTime * 0.003f) * 40.0f;
                o->Position[2] = pObject->Position[2] + (sinf(WorldTime * 0.0010f) + 2.0f) * 80.0f - 60.0f;
                CreateJoint(MODEL_SPEARSKILL, o->Position, o->Position, o->Angle, 17, o, 40.0f, -1, 0, 0);
            }
            break;
            case MODEL_SUMMONER_SUMMON_LAGUL:
                if (o->SubType == 0)
                {
                    o->LifeTime = 160;
                    o->Scale = 1.0f;
                    o->Velocity = 0.5f;
                    VectorCopy(Position, o->HeadTargetAngle);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 160;
                    o->Alpha = 0.0f;
                    ((JOINT*)o->Owner)->Target = o;
                    o->Owner = NULL;

                    for (int i = 48; i <= 53; ++i)
                    {
                        CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, i, o, 10.f);
                    }
                }
                break;
            case MODEL_LIGHTNING_SHOCK:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 20;
                    o->Position[2] += 280.f;
                    o->Velocity = 0.0f;
                    o->Gravity = 1.0f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 12;
                    vec3_t vLight;
                    Vector(1.0f, 0.8f, 0.5f, vLight);
                    CreateEffect(BITMAP_DAMAGE_01_MONO, o->Position, o->Angle, vLight, 1);
                    Vector(1.0f, 0.0f, 0.0f, vLight);
                    CreateEffect(BITMAP_DAMAGE_01_MONO, o->Position, o->Angle, vLight, 1);

                    // magic_ground
                    vec34_t Matrix;
                    vec3_t vAngle, vDirection, vPosition;
                    float fAngle;
                    Vector(1.0f, 0.2f, 0.05f, vLight);
                    for (int i = 0; i < 5; ++i)
                    {
                        Vector(0.f, 150.f, 0.f, vDirection);
                        fAngle = o->Angle[2] + i * 72.f;
                        Vector(0.f, 0.f, fAngle, vAngle);
                        AngleMatrix(vAngle, Matrix);
                        VectorRotate(vDirection, Matrix, vPosition);
                        VectorAdd(vPosition, o->Position, vPosition);

                        CreateEffect(BITMAP_MAGIC, vPosition, o->Angle, vLight, 12);
                    }

                    Vector(1.0f, 0.4f, 0.2f, vLight);
                    VectorCopy(o->Position, vPosition);
                    vPosition[2] = RequestTerrainHeight(vPosition[0], vPosition[1]) + 10;

                    for (int i = 0; i < 3; ++i)
                        CreateEffect(MODEL_KNIGHT_PLANCRACK_A, vPosition, o->Angle, vLight, 1, o, 0, 0, 0, 0,
                                     Random::Rand() % 4 * 0.1f + 1.0f);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 15;
                    vec3_t vLight;
                    vec3_t vPosition;
                    Vector(1.0f, 0.4f, 0.2f, vLight);
                    VectorCopy(o->Position, vPosition);
                    vPosition[2] = RequestTerrainHeight(vPosition[0], vPosition[1]) + 10;

                    for (int i = 0; i < 3; ++i)
                        CreateEffect(MODEL_KNIGHT_PLANCRACK_A, o->Position, o->Angle, vLight, 1, o, 0, 0, 0, 0,
                                     Random::Rand() % 4 * 0.1f + 0.5f);
                }
            }
            break;

            case BITMAP_BOSS_LASER:
            case BITMAP_BOSS_LASER + 1:
            case BITMAP_BOSS_LASER + 2:
                o->LifeTime = 20;
                switch (Type)
                {
                case BITMAP_BOSS_LASER:
                    Vector(0.5f, 0.7f, 1.f, o->Light);
                    Vector(0.f, -50.f, 0.f, p1);
                    o->Scale = 16.f;

                    if (SubType == 1)
                    {
                        Vector(0.f, -50.f, 0.f, p1);
                        o->Scale = 3.0f;
                        Vector(1.0f, 1.0f, 1.0f, o->Light);
                    }
                    else if (SubType == 2)
                    {
                        o->LifeTime = 35;
                        Vector(0.f, -50.f, 0.f, p1);
                        o->Scale = 2.5f;
                        Vector(1.0f, 1.0f, 1.0f, o->Light);
                    }
                    break;
                case BITMAP_BOSS_LASER + 1:
                    Vector(1.f, 0.4f, 0.2f, o->Light);
                    Vector(0.f, -50.f, 0.f, p1);
                    o->Scale = 16.f;
                    break;
                case BITMAP_BOSS_LASER + 2:
                    Vector(1.f, 0.4f, 0.2f, o->Light);
                    Vector(0.f, -15.f, 0.f, p1);
                    o->Scale = 5.f;
                    break;
                }
                //o->Scale = 10.f;
                //Vector(0.f,-30.f,0.f,p1);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);
                if (o->Owner == &Hero->Object)
                {
                    VectorCopy(o->Position, Position);
                    Vector(0.f, -150.f, 0.f, p1);
                    AngleMatrix(o->Angle, Matrix);
                    vec3_t Direction;
                    VectorRotate(p1, Matrix, Direction);
                    int Number = 4;
                    for (int j = 0; j < Number; j++)
                    {
                        VectorAdd(Position, Direction, Position);
                        AttackCharacterRange(o->Skill, Position, 150.f, o->Weapon, o->PKKey);
                    }
                }
                break;
            case BITMAP_LIGHT:
                if (o->SubType == 0)
                {
                    //Vector( 0.5f, 0.5f, 1.0f, o->Light);
                    Vector(0.3f, 0.3f, 0.3f, o->Light);
                    float fAngle = 70.0f * Q_PI / 180.0f;
                    float fAngle2 = 30.0f; //( float)( Random::Rand() % 360);
                    // float fSpeed = ( float)( 18 + Random::Rand() % 10);
                    float fSpeed = (float)(9 + Random::Rand() % 5) * 0.5f;
                    o->Direction[0] = fSpeed * cosf(fAngle) * sinf(fAngle2 * Q_PI / 180.0f);
                    o->Direction[1] = fSpeed * cosf(fAngle) * cosf(fAngle2 * Q_PI / 180.0f);
                    o->Direction[2] = fSpeed * sinf(fAngle);
                    o->Scale = 3.f;
                    //o->LifeTime = 100;
                    o->LifeTime = 400;
                }
                else if (o->SubType == 1 || o->SubType == 2)
                {
                    o->LifeTime = 1000;
                    o->Velocity = 0.f;
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 30;
                    o->Velocity = 0.f;
                }
                break;
            case BITMAP_FIRE + 1:
                o->LifeTime = 10;
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, -60.f, 0.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);
                o->Position[2] += 130.f;
                break;
            case BITMAP_FLAME:
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;
                    o->Weapon = CharacterMachine->PacketSerial;
                }
                else if (o->SubType == 1 || o->SubType == 2)
                {
                    o->LifeTime = 10;
                    Vector(0.f, 0.f, 0.f, o->Angle);
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 15;
                }
                else if (o->SubType == 4)
                {
                    o->Scale = 0.01f;
                    o->LifeTime = 10;
                    Vector(0.f, 0.f, 0.f, o->Angle);
                }
                else if (o->SubType == 5)
                {
                    o->LifeTime = 20;
                }
                else if (o->SubType == 6)
                {
                    o->LifeTime = 40;
                }
                break;
            case MODEL_RAKLION_BOSS_CRACKEFFECT:
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;
                    o->Scale = Scale + 1.f;
                    o->Position[2] += 30.f;
                    o->Angle[2] = Random::Rand() % 360;
                }
                break;
            case BITMAP_CLOUD:
                if (o->SubType == 0)
                {
                    o->LifeTime = 60;
                    o->Scale = Scale;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                }
                break;
            case BITMAP_MAGIC:
                o->LifeTime = 20;
                o->Scale = 0.5f;
                if (o->SubType == 0)
                {
                    o->LifeTime = 15;
                }
                else if (o->SubType == 8)
                {
                    o->LifeTime = 30;
                    o->Scale = 1.f;
                }
                else if (o->SubType == 9)
                {
                    o->LifeTime = 40;
                    o->Scale = 2.4f;
                    Vector(0, 0, 0, o->HeadAngle);
                }
                else if (o->SubType == 10)
                {
                    o->LifeTime = 44;
                    o->Scale = 12.f;
                    o->Alpha = 0.0f;
                }
                else if (o->SubType == 11)
                {
                    o->LifeTime = 24;
                    o->Scale = 0.8f;
                    Vector(0, 0, 0, o->HeadAngle);
                }
                else if (o->SubType == 12)
                {
                    o->LifeTime = 20;
                    o->Scale = Scale * 0.1f;
                }
                else if (o->SubType == 13 || o->SubType == 14)
                {
                    o->LifeTime = 30;
                    o->Scale = 1.0f;
                    VectorCopy(Light, o->Light);
                }
                break;

            case BITMAP_MAGIC + 1:
            case BITMAP_MAGIC + 2:
                o->LifeTime = 20;
                if (o->SubType == 4 || o->SubType == 10)
                {
                    o->LifeTime = 40;
                    o->Scale = ((Random::Rand() % 50) + 50) / 100.f * 4.f;
                }
                else if (o->SubType == 6)
                {
                    o->LifeTime = 60;
                    o->Scale = ((Random::Rand() % 50) + 50) / 100.f * 4.f;
                    VectorCopy(Position, o->StartPosition);
                }
                else if (o->SubType == 7)
                {
                    o->LifeTime = 40;
                    o->Angle[2] = Random::Rand() % 360;
                }
                else if (o->SubType == 8)
                {
                    o->LifeTime = 20;
                }
                else if (o->SubType == 9)
                {
                    o->LifeTime = 10;
                    o->Scale = 0.1f;
                }
                else if (o->SubType == 11)
                {
                    o->LifeTime = 20;
                }
                else if (o->SubType == 12)
                {
                    o->LifeTime = 20;
                }
                else if (o->SubType == 13)
                {
                    o->LifeTime = 40;
                    o->Scale = Scale;
                }
                break;

            case BITMAP_PIN_LIGHT:
                switch (o->SubType)
                {
                case 3:
                case 0:	o->LifeTime = 40;	break;
                case 1:
                case 2:	o->LifeTime = 100;	break;
                case 4:
                {
                    o->Alpha = 1.0f;
                    o->LifeTime = 30;
                    o->Scale += (float)(Random::Rand() % 5) / 10.0f;
                    o->Angle[1] = Random::Rand() % 360;
                }break;
                }
                break;
            case BITMAP_ORORA:
                switch (o->SubType)
                {
                case 0:
                case 1:	o->LifeTime = 100;	break;
                case 2:
                case 3:	o->LifeTime = 25;	break;
                }
                CreateParticle(o->Type, o->Position, o->Angle, o->Light, o->SubType, 1.0f, o->Owner);
                break;

            case BITMAP_GATHERING:
                o->LifeTime = 10;

                switch (o->SubType)
                {
                case 0:
                    Vector(0.f, -100.f, 0.f, p1);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, p2);
                    VectorAdd(o->Position, p2, o->Position);

                    o->Position[2] += 150.f;
                    break;
                case 1:
                case 2:
                    VectorCopy(Position, o->StartPosition);
                    o->LifeTime = 20;
                    break;
                case 3:
                    o->LifeTime = 10;
                    Vector(-10.f, 10.f, 0.f, p1);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, p2);
                    VectorAdd(o->Position, p2, o->Position);
                    break;
                }
                break;
            case MODEL_SKILL_BLAST:
                o->LifeTime = 30;
                o->BlendMesh = 0;
                o->Scale = (float)(Random::Rand() % 8 + 10) * 0.1f;
                o->Position[0] += (float)(Random::Rand() % 100 + 200);
                o->Position[1] += (float)(Random::Rand() % 100 - 50);
                o->Position[2] += (float)(Random::Rand() % 500 + 300);
                Vector(0.f, 0.f, -50.f - Random::Rand() % 50, o->Direction);
                Vector(0.f, 20.f, 0.f, o->Angle);
                VectorCopy(o->Position, o->EyeLeft);
                CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 5, o, 100.f);
                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case MODEL_WAVE_FORCE:
                o->BlendMesh = -2;
                o->Scale = 0.9f;
                o->Velocity = 0.5f;
                o->LifeTime = 12;
                o->Skill = 0;
                o->PKKey = -1;
                o->Scale = PKKey / 100.f;
                o->BlendMeshLight = 0.1f;
                break;
            case MODEL_SKILL_INFERNO:
                o->BlendMesh = -2;
                o->Scale = 0.9f;
                o->Velocity = 0.5f;
                switch (o->SubType)
                {
                case 0:
                    Vector(0.8f, 0.8f, 0.8f, o->Light);
                    o->LifeTime = 15;
                    break;
                case 1:
                    Vector(1.0f, .5f, .2f, o->Light);
                    o->LifeTime = 35;
                    break;
                case 2:
                    o->LifeTime = 12;
                    o->HiddenMesh = SkillIndex;
                    o->Skill = 0;
                    o->PKKey = -1;
                    o->Distance = PKKey;
                    o->Scale = PKKey / 100.f;
                    o->BlendMeshLight = 0.1f;
                    break;
                case 8:
                    o->LifeTime = 12;
                    o->HiddenMesh = SkillIndex;
                    o->Skill = 0;
                    o->PKKey = -1;
                    o->Distance = PKKey;
                    o->Scale = PKKey / 100.f;
                    o->BlendMeshLight = 0.1f;
                    o->Velocity *= 4;
                    break;
                case 3:
                    Vector(0.8f, 0.8f, 0.8f, o->Light);
                    o->LifeTime = 4;
                    o->HiddenMesh = 1;
                    o->Scale = 0.02f;
                    o->Velocity = 1.f;
                    Vector(90.f, 0.f, 0.f, o->Angle);
                    break;
                case 4:
                    Vector(0.8f, 0.8f, 0.8f, o->Light);
                    o->LifeTime = 35;
                    o->HiddenMesh = 1;
                    o->Scale = 0.1f;
                    o->Gravity = 0.f;
                    break;
                case 5:
                    Vector(0.8f, 0.8f, 0.8f, o->Light);
                    o->LifeTime = 15;
                    break;
                case 6:
                    o->LifeTime = 5;
                    o->HiddenMesh = SkillIndex;
                    o->Skill = 0;
                    o->PKKey = -1;
                    o->Distance = PKKey;
                    o->Scale = PKKey / 100.f;
                    o->Velocity = 0.1f;
                    o->BlendMeshLight = 0.1f;
                    break;
                case 9:
                {
                    o->LifeTime = 13;
                    Vector(0.1f, 1.0f, 0.2f, o->Light);
                    o->Scale = 0.45f;
                    o->BlendMeshLight = 0.1f;
                    o->Gravity = 2.0f;
                }
                break;
                case 10:
                {
                    o->LifeTime = 12;
                    o->HiddenMesh = SkillIndex;
                    o->Skill = 0;
                    o->PKKey = -1;
                    o->Distance = PKKey;
                    o->Scale = PKKey / 100.f;
                    o->BlendMeshLight = 0.1f;
                }
                break;
                }
                if (o->Owner == &Hero->Object && o->SubType < 2)
                {
                    o->Weapon = CharacterMachine->PacketSerial;

                    AttackCharacterRange(o->Skill, o->Position, 400.f, o->Weapon, o->PKKey);
                }
                break;
            case MODEL_BIG_METEO1:
            case MODEL_BIG_METEO2:
            case MODEL_BIG_METEO3:
                o->LifeTime = 100;
                o->Scale = (float)(Random::Rand() % 10 + 4) * 0.1f;
                Vector(0.f, -15.f / o->Scale, -30.f / o->Scale, o->Direction);
                o->SubType = 1;
                break;
            case MODEL_PIERCING:
                o->LifeTime = 100;
                o->BlendMesh = 0;
                o->BlendMeshLight = 1.f;
                o->Gravity = 0;

                switch (SubType)
                {
                case 0:
                {
                    o->Scale = 12.f;
                    VectorCopy(o->Owner->Position, o->StartPosition);
                }
                break;
                case 1:
                    o->HiddenMesh = 0;
                    o->Scale = 24.f;
                    break;
                case 2:
                    o->HiddenMesh = 0;
                    o->Scale = 12.f;
                    o->LifeTime = 10;
                    break;
                case 3:
                {
                    o->Scale = 10.f;
                    Vector(0.9f, 0.4f, 0.6f, o->Light);
                    VectorCopy(o->Owner->Position, o->StartPosition);
                }
                break;
                }

                CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 0, o, o->Scale, 30, SubType);
                CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 1, o, o->Scale, 30, SubType);
                CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 2, o, o->Scale, 30, SubType);
                CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 3, o, o->Scale, 30, SubType);
                PlayBuffer(SOUND_FLASH);
                o->Scale = 1.f;
                break;

            case MODEL_PIERCING + 1:
                o->Velocity = 1.f;
                o->LifeTime = 30;
                AngleMatrix(o->Angle, Matrix);
                Vector(-10.f, -60.f, 135.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);

                o->Scale = 0.8f;
                o->Direction[1] = -70.f;

                CreateEffect(MODEL_PIERCING, o->Position, o->Angle, o->Light, SubType, o);
                break;

            case MODEL_ARROW_BEST_CROSSBOW:
                o->LifeTime = 30;
                o->BlendMesh = -2;
                o->Scale = 1.f;
                o->Position[2] += 130.f;
                Vector(0.f, -70.f, 0.f, o->Direction);
                VectorCopy(o->Position, o->EyeLeft);
                CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 5, o, 100.f);

                if (o->SubType != 0)
                {
                    CreateEffect(MODEL_PIERCING, o->Position, o->Angle, o->Light, 0, o);
                    o->AttackPoint[0] = 0;
                    o->Kind = 1;
                }

                o->Weapon = CharacterMachine->PacketSerial;
                break;

            case MODEL_ARROW_DOUBLE:
                o->LifeTime = 30;
                o->BlendMesh = -2;
                o->Scale = 1.f;
                o->Position[2] += 130.f;
                Vector(0.f, -70.f, 0.f, o->Direction);
                VectorCopy(o->Position, o->EyeLeft);
                CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 5, o, 100.f);

                if (o->SubType != 0)
                {
                    CreateEffect(MODEL_PIERCING, o->Position, o->Angle, o->Light, 0, o);
                    o->AttackPoint[0] = 0;
                    o->Kind = 1;
                }

                o->Weapon = CharacterMachine->PacketSerial;
                break;

            case MODEL_ARROW_HOLY:
                o->LifeTime = 30;
                o->BlendMesh = -2;
                o->Scale = 1.f;
                o->Position[2] += 130.f;

                Vector(0.f, -60.f, 0.f, o->Direction);
                AngleMatrix(o->Angle, Matrix);
                Vector(-10.f, -100.f, 15.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorCopy(o->Position, o->StartPosition);
                VectorAdd(o->StartPosition, p2, o->StartPosition);

                Vector(0.f, 0.f, o->Angle[2], Angle);

                if (o->SubType == 1)
                {
                    for (int i = 0; i < 3; ++i)
                    {
                        if (i == 1)
                            CreateJoint(BITMAP_FLARE, o->StartPosition, o->StartPosition, Angle, 25, o, 50.f, -1, 1);
                        else
                            CreateJoint(BITMAP_FLARE, o->StartPosition, o->StartPosition, Angle, 25, o, 50.f);
                    }
                }
                else
                {
                    for (int i = 0; i < 4; ++i)
                    {
                        if (i == 1)
                            CreateJoint(BITMAP_FLARE, o->StartPosition, o->StartPosition, Angle, 11, o, 50.f, -1, 1);
                        else
                            CreateJoint(BITMAP_FLARE, o->StartPosition, o->StartPosition, Angle, 11, o, 50.f);
                    }
                }

                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case MODEL_MULTI_SHOT1:
            case MODEL_MULTI_SHOT2:
            case MODEL_MULTI_SHOT3:
            case MODEL_ARROW:
            case MODEL_ARROW_STEEL:
            case MODEL_ARROW_THUNDER:
            case MODEL_ARROW_LASER:
            case MODEL_ARROW_V:
            case MODEL_ARROW_SAW:
            case MODEL_ARROW_NATURE:
            case MODEL_ARROW_WING:
            case MODEL_LACEARROW:
            case MODEL_DARK_SCREAM:
            case MODEL_DARK_SCREAM_FIRE:
            case MODEL_ARROW_SPARK:
            case MODEL_ARROW_RING:
            case MODEL_ARROW_TANKER:
            case MODEL_ARROW_DARKSTINGER:
            case MODEL_ARROW_GAMBLE:
                if (Type == MODEL_ARROW)
                    o->BlendMesh = 1;
                else if (Type == MODEL_ARROW_NATURE)
                    o->BlendMesh = -2;
                else if (Type == MODEL_ARROW_THUNDER || Type == MODEL_ARROW_LASER || Type == MODEL_ARROW_V || Type == MODEL_ARROW_WING)
                    o->BlendMesh = 0;

                o->Velocity = 1.f;
                o->LifeTime = 30;
                AngleMatrix(o->Angle, Matrix);
                Vector(-10.f, -60.f, 135.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);
                if (Type == MODEL_ARROW_WING)
                {
                    o->Scale = 1.8f;
                    o->Direction[1] = -50.f;
                    o->Gravity = -10.f;
                }
                else if (Type == MODEL_ARROW_TANKER)
                {
                    o->Angle[0] -= 18.0f;
                    o->Scale = 1.0f;
                    o->Direction[1] = -42.0f;
                    o->Direction[2] = 4.0f;
                }
                else
                    if (Type == MODEL_MULTI_SHOT1)
                    {
                        o->LifeTime = 16;
                        o->BlendMesh = -2;
                        o->Scale = 0.f;
                    }
                    else
                        if (Type == MODEL_MULTI_SHOT2)
                        {
                            o->LifeTime = 13;
                            o->BlendMesh = -2;
                            o->Scale = 0.f;
                        }
                        else
                            if (Type == MODEL_MULTI_SHOT3)
                            {
                                o->LifeTime = 12;
                                o->BlendMesh = -2;
                                o->Scale = 0.f;
                            }
                            else if (Type == MODEL_DARK_SCREAM || Type == MODEL_DARK_SCREAM_FIRE)
                            {
                                o->LifeTime = 19;
                                o->Scale = 2.3f;
                                o->Direction[1] = -35.f;
                                //					o->Direction[1] = -5.f;
                                if (Type == MODEL_DARK_SCREAM)
                                {
                                    o->Scale = 0.9f;
                                    o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]) + 3.f;
                                    vec3_t Light;
                                    Vector(0.0f, 1.0f, 0.0f, Light);
                                    if (SubType == 0)
                                    {
                                        CreateJoint(BITMAP_JOINT_FORCE, o->Position, o->Position, o->Angle, 7, o, 150.f, 40);
                                    }
                                    else if (SubType == 1)
                                    {
                                        CreateJoint(BITMAP_JOINT_FORCE, o->Position, o->Position, o->Angle, 20, o, 400.f, 40);
                                    }
                                    o->Position[2] += 20.f;
                                    vec3_t ap, P, dp;
                                    VectorCopy(o->Position, ap);
                                    Vector(0.f, -20.f, 0.f, P);
                                    AngleMatrix(o->Angle, o->Matrix);
                                    VectorRotate(P, o->Matrix, dp);
                                    VectorAdd(dp, o->Position, o->Position);
                                    CreateParticle(BITMAP_BLUE_BLUR, o->Position, o->Angle, Light, 1, 1.f);
                                }
                            }
                            else if (Type == MODEL_ARROW_SPARK)
                            {
                                o->Scale = 1.0f;
                                o->Direction[1] = -70.f;
                                CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 14, o, 50.f, 40);
                            }
                            else if (Type == MODEL_ARROW_DARKSTINGER)
                            {
                                o->Scale = 0.8f;
                                o->Direction[1] = -70.f;
                                o->LifeTime = 30;
                            }
                            else if (Type == MODEL_ARROW_GAMBLE)
                            {
                                o->Scale = 0.8f;
                                o->Direction[1] = -70.f;
                                o->LifeTime = 30;
                            }
                            else
                            {
                                o->Scale = 0.8f;
                                o->Direction[1] = -70.f;
                            }

                if (o->SubType == 2)
                {
                    CreateEffect(MODEL_PIERCING, o->Position, o->Angle, o->Light, 0, o);
                    o->AttackPoint[0] = 0;
                    o->Kind = 1;
                }
                //. Create Effect
                if (Type == MODEL_ARROW_NATURE && o->SubType == 1)
                {	//. 녹색 띠 생성
                    CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 13, o, 20.f, 40);
                    //					CreateJoint ( BITMAP_FLARE+1, o->Position, o->Position, o->Angle, 6, o, 20.f, 40 );
                    //					CheckTargetRange(o);
                }

                if (Type == MODEL_ARROW && (o->SubType == 3 || o->SubType == 4))
                {
                    o->LifeTime = 40;
                    o->Scale = 1.5f;
                    o->Gravity = (Random::Rand() % 100 + 50) / 15.f;
                    VectorCopy(Hero->Object.Position, o->StartPosition);
                    if (o->SubType == 3)
                    {
                        o->Direction[1] = -(Random::Rand() % 30 + 50.f);
                        o->Angle[0] = -(Random::Rand() % 20 + 45.f);
                    }
                    else
                    {
                        o->Direction[1] = -(Random::Rand() % 15 + 55.f);
                        o->Angle[0] = -10.f;
                    }
                }
                else if (Type == MODEL_LACEARROW)
                {
                    o->BlendMesh = 1;
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 12, o, 40.f, 80);
                }
                else if (Type == MODEL_ARROW_RING)
                {
                    o->BlendMesh = 0;
                    o->Scale = 1.0f;
                    o->Direction[1] = -70.f;
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 15, o, 50.f, 40);
                }
                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case MODEL_ARROW_BOMB:
                o->Velocity = 1.f;
                o->LifeTime = 30;
                AngleMatrix(o->Angle, Matrix);
                Vector(-10.f, -60.f, 135.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);

                o->BlendMesh = 0;
                o->Scale = 1.f;
                o->Direction[1] = -30.f;
                o->Gravity = -10.f;
                o->LifeTime = 40;

                if (o->SubType == 2)
                {
                    o->AttackPoint[0] = 0;
                    o->Kind = 1;
                }

                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case MODEL_SAW:
                o->LifeTime = 10;
                o->Position[2] += 130.f;
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, -60.f, 0.f, p1);
                VectorRotate(p1, Matrix, o->Direction);
                break;
            case MODEL_LASER:
                if (o->SubType == 0 || o->SubType == 3)
                {
                    o->LifeTime = 1;
                    o->BlendMesh = 0;
                    o->BlendMeshLight = o->Light[0];
                    o->Scale = 1.3f;
                    o->RenderType = RENDER_DARK;
                }
                else
                {
                    o->LifeTime = 30;
                    o->Velocity = 1.f;
                    o->BlendMesh = 0;
                    o->BlendMeshLight = 1.f;
                    o->Scale = 1.3f;
                    o->RenderType = RENDER_DARK;

                    o->Position[2] += 150.f;
                    Vector(0.f, -1.f, 0.f, o->Direction);
                    Vector(1.f, 0.f, 0.f, o->Light);
                    Vector(30.f, 0.f, Angle[2], o->Angle);

                    CreateJoint(BITMAP_JOINT_FORCE, o->Position, o->Position, o->Angle, 1, o, 180.f);
                }
                break;
            case MODEL_SKILL_WHEEL1:
                o->LifeTime = 5;
                CharacterMachine->PacketSerial++;
                break;
            case MODEL_SKILL_WHEEL2:
                o->LifeTime = 25;//
                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case MODEL_SKILL_FURY_STRIKE:
            {
                VectorCopy(o->Angle, o->HeadAngle);
                VectorCopy(o->Position, o->StartPosition);

                o->LifeTime = 20;//18;
                o->SubType = Random::Rand() % 100;
                o->Angle[2] += 330.f;
                o->HeadAngle[0] += 80.f;
                o->HeadAngle[2] += 180.f;
                o->Gravity = 50.f;

                o->Weapon = CharacterMachine->PacketSerial++;
            }
            break;
            case MODEL_SKILL_FURY_STRIKE + 1:
                if (o->SubType == 0)
                {
                    o->LifeTime = 35;
                    o->Scale = PKKey / 100.f;
                    o->BlendMesh = 0;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 60;
                    o->Scale = PKKey / 100.f;
                    o->BlendMesh = 0;
                }
                break;
            case MODEL_SKILL_FURY_STRIKE + 2:
                if (o->SubType == 0 || o->SubType == 1)
                {
                    o->LifeTime = 20;
                    o->Scale = PKKey / 100.f;
                    o->BlendMesh = 0;
                    if (SubType == 1)
                        o->RenderType = RENDER_DARK;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 50;
                    o->Scale = PKKey / 100.f;
                    o->BlendMesh = 0;
                }
                break;
            case MODEL_SKILL_FURY_STRIKE + 3:
                o->LifeTime = 35;
                o->Scale = PKKey / 100.f;
                break;
            case MODEL_SKILL_FURY_STRIKE + 4:
                o->LifeTime = 35;
                o->Scale = PKKey / 100.f;
                o->BlendMesh = 0;
                break;
            case MODEL_SKILL_FURY_STRIKE + 5:
                o->LifeTime = 40;
                o->Scale = PKKey / 100.f;
                o->BlendMesh = 0;
                if (SubType == 1)
                    o->RenderType = RENDER_DARK;
                break;
            case MODEL_SKILL_FURY_STRIKE + 6:
                o->LifeTime = 35;
                o->Scale = PKKey / 100.f;
                break;
            case MODEL_SKILL_FURY_STRIKE + 7:
                o->LifeTime = 40;
                o->Scale = PKKey / 100.f;
                o->BlendMesh = 0;
                break;
            case MODEL_SKILL_FURY_STRIKE + 8:
                o->LifeTime = 40;
                o->Scale = PKKey / 100.f;
                o->BlendMesh = 0;
                if (SubType == 1)
                    o->RenderType = RENDER_DARK;
                break;
            case MODEL_MAGIC2:
                o->BlendMesh = 0;
                o->LifeTime = 20;
                Vector(0.f, -60.f, 0.f, o->Direction);
                if (o->SubType == 2)
                {
                    o->Weapon = CharacterMachine->PacketSerial++;
                }
                break;
            case MODEL_STORM:
                switch (o->SubType)
                {
                case 0:
                    o->LifeTime = 59;
                    o->BlendMesh = 0;
                    Vector(0.f, -10.f, 0.f, o->Direction);
                    //Vector(0.f,-50.f,0.f,o->Direction);
                    o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
                    o->Weapon = CharacterMachine->PacketSerial++;
                    break;

                case 1:
                    o->LifeTime = 30;
                    o->HiddenMesh = -2;
                    o->Scale = 1.f;
                    o->BlendMesh = 0;
                    Vector(0.f, 0.f, 0.f, o->Direction);
                    break;

                case 2:
                    o->LifeTime = 59;
                    o->HiddenMesh = -2;
                    o->Scale = 1.f;
                    o->BlendMesh = 0;
                    Vector(0.f, -10.f, 0.f, o->Direction);
                    Vector(1.f, 1.f, 1.f, o->Light);
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                {
                    o->LifeTime = 60;
                    o->HiddenMesh = -2;
                    o->Scale = 1.0f;

                    if (o->SubType == 3) { Vector(0.f, -12.f, 0.f, o->Direction); }
                    else if (o->SubType == 4) { Vector(7.f, -6.f, 0.f, o->Direction); }
                    else if (o->SubType == 5) { Vector(-7.f, -6.f, 0.f, o->Direction); }
                    else if (o->SubType == 6) { Vector(4.f, 5.f, 0.f, o->Direction); }
                    else { Vector(-4.f, 5.f, 0.f, o->Direction); }
                }
                break;
                case 8:
                {
                    o->LifeTime = 100;
                    o->BlendMesh = 0;
                    o->Scale = 2.0f;
                }
                break;
                }
                break;
            case MODEL_SUMMON:
            {
                o->LifeTime = 60;
                o->BlendMesh = 0;
                if (o->SubType == 0)
                    o->Scale = 0.7f;
                else
                    o->Scale = 1.2f;
                o->Angle[2] += Random::Rand() % 360;
            }
            break;
            case MODEL_STORM2:
            {
                if (o->SubType == 0)
                {
                    o->Angle[0] = 90.0f;
                    o->LifeTime = 35;
                    o->BlendMesh = 0;
                    o->Scale = 0.5 + Random::Rand() % 10 / 100.0f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 60;
                    o->BlendMesh = 0;
                    o->Gravity = Random::Rand() % 10 + 30.0f;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 100;
                    o->Angle[0] = 90.0f;
                    o->BlendMesh = 0;
                    o->Scale = 1.0f;
                }
            }
            break;
            case MODEL_STORM3:
            {
                o->LifeTime = 50;
                o->BlendMesh = 0;
                o->Angle[0] = 90.0f;
                o->Scale = 3.5f;
                VectorCopy(Hero->Object.Position, o->StartPosition);
            }
            break;
            case MODEL_MAYASTONE1:
            case MODEL_MAYASTONE2:
            case MODEL_MAYASTONE3:
            {
                o->LifeTime = 40;
                o->Scale = 6.0f + (float)(Random::Rand() % 8 + 15) * 0.1f;
                Vector(0.f, 0.f, -60.f, o->Direction);
                Vector(0.f, 30.f, 0.f, o->HeadAngle);

                CreateJoint(BITMAP_SMOKE, o->Position, o->Position, o->HeadAngle, 2, o, 100.f);
            }
            break;
            case MODEL_MAYASTONEFIRE:
            {
                if (o->SubType == MODEL_MAYASTONE1)
                    o->Scale = Scale * 0.8f;
                else if (o->SubType == MODEL_MAYASTONE2)
                    o->Scale = Scale * 0.6f;
                else if (o->SubType == MODEL_MAYASTONE3)
                    o->Scale = Scale * 0.5f;
                o->LifeTime = 40;
                Vector(0.f, 0.f, -60.f, o->Direction);
                Vector(0.f, 30.f, 0.f, o->HeadAngle);
            }
            break;
            case MODEL_CIRCLE:
                o->LifeTime = 45;
                o->BlendMesh = 0;
                if (o->SubType == 0)
                {
                    if (o->Owner == &Hero->Object)
                    {
                        o->Weapon = CharacterMachine->PacketSerial++;
                        AttackCharacterRange(o->Skill, o->Position, 300.f, o->Weapon, o->PKKey);
                    }
                }
                else if (o->SubType == 1 || o->SubType == 4)
                {
                    o->LifeTime = 45;
                    o->Scale = 1.f;
                    o->HiddenMesh = -2;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 250;
                    o->Scale = 1.f;
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 30;
                    o->Scale = 1.f;
                }
                break;
            case MODEL_ICE:
                switch (o->SubType)
                {
                case 0:
                    o->LifeTime = 50;
                    o->Scale = 0.8f;
                    o->Velocity = 1.f;
                    o->Angle[0] = 0.f;
                    o->BlendMesh = 0;
                    break;

                case 1:
                case 2:
                    o->LifeTime = 20;
                    o->Scale = 0.8f;
                    o->Angle[0] = -20.f;
                    o->BlendMesh = 0;
                    o->BlendMeshLight = 0.5f;
                    o->Gravity = 5.f;
                    Vector(0.f, 0.f, (float)(Random::Rand() % 360), o->HeadAngle);

                    for (int i = 0; i < 3; ++i)
                    {
                        vec3_t Position;
                        Vector(o->Position[0] + (float)(Random::Rand() % 64 - 32),
                               o->Position[1] + (float)(Random::Rand() % 64 - 32),
                               o->Position[2] + (float)(Random::Rand() % 128 + 32), Position);
                        CreateParticle(BITMAP_SMOKE, Position, o->Angle, o->Light);
                    }
                    Vector(0.4f, 0.3f, 0.2f, Light);
                    AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);

                    VectorCopy(o->Position, o->StartPosition);
                    break;
                }
                break;
            case MODEL_SNOW1:
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, -40.f, 150.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);
                o->Direction[1] = -40.f;
                o->Direction[2] = 10.f;
                o->LifeTime = 20;
                o->Scale = 1.2f;
                break;
            case MODEL_WOOSISTONE:
                if (o->SubType == 1)
                {
                    o->Direction[0] = 0;
                    o->Direction[1] = 0;
                    o->Direction[2] = 0;

                    o->LifeTime = Random::Rand() % 16 + 20;
                    o->Scale = (float)(Random::Rand() % 13 + 3) * 0.04f;
                    o->Gravity = (float)(Random::Rand() % 3 + 3);

                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                    VectorRotate(p1, Matrix, o->HeadAngle);
                    o->HeadAngle[2] += 15.0f;
                    break;
                }
                else
                {
                    AngleMatrix(o->Angle, Matrix);
                    Vector(0.f, -60.f, 150.f, p1);
                    VectorRotate(p1, Matrix, p2);
                    VectorAdd(o->Position, p2, o->Position);
                    o->Direction[1] = -40.f;
                    o->Direction[2] = 10.f;
                    o->LifeTime = 20;
                    o->Scale = 1.0f;
                    break;
                }
            case MODEL_SKULL:
                if (o->SubType == 0)
                {
                    o->LifeTime = 1;
                    o->Scale = 2.3f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 49;
                    o->Scale = 2.f;
                    o->BlendMesh = -2;
                    o->BlendMeshLight = 0.5f;
                    Vector(0.f, 0.f, 0.f, o->HeadAngle);
                    Vector(0.f, -45.f, 0.f, o->Direction);
                    VectorCopy(o->Position, o->StartPosition);
                    VectorCopy(o->Position, o->m_vDeadPosition);

                    //
                    VectorCopy(o->Position, o->EyeLeft);
                    VectorCopy(o->Position, o->EyeRight);

                    CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 10, o, 30.f);
                    CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 11, o, 30.f);
                }
                break;
            case MODEL_CUNDUN_PART1:
            case MODEL_CUNDUN_PART2:
            case MODEL_CUNDUN_PART3:
            case MODEL_CUNDUN_PART4:
            case MODEL_CUNDUN_PART5:
            case MODEL_CUNDUN_PART6:
            case MODEL_CUNDUN_PART7:
            case MODEL_CUNDUN_PART8:
            case MODEL_ILLUSION_OF_KUNDUN:
                switch (o->SubType)
                {
                case 1:
                    o->LifeTime = 100;
                    o->Scale = 2.0f;
                    break;
                case 2:
                case 3:
                    Vector(o->Position[0], o->Position[1],
                        RequestTerrainHeight(o->Position[0], o->Position[1]) - (float)o->PKKey - 80,
                        o->StartPosition);
                    Vector(0, 0, 0, o->Direction);
                    o->LifeTime = 250 * 2;
                    o->Scale = 2.0f;
                    o->HeadAngle[0] = (float)(Random::Rand() % 2);
                    if (o->SubType == 2) o->HeadAngle[0] = 0;
                    break;
                case 4:
                    Vector(o->Position[0], o->Position[1],
                        RequestTerrainHeight(o->Position[0], o->Position[1]) - (float)o->PKKey,
                        o->StartPosition);
                    Vector(0, 0, 0, o->Direction);
                case 5:
                    o->CurrentAction = 0;
                    o->LifeTime = 170;
                    o->Scale = 2.0f;
                    break;
                }
                o->PKKey = -1;
                o->Owner = Owner;
                break;
            case MODEL_CURSEDTEMPLE_STATUE_PART1:
            case MODEL_CURSEDTEMPLE_STATUE_PART2:
                o->LifeTime = 180 + (Random::Rand() % 40);
                o->Scale = 0.1f + (Random::Rand() % 6) * 0.1f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 2.5f;
                o->Direction[0] = (float)((-15 + (Random::Rand() % 30)));
                o->Direction[1] = (float)((-15 + (Random::Rand() % 30)));
                o->Direction[2] = 0;
                o->Angle[0] = 0; //( float)( Random::Rand() % 360);
                o->Angle[1] = 0; //( float)( Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                break;
            case MODEL_XMAS2008_SNOWMAN_HEAD:
            {
                o->LifeTime = 50;
                o->Scale = 1.3f;

                o->Angle[2] = o->Owner->Angle[2];
                AngleMatrix(o->Angle, Matrix);
                o->Gravity = 5.0f;
                vec3_t p;
                Vector((float)(Random::Rand() % 10 - 5) * 0.1f, (float)(Random::Rand() % 60 - 40) * 0.1f, 0.0f, p);
                VectorScale(p, 1.3f, p);
                VectorRotate(p, Matrix, o->Direction);
                o->m_iAnimation = Random::Rand() % 3;
            }
            break;
            case MODEL_XMAS2008_SNOWMAN_BODY:
            {
                o->LifeTime = 50;
                o->Scale = 1.3f;
                o->Velocity = 1.2f;

                o->PKKey = -1;
                o->Owner = Owner;

                o->Direction[0] = o->Owner->Direction[0];
                o->Direction[1] = o->Owner->Direction[1];
                o->Direction[2] = o->Owner->Direction[2];
            }
            break;
            case MODEL_TOTEMGOLEM_PART1:
            case MODEL_TOTEMGOLEM_PART2:
            case MODEL_TOTEMGOLEM_PART3:
            case MODEL_TOTEMGOLEM_PART4:
            case MODEL_TOTEMGOLEM_PART5:
            case MODEL_TOTEMGOLEM_PART6:
                o->LifeTime = 30 + (Random::Rand() % 30);
                o->Scale = 0.17f; // 0.1f+(Random::Rand()%6)*0.1f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 3.5f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 15;

                o->SubType = Random::Rand() % 2;

                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
                break;
#ifdef ASG_ADD_KARUTAN_MONSTERS
            case MODEL_CONDRA_ARM_L:
            case MODEL_CONDRA_ARM_L2:
            case MODEL_CONDRA_SHOULDER:
            case MODEL_CONDRA_ARM_R:
            case MODEL_CONDRA_ARM_R2:
            case MODEL_CONDRA_CONE_L:
            case MODEL_CONDRA_CONE_R:
            case MODEL_CONDRA_PELVIS:
            case MODEL_CONDRA_STOMACH:
            case MODEL_CONDRA_NECK:

            case MODEL_NARCONDRA_ARM_L:
            case MODEL_NARCONDRA_ARM_L2:
            case MODEL_NARCONDRA_SHOULDER_L:
            case MODEL_NARCONDRA_SHOULDER_R:
            case MODEL_NARCONDRA_ARM_R:
            case MODEL_NARCONDRA_ARM_R2:
            case MODEL_NARCONDRA_ARM_R3:
            case MODEL_NARCONDRA_CONE_1:
            case MODEL_NARCONDRA_CONE_2:
            case MODEL_NARCONDRA_CONE_3:
            case MODEL_NARCONDRA_CONE_4:
            case MODEL_NARCONDRA_CONE_5:
            case MODEL_NARCONDRA_CONE_6:
            case MODEL_NARCONDRA_PELVIS:
            case MODEL_NARCONDRA_STOMACH:
            case MODEL_NARCONDRA_NECK:
                o->LifeTime = 30 + (Random::Rand() % 30);
                o->Scale = 1.4f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 3.5f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 15;

                o->SubType = Random::Rand() % 2;

                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
                break;
#endif	// ASG_ADD_KARUTAN_MONSTERS
            case MODEL_DOPPELGANGER_SLIME_CHIP:
                o->LifeTime = 30 + (Random::Rand() % 10);
                o->Scale = 0.1f + (Random::Rand() % 7) * 0.1f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 4.0f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 35 + Random::Rand() % 5;

                o->SubType = Random::Rand() % 2;

                VectorCopy(Light, o->Light);
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                break;

            case MODEL_SHADOW_PAWN_ANKLE_LEFT:		case MODEL_SHADOW_PAWN_ANKLE_RIGHT:
            case MODEL_SHADOW_PAWN_BELT:			case MODEL_SHADOW_PAWN_CHEST:
            case MODEL_SHADOW_PAWN_HELMET:
            case MODEL_SHADOW_PAWN_KNEE_LEFT:		case MODEL_SHADOW_PAWN_KNEE_RIGHT:
            case MODEL_SHADOW_PAWN_WRIST_LEFT:		case MODEL_SHADOW_PAWN_WRIST_RIGHT:

            case MODEL_SHADOW_KNIGHT_ANKLE_LEFT:	case MODEL_SHADOW_KNIGHT_ANKLE_RIGHT:
            case MODEL_SHADOW_KNIGHT_BELT:			case MODEL_SHADOW_KNIGHT_CHEST:
            case MODEL_SHADOW_KNIGHT_HELMET:
            case MODEL_SHADOW_KNIGHT_KNEE_LEFT:		case MODEL_SHADOW_KNIGHT_KNEE_RIGHT:
            case MODEL_SHADOW_KNIGHT_WRIST_LEFT:	case MODEL_SHADOW_KNIGHT_WRIST_RIGHT:

            case MODEL_ICE_GIANT_PART1:				case MODEL_ICE_GIANT_PART2:
            case MODEL_ICE_GIANT_PART3:				case MODEL_ICE_GIANT_PART4:

                o->LifeTime = 30 + (Random::Rand() % 30);
                o->Scale = 1.1f; // 0.1f+(Random::Rand()%6)*0.1f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 3.5f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 15;

                o->SubType = Random::Rand() % 2;

                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
                break;
            case MODEL_SHADOW_ROOK_ANKLE_LEFT:		case MODEL_SHADOW_ROOK_ANKLE_RIGHT:
            case MODEL_SHADOW_ROOK_BELT:			case MODEL_SHADOW_ROOK_CHEST:
            case MODEL_SHADOW_ROOK_HELMET:
            case MODEL_SHADOW_ROOK_KNEE_LEFT:		case MODEL_SHADOW_ROOK_KNEE_RIGHT:
            case MODEL_SHADOW_ROOK_WRIST_LEFT:		case MODEL_SHADOW_ROOK_WRIST_RIGHT:
                o->LifeTime = 30 + (Random::Rand() % 30);
                o->Scale = 1.3f; // 0.1f+(Random::Rand()%6)*0.1f;
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 3.5f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 15;

                o->SubType = Random::Rand() % 2;

                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
                break;


            case MODEL_FIRE:
                o->BlendMesh = 1;
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;
                    o->Scale = (float)(Random::Rand() % 8 + 10) * 0.1f;
                    o->Position[0] += 130.f + (float)(Random::Rand() % 32);
                    o->Position[2] += 400.f;
                    Vector(0.f, 0.f, -50.f, o->Direction);
                    Vector(0.f, 20.f, 0.f, o->Angle);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 40;
                    o->Scale = (float)(Random::Rand() % 8 + 10) * 0.1f;
                    Vector(0.f, 0.f, -50.f, o->Direction);
                    //o->Angle[0] = -20.f;
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 80;
                    o->Scale = 0.3f;
                    Vector(0.f, -12.f, 0.f, o->Direction);
                    //					PlayBuffer( SOUND_PHOENIXFIRE);
                }
                else if (o->SubType == 4)
                {
                    o->LifeTime = 40;
                    o->Scale = (float)(Random::Rand() % 10 + 15) * 0.1f;
                    o->Position[0] += 130.f + (float)(Random::Rand() % 32);
                    o->Position[2] += 400.f;
                    Vector(0.f, -(Random::Rand() % 20 + 10.f), -(Random::Rand() % 10 + 20.f), o->Direction);
                    Vector(0.f, 20.f, 0.f, o->Angle);
                }
                else if (o->SubType == 5)
                {
                    o->LifeTime = 40;
                    o->Gravity = 5.f;
                    Vector(0.f, -30.f, 0.f, o->Direction);
                }
                else if (o->SubType == 6)
                {
                    o->LifeTime = 40;
                    o->HiddenMesh = -2;
                    o->Scale = (float)(Random::Rand() % 8 + 15) * 0.1f;
                    o->PKKey = -1;
                    o->Velocity = PKKey;
                    o->Position[0] += (float)(Random::Rand() % 100 + 200);
                    o->Position[1] += (float)(Random::Rand() % 100 - 50);
                    o->Position[2] += (float)(Random::Rand() % 300 + 500);
                    Vector(0.f, 0.f, -50.f - Random::Rand() % 50, o->Direction);
                    Vector(0.f, 20.f, 0.f, o->HeadAngle);

                    CreateJoint(BITMAP_SMOKE, o->Position, o->Position, o->HeadAngle, 0, o, 100.f);
                }
                else if (o->SubType == 7)
                {
                    o->LifeTime = 40;
                    o->HiddenMesh = -2;
                    o->Scale = (float)(Random::Rand() % 8 + 15) * 0.1f;
                    o->PKKey = -1;
                    o->Velocity = PKKey;
                    o->Position[0] += (float)(Random::Rand() % 100 + 200);
                    o->Position[1] += (float)(Random::Rand() % 100 - 50);
                    o->Position[2] += (float)(Random::Rand() % 300 + 500);
                    Vector(0.f, 0.f, -50.f - Random::Rand() % 50, o->Direction);
                    Vector(0.f, 20.f, 0.f, o->HeadAngle);
                }
                else if (o->SubType == 8)
                {
                    o->LifeTime = 40;
                    o->HiddenMesh = -2;
                    o->Scale = (float)(Random::Rand() % 8 + 15) * 0.1f;
                    o->PKKey = -1;
                    o->Velocity = PKKey;
                    //					o->Position[0] += Random::Rand()%100+200;
                    //					o->Position[1] += Random::Rand()%100-50;
                    o->Position[2] += (float)(Random::Rand() % 300 + 500);
                    Vector(0.f, 0.f, -50.f - Random::Rand() % 50, o->Direction);
                    Vector(0.f, (float)(5 + Random::Rand() % 5), 0.f, o->HeadAngle);

                    CreateJoint(BITMAP_SMOKE, o->Position, o->Position, o->HeadAngle, 0, o, 60.f);
                }
                else if (o->SubType == 9)
                {
                    o->BlendMeshLight = 0.f;
                    o->LifeTime = 600;
                    o->Scale = (float)(Random::Rand() % 10 + 20) * 0.13f;
                    o->Position[0] += 130.f + Random::Rand() % 32;
                    o->Position[2] += 400.f + Random::Rand() % 32;
                    Vector(0.f, -Random::Rand() % 5 - 8.0f, -10.f - Random::Rand() % 10, o->Direction);
                    Vector(0.f, 0.f, 0.f, o->Angle);
                }
                else
                {
                    o->LifeTime = 60;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    o->Position[2] += 120.f;
                    Vector(0.f, -50.f, 0.f, o->Direction);
                }
                break;
            case MODEL_BONE1:
                o->Position[2] += 50.f;
            case MODEL_BONE2:
                o->Position[2] += 100.f;
            case MODEL_BIG_STONE1:
            case MODEL_BIG_STONE2:
                if (o->SubType == 5)
                {
                    o->LifeTime = 60;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    VectorCopy(o->Position, o->StartPosition);
                    VectorCopy(o->Owner->Position, o->Position);
                    break;
                }
            case MODEL_SNOW2:
            case MODEL_SNOW3:
            case MODEL_STONE1:
            case MODEL_STONE2:
                if (o->SubType == 5)
                {
                    o->LifeTime = 60;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    break;
                }
                else if (o->SubType == 11)
                {
                    o->LifeTime = 40;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.8f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    break;
                }
                else if (o->SubType == 10)
                {
                    Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.2, 0.f, p1);
                    o->LifeTime = Random::Rand() % 16 + 32;
                    o->Scale = (float)(Random::Rand() % 4 + 15) * 0.05f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, o->Direction);
                    o->Gravity = (float)(Random::Rand() % 16 + 28);
                    break;
                }
                else if (o->SubType == 12)
                {
                    Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.1f, 0.f, p1);
                    o->LifeTime = Random::Rand() % 16 + 32;
                    o->Scale = (float)(Random::Rand() % 4 + 15) * 0.1f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, o->Direction);
                    o->Gravity = (float)(Random::Rand() % 16 + 8);
                    break;
                }
                else if (o->SubType == 13 || o->SubType == 14)
                {
                    o->Direction[0] = 0;
                    o->Direction[1] = 0;
                    o->Direction[2] = 0;

                    o->LifeTime = Random::Rand() % 16 + 20;
                    o->Scale = (float)(Random::Rand() % 13 + 3) * 0.08f;
                    o->Scale *= Scale;
                    o->Gravity = (float)(Random::Rand() % 3 + 3);

                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                    VectorRotate(p1, Matrix, o->HeadAngle);
                    o->HeadAngle[2] += 15.0f;
                    break;
                }

            case MODEL_ICE_SMALL:
            case MODEL_METEO1:
            case MODEL_METEO2:
            case MODEL_EFFECT_SAPITRES_ATTACK_2:
                if (o->Type == MODEL_BIG_STONE1 || o->Type == MODEL_BIG_STONE2)
                {
                    Vector((float)(Random::Rand() % 128 - 64), (float)(Random::Rand() % 128 - 64),
                           (float)(Random::Rand() % 180), p1);
                    VectorAdd(o->Position, p1, o->Position);
                }

                if (Type == MODEL_ICE_SMALL)
                {
                    o->BlendMesh = 0;
                    o->BlendMeshLight = 0.3f;
                    Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.1f, 0.f, p1);
                    o->Position[2] += 50.f;
                    if (o->SubType == 13)
                    {
                        Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.2, 0.f, p1);
                        o->LifeTime = Random::Rand() % 16 + 32;
                        o->Scale = (float)(Random::Rand() % 4 + 15) * 0.05f;
                        o->Angle[2] = (float)(Random::Rand() % 360);
                        AngleMatrix(o->Angle, Matrix);
                        VectorRotate(p1, Matrix, o->Direction);
                        o->Gravity = (float)(Random::Rand() % 16 + 28);
                    }
                    //						o->Scale += 50.f;
                }
                else if (Type == MODEL_EFFECT_SAPITRES_ATTACK_2)
                {
                    o->BlendMesh = 0;
                    o->BlendMeshLight = 1.0f;
                    Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.1f, 0.f, p1);
                    o->Position[2] += 50.f;
                }
                else
                {
                    if (o->SubType == 1)
                    {
                        Vector(0.f, 0.f, 0.f, p1);
                    }
                    else
                    {
                        Vector(0.f, (float)(Random::Rand() % 256 + 64) * 0.1f, 0.f, p1);
                    }
                }
                if (o->SubType == 13)
                {
                    o->LifeTime = Random::Rand() % 16 + 100;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, o->Direction);
                    o->Gravity = (float)(Random::Rand() % 16 + 8);
                }
                else if (Type == MODEL_EFFECT_SAPITRES_ATTACK_2 && o->SubType == 14)
                {
                    o->LifeTime = Random::Rand() % 5 + 15;
                    o->Angle[0] = (float)(Random::Rand() % 60 - 30);
                    o->Angle[1] = (float)(Random::Rand() % 60 - 30);
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, o->Direction);
                    VectorNormalize(o->Direction);
                    o->Gravity = 0.f;
                }
                else
                {
                    o->LifeTime = Random::Rand() % 16 + 32;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    VectorRotate(p1, Matrix, o->Direction);
                    o->Gravity = (float)(Random::Rand() % 16 + 8);
                }
                break;

            case MODEL_EFFECT_BROKEN_ICE0:
            case MODEL_EFFECT_BROKEN_ICE1:
            case MODEL_EFFECT_BROKEN_ICE2:
            case MODEL_EFFECT_BROKEN_ICE3:
#ifdef ASG_ADD_KARUTAN_MONSTERS
            case MODEL_CONDRA_STONE:
            case MODEL_CONDRA_STONE1:
            case MODEL_CONDRA_STONE2:
            case MODEL_CONDRA_STONE3:
            case MODEL_CONDRA_STONE4:
            case MODEL_CONDRA_STONE5:
            case MODEL_NARCONDRA_STONE:
            case MODEL_NARCONDRA_STONE1:
            case MODEL_NARCONDRA_STONE2:
            case MODEL_NARCONDRA_STONE3:
#endif	// ASG_ADD_KARUTAN_MONSTERS
                if (o->SubType == 0)
                {
                    o->Direction[0] = 0;
                    o->Direction[1] = 0;
                    o->Direction[2] = 0;

                    o->LifeTime = Random::Rand() % 16 + 35;
                    o->Scale = (float)(Random::Rand() % 13 + 3) * 0.2f;
                    o->Gravity = (float)(Random::Rand() % 3 + 3);

                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                    VectorRotate(p1, Matrix, o->HeadAngle);
                    o->HeadAngle[2] += 25.0f;
                    break;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 40;
                    o->Scale = Scale + (float)(Random::Rand() % 8 + 15) * 0.1f;
                    Vector(0.f, 0.f, -60.f, o->Direction);
                    Vector(0.f, 30.f, 0.f, o->HeadAngle);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 100;
                    o->Scale = Scale;
                    o->Gravity = 20.f + (float)(Random::Rand() % 20) * 0.5f;
                }
                break;
            case MODEL_PKFIELD_ASSASSIN_EFFECT_GREEN_HEAD:
            case MODEL_PKFIELD_ASSASSIN_EFFECT_RED_HEAD:
            {
                o->LifeTime = 50 + (Random::Rand() % 30);
                o->Scale = 1.0f;
                o->Velocity = 1.0f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 3.5f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 25) * 0.2f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 25;

                o->SubType = Random::Rand() % 2;

                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
            }
            break;
            case MODEL_PKFIELD_ASSASSIN_EFFECT_GREEN_BODY:
            case MODEL_PKFIELD_ASSASSIN_EFFECT_RED_BODY:
            {
                o->Scale = 1.0f;
                o->LifeTime = 40 + (Random::Rand() % 30);
                o->Velocity = 0.4f;						//b->Actions[MONSTER01_DIE].PlaySpeed
                o->CurrentAction = MONSTER01_DIE;
            }
            break;
            case MODEL_DUNGEON_STONE01:
                o->LifeTime = Random::Rand() % 16 + 24;
                o->Scale = (float)(Random::Rand() % 8 + 6) * 0.1f;
                o->Gravity = -(float)(Random::Rand() % 4);
                Vector((float)(Random::Rand() % 64 - 32), -(float)(Random::Rand() % 32 + 50),
                       (float)(Random::Rand() % 128 + 200), p1);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);
                break;
            case MODEL_WARCRAFT:
                o->LifeTime = 50;
                o->Scale = 0.7f;
                if (SubType == 0)
                    o->BlendMesh = -3;
                else
                    o->BlendMesh = -4;
                Vector(0.f, 0.f, 45.f, o->Angle);
                break;
            case BITMAP_FIRECRACKER:
                Vector(1.0f, 1.0f, 1.0f, o->Light);
                Vector((float)(Random::Rand() % 9 - 4), (float)(Random::Rand() % 9 - 4), 26.f, o->Direction);

                if (o->SubType == 1)
                    o->LifeTime = 4 + (Random::Rand() % 3);
                else
                    o->LifeTime = 12;

                PlayBuffer(SOUND_FIRECRACKER1, o);
                break;
            case BITMAP_FIRECRACKER0002:
            {
                o->LifeTime = 30;

                CreateParticle(BITMAP_EXPLOTION_MONO, o->Position, o->Angle, o->Light, 0, 0.6f);

                vec3_t vLight;
                Vector(1.0f, 1.0f, 1.0f, vLight);
                for (int i = 0; i < 60; i++)
                {
                    CreateParticle(BITMAP_SPARK + 1, o->Position, o->Angle, vLight, 27);
                }

                for (int i = 0; i < 30; i++)
                {
                    CreateParticle(BITMAP_SPARK + 1, o->Position, o->Angle, vLight, 28);
                }

                Vector(o->Position[0] + (Random::Rand() % 100 - 50), o->Position[1] + (Random::Rand() % 100 - 50),
                       o->Position[2], Position);
                CreateSprite(BITMAP_DS_SHOCK, Position, Random::Rand() % 10 * 0.1f + 1.5f, o->Light, o);

                for (int i = 0; i < 60; i++)
                {
                    Vector(0.3f + (Random::Rand() % 700) * 0.001f, 0.3f + (Random::Rand() % 700) * 0.001f,
                           0.3f + (Random::Rand() % 700) * 0.001f, vLight);
                    CreateParticle(BITMAP_SHINY, o->Position, o->Angle, vLight, 6);
                }

                if (o->SubType == 1)
                {
                    CreateEffect(MODEL_HALLOWEEN_CANDY_STAR, o->Position, o->Angle, vLight, 1);
                    CreateEffect(Random::Rand() % 4 + MODEL_XMAS_EVENT_BOX, o->Position, o->Angle, vLight, 0, o);
                    CreateEffect(Random::Rand() % 4 + MODEL_XMAS_EVENT_BOX, o->Position, o->Angle, vLight, 0, o);
                }

                PlayBuffer(SOUND_XMAS_FIRECRACKER, o);
            }
            break;
            case BITMAP_FIRECRACKER0003:
            {
                o->LifeTime = 15;
                o->Angle[2] = Random::Rand() % 360;
            }
            break;
            case BITMAP_SWORD_FORCE:
                o->LifeTime = 30;
                if (o->SubType == 0 || o->SubType == 1)
                    Vector(0.8f, 0.8f, 0.8f, o->Light);
                Vector(0.f, 0.f, Angle[2] + 45.f, o->HeadAngle);
                VectorCopy(o->Position, o->StartPosition);
                break;
            case BITMAP_BLIZZARD:
            {
                o->LifeTime = Random::Rand() % 15 + 15;
                o->Gravity = -20.f;
                o->Velocity = (float)(Random::Rand() % 360);
                Vector(0.f, 0.f, 0.f, o->Light);

                int rangeX, rangeY, rangeZ;
                if (o->SubType == 1)
                {
                    rangeX = 300; rangeY = 150; rangeZ = 700;
                    o->Scale = 0.5f;
                    o->Gravity -= Random::Rand() % 20 + 10;
                }
                else
                {
                    rangeX = 200; rangeY = 100; rangeZ = 500;
                    o->Scale = 0.f;
                }

                o->Position[0] = o->Position[0] + Random::Rand() % rangeX - rangeY;
                o->Position[1] = o->Position[1] + Random::Rand() % rangeX - rangeY;
                o->Position[2] = o->Position[2] + 500.f;
                o->Position[0] += 100.f;

                VectorCopy(o->Position, o->StartPosition);
                PlayBuffer(SOUND_METEORITE01);
            }
            break;
            case BITMAP_SHOTGUN:
            {
                o->LifeTime = 10;
                o->Velocity = 1.f;
                Vector(0.f, -30.f, 0.f, o->Direction);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, -20.f, 50.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);

                vec3_t  Angle, Pos, p3;
                Vector(-20.f, -20.f, 60.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(Position, p2, Pos);
                VectorCopy(o->Angle, Angle);
                for (int i = 0; i < 20; ++i)
                {
                    Angle[0] = o->Angle[0] + Random::Rand() % 20 + 5;
                    Angle[1] += i * 18;
                    CreateJoint(BITMAP_JOINT_SPARK, Pos, Pos, Angle, 1);
                }

                Vector(30.f, -20.f, 60.f, p3);
                VectorRotate(p3, Matrix, p2);
                VectorAdd(Position, p2, Pos);
                VectorCopy(o->Angle, Angle);

                for (int i = 0; i < 20; ++i)
                {
                    Angle[0] = o->Angle[0] + Random::Rand() % 20 + 5;
                    Angle[1] += i * 18;
                    CreateJoint(BITMAP_JOINT_SPARK, Pos, Pos, Angle, 1);
                }
            }
            break;
            case MODEL_GATE:
            case MODEL_GATE + 1:
                Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                o->Position[2] += 50.f;
                o->LifeTime = Random::Rand() % 16 + 32;
                o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);
                o->Gravity = (float)(Random::Rand() % 5 + 2);
                if (o->Type == MODEL_GATE && o->SubType == 0)
                {
                    o->SubType = 1;
                    o->Gravity += (float)(Random::Rand() % 5);
                }
                else if (o->SubType == 2)
                {
                    o->Scale *= 0.6f;
                }

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                break;

            case MODEL_STONE_COFFIN:
            case MODEL_STONE_COFFIN + 1:
                Vector(0.f, (float)(Random::Rand() % 128 + 32) * 0.1f, 0.f, p1);
                o->Position[2] += 50.f;
                o->LifeTime = Random::Rand() % 16 + 32;
                o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);
                o->Gravity = (float)(Random::Rand() % 5 + 2);
                if (o->Type == MODEL_STONE_COFFIN + 1 && o->SubType == 0)
                {
                    o->SubType = 1;
                    o->Gravity += (float)(Random::Rand() % 5);
                }

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                break;
            case MODEL_SHINE:
                if (o->SubType == 0)
                {
                    vec3_t Pos;
                    o->LifeTime = 50;
                    for (int j = 0; j < 10; ++j)
                    {
                        Pos[0] = o->Position[0] + (j - 5) * 12.f - 30.f;
                        Pos[1] = o->Position[1] + (j - 5) * 12.f + 30.f;
                        Pos[2] = o->Position[2] - 300.f;

                        CreateJoint(BITMAP_FLARE, Pos, o->Position, o->Angle, 16, o->Owner, 120.f);
                    }
                }
                break;
            case MODEL_BLIZZARD:
                if (o->SubType == 0 || o->SubType == 2)
                {
                    o->BlendMesh = -2;
                    o->LifeTime = Random::Rand() % 15 + 15;
                    o->Gravity = -20.f;
                    o->Velocity = (float)(Random::Rand() % 360);
                    Vector(0.f, 0.f, 0.f, o->Light);

                    int rangeX, rangeY, rangeZ;

                    rangeX = 300; rangeY = 150; rangeZ = 700;
                    o->Scale = 0.5f;
                    o->Gravity -= Random::Rand() % 30 + 10;

                    o->Position[0] = o->Position[0] + Random::Rand() % rangeX - rangeY;
                    o->Position[1] = o->Position[1] + Random::Rand() % rangeX - rangeY;
                    o->Position[2] = o->Position[2] + 600.f;
                    o->Position[0] += 100.f;

                    VectorCopy(o->Position, o->StartPosition);

                    if (o->SubType == 2)
                    {
                        CreateJoint(BITMAP_JOINT_THUNDER + 1, o->Position, o->Position, o->Angle, 4, o,
                                    60.f + Random::Rand() % 10);
                        if (Random::Rand() % 2 == 0)
                            CreateJoint(BITMAP_JOINT_THUNDER + 1, o->Position, o->Position, o->Angle, 4, o,
                                        60.f + Random::Rand() % 10);
                    }
                }
                else if (o->SubType == 1)
                {
                    o->BlendMesh = -2;
                    o->LifeTime = 20;
                    o->Velocity = 0.f;
                }
                break;

            case MODEL_ARROW_DRILL:
                if (o->SubType == 0 || o->SubType == 2)
                {
                    o->LifeTime = 30;
                    o->BlendMesh = -2;
                    o->Scale = 1.f;
                    o->Gravity = -10.f;
                    o->Position[2] += 130.f;

                    if (o->SubType != 0)
                    {
                        CreateEffect(MODEL_PIERCING, o->Position, o->Angle, o->Light, 0, o);
                        o->AttackPoint[0] = 0;
                        o->Kind = 1;
                    }

                    Vector(0.f, -70.f, 0.f, o->Direction);
                    VectorCopy(o->Position, o->EyeLeft);
                    CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 5, o, 100.f);

                    o->Weapon = CharacterMachine->PacketSerial;
                }
                break;

            case MODEL_COMBO:
                o->LifeTime = 20;
                o->Gravity = 0.1f;
                o->BlendMesh = -2;
                o->BlendMeshLight = 1.f;
                Vector(0.f, 0.f, 0.f, o->Angle);
                VectorCopy(o->Position, o->StartPosition);
                o->Position[2] += 50.f;

                if (o->SubType == 0)
                {
                    for (int j = 0; j < 60; ++j)
                    {
                        CreateJoint(BITMAP_LIGHT, o->Position, o->Position, o->Angle, 0, NULL,
                                    (float)(Random::Rand() % 40 + 70));
                    }
                }
                break;
            case MODEL_WAVES:
                o->LifeTime = 20;
                o->Gravity = 0.1f;
                o->BlendMesh = -2;
                o->BlendMeshLight = 1.f;
                Vector(0.f, 0.f, 0.f, o->Angle);
                VectorCopy(o->Position, o->StartPosition);
                o->Position[2] += 50.f;

                if (o->SubType == 0)
                {
                    for (int j = 0; j < 60; ++j)
                    {
                        CreateJoint(BITMAP_LIGHT, o->Position, o->Position, o->Angle, 0, NULL,
                                    (float)(Random::Rand() % 40 + 70));
                    }
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 15;
                    o->RenderType = RENDER_NODEPTH;
                    o->Position[2] += 80.f;
                    o->Scale = 0.1f + Random::Rand() % 50 / 100.f;
                    o->Gravity = 0.01f;

                    o->Angle[0] = 90.f;
                    o->Angle[2] = Angle[2];

                    for (int j = 0; j < 2; ++j)
                    {
                        CreateJoint(BITMAP_PIERCING, o->Position, o->Position, o->Angle, 0, NULL,
                                    (float)(Random::Rand() % 40 + 70));
                    }

                    o->Position[0] += Random::Rand() % 100 - 50.f;
                    o->Position[1] += Random::Rand() % 100 - 50.f;
                }
                else if (o->SubType == 2 || o->SubType == 3 || o->SubType == 4)
                {
                    o->LifeTime = 15;
                    o->PKKey = -1;
                    o->Scale = PKKey * 0.05f;
                    o->Gravity = 0.01f;
                    o->Position[2] -= 50.f;

                    o->Angle[0] = 90.f;
                    o->Angle[2] = Angle[2];
                }
                else if (o->SubType == 5 || o->SubType == 6)
                {
                    o->LifeTime = 10;
                    o->PKKey = -1;
                    o->Scale = PKKey * 0.05f;
                    o->Gravity = 0.08f;
                    o->Position[2] -= 50.f;

                    o->Angle[0] = -90.f;
                    o->Angle[2] = Angle[2];
                }
                break;
            case MODEL_DEASULER:
                if (o->SubType == 0)
                {
                    const int	TOTAL_LIFETIME = 55;
                    vec3_t		v3PosProcess01, v3PosProcessFinal,
                        v3DirModify, v3PosModify,
                        v3PosTargetModify;

                    o->ExtState = TOTAL_LIFETIME;
                    o->LifeTime = TOTAL_LIFETIME;
                    o->Gravity = 0.0f;
                    o->HiddenMesh = 1;
                    o->Distance = 0.0f;
                    o->Alpha = 1.0f;
                    o->ChromeEnable = false;

                    Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                    VectorCopy(o->Position, o->StartPosition);
                    VectorSubtract(o->Light, o->Position, o->Direction);

                    o->Distance = sqrt(o->Direction[0] * o->Direction[0] +
                        o->Direction[1] * o->Direction[1] +
                        o->Direction[2] * o->Direction[2]);

                    VectorDivFSelf(o->Direction, o->Distance);

                    float	fDistanceResult = 0;
                    vec3_t	v3DirResult;

                    vec3_t v3PosModify02;
                    float	fTotalDist = 1700.0f, fFirstDist = 0.0f, fRateFirstDist = 0.0f;
                    VectorCopy(o->Owner->Position, v3PosModify02);
                    VectorCopy(o->Position, v3PosModify);

                    v3PosModify02[2] = o->Light[2];
                    v3PosModify[2] = o->Light[2];
                    VectorCopy(o->Light, v3PosTargetModify);
                    v3PosModify[2] = v3PosModify[2] + 100.0f;
                    v3PosModify02[2] = v3PosModify02[2] + 100.0f;
                    v3PosTargetModify[2] = v3PosTargetModify[2] + 100.0f;
                    VectorDistNormalize(v3PosModify02, v3PosTargetModify, v3DirModify);

                    fDistanceResult = o->Distance * 0.3f;
                    fFirstDist = fDistanceResult;
                    VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                    VectorAdd(v3PosModify, v3DirResult, v3PosProcess01);

                    fDistanceResult = fTotalDist;
                    VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                    VectorAdd(v3PosModify, v3DirResult, v3PosProcessFinal);

                    fRateFirstDist = fFirstDist / fTotalDist;

                    o->m_Interpolates.ClearContainer();

                    fRateFirstDist = fFirstDist / fTotalDist;

                    CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                    InsertFactor.fRateStart = 0.0f;			// Start
                    InsertFactor.fRateEnd = fRateFirstDist;			// 01 Ready
                    Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                    Vector(0.0f, 90.0f, 0.0f, InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                    InsertFactor.fRateStart = fRateFirstDist;			// 02 First Final
                    InsertFactor.fRateEnd = 1.01f;
                    Vector(0.0f, 90.0f, 0.0f, InsertFactor.v3Start);
                    Vector(0.0f, 90.0f, 2560.0f, InsertFactor.v3End);
                    //Vector(90.0f, 0.0f, 1000.0f, InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);
                    InsertFactor.fRateStart = 0.0f;
                    InsertFactor.fRateEnd = fRateFirstDist;
                    VectorCopy(o->Position, InsertFactor.v3Start);
                    VectorCopy(v3PosProcess01, InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    InsertFactor.fRateStart = fRateFirstDist;
                    InsertFactor.fRateEnd = 1.01f;
                    VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                    VectorCopy(v3PosProcessFinal, InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);
                    o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                    o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                }
                break;
            case MODEL_DEATH_SPI_SKILL:
                if (o->SubType == 0)
                {
                    o->LifeTime = 30;
                    o->Gravity = 1.0f;
                    o->Velocity = 10.f;
                    o->HiddenMesh = 1;
                    o->Scale = 0.3f;
                    o->BlendMesh = -1;
                    o->Alpha = 0.8f;
                    Vector(1.f, 1.f, 1.f, o->Light);
                    Vector(0.f, -26.f, 0.f, o->Direction);
                    VectorCopy(Light, o->StartPosition);
                    VectorCopy(o->Angle, o->HeadAngle);
                    Vector(0.f, 0.f, Angle[2], o->Angle);
                }
                else if (o->SubType == 1)
                {
                    //					o->LifeTime     = 20;
                    o->LifeTime = o->Owner->LifeTime;
                    o->HiddenMesh = 1;
                    o->Scale = 0.2f;
                    o->BlendMesh = -1;
                    o->Alpha = (float)((20 - o->LifeTime) / 5.f);
                    Vector(0.3f, 0.4f, 1.f, o->Light);
                    Vector(0.f, 0.f, 0.f, o->Direction);

                    CreateParticle(BITMAP_FIRE + 2, o->Position, o->Angle, o->Light, 0);
                    //                    CreateParticle ( BITMAP_FIRE+1, o->Position, o->Angle, o->Light, 0, 1.f, o );
                }
                break;
            case MODEL_PIER_PART:
                if (o->SubType == 0)
                {
                    o->LifeTime = 20;
                    o->Gravity = 2.f;
                    o->Velocity = 10.f;
                    o->HiddenMesh = 1;
                    o->Scale = 1.2f;
                    Vector(1.f, 1.f, 1.f, o->Light);
                    Vector(0.f, -26.f, 0.f, o->Direction);
                    VectorCopy(Light, o->StartPosition);
                    VectorCopy(o->Angle, o->HeadAngle);
                    Vector(0.f, 0.f, Angle[2], o->Angle);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = o->Owner->LifeTime;
                    o->HiddenMesh = 0;
                    o->Scale = 0.5f;
                    o->Alpha = (float)((20 - o->LifeTime) / 5.f);
                    Vector(0.f, 0.f, 0.f, o->Direction);

                    CreateParticle(BITMAP_FIRE + 1, o->Position, o->Angle, o->Light, 0, 1.f, o);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 20;
                    o->Velocity = 50.f;
                    o->HiddenMesh = -2;
                    o->Position[2] -= 20.f;

                    Vector(0.f, -40.f, 0.f, o->Direction);
                    VectorCopy(o->Angle, o->HeadAngle);
                    Vector(0.f, 0.f, Angle[2], o->Angle);
                }
                break;

            case BITMAP_FLARE_FORCE:
                if (o->SubType == 0)
                {
                    o->LifeTime = 0;
                    if (o->Owner != NULL)
                    {
                        CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 1, o->Owner, 100.f);
                        CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 0, o->Owner, 250.f);
                        CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 2, o->Owner, 100.f);
                        CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 3, o->Owner, 100.f);
                        CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 4, o->Owner, 100.f);
                    }
                }
                else if (o->SubType == 1)
                {
                    CreateJoint(BITMAP_FLARE_FORCE, o->Position, o->Position, o->Angle, 5, o->Owner, 20.f, PKKey, SkillIndex);
                    CreateJoint(BITMAP_FLARE_FORCE, o->Position, o->Position, o->Angle, 6, o->Owner, 20.f, PKKey, SkillIndex);
                    CreateJoint(BITMAP_FLARE_FORCE, o->Position, o->Position, o->Angle, 7, o->Owner, 20.f, PKKey, SkillIndex);
                }
                else if (o->SubType >= 2 && o->SubType <= 4)
                {
                    CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 8 + (o->SubType - 2), o->Owner, 100.f); // 8, 9, 10
                    CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 0, o->Owner, 150.f);
                }
                else if (o->SubType >= 5 && o->SubType <= 7)
                {
                    CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 11 + (o->SubType - 5), o->Owner, 100.f); // 12, 13, 14
                    CreateJoint(BITMAP_FLARE_FORCE, Position, Position, Angle, 1, o->Owner, 100.f);
                }
                break;

            case MODEL_DARKLORD_SKILL:
            {
                o->LifeTime = 10;
                o->Scale = 0.2f;
                o->Velocity = 0.1f;

                if (o->SubType <= 1)
                {
                    float angle = 45.f + (-90.f * o->SubType);

                    if (Random::Rand() % 2 == 0)
                    {
                        if (o->SubType)
                        {
                            angle = 45.f - 90.f;
                        }
                        else
                        {
                            angle = 45.f;
                        }
                    }
                    Vector(45.f, angle, 0.f, o->Angle);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 12;
                    o->Velocity = 0.4f;
                }
            }
            break;

            case MODEL_GROUND_STONE:
            {
                int TargetX = (int)(o->Position[0] / TERRAIN_SCALE);
                int TargetY = (int)(o->Position[1] / TERRAIN_SCALE);

                WORD wall = TerrainWall[TERRAIN_INDEX(TargetX, TargetY)];

                if ((wall & TW_NOMOVE) != TW_NOMOVE && (wall & TW_NOGROUND) != TW_NOGROUND && (wall & TW_WATER) != TW_WATER)
                {
                    o->LifeTime = 40;
                    o->Scale = 1.2f + Random::Rand() % 30 / 100.f;
                    o->Velocity = 0.3f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    SetAction(o, 0);
                }
                else
                {
                    o->Live = false;
                }
            }
            break;
            case MODEL_GROUND_STONE2:
            {
                int TargetX = (int)(o->Position[0] / TERRAIN_SCALE);
                int TargetY = (int)(o->Position[1] / TERRAIN_SCALE);

                WORD wall = TerrainWall[TERRAIN_INDEX(TargetX, TargetY)];

                if ((wall & TW_NOMOVE) != TW_NOMOVE && (wall & TW_NOGROUND) != TW_NOGROUND && (wall & TW_WATER) != TW_WATER)
                {
                    o->LifeTime = 40;
                    o->Scale = 1.f + Random::Rand() % 30 / 100.f;
                    o->Velocity = 0.3f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    SetAction(o, 0);
                }
                else
                {
                    o->Live = false;
                }
            }
            break;
            case BITMAP_SHOCK_WAVE:
                if (o->SubType == 0)
                {
                    o->LifeTime = 30;
                    o->Scale = 20.f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 20;
                    o->Scale = (Random::Rand() % 10 + 10.f) / 10.f;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 20;
                    o->Scale = (Random::Rand() % 10 + 10.f) / 10.f;
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 15;
                    o->Scale = 1.f;
                }
                else if (o->SubType == 4)
                {
                    o->LifeTime = 10;
                    o->Scale = (Random::Rand() % 6 + 6.f) / 10.f;
                }
                else if (o->SubType == 5)
                {
                    o->LifeTime = 20;
                    o->Scale = 9.f;
                }
                else if (o->SubType == 6)
                {
                    o->LifeTime = 50;
                    o->Scale = 9.f;
                }
                else if (o->SubType == 7)
                {
                    o->LifeTime = 10;
                    o->Scale = 1.f;
                }
                else if (o->SubType == 8)
                {
                    o->LifeTime = 10;
                    o->Scale = (Random::Rand() % 10 + 10.f) / 5.f;
                }
                else if (o->SubType == 9)
                {
                    o->LifeTime = 5;
                    o->Scale = 5.f;
                }
                else if (o->SubType == 10)
                {
                    o->LifeTime = 1;
                    o->Scale = 2.f;

                    o->Light[0] *= 2.3f;
                    o->Light[1] *= 2.3f;
                    o->Light[2] *= 2.3f;
                }
                else if (o->SubType == 11)
                {
                    o->LifeTime = 20;
                    o->Scale = (Random::Rand() % 10 + 10.f) / 10.f;
                }
                else if (o->SubType == 12)
                {
                    o->LifeTime = 10;
                    o->Scale = Scale;
                }
                else if (o->SubType == 13)
                {
                    o->LifeTime = 40;
                    o->Scale = (Random::Rand() % 10 + 20.f) / 7.f;
                }
                else if (o->SubType == 14)
                {
                    o->LifeTime = 30;
                    o->Alpha = 0.0f;
                    o->PKKey = 0;
                    VectorCopy(o->Light, o->EyeRight);
                }
                break;
            case BITMAP_JOINT_THUNDER + 1:
                o->LifeTime = 10;

                if (o->Owner != NULL && o->SubType == 0)
                {
                    float   Matrix[3][4];
                    vec3_t  p, p2;

                    Vector(-25.f, -80.f, 0.f, p);
                    AngleMatrix(o->Owner->Angle, Matrix);
                    VectorRotate(p, Matrix, p2);
                    VectorAdd(p2, o->Position, o->Position);
                }
                break;
            case MODEL_CUNDUN_DRAGON_HEAD:
            {
                o->LifeTime = 30;
                o->BlendMesh = -2;
                o->Scale = 1.0f;
                Vector(0.5, 0.5, 0.5, o->Light);
                o->Alpha = 0;
                vec3_t Position;
                VectorCopy(o->Position, Position);
                o->Position[2] += 100;

                auto fAngle = float(Random::Rand() % 360);
                auto fDistance = float(Random::Rand() % 600 + 200);
                Position[0] = o->Position[0] + sinf(fAngle) * fDistance;
                Position[1] = o->Position[1] + cosf(fAngle) * fDistance;
                Position[2] = 0;
                CreateJoint(BITMAP_JOINT_SPIRIT2, Position, Position, o->Angle, 18, o, 100.f, 0, 0);
                o->Angle[0] = -30;
                o->Angle[1] = 0;
                o->Angle[2] = (float)(Random::Rand() % 360);
            }
            break;
            case MODEL_CUNDUN_PHOENIX:
            {
                o->Velocity = 0.34f;
                o->LifeTime = 20;
                o->BlendMesh = -2;
                o->Scale = 0.7f;
                Vector(0.5, 0.5, 0.5, o->Light);
                o->Alpha = 0;
                vec3_t Position, Angle;
                VectorCopy(o->Position, Position);
                //o->Position[2] += 100;
                Vector(0, 0, o->Angle[2] * Q_PI / 180.0f, Angle);
                CreateJoint(BITMAP_JOINT_SPIRIT, Position, Position, Angle, 15, o, 100.f, 0, 0);
                //					o->Angle[2] -= 180;
                o->AnimationFrame = float(Random::Rand() % 5);
            }
            break;
            case MODEL_CUNDUN_SKILL:
                switch (o->SubType)
                {
                case 0:
                    o->LifeTime = 30;
                    break;
                case 1:
                    o->LifeTime = 30;
                    break;
                case 2:
                    o->LifeTime = 40;
                    o->PKKey = 0;
                    CreateEffect(MODEL_CUNDUN_GHOST, o->Position, o->Angle, o->Light, 0, o);
                    break;
                };
                break;


            case MODEL_HALLOWEEN_EX:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 0;
                    int iEffectType;
                    for (int i = 0; i < 24; ++i)
                    {
                        // iEffectType = Random::Rand()%6 + MODEL_HALLOWEEN_CANDY_BLUE;
                        iEffectType = Random::Rand() % 8;
                        switch (iEffectType)
                        {
                        case 0: iEffectType = MODEL_HALLOWEEN_CANDY_BLUE;	break;
                        case 1: iEffectType = MODEL_HALLOWEEN_CANDY_ORANGE;	break;
                        case 2: iEffectType = MODEL_HALLOWEEN_CANDY_YELLOW;	break;
                        case 3: iEffectType = MODEL_HALLOWEEN_CANDY_RED;	break;
                        case 4: iEffectType = MODEL_HALLOWEEN_CANDY_HOBAK;	break;
                        case 5: iEffectType = MODEL_HALLOWEEN_CANDY_STAR;	break;
                        case 6: iEffectType = MODEL_HALLOWEEN_CANDY_HOBAK;	break;
                        case 7: iEffectType = MODEL_HALLOWEEN_CANDY_STAR;	break;
                        }
                        //iEffectType = MODEL_HALLOWEEN_CANDY_STAR;
                        CreateEffect(iEffectType, o->Position, o->Angle, o->Light, 0);
                    }
                }
            }
            break;
            case MODEL_HALLOWEEN_CANDY_BLUE:
            case MODEL_HALLOWEEN_CANDY_ORANGE:
            case MODEL_HALLOWEEN_CANDY_YELLOW:
            case MODEL_HALLOWEEN_CANDY_RED:
            case MODEL_HALLOWEEN_CANDY_HOBAK:
            case MODEL_HALLOWEEN_CANDY_STAR:
            {
                if (o->SubType == 0)
                {
                    if (o->Type == MODEL_HALLOWEEN_CANDY_HOBAK)
                        o->Scale = 2.0f + (Random::Rand() % 10 - 5) * 0.02f;
                    else if (o->Type == MODEL_HALLOWEEN_CANDY_STAR)
                        o->Scale = 2.0f + (Random::Rand() % 10 - 5) * 0.02f;
                    else
                        o->Scale = 0.6f + (Random::Rand() % 10 - 5) * 0.02f;
                    o->LifeTime = Random::Rand() % 10 + 50;
                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    o->Gravity = (float)(Random::Rand() % 10 + 10);
                    vec3_t p;
                    Vector((float)(Random::Rand() % 60 - 30) * 0.1f, (float)(Random::Rand() % 60 - 30) * 0.1f, 0.f, p);
                    VectorScale(p, 2.0f, p);
                    VectorRotate(p, Matrix, o->Direction);
                    o->m_iAnimation = Random::Rand() % 3;
                }
                else if (o->SubType == 1)
                {
                    o->Scale = 2.0f + (Random::Rand() % 10 - 5) * 0.02f;
                    o->LifeTime = Random::Rand() % 10 + 40;
                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    o->Gravity = (float)(Random::Rand() % 10 + 10);
                    vec3_t p;
                    Vector((float)(Random::Rand() % 60 - 30) * 0.1f, (float)(Random::Rand() % 60 - 30) * 0.1f, -1.f, p);
                    VectorScale(p, 1.5f, p);
                    VectorRotate(p, Matrix, o->Direction);
                    o->m_iAnimation = Random::Rand() % 3;
                }
            }
            break;

            case MODEL_XMAS_EVENT_BOX:
            case MODEL_XMAS_EVENT_CANDY:
            case MODEL_XMAS_EVENT_TREE:
            case MODEL_XMAS_EVENT_SOCKS:
            {
                o->Scale = 0.7f + (Random::Rand() % 10 - 5) * 0.02f;
                if (o->Type == MODEL_XMAS_EVENT_BOX)
                {
                    o->Scale += 0.3f;
                }
                o->LifeTime = Random::Rand() % 10 + 50;
                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                o->Gravity = (float)(Random::Rand() % 5 + 15);
                vec3_t vPos;
                Vector((float)(Random::Rand() % 60 - 30) * 0.1f, (float)(Random::Rand() % 60 - 30) * 0.1f, -1.f, vPos);
                VectorScale(vPos, 1.5f, vPos);
                VectorRotate(vPos, Matrix, o->Direction);
                o->m_iAnimation = Random::Rand() % 3;
            }
            break;
            case MODEL_XMAS_EVENT_ICEHEART:
            {
                o->Scale = 4.0f + (Random::Rand() % 10 - 5) * 0.02f;
                o->LifeTime = 100;
            }
            break;

            case MODEL_NEWYEARSDAY_EVENT_BEKSULKI:
            case MODEL_NEWYEARSDAY_EVENT_CANDY:
            case MODEL_NEWYEARSDAY_EVENT_MONEY:
            case MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_GREEN:
            case MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_RED:
            case MODEL_NEWYEARSDAY_EVENT_YUT:
            case MODEL_NEWYEARSDAY_EVENT_PIG:
            {
                if (o->Type == MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_GREEN)
                {
                    if (Random::Rand() % 2 == 0)
                        o->Type = MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_RED;
                }
                else if (o->Type == MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_RED)
                {
                    if (Random::Rand() % 2 == 0)
                        o->Type = MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_GREEN;
                }

                o->LifeTime = Random::Rand() % 10 + 50;
                o->Scale = 1.6f + (Random::Rand() % 10 - 5) * 0.02f;

                if (o->Type == MODEL_NEWYEARSDAY_EVENT_BEKSULKI)
                {
                    o->Scale = 2.5f + (Random::Rand() % 10 - 5) * 0.02f;
                }
                if (o->Type == MODEL_NEWYEARSDAY_EVENT_CANDY)
                {
                    o->Scale = 3.0f + (Random::Rand() % 10 - 5) * 0.02f;
                }
                else if (o->Type == MODEL_NEWYEARSDAY_EVENT_PIG)
                {
                    o->Scale = 1.0f + (Random::Rand() % 10 - 5) * 0.02f;
                }

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                o->Gravity = (float)(Random::Rand() % 10 + 10);
                vec3_t p;
                Vector((float)(Random::Rand() % 10 - 5) * 0.1f, (float)(Random::Rand() % 60 - 40) * 0.1f, 0.0f, p);
                VectorScale(p, 1.3f, p);
                VectorRotate(p, Matrix, o->Direction);
                o->m_iAnimation = Random::Rand() % 3;
            }
            break;


            case MODEL_MOONHARVEST_GAM:
            case MODEL_MOONHARVEST_SONGPUEN1:
            case MODEL_MOONHARVEST_SONGPUEN2:
            {
                o->LifeTime = Random::Rand() % 10 + 50;
                if (o->Type == MODEL_MOONHARVEST_GAM)
                {
                    o->Scale = 0.5f + (Random::Rand() % 10 - 5) * 0.02f;
                }
                else
                {
                    o->Scale = 0.8f + (Random::Rand() % 10 - 5) * 0.02f;
                }
                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                o->Gravity = (float)(Random::Rand() % 10 + 10);
                vec3_t p;
                Vector((float)(Random::Rand() % 10 - 5) * 0.1f, (float)(Random::Rand() % 60 - 30) * 0.1f, 0.0f, p);
                VectorScale(p, 1.2f, p);
                VectorRotate(p, Matrix, o->Direction);
            }
            break;
            case MODEL_BATTLE_GUARD2:
                if (o->SubType == 0)
                {
                    o->LifeTime = 20;
                    o->HiddenMesh = 3;
                    o->Velocity = 0.33f;
                    SetAction(o, 2);

                    Vector(0.f, 0.f, 0.f, o->Angle);
                }
                break;
            case MODEL_FLY_BIG_STONE1:
                if (o->SubType <= 1)
                {
                    o->LifeTime = 300;
                    o->Velocity = Random::Rand() % 200 / 100.f + 28.f;
                    o->Gravity = 2.f;
                    o->Scale = 2.f;
                    o->PKKey = PKKey;
                    o->Kind = Skill;
                    o->Skill = SkillIndex;

                    switch ((int)o->PKKey)
                    {
                    case 1:
                        o->Velocity = 29.f;
                        VectorCopy(Angle, o->m_vDeadPosition);
                        break;

                    default:
                        o->m_vDeadPosition[0] = Hero->Object.Position[0] + (Random::Rand() % 16 - 8) * TERRAIN_SCALE;
                        if (Random::Rand() % 5 == 0)
                            o->m_vDeadPosition[1] = 114 * TERRAIN_SCALE;
                        else
                            o->m_vDeadPosition[1] = (Random::Rand() % 33 + 98) * TERRAIN_SCALE;
                        o->m_vDeadPosition[2] = 100.f;
                        break;
                    }
                    Vector(0.f, 0.f, 0.f, o->Angle);
                    Vector(1.f, 1.f, 1.f, o->Light);
                    VectorCopy(Position, o->StartPosition);

                    VectorSubtract(o->m_vDeadPosition, o->StartPosition, o->Direction);
                    VectorScale(o->Direction, 0.001f, o->Direction);
                    o->Direction[2] = 5.f;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 50;
                    o->Scale = Random::Rand() % 8 / 20.f + 0.7f;
                    o->Gravity = 10.f;
                    o->Angle[0] = (float)(Random::Rand() % 360);

                    Vector(0.f, 0.f, 0.f, o->Direction);
                    Vector(0.f, 0.f, (float)(Random::Rand() % 360), o->HeadAngle);
                }
                break;

            case MODEL_FLY_BIG_STONE2:
                if (o->SubType <= 1)
                {
                    o->LifeTime = 300;
                    o->Velocity = Random::Rand() % 200 / 100.f + 28.f;
                    o->Gravity = 2.f;
                    o->Scale = 2.f;
                    o->PKKey = PKKey;
                    o->Kind = Skill;
                    o->Skill = SkillIndex;

                    switch ((int)o->PKKey)
                    {
                    case 1:
                        o->Velocity = 29.f;
                        VectorCopy(Angle, o->m_vDeadPosition);
                        break;

                    default:
                        o->m_vDeadPosition[0] = Hero->Object.Position[0] + (Random::Rand() % 16 - 8) * TERRAIN_SCALE;
                        o->m_vDeadPosition[1] = (Random::Rand() % 30 + 80) * TERRAIN_SCALE;
                        o->m_vDeadPosition[2] = 100.f;
                        break;
                    }
                    Vector(0.f, 0.f, 0.f, o->Angle);
                    Vector(1.f, 1.f, 1.f, o->Light);
                    VectorCopy(Position, o->StartPosition);

                    VectorSubtract(o->m_vDeadPosition, o->StartPosition, o->Direction);
                    VectorScale(o->Direction, 0.001f, o->Direction);
                    o->Direction[2] = 5.f;
                }
                break;

            case MODEL_BIG_STONE_PART1:
            case MODEL_BIG_STONE_PART2:
            case MODEL_WALL_PART1:
            case MODEL_WALL_PART2:
            case MODEL_GOLEM_STONE:
                if (o->Type >= MODEL_WALL_PART1 && o->Type <= MODEL_WALL_PART2)
                {
                    Vector(0.f, (float)(Random::Rand() % 256 + 128) * 0.1f, 0.f, p1);
                    o->Scale = (float)(Random::Rand() % 2 + 7) * 0.1f;
                    o->Gravity = (float)(Random::Rand() % 5 + 6);
                }
                else if (o->Type == MODEL_GOLEM_STONE)
                {
                    Vector(0.f, (float)(Random::Rand() % 128 + 32) * 0.1f, 0.f, p1);
                    o->Scale = (float)(Random::Rand() % 2 + 10) * 0.25f;
                    o->Gravity = (float)(Random::Rand() % 5 + 2);
                }
                else if ((o->Type == MODEL_BIG_STONE_PART1 || o->Type == MODEL_BIG_STONE_PART2) && o->SubType == 2)
                {
                    Vector(0.f, (float)(Random::Rand() % 128 + 32) * 0.1f, 0.f, p1);
                    o->Scale = 0.6F + (float)(Random::Rand() % 2 + 4) * 0.12f;
                    o->Gravity = (float)(Random::Rand() % 5 + 2);
                }
                else if (o->Type == MODEL_BIG_STONE_PART2 && o->SubType == 3)
                {
                    o->LifeTime = Random::Rand() % 16 + 32;
                    o->Scale = 1.2f + (float)(Random::Rand() % 3 + 2) * 0.12f;
                    o->Direction[2] = -(Random::Rand() % 5 + 20);
                    o->Velocity = 1.8f;
                    break;
                }
                else
                {
                    Vector(0.f, (float)(Random::Rand() % 128 + 128) * 0.1f, 0.f, p1);
                    o->Scale = (float)(Random::Rand() % 7 + 10) * 0.1f;
                    o->Gravity = (float)(Random::Rand() % 5 + 2);
                }
                o->LifeTime = Random::Rand() % 16 + 32;
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);

                o->Position[2] += 50.f;
                break;

            case MODEL_GATE_PART1:
            case MODEL_GATE_PART2:
            case MODEL_GATE_PART3:
                Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                o->Position[2] += 50.f;
                o->LifeTime = Random::Rand() % 16 + 32;
                o->Scale = (float)(Random::Rand() % 2 + 7) * 0.1f;
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);
                o->Gravity = (float)(Random::Rand() % 5 + 2);
                if (o->Type == MODEL_GATE_PART1 && o->SubType == 0)
                {
                    o->SubType = 1;
                    o->Gravity += (float)(Random::Rand() % 5);
                }
                else if (o->SubType == 2)
                {
                    o->Scale *= 0.6f;
                }

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                break;

            case MODEL_AURORA:
                o->LifeTime = 100;
                o->Scale = PKKey / 100.f;
                o->BlendMesh = 0;
                o->BlendMeshLight = 0.f;
                break;




            case MODEL_STUN_STONE:
                if (o->SubType == 0)
                {
                    Vector(Random::Rand() % 256 / 64.f - 2.f, -(float)(Random::Rand() % 200 + 64) * 0.1f, 0.f, p1);

                    o->LifeTime = 40;
                    o->Scale = 1.1f + Random::Rand() % 100 / 100.f;
                    o->Gravity = -(float)(Random::Rand() % 16 + 10);

                    o->ExtState = 0;
                    o->Position[2] += 600.f;

                    AngleMatrix(Angle, Matrix);
                    VectorRotate(p1, Matrix, o->StartPosition);

                    Vector(1.f, 1.f, 1.f, o->Light);
                    Vector(-20.f, 0.f, Random::Rand() % 360, o->Angle);
                    Vector(0.f, 0.f, Angle[2], o->HeadAngle);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 22;
                    o->HiddenMesh = -2;

                    Vector(0.f, -25.f, 0.f, o->Direction);
                    Vector(-1.f, -1.f, -1.f, o->Light);
                }
                break;

            case MODEL_SKIN_SHELL:
                Vector(0.f, (float)(Random::Rand() % 128 + 32) * 0.1f, 0.f, p1);
                o->Position[2] += 50.f;
                o->LifeTime = Random::Rand() % 16 + 32;
                o->Scale = (float)(Random::Rand() % 3 + 3) * 0.1f;
                o->Alpha = 0.5f;
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                VectorRotate(p1, Matrix, o->Direction);
                o->Gravity = (float)(Random::Rand() % 5 + 2);
                o->Gravity += (float)(Random::Rand() % 5);

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);

                if (o->SubType == 0)
                {
                    Vector(0.5f, 0.5f, 0.5f, o->Light);
                }
                else if (o->SubType == 1)
                {
                    Vector(0.1f, 0.6f, 1.f, o->Light);
                }
                break;

            case MODEL_SKILL_JAVELIN:
            {
                o->LifeTime = 35;
                o->Gravity = 2.f;
                o->Velocity = 10.f;
                o->Scale = 1.2f;

                Vector(0.f, -5.f, 0.f, o->Direction);
                VectorCopy(o->Angle, o->HeadAngle);
                VectorCopy(o->Owner->Position, o->StartPosition);
                o->Position[2] += 150.f;

                float Ang = Random::Rand() % 80 + 10;

                o->HeadAngle[2] += o->SubType * Ang - Ang;
            }
            break;
            case MODEL_FENRIR_THUNDER:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 100;
                    o->Scale = 0.3f + (float)(Random::Rand() % 100) * 0.002f;
                    o->m_iAnimation = 0;
                    o->Alpha = 0.7f;

                    o->Angle[0] = Random::Rand() % 360;
                    o->Angle[1] = Random::Rand() % 360;
                    o->Angle[2] = Random::Rand() % 360;

                    VectorCopy(Light, o->Light);

                    vec3_t vPos;
                    Vector(0.0f, 0.0f, 0.0f, vPos);
                    BMD* p_b = &Models[o->Owner->Type];
                    // The Fenrir's own world pose, which its update builds before creating this.
                    vec34_t* ownerBones = o->Owner->BoneTransform != nullptr ? o->Owner->BoneTransform : BoneTransform;
                    int irandom = Random::Rand() % 30;

                    if (irandom >= 1 && irandom <= 2)
                    {
                        p_b->TransformPosition(ownerBones[10], vPos, o->Position, false);
                    }
                    else if (irandom == 3)
                    {
                        o->Scale -= 0.2f;
                        p_b->TransformPosition(ownerBones[14], vPos, o->Position, false);
                    }
                    else if (irandom >= 4 && irandom <= 5)
                    {
                        p_b->TransformPosition(ownerBones[2], vPos, o->Position, false);
                    }
                    else if (irandom >= 6 && irandom <= 7)
                    {
                        o->Scale -= 0.2f;
                        if (Random::Rand() % 2 == 0)
                            p_b->TransformPosition(ownerBones[50], vPos, o->Position, false);
                        else
                            p_b->TransformPosition(ownerBones[51], vPos, o->Position, false);
                    }
                    else if (irandom == 8)
                    {
                        o->Scale -= 0.2f;
                        p_b->TransformPosition(ownerBones[53], vPos, o->Position, false);
                    }
                    else if (irandom >= 9 && irandom <= 10)
                    {
                        o->Live = false;
                        o->Alpha = 0.0f;
                    }
                    else
                    {
                        o->Scale += 0.1f;
                        o->Position[0] += Random::Rand() % 240 - 120;
                        o->Position[1] += Random::Rand() % 10 - 5;
                        o->Position[2] += 110;
                    }

                    vec3_t vLight;
                    vLight[0] = o->Light[0] - 0.3f;
                    vLight[1] = o->Light[1] - 0.3f;
                    vLight[2] = o->Light[2] - 0.3f;
                    CreateSprite(BITMAP_LIGHT, o->Position, 2.0f, vLight, o);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 100;
                    o->Scale = 0.3f + (float)(Random::Rand() % 100) * 0.002f;
                    o->Alpha = 1.0f;
                    o->m_iAnimation = 0;

                    o->Angle[0] = Random::Rand() % 360;
                    o->Angle[1] = Random::Rand() % 360;
                    o->Angle[2] = Random::Rand() % 360;

                    VectorCopy(Light, o->Light);

                    o->Position[0] += Random::Rand() % 40 - 20;
                    o->Position[1] += Random::Rand() % 40 - 20;
                    o->Position[2] += Random::Rand() % 40 - 20;

                    vec3_t vLight;
                    vLight[0] = o->Light[0] - 0.3f;
                    vLight[1] = o->Light[1] - 0.3f;
                    vLight[2] = o->Light[2] - 0.3f;
                    CreateSprite(BITMAP_LIGHT, o->Position, 2.0f, vLight, o);
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 4;
                    o->Scale = 0.1f + (float)(Random::Rand() % 100) * 0.002f;
                    o->Alpha = 1.0f;
                    o->m_iAnimation = 0;

                    o->Angle[0] = Random::Rand() % 360;
                    o->Angle[1] = Random::Rand() % 360;
                    o->Angle[2] = Random::Rand() % 360;

                    VectorCopy(Light, o->Light);

                    o->Position[0] += Random::Rand() % 40 - 20;
                    o->Position[1] += Random::Rand() % 40 - 20;
                    o->Position[2] += Random::Rand() % 40 - 20;

                    vec3_t vLight;
                    vLight[0] = o->Light[0] - 0.3f;
                    vLight[1] = o->Light[1] - 0.3f;
                    vLight[2] = o->Light[2] - 0.3f;
                    CreateSprite(BITMAP_LIGHT, o->Position, 2.0f, vLight, o);
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = 4;
                    o->Scale = 0.5f + (float)(Random::Rand() % 100) * 0.002f;
                    o->Alpha = 1.0f;
                    o->m_iAnimation = 0;

                    o->Angle[0] = Random::Rand() % 360;
                    o->Angle[1] = Random::Rand() % 360;
                    o->Angle[2] = Random::Rand() % 360;

                    VectorCopy(Light, o->Light);

                    o->Position[0] += Random::Rand() % 160 - 80;
                    o->Position[1] += Random::Rand() % 160 - 80;
                    o->Position[2] += Random::Rand() % 160 - 80;

                    vec3_t vLight;
                    vLight[0] = o->Light[0] - 0.3f;
                    vLight[1] = o->Light[1] - 0.3f;
                    vLight[2] = o->Light[2] - 0.3f;
                    CreateSprite(BITMAP_LIGHT, o->Position, 2.0f, vLight, o);
                }
            }
            break;
            case MODEL_FALL_STONE_EFFECT:
            {
                if (o->SubType == 0 || o->SubType == 1)
                {
                    o->LifeTime = Random::Rand() % 5 + 100;

                    if (o->SubType == 0)
                        o->Scale = (float)(Random::Rand() % 20 + 5) * 0.005f + o->Scale * 0.05f;
                    else
                        o->Scale = (float)(Random::Rand() % 10 + 5) * 0.02f + o->Scale * 0.05f;

                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);

                    o->Position[0] += (float)(Random::Rand() % 100 - 50);
                    o->Position[1] += (float)(Random::Rand() % 100 - 50);

                    o->Gravity = (float)(Random::Rand() % 10 + 10) * 0.5f;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 100;
                    o->Scale = o->Scale + (float)(Random::Rand() % 20 + 5) * 0.05f;

                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);

                    o->Gravity = (float)(Random::Rand() % 20 + 40) * 0.5f + o->Scale * 2.f;
                }
                else if (o->SubType == 3)
                {
                    o->LifeTime = Random::Rand() % 5 + 15;
                    o->Scale = Scale;
                    o->Gravity = (float)(Random::Rand() % 3 + 3);

                    o->Angle[2] = (float)(Random::Rand() % 360);
                    AngleMatrix(o->Angle, Matrix);
                    Vector(0.f, (float)(Random::Rand() % 60 + 30) * 0.1f, 0.f, p1);
                    VectorRotate(p1, Matrix, o->HeadAngle);
                    o->HeadAngle[2] += 25.0f;

                    Vector(0, 0, 0, o->Direction);
                }
            }
            break;
            case MODEL_FENRIR_FOOT_THUNDER:
                o->LifeTime = 200;
                o->m_iAnimation = 0;
                VectorCopy(Position, o->Position);
                VectorCopy(Light, o->Light);
                o->Alpha = 1.0f;
                o->m_dwTime = timeGetTime();
                o->Position[2] = 0.0f;
                break;
            case MODEL_TWINTAIL_EFFECT:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 200;
                    VectorCopy(Position, o->Position);
                    VectorCopy(Light, o->Light);
                    o->Alpha = 1.0f;
                    o->Position[2] = 0.0f;
                    o->m_dwTime = timeGetTime();
                    o->m_iAnimation = 0;
                }
                else if (o->SubType == 1 || o->SubType == 2)
                {
                    o->LifeTime = 50;
                    o->Scale = 3.5f;
                    VectorCopy(Position, o->Position);
                    VectorCopy(Light, o->Light);
                    o->Alpha = 1.0f;
                    o->Position[2] = 0.0f;
                    o->Angle[0] = 0.0f;
                }
            }
            break;
            case MODEL_FENRIR_SKILL_DAMAGE:
            {
                switch (o->SubType)
                {
                case 1:
                    Vector(0.6f, 0.2f, 0.2f, o->Light);
                    break;
                case 2:
                    Vector(0.2f, 0.2f, 0.4f, o->Light);
                    break;
                case 3:
                    Vector(0.6f, 0.8f, 0.6f, o->Light);
                    break;
                }

                vec3_t vPos;
                int irandom;

                BMD* p_b = &Models[o->Owner->Type];
                for (int i = 0; i < 10; i++)
                {
                    irandom = Random::Rand() % p_b->NumBones;
                    Vector(0.0f, 0.0f, 0.0f, vPos);
                    p_b->TransformPosition(o->Owner->BoneTransform[irandom], vPos, o->Position, true);
                    CreateParticle(BITMAP_ENERGY, o->Position, o->Angle, o->Light, 2);
                }
            }
            break;
            case MODEL_ARROW_IMPACT:
                o->Velocity = 1.f;
                o->LifeTime = 20;
                o->Scale = 1.8f;
                o->BlendMesh = -2;
                o->Direction[1] = -30.f;

                Vector(0.3f, 0.8f, 1.f, o->Light);

                AngleMatrix(o->Angle, Matrix);
                Vector(-10.f, -80.f, 200.f, p1);
                VectorRotate(p1, Matrix, p2);
                VectorAdd(o->Position, p2, o->Position);

                o->Angle[0] = -30.f;
                CreateJoint(BITMAP_FLASH, o->Position, o->Position, o->Angle, 4, o, 40.f, 50);

                o->Weapon = CharacterMachine->PacketSerial;
                break;
            case BITMAP_JOINT_FORCE:
                if (o->SubType == 0)
                {
                    o->LifeTime = 20;
                    Vector(0.f, -550.f, 0.f, o->Direction);
                    Vector(-90.f, 0.f, Angle[2], o->Angle);
                    Vector(0.f, 0.f, Random::Rand() % 360, o->HeadAngle);
                    CreateJoint(BITMAP_JOINT_FORCE, o->Position, o->Position, o->Angle, 3, NULL, 80.f);
                    VectorCopy(Position, o->StartPosition);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 20;
                    Vector(0.f, -250.f, 0.f, o->Direction);
                    Vector(-90.f, 0.f, Angle[2], o->Angle);
                    Vector(0.f, 0.f, Random::Rand() % 360, o->HeadAngle);
                    VectorCopy(Position, o->StartPosition);
                }
                break;
            case MODEL_PROTECTGUILD:
            {
                o->Alpha = 0;
                o->Angle[2] = +45.0f;

                BMD* b = &Models[o->Owner->Type];
                vec3_t tempPosition, p;
                Vector(0.f, 0.f, 0.f, p);
                b->TransformPosition(o->Owner->BoneTransform[20], p, tempPosition, true);
                o->Position[0] = tempPosition[0];
                o->Position[1] = tempPosition[1];
                o->Position[2] = o->Owner->Position[2] + tempPosition[2] - o->Owner->Position[2] + 60;

                o->LifeTime = 130;
                o->Scale = 3.2f;
                Vector(1.0f, 1.0f, 1.0f, o->Light);
                VectorCopy(o->Position, o->StartPosition);
                for (int i = 0; i < 10; ++i)
                {
                    float fAngle = Random::Rand() % 360;
                    Vector(o->Position[0] + (Random::Rand() % 20 + 15) * sinf(fAngle),
                           o->Position[1] + (Random::Rand() % 20 + 15) * cosf(fAngle),
                           o->Position[2] /*- 25 + Random::Rand()%50*/, p);
                    CreateParticle(BITMAP_SPARK + 1, p, o->Angle, o->Light, 4, 0.6f, o);
                }
            }
            break;
            case MODEL_MOVE_TARGETPOSITION_EFFECT:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 30;
                    o->BlendMesh = 0;

                    vec3_t vLight, vPos;
                    Vector(1.0f, 0.7f, 0.3f, vLight);
                    VectorCopy(o->Position, vPos);
                    vPos[2] += 85.f;

                    DeleteEffect(BITMAP_MAGIC, NULL, 11);
                    DeleteEffect(BITMAP_TARGET_POSITION_EFFECT2, NULL, 0);
                    DeleteEffect(BITMAP_TARGET_POSITION_EFFECT1, NULL, 0);
                    DeleteJoint(MODEL_SPEARSKILL, NULL, 16);

                    CreateEffect(BITMAP_MAGIC, o->Position, o->Angle, vLight, 11);
                    CreateEffect(BITMAP_TARGET_POSITION_EFFECT2, o->Position, o->Angle, vLight, 0);
                    CreateJoint(MODEL_SPEARSKILL, vPos, vPos, Angle, 16, o, 5.0f);
                    CreateJoint(MODEL_SPEARSKILL, vPos, vPos, Angle, 16, o, 5.0f);
                    CreateJoint(MODEL_SPEARSKILL, vPos, vPos, Angle, 16, o, 5.0f);
                    CreateJoint(MODEL_SPEARSKILL, vPos, vPos, Angle, 16, o, 5.0f);
                }
            }
            break;

            case MODEL_EFFECT_SAPITRES_ATTACK:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 20;

                    for (int i = 0; i < 10; i++)
                    {
                        CreateEffect(MODEL_EFFECT_SAPITRES_ATTACK_2, o->Position, o->Angle, o->Light, 14);
                    }
                }
            }
            break;
            case MODEL_EFFECT_SAPITRES_ATTACK_1:
            {
                if (o->SubType == 0)
                {
                    o->BlendMesh = 0;
                    o->BlendMeshLight = 1.0f;
                    o->Position[2] += 100.f;
                    o->LifeTime = 17;
                    o->Scale = 1.1f;
                    VectorSubtract(o->Owner->Position, o->Position, o->Direction);
                    VectorNormalize(o->Direction);
                    o->Angle[2] = CreateAngle2D(o->Position, o->Owner->Position);
                }
            }
            break;


            case MODEL_EFFECT_TRACE:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 50;
                    VectorCopy(o->Position, o->EyeLeft);
                    CreateJoint(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 17, o, o->Scale, -1, 0, 0, -1, o->Light);
                }
            }break;
            case MODEL_STAR_SHINE:
            {
                switch (o->SubType)
                {
                case 0:
                {
                    o->LifeTime = 30;
                    o->Alpha = 0.2f;
                    o->Angle[0] = (float)(Random::Rand() % 360);
                }break;
                }
            }break;
            case MODEL_FEATHER:
            {
                switch (o->SubType)
                {
                case 0:
                case 1:
                case 2:
                case 3:
                {
                    vec3_t vOriginPos;
                    VectorCopy(o->Position, vOriginPos);

                    o->Position[0] += (float)(Random::Rand() % 20 - 10) * 4.f;
                    o->Position[1] += (float)(Random::Rand() % 20 - 10) * 4.f;
                    o->Position[2] += (float)(Random::Rand() % 20 - 10) * 4.f;

                    VectorSubtract(vOriginPos, o->Position, o->Direction);
                    VectorNormalize(o->Direction);
                    int iAddDirection = ((float)(Random::Rand() % 10 - 5) * 0.08f);
                    o->Direction[0] += iAddDirection;
                    o->Direction[1] += iAddDirection;
                    o->Direction[2] += iAddDirection;

                    o->Scale = o->Scale + ((float)(Random::Rand() % 20 - 10) * (o->Scale * 0.03f));
                    o->LifeTime = 30 + (Random::Rand() % 20 - 10);
                    if (o->SubType == 2 || o->SubType == 3)
                        o->LifeTime = 100;
                    o->Alpha = 0.6f + ((float)(Random::Rand() % 10) * 0.02f);

                    o->Gravity = 0.1f;

                    if (o->SubType == 2 || o->SubType == 3)
                        o->Gravity = 0.f;

                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);

                    o->EyeRight[0] = (float)(Random::Rand() % 10 - 5);
                    o->EyeRight[1] = (float)(Random::Rand() % 10 - 5);
                    o->EyeRight[2] = (float)(Random::Rand() % 10 - 5);
                }break;
                }
            }break;
            case MODEL_FEATHER_FOREIGN:
            {
                switch (o->SubType)
                {
                case 4:
                {
                    vec3_t vOriginPos;
                    VectorCopy(o->Position, vOriginPos);

                    o->Position[0] += (float)(Random::Rand() % 20 - 10) * 4.f;
                    o->Position[1] += (float)(Random::Rand() % 20 - 10) * 4.f;
                    o->Position[2] += (float)(Random::Rand() % 20 - 10) * 4.f;

                    VectorSubtract(vOriginPos, o->Position, o->Direction);
                    VectorNormalize(o->Direction);
                    int iAddDirection = ((float)(Random::Rand() % 10 - 5) * 0.08f);
                    o->Direction[0] += iAddDirection;
                    o->Direction[1] += iAddDirection;
                    o->Direction[2] += iAddDirection;

                    o->Scale = o->Scale + ((float)(Random::Rand() % 20 - 10) * (o->Scale * 0.03f));
                    o->LifeTime = 25;
                    o->Alpha = 0.3f;

                    o->Gravity = 0.1f;
                    o->Angle[0] = (float)(Random::Rand() % 360);
                    o->Angle[1] = (float)(Random::Rand() % 360);
                    o->Angle[2] = (float)(Random::Rand() % 360);

                    o->EyeRight[0] = (float)(Random::Rand() % 10 - 5);
                    o->EyeRight[1] = (float)(Random::Rand() % 10 - 5);
                    o->EyeRight[2] = (float)(Random::Rand() % 10 - 5);
                }break;
                }
            }break;
            case MODEL_BLOW_OF_DESTRUCTION:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;
                    vec3_t vPos, vPos2;
                    float Matrix[3][4];
                    Vector(-20.f, -100.f, 0.f, vPos);
                    AngleMatrix(o->Owner->Angle, Matrix);
                    VectorRotate(vPos, Matrix, vPos2);
                    VectorAdd(vPos2, o->Position, o->Position);
                    VectorCopy(o->Light, o->StartPosition);
                    Vector(1.2f, 1.2f, 1.2f, o->Light);
                    CreateEffect(MODEL_BLOW_OF_DESTRUCTION, o->StartPosition, o->Angle, o->Light, 1, o->Owner);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 40;
                    Vector(1.2f, 1.2f, 1.2f, o->Light);
                    o->Position[2] = 150.f;
                    o->Scale = 5.f;
                }
                else if (o->SubType == 2)
                {
                    o->LifeTime = 50;
                    vec3_t vPos, vPos2;
                    float Matrix[3][4];
                    Vector(0.f, 0.f, 0.f, vPos);
                    AngleMatrix(o->Owner->Angle, Matrix);
                    VectorRotate(vPos, Matrix, vPos2);
                    VectorAdd(vPos2, o->Position, o->Position);
                    if (o->Owner->m_sTargetIndex < 0)
                        break;
                    VectorCopy(CharactersClient[o->Owner->m_sTargetIndex].Object.Position, o->StartPosition);
                    o->Scale = 0.5f;
                }
            }
            break;
            case MODEL_NIGHTWATER_01:
            {
                o->LifeTime = 25;
                o->Alpha = 1.f;
                o->Angle[2] = Random::Rand() % 360;
            }
            break;
            case MODEL_KNIGHT_PLANCRACK_A:
                if (o->SubType == 0)
                {
                    o->LifeTime = 25;
                    o->Alpha = 1.f;
                    o->Angle[2] = Random::Rand() % 360;
                    o->Scale = Scale + Random::Rand() % 10 * 0.05f;
                    o->Position[2] += 10.f;
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 20;
                    o->Alpha = 1.f;
                    o->Angle[2] = Random::Rand() % 360;
                    o->Scale = Scale + Random::Rand() % 10 * 0.05f;
                    o->Position[2] += 10.f;
                }
                break;
            case MODEL_EFFECT_FLAME_STRIKE:
                if (o->SubType == 0)
                {
                    o->Alpha = 0;
                    o->LifeTime = 35;
                    o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_FLAMESTRIKE].PlaySpeed;
                    o->AI = 0;
                    o->m_iAnimation = Random::Rand();
                }
                break;
            case MODEL_STREAMOFICEBREATH:
            {
                const	float LENSCALAR = 50.0f;
                const	float RANDOMOFFSET_ANGLE = 5.0f;
                const	float RANDOMOFFSET_SCALE = 0.01f;
                const	float RANDOMOFFSET_POSITION = 20.0f;
                const float RANDNUM = ((float)((Random::Rand() % 2000) - 1000) * 0.001f);

                // 1. Set Value
                o->LifeTime = 17;
                o->Light[0] = 0.6f;
                o->Light[1] = 0.6f;
                o->Light[2] = 0.6f;

                // 2. Calculate Position
                vec3_t		v3Len_, v3LenBasis_, v3PosBasis_;
                float		matRotation[3][4];

                Vector(0.0f, -1.0f, 0.0f, v3LenBasis_);
                AngleMatrix(o->Angle, matRotation);
                VectorRotate(v3LenBasis_, matRotation, v3Len_);

                v3PosBasis_[0] = o->Position[0] + (v3Len_[0] * LENSCALAR);
                v3PosBasis_[1] = o->Position[1] + (v3Len_[1] * LENSCALAR);
                v3PosBasis_[2] = o->Position[2] + (v3Len_[2] * LENSCALAR);

                VectorCopy(v3PosBasis_, o->StartPosition);
                // 3. Reality Position, Angle, Scaling
                for (INT i_ = 0; i_ < 4; ++i_)
                {
                    vec3_t		v3ResultAngle, v3ResultPos;
                    float		fResultScale;
                    float		fCurrentOffsetScale, fCurrentOffsetPos, fCurrentOffsetAngle;
                    fCurrentOffsetScale = RANDOMOFFSET_SCALE * RANDNUM;
                    fCurrentOffsetPos = RANDOMOFFSET_POSITION * RANDNUM;
                    fCurrentOffsetAngle = RANDOMOFFSET_ANGLE * RANDNUM;

                    v3ResultPos[0] = v3PosBasis_[0] + fCurrentOffsetPos;
                    v3ResultPos[1] = v3PosBasis_[1] + fCurrentOffsetPos;
                    v3ResultPos[2] = v3PosBasis_[2] + fCurrentOffsetPos;

                    v3ResultAngle[0] = o->Angle[0] + fCurrentOffsetAngle;
                    v3ResultAngle[1] = o->Angle[1] + fCurrentOffsetAngle;
                    v3ResultAngle[2] = o->Angle[2] + fCurrentOffsetAngle;

                    fResultScale = o->Scale + fCurrentOffsetScale;

                    CreateParticle(BITMAP_RAKLION_CLOUDS, v3ResultPos, v3ResultAngle, o->Light, 0, fResultScale);
                }
            }break;
            case MODEL_LAVAGIANT_FOOTPRINT_R:
            case MODEL_LAVAGIANT_FOOTPRINT_V:
            {
                o->LifeTime = 200;
                VectorCopy(Position, o->Position);
                VectorCopy(Light, o->Light);
                o->Alpha = 1.0f;
                o->Position[2] = 0.0f;
                o->m_dwTime = timeGetTime();
                o->Scale = o->Scale;
            }
            break;
            case MODEL_EFFECT_FIRE_HIK3_MONO:
            {
                int iRandNum = (Random::Rand() % 100);

                if (iRandNum > 20)
                {
                    CreateParticle(BITMAP_FIRE_HIK3_MONO, o->Position, o->Angle, o->Light, 1, o->Scale);
                }
            }
            break;
            case MODEL_DOOR_CRUSH_EFFECT_PIECE01:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE02:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE03:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE04:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE05:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE06:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE07:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE08:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE09:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE11:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE12:
            case MODEL_DOOR_CRUSH_EFFECT_PIECE13:
            case MODEL_STATUE_CRUSH_EFFECT_PIECE01:
            case MODEL_STATUE_CRUSH_EFFECT_PIECE02:
            case MODEL_STATUE_CRUSH_EFFECT_PIECE03:
            {
                o->LifeTime = 30 + (Random::Rand() % 30);
                o->Velocity = 0.f;
                o->PKKey = -1;
                o->Owner = Owner;
                o->Gravity = 2.3f;

                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 64 + 48) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] = 15;

                o->SubType = Random::Rand() % 2;

                o->Light[0] = o->Light[1] = o->Light[2] = 0.5 + (Random::Rand() % 6) * 0.1f;
                o->Direction[0] = 0;
                o->Direction[1] = 0;
                o->Direction[2] = 0;
            }
            break;
            case MODEL_DOOR_CRUSH_EFFECT:
            {
                switch (o->SubType)

                {
                case 0:
                {
                    vec3_t vPos;
                    for (int i = 0; i < 9; i++)
                    {
                        Vector(o->Position[0] + (Random::Rand() % 200 - 100),
                               o->Position[1] + (Random::Rand() % 200 - 100),
                               o->Position[2] + (Random::Rand() % 200 - 100), vPos);
                        CreateEffect(MODEL_DOOR_CRUSH_EFFECT_PIECE01 + i, vPos, o->Angle, o->Light, 0, o->Owner, 0, 0);
                    }
                }break;
                case 1:
                {
                    vec3_t vPos;
                    for (int i = 0; i < 9; i++)
                    {
                        Vector(o->Position[0] + (Random::Rand() % 200 - 100),
                               o->Position[1] + (Random::Rand() % 200 - 100),
                               o->Position[2] + (Random::Rand() % 200 - 100), vPos);
                        CreateEffect(MODEL_DOOR_CRUSH_EFFECT_PIECE11 + (i % 3), vPos, o->Angle, o->Light, 0, o->Owner, 0, 0);
                    }
                }break;
                }
            }
            break;
            case MODEL_STATUE_CRUSH_EFFECT:
            {
                for (int i = 0; i < 6; i++)
                {
                    CreateEffect(MODEL_STATUE_CRUSH_EFFECT_PIECE01 + (i % 3), o->Position, o->Angle, o->Light, 0, o->Owner, 0, 0);
                }
            }
            break;
            case MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_:
            case MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_:
            case MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_:
            case MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_:
            case MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_:
            case MODEL_EMPIREGUARDIANBOSS_FRAMESTRIKE:
            {
                OBJECT* O = &(Hero->Object);
                for (int i = 113; i <= 155; ++i)
                {
                    RemoveObjectBlurs(O, i);
                }

                if (o->SubType == 0)
                {
                    o->LifeTime = 2;
                    o->ChromeEnable = true;
                }
                else if (o->SubType == 3)
                {
                    const int	TOTAL_LIFETIME = 60;
                    vec3_t		v3PosStart, v3PosTarget;
                    vec3_t arv3PosProcess[4];

                    o->ExtState = TOTAL_LIFETIME;
                    o->LifeTime = TOTAL_LIFETIME;
                    o->Gravity = 0.0f;
                    o->HiddenMesh = 1;
                    o->Distance = 0.0f;
                    o->Alpha = 1.0f;
                    o->ChromeEnable = false;

                    Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);

                    VectorCopy(o->Position, o->StartPosition);
                    VectorCopy(o->Position, v3PosStart);
                    VectorCopy(o->Light, v3PosTarget);

                    vec3_t		v3DirDistAD;
                    vec3_t		v3PosStartModify, v3PosTargetModify;
                    const int	iLimitArea1 = 200;
                    float fDistAD, fDistAB;
                    float		fHeightTerrainTarget = RequestTerrainHeight(v3PosTarget[0], v3PosTarget[1]);
                    int			iOffsetDist = 100;
                    VectorCopy(v3PosStart, v3PosStartModify);
                    VectorCopy(v3PosTarget, v3PosTargetModify);
                    v3PosTargetModify[2] = v3PosStartModify[2];
                    fDistAD = VectorDistance3D_DirDist(v3PosStartModify, v3PosTargetModify, v3DirDistAD);

                    fDistAB = 900.0f + (Random::Rand() % iOffsetDist - (iOffsetDist / 2));
                    VectorCopy(v3PosStart, arv3PosProcess[0]);
                    arv3PosProcess[1][0] =
                        arv3PosProcess[0][0] + (float)(Random::Rand() % iLimitArea1 - (iLimitArea1 / 2));
                    arv3PosProcess[1][1] =
                        arv3PosProcess[0][1] + (float)(Random::Rand() % iLimitArea1 - (iLimitArea1 / 2));
                    arv3PosProcess[1][2] = v3PosStart[2] + fDistAB;
                    VectorAdd(arv3PosProcess[1], v3DirDistAD, arv3PosProcess[2]);

                    VectorCopy(v3PosTargetModify, arv3PosProcess[3]);
                    arv3PosProcess[3][0] =
                        arv3PosProcess[2][0]; // + (float)(Random::Rand()%iLimitArea2 - (iLimitArea2/2));
                    arv3PosProcess[3][1] =
                        arv3PosProcess[2][1]; // + (float)(Random::Rand()%iLimitArea2 - (iLimitArea2/2));
                    arv3PosProcess[3][2] = fHeightTerrainTarget + (float)iOffsetDist * 1.2f +
                                           ((Random::Rand() % iOffsetDist) - (iOffsetDist / 2));

                    float	arfRates[] = { 0.0f, 0.22f, 0.35f, 0.50f, 1.01f };
                    float	fOffsetRate = (0.03f * (o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_));

                    o->m_Interpolates.ClearContainer();
                    CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                    InsertFactor.fRateStart = arfRates[0] + fOffsetRate;
                    InsertFactor.fRateEnd = arfRates[1] + fOffsetRate;
                    VectorCopy(v3PosStart, InsertFactor.v3Start);
                    VectorCopy(arv3PosProcess[1], InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    InsertFactor.fRateStart = arfRates[1] + fOffsetRate;
                    InsertFactor.fRateEnd = arfRates[2] + fOffsetRate;
                    VectorCopy(arv3PosProcess[1], InsertFactor.v3Start);
                    VectorCopy(arv3PosProcess[2], InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    InsertFactor.fRateStart = arfRates[2] + fOffsetRate;
                    InsertFactor.fRateEnd = arfRates[3] + fOffsetRate;
                    VectorCopy(arv3PosProcess[2], InsertFactor.v3Start);
                    VectorCopy(arv3PosProcess[3], InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    InsertFactor.fRateStart = arfRates[3] + fOffsetRate;
                    InsertFactor.fRateEnd = arfRates[4];
                    VectorCopy(arv3PosProcess[3], InsertFactor.v3Start);
                    VectorCopy(arv3PosProcess[3], InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    CInterpolateContainer::INTERPOLATE_FACTOR_F	InsertFactorF;
                    InsertFactorF.fRateStart = arfRates[0];
                    InsertFactorF.fRateEnd = arfRates[3];
                    InsertFactorF.fStart = 1.0f;
                    InsertFactorF.fEnd = 1.0f;

                    InsertFactorF.fRateStart = arfRates[3];
                    InsertFactorF.fRateEnd = arfRates[4];
                    InsertFactorF.fStart = 1.0f;
                    InsertFactorF.fEnd = 0.0f;
                    o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);
                    o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                    o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                    o->m_Interpolates.GetAlphaCurrent(o->Alpha, 0.0f);

                    CreateJoint(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 20, o, 160.f, 40);
                }
                else if (o->SubType == 11)
                {
                    const int	TOTALLIFETIME = 24;
                    o->LifeTime = TOTALLIFETIME;
                    o->ExtState = TOTALLIFETIME;
                    o->ChromeEnable = true;
                    o->Scale = Scale;

                    o->m_Interpolates.ClearContainer();

                    CInterpolateContainer::INTERPOLATE_FACTOR_F InsertFactorF;
                    InsertFactorF.fRateStart = 0.0f;
                    InsertFactorF.fRateEnd = 0.61f;
                    InsertFactorF.fStart = 0.0f;
                    InsertFactorF.fEnd = 1.0f;
                    o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                    InsertFactorF.fRateStart = 0.61f;
                    InsertFactorF.fRateEnd = 1.01f;
                    InsertFactorF.fStart = 1.0f;
                    InsertFactorF.fEnd = 1.0f;
                    o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);
                }
                else if (o->SubType == 12)
                {
                    const int	TOTALLIFETIME = 14;
                    o->LifeTime = TOTALLIFETIME;
                    o->ExtState = TOTALLIFETIME;
                    o->ChromeEnable = true;
                    o->Scale = Scale;
                    o->m_Interpolates.ClearContainer();

                    CInterpolateContainer::INTERPOLATE_FACTOR_F InsertFactorF;
                    InsertFactorF.fRateStart = 0.0f;
                    InsertFactorF.fRateEnd = 1.01f;
                    InsertFactorF.fStart = 0.0f;
                    InsertFactorF.fEnd = 1.0f;
                    o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);
                }
                else if (o->SubType == 20)
                {
                    const int	TOTALLIFETIME = 10;
                    o->LifeTime = TOTALLIFETIME;
                    o->ExtState = TOTALLIFETIME;
                    o->ChromeEnable = false;

                    switch (o->Type)
                    {
                    case MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_:
                    case MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        o->LifeTime = 10;
                    }
                    break;
                    case MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_:
                    case MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        o->LifeTime = 5;
                    }
                    break;
                    case MODEL_EMPIREGUARDIANBOSS_FRAMESTRIKE:
                    {
                        o->LifeTime = 5;
                    }
                    }
                    o->m_Interpolates.ClearContainer();
                    CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                    InsertFactor.fRateStart = 0.0f;
                    InsertFactor.fRateEnd = 1.0f;
                    VectorCopy(o->Angle, InsertFactor.v3Start);
                    VectorCopy(o->Angle, InsertFactor.v3End);

                    o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);
                    InsertFactor.fRateStart = 0.0f;
                    InsertFactor.fRateEnd = 1.0f;
                    VectorCopy(o->Position, InsertFactor.v3Start);
                    VectorCopy(o->Position, InsertFactor.v3End);
                    o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                    CInterpolateContainer::INTERPOLATE_FACTOR_F	InsertFactorF;
                    InsertFactorF.fRateStart = 0.0f;
                    InsertFactorF.fRateEnd = 1.0f;
                    InsertFactorF.fStart = 0.7f;
                    InsertFactorF.fEnd = 0.0f;
                    o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                    InsertFactorF.fRateStart = 0.0f;
                    InsertFactorF.fRateEnd = 1.0f;
                    InsertFactorF.fStart = o->Scale;
                    InsertFactorF.fEnd = o->Scale;
                    o->m_Interpolates.m_vecInterpolatesScale.push_back(InsertFactorF);
                }
                else	// SubType == 1
                {
                    switch (o->Type)
                    {
                    case MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        if (o->SubType == 1)
                        {
                            const int	TOTAL_LIFETIME = 35;
                            vec3_t		v3PosProcess01, v3PosProcessFinal,
                                v3DirModify, v3PosModify,
                                v3PosTargetModify;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->Gravity = 0.0f;
                            o->HiddenMesh = 1;
                            o->Distance = 0.0f;
                            o->Alpha = 1.0f;
                            o->ChromeEnable = false;

                            Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                            VectorCopy(o->Position, o->StartPosition);
                            VectorSubtract(o->Light, o->Position, o->Direction);
                            o->Distance = sqrt(o->Direction[0] * o->Direction[0] +
                                o->Direction[1] * o->Direction[1] +
                                o->Direction[2] * o->Direction[2]);

                            VectorDivFSelf(o->Direction, o->Distance);

                            float	fDistanceResult = 0;
                            vec3_t	v3DirResult;
                            vec3_t v3PosModify02;
                            float	fTotalDist = 1700.0f, fFirstDist = 0.0f, fRateFirstDist = 0.0f;
                            VectorCopy(o->Owner->Position, v3PosModify02);
                            VectorCopy(o->Position, v3PosModify);

                            v3PosModify02[2] = o->Light[2];
                            v3PosModify[2] = o->Light[2];
                            VectorCopy(o->Light, v3PosTargetModify);
                            v3PosModify[2] = v3PosModify[2] + 100.0f;
                            v3PosModify02[2] = v3PosModify02[2] + 100.0f;
                            v3PosTargetModify[2] = v3PosTargetModify[2] + 100.0f;
                            VectorDistNormalize(v3PosModify02, v3PosTargetModify, v3DirModify);

                            fDistanceResult = o->Distance * 0.3f;
                            fFirstDist = fDistanceResult;
                            VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                            VectorAdd(v3PosModify, v3DirResult, v3PosProcess01);

                            fDistanceResult = fTotalDist;
                            VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                            VectorAdd(v3PosModify, v3DirResult, v3PosProcessFinal);

                            fRateFirstDist = fFirstDist / fTotalDist;

                            o->m_Interpolates.ClearContainer();

                            fRateFirstDist = fFirstDist / fTotalDist;

                            CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = fRateFirstDist;
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = fRateFirstDist;
                            InsertFactor.fRateEnd = 1.01f;
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, 1560.0f, InsertFactor.v3End);

                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = fRateFirstDist;
                            VectorCopy(o->Position, InsertFactor.v3Start);
                            VectorCopy(v3PosProcess01, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            InsertFactor.fRateStart = fRateFirstDist;
                            InsertFactor.fRateEnd = 1.01f;
                            VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                            VectorCopy(v3PosProcessFinal, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                            o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                        }
                    }	// MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_
                    break;
                    case MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        if (o->SubType == 1)
                        {
                            const int	TOTAL_LIFETIME = 35;
                            vec3_t		v3PosProcess01, v3PosProcessFinal,
                                v3DirModify, v3PosModify,
                                v3PosTargetModify;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->Gravity = 0.0f;
                            o->HiddenMesh = 1;
                            o->Distance = 0.0f;
                            o->Alpha = 1.0f;
                            o->ChromeEnable = false;

                            Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                            VectorCopy(o->Position, o->StartPosition);
                            VectorSubtract(o->Light, o->Position, o->Direction);

                            o->Distance = sqrt(o->Direction[0] * o->Direction[0] + o->Direction[1] * o->Direction[1] + o->Direction[2] * o->Direction[2]);

                            VectorDivFSelf(o->Direction, o->Distance);

                            float	fDistanceResult = 0;
                            vec3_t	v3DirResult;

                            vec3_t v3PosModify02;
                            float	fTotalDist = 1700.0f, fFirstDist = 0.0f, fRateFirstDist = 0.0f;
                            VectorCopy(o->Owner->Position, v3PosModify02);
                            VectorCopy(o->Position, v3PosModify);

                            v3PosModify02[2] = o->Light[2];
                            v3PosModify[2] = o->Light[2];
                            VectorCopy(o->Light, v3PosTargetModify);
                            v3PosModify[2] = v3PosModify[2] + 100.0f;
                            v3PosModify02[2] = v3PosModify02[2] + 100.0f;
                            v3PosTargetModify[2] = v3PosTargetModify[2] + 100.0f;
                            VectorDistNormalize(v3PosModify02, v3PosTargetModify, v3DirModify);

                            fDistanceResult = o->Distance * 0.3f;
                            fFirstDist = fDistanceResult;
                            VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                            VectorAdd(v3PosModify, v3DirResult, v3PosProcess01);

                            fDistanceResult = fTotalDist;
                            VectorMulF(v3DirModify, fDistanceResult, v3DirResult);
                            VectorAdd(v3PosModify, v3DirResult, v3PosProcessFinal);

                            fRateFirstDist = fFirstDist / fTotalDist;

                            o->m_Interpolates.ClearContainer();

                            CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = fRateFirstDist;
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = fRateFirstDist;
                            InsertFactor.fRateEnd = 1.01f;
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, -1560.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = fRateFirstDist;
                            VectorCopy(o->Position, InsertFactor.v3Start);
                            VectorCopy(v3PosProcess01, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            InsertFactor.fRateStart = fRateFirstDist;
                            InsertFactor.fRateEnd = 1.01f;
                            VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                            VectorCopy(v3PosProcessFinal, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                            o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                        }
                    }	// MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_
                    break;
                    case MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        if (o->SubType == 1)	// 일반공격 Animation
                        {
                            //const int	TOTAL_LIFETIME = 24;
                            const int	TOTAL_LIFETIME = 30;
                            vec3_t		v3PosProcess01, v3PosProcessFinal,
                                v3AngleOffset,
                                v3Dir,
                                v3DirPower,
                                v3DirModify,
                                v3DirModifyR;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->Gravity = 0.2f;
                            o->HiddenMesh = 1;
                            o->Distance = 0.0f;
                            o->Alpha = 1.0f;
                            o->ChromeEnable = false;

                            Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                            VectorCopy(o->Position, o->StartPosition);
                            vec3_t	v3PosStartModify, v3PosEndModify;
                            VectorCopy(o->Light, v3PosEndModify);
                            VectorCopy(o->StartPosition, v3PosStartModify);
                            v3PosStartModify[2] = v3PosEndModify[2];

                            VectorSubtract(v3PosEndModify, v3PosStartModify, v3DirModify);
                            VectorSubtract(o->Light, o->StartPosition, v3Dir);

                            o->Distance = sqrt(v3Dir[0] * v3Dir[0] +
                                v3Dir[1] * v3Dir[1] +
                                v3Dir[2] * v3Dir[2]);

                            v3Dir[0] /= o->Distance;
                            v3Dir[1] /= o->Distance;
                            v3Dir[2] /= o->Distance;

                            VectorNormalize(v3DirModify);
                            VectorCopy(v3Dir, o->Direction);

                            Vector(0.0f, 0.0f, -40.0f, v3AngleOffset);
                            AngleMatrix(v3AngleOffset, Matrix);
                            VectorRotate(v3DirModify, Matrix, v3DirModifyR);
                            VectorMulF(v3DirModifyR, o->Distance * 0.4f, v3DirPower);
                            VectorAdd(o->StartPosition, v3DirPower, v3PosProcess01);
                            v3PosProcess01[2] -= 100.0f;

                            Vector(0.0f, 0.0f, 24.0f, v3AngleOffset);
                            AngleMatrix(v3AngleOffset, Matrix);
                            VectorRotate(v3DirModify, Matrix, v3DirModifyR);
                            VectorMulF(v3DirModifyR, o->Distance + 700.0f, v3DirPower);
                            VectorAdd(o->StartPosition, v3DirPower, v3PosProcessFinal);
                            v3PosProcessFinal[2] -= 290.0f;

                            o->m_Interpolates.ClearContainer();

                            CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = 0.32f;
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = 0.32f;
                            InsertFactor.fRateEnd = 1.01f;
                            Vector(90.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(90.0f, 0.0f, 340.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = 0.32f;
                            VectorCopy(o->Position, InsertFactor.v3Start);
                            VectorCopy(v3PosProcess01, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            InsertFactor.fRateStart = 0.32f;
                            InsertFactor.fRateEnd = 1.01f;
                            VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                            VectorCopy(v3PosProcessFinal, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            CInterpolateContainer::INTERPOLATE_FACTOR_F InsertFactorF;
                            InsertFactorF.fRateStart = 0.0f;
                            InsertFactorF.fRateEnd = 0.15f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                            InsertFactorF.fRateStart = 0.15f;
                            InsertFactorF.fRateEnd = 0.75f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                            InsertFactorF.fRateStart = 0.75f;
                            InsertFactorF.fRateEnd = 1.01f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 0.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                            o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                            o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                            o->m_Interpolates.GetAlphaCurrent(o->Alpha, 0.0f);
                        }
                    }	// MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_
                    break;
                    case MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_:
                    {
                        if (o->SubType == 1)
                        {
                            //const int	TOTAL_LIFETIME = 22;
                            const int	TOTAL_LIFETIME = 30;
                            vec3_t		v3PosProcess01, v3PosProcessFinal,
                                v3AngleOffset,
                                v3Dir,
                                v3DirPower,
                                v3DirModify,
                                v3DirModifyR;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->Gravity = 0.2f;
                            o->HiddenMesh = 1;
                            o->Distance = 0.0f;
                            o->Alpha = 1.0f;
                            o->ChromeEnable = false;

                            Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                            VectorCopy(o->Position, o->StartPosition);
                            vec3_t	v3PosStartModify, v3PosEndModify;
                            VectorCopy(o->Light, v3PosEndModify);
                            VectorCopy(o->StartPosition, v3PosStartModify);
                            v3PosStartModify[2] = v3PosEndModify[2];

                            VectorSubtract(v3PosEndModify, v3PosStartModify, v3DirModify);
                            VectorSubtract(o->Light, o->StartPosition, v3Dir);

                            o->Distance = sqrt(v3Dir[0] * v3Dir[0] + v3Dir[1] * v3Dir[1] + v3Dir[2] * v3Dir[2]);

                            v3Dir[0] /= o->Distance;
                            v3Dir[1] /= o->Distance;
                            v3Dir[2] /= o->Distance;

                            VectorNormalize(v3DirModify);
                            VectorCopy(v3Dir, o->Direction);

                            Vector(0.0f, 0.0f, 50.0f, v3AngleOffset);
                            AngleMatrix(v3AngleOffset, Matrix);
                            VectorRotate(v3DirModify, Matrix, v3DirModifyR);
                            VectorMulF(v3DirModifyR, o->Distance * 0.4f, v3DirPower);
                            VectorAdd(o->StartPosition, v3DirPower, v3PosProcess01);
                            v3PosProcess01[2] -= 100.0f;

                            Vector(0.0f, 0.0f, -26.0f, v3AngleOffset);
                            AngleMatrix(v3AngleOffset, Matrix);
                            VectorRotate(v3DirModify, Matrix, v3DirModifyR);
                            VectorMulF(v3DirModifyR, o->Distance + 700.0f, v3DirPower);
                            VectorAdd(o->StartPosition, v3DirPower, v3PosProcessFinal);
                            v3PosProcessFinal[2] -= 280.0f;

                            o->m_Interpolates.ClearContainer();

                            CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                            InsertFactor.fRateStart = 0.0f;			// Start
                            InsertFactor.fRateEnd = 0.4f;			// 01 Ready
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(110.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);		// 1#

                            InsertFactor.fRateStart = 0.4f;			// 01 Ready
                            InsertFactor.fRateEnd = 1.01f;			// 02 First Final
                            Vector(110.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(60.0f, 0.0f, -300.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = 0.33f;
                            VectorCopy(o->Position, InsertFactor.v3Start);
                            VectorCopy(v3PosProcess01, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);		// 2#

                            InsertFactor.fRateStart = 0.33f;
                            InsertFactor.fRateEnd = 1.01f;
                            VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                            VectorCopy(v3PosProcessFinal, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);

                            CInterpolateContainer::INTERPOLATE_FACTOR_F InsertFactorF;
                            InsertFactorF.fRateStart = 0.0f;
                            InsertFactorF.fRateEnd = 0.15f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);		// 2#

                            InsertFactorF.fRateStart = 0.15f;
                            InsertFactorF.fRateEnd = 0.75f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);		// 2#

                            InsertFactorF.fRateStart = 0.75f;
                            InsertFactorF.fRateEnd = 1.01f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 0.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);

                            o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                            o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                            o->m_Interpolates.GetAlphaCurrent(o->Alpha, 0.0f);
                        }
                    }	// MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_
                    break;
                    case MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_:		//
                    {
                        if (o->SubType == 1)
                        {
                            const int	TOTAL_LIFETIME = 10;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->ChromeEnable = true;
                            //o->Scale		= 0.8f;

                            o->m_Interpolates.ClearContainer();

                            CInterpolateContainer::INTERPOLATE_FACTOR_F InsertFactorF;
                            InsertFactorF.fRateStart = 0.0f;
                            InsertFactorF.fRateEnd = 1.01f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 0.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);
                        }
                    }	// MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_
                    break;
                    case MODEL_EMPIREGUARDIANBOSS_FRAMESTRIKE:
                    {
                        if (o->SubType == 1)
                        {
                            const int	TOTAL_LIFETIME = 36;
                            vec3_t		v3PosProcess01,
                                v3DirModify,
                                v3PosModify,
                                v3PosTargetModify;

                            o->ExtState = TOTAL_LIFETIME;
                            o->LifeTime = TOTAL_LIFETIME;
                            o->Gravity = 0.0f;
                            o->HiddenMesh = 1;
                            o->Distance = 0.0f;
                            o->Alpha = 1.0f;
                            o->ChromeEnable = false;
                            o->Scale = 1.0f;
                            o->Visible = false;
                            o->Velocity = 0.4f;

                            BMD* b = &Models[o->Type];
                            //b->Velocity = 10.f;

                            Vector(o->Angle[0], o->Angle[1], o->Angle[2], o->HeadAngle);
                            VectorSubtract(o->Light, o->Position, o->Direction);

                            o->Distance = sqrt(o->Direction[0] * o->Direction[0] +
                                o->Direction[1] * o->Direction[1] +
                                o->Direction[2] * o->Direction[2]);

                            VectorDivFSelf(o->Direction, o->Distance);

                            VectorCopy(o->Owner->Position, v3PosModify);
                            v3PosModify[2] = o->Light[2];
                            VectorCopy(o->Light, v3PosTargetModify);

                            v3PosModify[2] = v3PosModify[2] + 100.0f;
                            v3PosTargetModify[2] = v3PosTargetModify[2] + 100.0f;
                            VectorDistNormalize(v3PosTargetModify, v3PosModify, v3DirModify);

                            //vc = va + scale*vb
                            VectorMA(v3PosTargetModify, 200.0f, v3DirModify, v3PosProcess01);

                            VectorCopy(v3PosProcess01, o->StartPosition);

                            o->m_Interpolates.ClearContainer();

                            CInterpolateContainer::INTERPOLATE_FACTOR	InsertFactor;
                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = 0.28f;
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);		// 1#

                            InsertFactor.fRateStart = 0.28f;
                            InsertFactor.fRateEnd = 0.36f;
                            Vector(0.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(-90.0f, 0.0f, 0.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);		// 2#

                            InsertFactor.fRateStart = 0.36f;
                            InsertFactor.fRateEnd = 1.01f;
                            Vector(-90.0f, 0.0f, 0.0f, InsertFactor.v3Start);
                            Vector(-90.0f, 0.0f, 880.0f, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesAngle.push_back(InsertFactor);

                            InsertFactor.fRateStart = 0.0f;
                            InsertFactor.fRateEnd = 1.01f;
                            VectorCopy(v3PosProcess01, InsertFactor.v3Start);
                            VectorCopy(v3PosProcess01, InsertFactor.v3End);
                            o->m_Interpolates.m_vecInterpolatesPos.push_back(InsertFactor);		// 2#

                            CInterpolateContainer::INTERPOLATE_FACTOR_F	InsertFactorF;
                            InsertFactorF.fRateStart = 0.0f;
                            InsertFactorF.fRateEnd = 1.01f;
                            InsertFactorF.fStart = o->Scale * 1.0f;
                            InsertFactorF.fEnd = o->Scale * 1.0f;
                            o->m_Interpolates.m_vecInterpolatesScale.push_back(InsertFactorF);		// 2#

                            InsertFactorF.fRateStart = 0.0f;
                            InsertFactorF.fRateEnd = 0.15f;
                            InsertFactorF.fStart = 0.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);		// 2#

                            InsertFactorF.fRateStart = 0.15f;
                            InsertFactorF.fRateEnd = 0.75f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 1.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);		// 2#

                            InsertFactorF.fRateStart = 0.75f;
                            InsertFactorF.fRateEnd = 1.01f;
                            InsertFactorF.fStart = 1.0f;
                            InsertFactorF.fEnd = 0.0f;
                            o->m_Interpolates.m_vecInterpolatesAlpha.push_back(InsertFactorF);		// 2#

                            o->m_Interpolates.GetAngleCurrent(o->Angle, 0.0f);
                            o->m_Interpolates.GetPosCurrent(o->Position, 0.0f);
                            o->m_Interpolates.GetAlphaCurrent(o->Alpha, 0.0f);
                            o->m_Interpolates.GetScaleCurrent(o->Scale, 0.0f);
                        }
                    }
                    }
                }
            }
            break;
            case MODEL_EMPIREGUARDIAN_BLOW_OF_DESTRUCTION:
            {
                if (o->SubType == 0)
                {
                    o->LifeTime = 40;

                    vec3_t vPos, vPos2;
                    float Matrix[3][4];
                    Vector(-20.f, -100.f, 0.f, vPos);
                    AngleMatrix(o->Owner->Angle, Matrix);
                    VectorRotate(vPos, Matrix, vPos2);
                    VectorAdd(vPos2, o->Position, o->Position);
                    VectorCopy(o->Light, o->StartPosition);
                    Vector(1.2f, 1.2f, 1.2f, o->Light);

                    CreateEffect(MODEL_EMPIREGUARDIAN_BLOW_OF_DESTRUCTION, o->StartPosition, o->Angle, o->Light, 1, o->Owner, -1, 0, 0, 0, o->Scale);
                }
                else if (o->SubType == 1)
                {
                    o->LifeTime = 40;
                    Vector(1.2f, 1.2f, 1.2f, o->Light);
                    o->Position[2] = 150.f;
                    o->Scale = o->Scale * 2.f;
                }
            }
            break;
#ifdef PBG_ADD_CHARACTERSLOT
            case MODEL_SLOT_LOCK:
            {
                o->Scale *= 2.0f;
                o->Position[2] = 300.0f;
                float temptime = sinf(WorldTime * 0.0005f);
                Vector(0.0f, 0.0f, o->Angle[2] + temptime * 10, o->Angle);
                o->LifeTime = 1000;
            }
            break;
#endif //PBG_ADD_CHARACTERSLOT
            case MODEL_EFFECT_UMBRELLA_GOLD:
            {
                o->LifeTime = Random::Rand() % 10 + 50;
                o->Scale = 2.0f + (Random::Rand() % 10 - 5) * 0.2f;

                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Angle[1] = (float)(Random::Rand() % 360);
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                o->Gravity = (float)(Random::Rand() % 10 + 10);
                vec3_t p;
                Vector((float)(Random::Rand() % 10 - 5) * 0.1f, (float)(Random::Rand() % 60 - 30) * 0.1f, 0.0f, p);
                VectorScale(p, 1.2f, p);
                VectorRotate(p, Matrix, o->Direction);

                o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]) + 100.f;
            }break;
            case BITMAP_WATERFALL_4:
            {
                o->LifeTime = 80;
                o->Scale = (Random::Rand() % 20 * 0.01f) + 0.1f;
                o->Angle[0] = (float)(Random::Rand() % 360);
                o->Distance = Random::Rand() % 10 + 5.0f;
                o->Timer = (float)(Random::Rand() % 360);
            }
            break;
            case MODEL_WOLF_HEAD_EFFECT:
            {
                BMD* b = &Models[o->Owner->Type];
                b->TransformByObjectBone(p1, o->Owner, 27);
                VectorCopy(p1, o->Position);
                if (o->SubType == 0)
                {
                    o->Scale = 1.0f;
                    o->LifeTime = 10.0f / Models[o->Owner->Type].Actions[PLAYER_SKILL_THRUST].PlaySpeed;
                }
                else if (o->SubType == 1)
                {
                    o->Velocity = 0.1f;
                    o->Scale = 1.2f + Random::Rand() % 5 * 0.1f;
                    o->Direction[1] = -50.f;
                    o->LifeTime = 2 + Random::Rand() % 2;
                }
                else if (o->SubType == 2)
                {
                    o->Velocity = 0.1f;
                    o->Scale = 0.8f + Random::Rand() % 3 * 0.1f;
                    o->Direction[1] = -40.f;
                    o->LifeTime = 3 + Random::Rand() % 3;
                    o->Angle[2] += (Random::Rand() % 10 - 5.0f);
                }
            }
            break;
            case BITMAP_SBUMB:
            {
                o->LifeTime = 20;
                o->Scale = Scale;
                BMD* b = &Models[o->Owner->Type];
                b->TransformByObjectBone(p1, o->Owner, 27);
                o->Position[2] = p1[2];
            }
            break;
            case MODEL_DOWN_ATTACK_DUMMY_L:
            case MODEL_DOWN_ATTACK_DUMMY_R:
            {
                VectorCopy(Position, o->Position);
                o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_STAMP].PlaySpeed * 2.0f;
                o->LifeTime = 100;
                Models[MODEL_DOWN_ATTACK_DUMMY_L].Actions[0].PlaySpeed = Models[o->Owner->Type].Actions[PLAYER_SKILL_STAMP].PlaySpeed;
                Models[MODEL_DOWN_ATTACK_DUMMY_R].Actions[0].PlaySpeed = Models[o->Owner->Type].Actions[PLAYER_SKILL_STAMP].PlaySpeed;
            }
            break;
            case MODEL_SHOCKWAVE01:
            {
                if (o->Owner == NULL)
                {
                    o->Live = false;
                    break;
                }

                o->Scale = Scale;
                VectorCopy(Light, o->Light);
                if (o->SubType == 1)
                {
                    o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_DRAGONLORE].PlaySpeed;
                    o->LifeTime = 5.0f / o->Velocity;
                }
                else if (o->SubType == 2)
                {
                    o->Velocity = 0.3f;
                    o->LifeTime = 5.0f / o->Velocity;
                }
                else if (o->SubType == 3)
                {
                    o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_DARKSIDE_READY].PlaySpeed * 2.0f;
                    o->LifeTime = 5.0f / o->Velocity;
                    o->Scale = Scale;
                    vec3_t vPos, vDir;
                    VectorCopy(o->Position, vPos);
                    VectorCopy(o->Owner->StartPosition, vDir);
                    vPos[2] = RequestTerrainHeight(vPos[0], vPos[1]);
                    vDir[2] = RequestTerrainHeight(vDir[0], vDir[1]);
                    VectorSubtract(vPos, vDir, vDir);
                    VectorNormalize(vDir);
                    VectorScale(vDir, 30, vDir);
                    VectorCopy(vDir, o->StartPosition);
                    vec3_t Transpos;
                    VectorScale(vDir, 5.0f, vDir);
                    VectorCopy(vDir, Transpos);
                    VectorAdd(o->Position, Transpos, o->Position);
                }
                else if (o->SubType == 4)
                {
                    o->Velocity = 0.6f;
                    o->LifeTime = 12.0f;
                    o->Scale = Scale;
                    vec3_t vPos, vDir;
                    VectorCopy(o->Position, vPos);
                    VectorCopy(o->Owner->StartPosition, vDir);
                    vPos[2] = RequestTerrainHeight(vPos[0], vPos[1]);
                    vDir[2] = RequestTerrainHeight(vDir[0], vDir[1]);
                    VectorSubtract(vPos, vDir, vDir);
                    VectorNormalize(vDir);
                    VectorScale(vDir, 30, vDir);
                    VectorCopy(vDir, o->StartPosition);
                    vec3_t Transpos;
                    VectorNormalize(vDir);
                    VectorScale(vDir, 150.0f, vDir);
                    VectorCopy(vDir, Transpos);
                    VectorAdd(o->Position, Transpos, o->Position);
                }
                else
                {
                    o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_GIANTSWING].PlaySpeed * 2.0f;
                    o->LifeTime = 5.0f / o->Velocity;

                    vec3_t vPos, vDir;
                    VectorCopy(o->Position, vPos);
                    VectorCopy(o->Owner->Position, vDir);
                    vPos[2] = RequestTerrainHeight(vPos[0], vPos[1]);
                    vDir[2] = RequestTerrainHeight(vDir[0], vDir[1]);
                    VectorSubtract(vPos, vDir, vDir);
                    VectorNormalize(vDir);
                    VectorScale(vDir, 30, vDir);
                    VectorCopy(vDir, o->StartPosition);
                }
            }
            break;
            case MODEL_SHOCKWAVE02:
            {
                o->Scale = Scale;
                VectorCopy(Light, o->Light);
                o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_GIANTSWING].PlaySpeed * 2.0f;
                o->LifeTime = 14.0f / o->Velocity;

                vec3_t vPos, vDir;
                VectorCopy(o->Position, vPos);
                VectorCopy(o->Owner->Position, vDir);
                vPos[2] = RequestTerrainHeight(vPos[0], vPos[1]);
                vDir[2] = RequestTerrainHeight(vDir[0], vDir[1]);
                VectorSubtract(vPos, vDir, vDir);
                VectorNormalize(vDir);
                VectorScale(vDir, 25, vDir);
                VectorCopy(vDir, o->StartPosition);
            }
            break;
            case BITMAP_DAMAGE1:
            {
                o->LifeTime = 20;
                o->Scale = Scale;
                BMD* b = &Models[o->Owner->Type];
                b->TransformByObjectBone(p1, o->Owner, 27);
                o->Position[2] = p1[2];
            }
            break;
            case MODEL_SHOCKWAVE_SPIN01:
            {
                o->Scale = Scale;
                VectorCopy(Light, o->Light);
                o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_GIANTSWING].PlaySpeed;
                o->LifeTime = 8.0f / o->Velocity;
                if (o->SubType == 0)
                {
                    o->Velocity *= 2.0f;
                }
                else if (o->SubType == 1)
                {
                    o->Velocity *= 3.0f;
                }
            }
            break;
            case BITMAP_LIGHT_RED:
            {
                o->LifeTime = 9999;
                o->Velocity = 0.0f;
                o->Scale = 1.5f;
                Vector(1.0f, 1.0f, 1.0f, o->Light);
                VectorCopy(Position, o->Position);
                if (o->SubType == 1)
                {
                    o->LifeTime = 50;
                }
                else if (o->SubType == 3 || o->SubType == 4)
                {
                    o->Scale = Scale;
                    o->LifeTime = 100;
                    if (o->SubType == 4)
                    {
                        o->LifeTime = 50;
                    }
                    vec3_t Light;
                    float Luminosity = (float)(Random::Rand() % 5) * 0.01f;
                    Vector(Luminosity + 1.0f, Luminosity + 0.2f, Luminosity + 0.2f, Light);
                    int range = 2;
                    if (o->SubType == 4)
                    {
                        range = 4;
                    }
                    AddTerrainLight(o->Position[0], o->Position[1], Light, range, PrimaryTerrainLight);
                }
            }
            break;
            case MODEL_WOLF_HEAD_EFFECT2:
            {
                BMD* b = &Models[o->Owner->Type];
                b->TransformByObjectBone(p1, o->Owner, 27);
                VectorCopy(p1, o->Position);

                if (o->SubType == 3 || o->SubType == 5)
                {
                    b->TransformByObjectBone(p1, o->Owner, 5);
                    VectorCopy(p1, o->Position);
                    o->Scale = 1.0f;
                    if (o->SubType == 5)
                    {
                        o->Scale = 1.5f;
                    }
                    o->LifeTime = 4.0f / Models[o->Owner->Type].Actions[PLAYER_SKILL_GIANTSWING].PlaySpeed;
                }
                else if (o->SubType == 4)
                {
                    o->Velocity = 0.1f;
                    o->Scale = 0.7f + Random::Rand() % 3 * 0.1f;
                    o->Direction[1] = -40.0f;
                    o->LifeTime = 5 + Random::Rand() % 2;
                }
                else if (o->SubType == 6)
                {
                    o->Velocity = 0.1f;
                    o->Scale = 1.2f + Random::Rand() % 5 * 0.1f;
                    o->Direction[1] = -50.f;
                    o->LifeTime = 2 + Random::Rand() % 2;
                }
                Vector(0.4f, 0.4f, 0.6f, o->Light);
            }
            break;
            case MODEL_DRAGON_KICK_DUMMY:
            {
                VectorCopy(Position, o->Position);
                // ani keyframe 10 : 19
                o->LifeTime = 200;
                Models[MODEL_DRAGON_KICK_DUMMY].Actions[0].PlaySpeed = Models[o->Owner->Type].Actions[PLAYER_SKILL_DRAGONKICK].PlaySpeed;
                o->Velocity = Models[MODEL_DRAGON_KICK_DUMMY].Actions[0].PlaySpeed * 2.0f;
                VectorCopy(Light, o->Light);
            }
            break;
            case BITMAP_LAVA:
            {
                o->LifeTime = 999;
                VectorCopy(o->Owner->Position, o->StartPosition);
                o->Scale = Scale;
                o->Velocity = Models[o->Owner->Type].Actions[PLAYER_SKILL_DRAGONLORE].PlaySpeed;
            }
            break;
            case MODEL_DRAGON_LOWER_DUMMY:
            {
                VectorCopy(Light, o->Light);
                o->Scale = Scale;
                o->Velocity = 0.3f;
                o->LifeTime = 300;
                o->Alpha = 1.0f;
                vec3_t vPos;
                VectorCopy(o->Position, vPos);
                vPos[2] = RequestTerrainHeight(vPos[0], vPos[1]);
                o->Position[2] = vPos[2] + 10.0f;
                o->Angle[2] = 45.0f + Random::Rand() % 180;
                Models[o->Type].Actions[o->CurrentAction].PlaySpeed = 0.03f;
                o->m_iAnimation = 0;
            }
            break;
            case MODEL_VOLCANO_OF_MONK:
            {
                if (o->SubType == 1)
                {
                    o->Scale = Scale;
                    VectorCopy(Light, o->Light);
                    VectorCopy(Position, o->Position);
                    o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
                    Models[o->Type].Actions[0].PlaySpeed = 0.1f;
                    o->LifeTime = 100;
                    o->Velocity = 0.6f;
                    vec3_t vLight;
                    Vector(1.0f, 1.0f, 1.0f, vLight);
                    for (int cnt = 0; cnt < 4; ++cnt)
                    {
                        CreateEffect(MODEL_VOLCANO_STONE, o->Position, o->Angle, vLight, o->SubType, o, -1, 0, 0, 0, 1.0f);
                    }
                    CreateEffect(BITMAP_LIGHT_RED, o->Position, o->Angle, vLight, 3, o, -1, 0, 0, 0, 3.0f);
                }
                else if (o->SubType == 2 || o->SubType == 3)
                {
                    o->LifeTime = 20 + Random::Rand() % 10;
                    if (o->SubType == 3)
                    {
                        o->LifeTime = 30 + Random::Rand() % 20;
                    }
                    VectorCopy(Light, o->Light);
                    VectorCopy(Position, o->Position);
                }
            }
            break;
            case MODEL_VOLCANO_STONE:
            {
                o->Scale = Scale + (float)(Random::Rand() % 20 + 5) * 0.06f;
                VectorCopy(Light, o->Light);
                VectorCopy(Position, o->Position);
                Vector(0.0f, 0.0f, 0.0f, o->Direction);
                o->LifeTime = Random::Rand() % 10 + 30;
                o->Gravity = (float)(Random::Rand() % 2 + 2);
                o->Angle[2] = (float)(Random::Rand() % 360);
                AngleMatrix(o->Angle, Matrix);
                Vector(0.f, (float)(Random::Rand() % 128 + 64) * 0.1f, 0.f, p1);
                VectorRotate(p1, Matrix, o->HeadAngle);
                o->HeadAngle[2] += 25.0f;
            }
            break;
            }
            return;
        }
    }
}

void MoveParticle(OBJECT* o, int Turn)
{
    if (Turn)
    {
        float Matrix[3][4];
        vec3_t Angle;
        vec3_t Position;
        VectorCopy(o->Angle, Angle);
        AngleMatrix(Angle, Matrix);
        VectorRotate(o->Direction, Matrix, Position);
        VectorAddScaled(o->Position, Position, o->Position, FPS_ANIMATION_FACTOR);
    }
    else
    {
        VectorAddScaled(o->Position, o->Direction, o->Position, FPS_ANIMATION_FACTOR);
    }
}

void MoveParticle(OBJECT* o, vec3_t angle)
{
    float Matrix[3][4];
    vec3_t Angle;
    vec3_t Position;
    VectorCopy(angle, Angle);
    AngleMatrix(Angle, Matrix);
    VectorRotate(o->Direction, Matrix, Position);
    VectorAddScaled(o->Position, Position, o->Position, FPS_ANIMATION_FACTOR);
}

bool MoveJump(OBJECT* o)
{
    o->Position[2] += (o->Gravity) * FPS_ANIMATION_FACTOR;
    o->Gravity -= (1.f) * FPS_ANIMATION_FACTOR;
    float Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
    if (o->Position[2] < Height)
    {
        o->Position[2] = Height;
        o->Gravity = -o->Gravity * 0.4f;
        o->Direction[1] = o->Direction[1] * 0.4f;
        return true;
    }
    return false;
}

void CreateBomb(vec3_t p, bool Exp, int SubType)
{
    vec3_t Position, Light;
    VectorCopy(p, Position);
    Position[2] += 80.f;
    vec3_t Angle;

    Vector(1.f, 1.f, 1.f, Light);

    if (SubType != 5)
    {
        for (int j = 0; j < 20; j++)
        {
            Vector((float)(Random::Rand() % 60 + 60 + 90), 0.f, (float)(Random::Rand() % 30), Angle);
            if (SubType == 2)
            {
                Vector(0.7f, 0.7f, 1.f, Light);
                CreateParticle(BITMAP_SPARK, Position, Angle, Light, 8);
            }
            else if (SubType == 3)
            {
                Vector(1.0f, 0.7f, 0.4f, Light);
                CreateParticle(BITMAP_SPARK, Position, Angle, Light, 8);
            }
            else if (SubType == 4)
            {
                if (j == 5) break;
                Vector(1.0f, 0.5f, 0.3f, Light);
                CreateParticle(BITMAP_SPARK, Position, Angle, Light, 8);
            }
            else if (SubType == 6)
            {
                Vector(0.3f, 0.3f, 0.3f, Light);
                CreateParticle(BITMAP_SPARK, Position, Angle, Light, 10);
            }
            else
            {
                CreateParticle(BITMAP_SPARK, Position, Angle, Light, 2);
            }
        }
    }

    Vector(0.7f, 0.7f, 0.7f, Light);

    if (Exp)
    {
        if (SubType == 2 || SubType == 5 || SubType == 6)
        {
            Vector(0.3f, 0.6, 1.f, Light);
            if (SubType == 6)
            {
                Vector(0.3f, 0.3f, 0.3f, Light);
            }
            CreateParticle(BITMAP_EXPLOTION_MONO, Position, Angle, Light);
        }
        else if (SubType == 3)
        {
            Vector(1.0f, 0.6, 0.3f, Light);
            CreateParticle(BITMAP_EXPLOTION_MONO, Position, Angle, Light);
        }
        else if (SubType == 4)
        {
            Vector(1.0f, 0.4, 0.2f, Light);
            CreateParticle(BITMAP_EXPLOTION_MONO, Position, Angle, Light, 0, 0.5f);
            Vector(1.0f, 0.6, 0.2f, Light);
            CreateParticle(BITMAP_EXPLOTION_MONO, Position, Angle, Light, 0, 0.3f);
        }
        else
        {
            CreateParticle(BITMAP_EXPLOTION, Position, Angle, Light);
        }
    }
}

void CreateBomb2(vec3_t p, bool Exp, int SubType, float Scale)
{
    vec3_t Position, Light;
    VectorCopy(p, Position);
    Position[2] += 30.f;
    vec3_t Angle;
    Vector(1.f, 1.f, 1.f, Light);
    for (int j = 0; j < 20; j++)
    {
        Vector((float)(Random::Rand() % 60 + 60 + 90), 0.f, (float)(Random::Rand() % 30), Angle);
        CreateParticle(BITMAP_SPARK, Position, Angle, Light, 2);
    }
    Vector(1.f, 1.f, 1.f, Light);
    Vector(0.f, 0.f, 0.f, Angle);
    if (Exp)
    {
        CreateParticle(BITMAP_EXPLOTION_MONO, Position, Angle, Light, 0, 4.f + Scale);
    }
    else
    {
        CreateParticle(BITMAP_EXPLOTION + 1, Position, Angle, Light, 0, 4.f);
    }
}

void CreateBomb3(vec3_t vPos, int iSubType, float fScale)
{
    vec3_t vBombPos, vAngle, vLight;
    Vector((float)(Random::Rand() % 60 + 60 + 90), 0.f, (float)(Random::Rand() % 30), vAngle);
    Vector(1.0f, 1.0f, 1.0f, vLight);
    for (int i = 0; i < 2; ++i)
    {
        if (iSubType == 2)
        {
            if (rand_fps_check(10)) break;
            Vector(vPos[0] + Random::Rand() % 150 - 75, vPos[1] + Random::Rand() % 150 - 75,
                   vPos[2] + Random::Rand() % 130 + 30, vBombPos);
        }
        else if (iSubType == 1)
        {
            if (i == 1) break;
            else if (rand_fps_check(5)) break;
            Vector(vPos[0] + Random::Rand() % 80 - 40, vPos[1] + Random::Rand() % 80 - 40,
                   vPos[2] + Random::Rand() % 120 + 30, vBombPos);
        }
        else if (iSubType == 3)
        {
            Vector(vPos[0] + Random::Rand() % 90 - 40, vPos[1] + Random::Rand() % 90 - 40,
                   vPos[2] + Random::Rand() % 100 + 70, vBombPos);
        }
        else
        {
            if (i == 1) break;
            else if (Random::Rand() % 3 != 0)
                break;
            Vector(vPos[0] + Random::Rand() % 30 - 15, vPos[1] + Random::Rand() % 30 - 15,
                   vPos[2] + Random::Rand() % 80 + 30, vBombPos);
        }
        if (fScale != 1.0f)
            CreateParticle(BITMAP_SUMMON_SAHAMUTT_EXPLOSION, vBombPos, vAngle, vLight, 0, fScale);
        else
            CreateParticle(BITMAP_SUMMON_SAHAMUTT_EXPLOSION, vBombPos, vAngle, vLight, 0,
                           0.15f * (Random::Rand() % 10));
    }

    Vector(1.0f, 0.5f, 0.2f, vLight);
    if (fScale != 1.0f)
        CreateParticle(BITMAP_MAGIC + 1, vBombPos, vAngle, vLight, 0, 2.2f * fScale);
    else
        CreateParticle(BITMAP_MAGIC + 1, vBombPos, vAngle, vLight, 0, 1.0f);
    Vector(1.0f, 0.6f, 0.2f, vLight);

    for (int i = 0; i < 3; ++i)
    {
        if (fScale != 1.0f)
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, vBombPos, vAngle, vLight, 14, NULL, -1, 0, 0, 0,
                         2.2f * fScale);
        else
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, vBombPos, vAngle, vLight, 13);
    }
    Vector(1.0f, 1.0f, 1.0f, vLight);

    int nParCnt = 5;
    if (iSubType == 3)
    {
        nParCnt = 20;
    }

    for (int i = 0; i < nParCnt; ++i)
    {
        CreateParticle(BITMAP_SPARK, vBombPos, vAngle, vLight, 2);
    }
}

void CreateInferno(vec3_t Position, int SubType)
{
    vec3_t p, p2, Angle, Light;
    float Matrix[3][4];
    Vector(1.f, 1.f, 1.f, Light);
    for (int j = 0; j < 8; j++)
    {
        if (SubType == 2 || SubType == 3 || SubType == 5)
        {
            Vector(0.f, -240.f, 0.f, p);
        }
        else
            Vector(0.f, -220.f, 0.f, p);
        Vector(0.f, 0.f, j * 45.f, Angle);
        AngleMatrix(Angle, Matrix);
        VectorRotate(p, Matrix, p2);
        VectorAdd(Position, p2, p2);
        CreateBomb(p2, true, SubType);
        if (SubType == 1)
        {
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 0);
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 0);
        }
        else if (SubType == 2 || SubType == 3)
        {
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 10);
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 10);
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 10);
        }
        else if (SubType == 5)
        {
            Vector(0.3f, 0.6f, 1.0f, Light);
            for (int i = 0; i < 3; ++i)
                CreateEffect(MODEL_EFFECT_BROKEN_ICE0 + Random::Rand() % 3, p2, Angle, Light, 0);
        }
        else
        {
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 1);
            CreateEffect(MODEL_STONE1 + Random::Rand() % 2, p2, Angle, Light, 0);
        }
    }
}

void CheckClientArrow(OBJECT* o)
{
    if (battleCastle::IsBattleCastleStart())
    {
        DWORD att = TERRAIN_ATTRIBUTE(o->Position[0], o->Position[1]);
        if ((att & TW_NOATTACKZONE) == TW_NOATTACKZONE)
        {
            o->Velocity = 0.f;
            Vector(0.f, 0.f, 0.f, o->Direction);
            o->LifeTime *= pow(1.0f / (2.f), FPS_ANIMATION_FACTOR);
            return;
        }
    }

    if (o->Type == MODEL_DARK_SCREAM)
    {
        float range = 100.f;
        short TKey = o->PKKey;

        AttackCharacterRange(Hero->CurrentSkill, o->Position, range, Hero->Object.Weapon, TKey, o->AttackPoint[0]);
    }

    if (!o->Kind || o->SubType == 99)
    {
        if (CheckCharacterRange(o, 100.f, o->PKKey))
        {
            int Skill = CharacterAttribute->Skill[o->Skill];

            switch (Skill)
            {
            case AT_SKILL_PENETRATION:
            case AT_SKILL_PENETRATION_STR:
                if (o->SubType == 2)
                {
                    CreateJoint(BITMAP_FLARE, o->Position, o->Position, o->Angle, 6, o, 30.0f);
                }
                else
                {
                    o->Live = false;
                    CreateBomb(o->Position, true);
                }
                break;
            case AT_SKILL_ICE_ARROW:
            case AT_SKILL_ICE_ARROW_STR:
                o->Live = false;
                if (o->Type == MODEL_ARROW_BOMB || o->Type == MODEL_ARROW_HOLY)
                    CreateBomb(o->Position, true);
                break;

            default:
                o->Live = false;
                if (o->Type == MODEL_ARROW_BOMB || o->Type == MODEL_ARROW_HOLY)
                {
                    if (o->SubType == 1)
                    {
                    }
                    else
                    {
                        CreateBomb(o->Position, true);
                    }
                }
                break;
            }
        }
    }
    else
    {
        if (rand_fps_check(2))
            if (o->Owner == &Hero->Object)
            {
                float range = 100.f;
                int Skill = CharacterAttribute->Skill[o->Skill];

                if ((Skill == AT_SKILL_PENETRATION || Skill == AT_SKILL_PENETRATION_STR) && o->Type == MODEL_ARROW_BOMB)
                {
                    float dx = o->Position[0] - Hero->Object.Position[0];
                    float dy = o->Position[1] - Hero->Object.Position[1];
                    float Distance = sqrtf(dx * dx + dy * dy);
                    if (Distance > 500) {
                        return;
                    }
                }

                if ((Skill == AT_SKILL_PENETRATION
                    || Skill == AT_SKILL_PENETRATION_STR
#ifdef PJH_FIX_4_BUGFIX_7
                    || Skill == AT_SKILL_DARK_SCREAM
#endif //#ifdef PJH_FIX_4_BUGFIX_7
                    )
                    && o->AttackPoint[0] > 0)
                {
                    range = 200.f;
#ifdef PJH_FIX_4_BUGFIX_7
                    if (Skill == AT_SKILL_DARK_SCREAM)
                        range = 100.f;
#endif //#ifdef PJH_FIX_4_BUGFIX_7
                    o->AttackPoint[0]--;
                }
                else if (AttackCharacterRange(o->Skill, o->Position, range, o->Weapon, o->PKKey))
                {
                    switch (Skill)
                    {
#ifdef PJH_FIX_4_BUGFIX_7
                    case AT_SKILL_DARK_SCREAM:
                    {
                        o->AttackPoint[0] = 2;
                    }
                    break;
#endif //#ifdef PJH_FIX_4_BUGFIX_7
                    case AT_SKILL_PENETRATION:
                    case AT_SKILL_PENETRATION_STR:
                        if (o->SubType == 2)
                        {
                            if (o->Type == MODEL_ARROW_HOLY && o->LifeTime > 14)
                            {
                                o->AttackPoint[0] = 5;
                            }
                            else if (o->Type == MODEL_ARROW_BOMB)
                            {
                                o->AttackPoint[0] = 5;
                            }
                            else
                            {
                                o->AttackPoint[0] = 2;
                            }
                            CreateJoint(BITMAP_FLARE, o->Position, o->Position, o->Angle, 6, o, 30.0f);
                        }
                        else
                        {
                            o->Live = false;
                            CreateBomb(o->Position, true);
                        }
                        break;
                    case AT_SKILL_ICE_ARROW:
                    case AT_SKILL_ICE_ARROW_STR:
                        o->Live = false;
                        if (o->Type == MODEL_ARROW_BOMB || o->Type == MODEL_ARROW_HOLY)
                            CreateBomb(o->Position, true);
                        break;

                    default:
                        o->Live = false;
                        PlayBuffer(static_cast<ESound>(SOUND_ATTACK_MELEE_HIT1 + 5 + Random::Rand() % 4), o);
                        if (o->Type == MODEL_ARROW_BOMB || o->Type == MODEL_ARROW_HOLY)
                            CreateBomb(o->Position, true);
                        break;
                    }
                }
            }
    }
#ifdef USE_SELFCHECKCODE
    END_OF_FUNCTION(Pos_SelfCheck01);
Pos_SelfCheck01:
    ;
#endif
}

void MoveCharacter(CHARACTER* c, OBJECT* o);

void MoveEffect(OBJECT* o, int iIndex)
{
    vec3_t Light;
    vec3_t Angle;
    int Index;
    vec3_t p, Position;
    float Matrix[3][4];
    float Height;
    float Luminosity = (float)(Random::Rand() % 4 + 7) * 0.1f;
    if (o->LifeTime < 5)
    {
        Luminosity -= (5 - o->LifeTime) * 0.2f;
        if (Luminosity < 0.f) Luminosity = 0.f;
    }
    Vector(1.f, 1.f, 1.f, Light);

    // Registry-driven per-frame behaviour. A false return mirrors the legacy
    // cases that `return` out of the switch, skipping the shared tail below.
    if (const Render::Effects::EffectDescriptor* desc = Render::Effects::Lookup(o->Type); desc && desc->move)
    {
        if (!desc->move(o, iIndex, Luminosity))
            return;
    }
    else
    switch (o->Type)
    {
    case BATTLE_CASTLE_WALL1:
    case BATTLE_CASTLE_WALL2:
    case BATTLE_CASTLE_WALL3:
    case BATTLE_CASTLE_WALL4:
        // Its two-tick life can end before a draw stamps it, so the debris bursts once, here.
        if (o->SubType != 0 && o->HiddenMesh != -2)
        {
            o->HiddenMesh = -2;
            SkinObjectMeshes(o, &Models[o->Type], false);
            Models[o->Type].SpawnMeshEffects(0, MODEL_WALL_PART1);
        }
        break;

    case 9:
        VectorScale(o->Direction, o->Velocity, Position);
        VectorAddScaled(Position, o->Position, o->Position, FPS_ANIMATION_FACTOR);
        //        o->Position[2] -= o->Velocity;
        o->Velocity += (3.f) * FPS_ANIMATION_FACTOR;
        o->Angle[0] += (5.f * o->Velocity) * FPS_ANIMATION_FACTOR; // Random::Rand()%20+20.f) ;

        if (o->Position[2] < 350.f && o->PKKey == 0)
        {
            o->PKKey = 1;
            int PositionX = (int)(o->Position[0] / TERRAIN_SCALE);
            int PositionY = (int)(o->Position[1] / TERRAIN_SCALE);
            AddWaterWave(PositionX, PositionY, 2, -1000);
        }
        break;






    case MODEL_SUMMONER_EQUIP_HEAD_LAGUL:
    {
        OBJECT* pObject = o->Owner;
        o->Position[0] = pObject->Position[0] + cosf(WorldTime * 0.003f + o->Skill * 0.024f) * 60.0f;
        o->Position[1] = pObject->Position[1] + sinf(WorldTime * 0.003f + o->Skill * 0.024f) * 60.0f;
        o->Position[2] = pObject->Position[2] + (sinf(WorldTime * 0.0010f + o->Skill * 0.024f) + 2.0f) * 80.0f - 60.0f;

        if (o->StartPosition[0] != o->Position[0] - pObject->Position[0])
        {
            float fAngle = CreateAngle(o->StartPosition[0], o->StartPosition[1],
                o->Position[0] - pObject->Position[0], o->Position[1] - pObject->Position[1]);
            o->Angle[2] = fAngle + 0;
        }
        VectorSubtract(o->Position, pObject->Position, o->StartPosition);

        if (o->Kind == 1)
        {
            if (o->Alpha > 0.0f)
                o->Alpha -= 0.03f * FPS_ANIMATION_FACTOR;
            else DeleteEffect(MODEL_SUMMONER_EQUIP_HEAD_LAGUL, o->Owner);
        }
        else
        {
            if (Hero->SafeZone || sinf(WorldTime * 0.0004f + o->Skill * 0.024f) < 0.3f)
                o->Kind = 1;
            if (o->Alpha < 1.0f)
                o->Alpha += 0.03f * FPS_ANIMATION_FACTOR;
        }

        if (pObject->Live)
            o->LifeTime = 100.f;

        if (rand_fps_check(1))
        {
            vec3_t vLight;
            Vector(o->Alpha * 0.7f, o->Alpha * 0.3f, o->Alpha * 1.f, vLight);
            CreateParticle(BITMAP_CLUD64, o->Position, o->Angle, vLight, 10, 1.f, pObject);
        }
    }
        // The original code went on with the move code of the summoner casting effects; it is a
        // handler of the registry now.
        Render::Effects::Behaviors::Move_MODEL_SUMMONER_CASTING_EFFECT1(o, iIndex, Luminosity);
        break;

    case BITMAP_FIRE + 1:
        Vector(1.f, 1.f, 1.f, Light);
        CreateParticleFpsChecked(BITMAP_FIRE + 1, o->Position, o->Angle, Light, 1);
        Vector(Luminosity * 1.f, Luminosity * 0.6f, Luminosity * 0.3f, Light);
        AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
        break;
    case BITMAP_MAGIC + 1:
    case BITMAP_MAGIC + 2:
        if (o->SubType >= 1
            && o->SubType != 4 && o->SubType != 6 && o->SubType != 7 && o->SubType != 8 && o->SubType != 9 && o->SubType != 10
            && o->SubType != 11 && o->SubType != 12
            && o->SubType != 13
            )
        {
            CreateHealing(o);
        }
#ifdef ENABLE_POTION_EFFECT
        if (o->SubType == 15)
        {
            if ((int)o->LifeTime == 1)
            {
                if ((o->State & STATE_HP_RECOVERY) == STATE_HP_RECOVERY)
                    o->State ^= STATE_HP_RECOVERY;
            }
        }
#endif	// ENABLE_POTION_EFFECT
        else if (o->SubType == 6)
        {
            BMD* b = &Models[o->Owner->Type];
            Vector(1, 1, 1, Light);
            VectorCopy(o->StartPosition, b->BodyOrigin);
            o->BlendMeshLight = (float)(Random::Rand() % 10) * 0.1f;

            int iIndex;
            for (int i = 0; i < o->LifeTime; i++)
            {
                iIndex = Random::Rand() % b->NumBones;
                if (b->Bones[iIndex].Dummy)
                    continue;
                Vector(-50 + Random::Rand() % 100, -10 + Random::Rand() % 20, -10 + Random::Rand() % 20, p);
                b->TransformPosition(o->Owner->BoneTransform[iIndex], p, Position, true);
                CreateParticleFpsChecked(BITMAP_LIGHT, Position, o->Owner->Angle, Light, 8);
            }
            o->Owner->Alpha = o->LifeTime / 80.0f;
        }
        else if (o->SubType == 9)
        {
            o->Scale += (0.3f) * FPS_ANIMATION_FACTOR;
            o->Light[0] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
        }
        break;


    case BITMAP_SHINY + 6:
        switch (o->SubType)
        {
        case 0:
            Position[0] = o->Position[0] + (float)(Random::Rand() % 500 - 250);
            Position[1] = o->Position[1] + (float)(Random::Rand() % 500 - 250);
            Position[2] = o->Position[2] - (float)(Random::Rand() % 100) + 150.0f;
            CreateParticleFpsChecked(o->Type, Position, o->Angle, o->Light, 0, o->Scale);
            break;
        case 1:
        case 2:
            if (o->Owner == NULL || o->Owner->Live == false)
                o->Live = false;
            else
            {
                o->LifeTime = 100;
                BMD* pModel = &Models[o->Owner->Type];
                int iBone = Random::Rand() % pModel->NumBones;
                vec3_t vRelativePos, vWorldPos;
                Vector(0.f, 0.f, 100.f, vRelativePos);
                if (!pModel->Bones[iBone].Dummy)
                {
                    pModel->TransformPosition(o->Owner->BoneTransform[iBone], vRelativePos, vWorldPos, false);
                    VectorScale(vWorldPos, pModel->BodyScale, vWorldPos);
                    VectorAdd(vWorldPos, o->Owner->Position, vWorldPos);
                    if (rand_fps_check(2))
                    {
                        vWorldPos[2] -= 20.f;
                        CreateParticle(o->Type, vWorldPos, o->Angle, o->Light, 0, o->Scale);
                    }
                }
            }
            break;
        case 3:
        {
            vec3_t Position, P, dp;
            vec3_t vFirePosition;

            float Matrix[3][4];
            int iNumBones = Models[o->Owner->Type].NumBones;
            Models[o->Owner->Type].TransformByObjectBone(vFirePosition, o->Owner, Random::Rand() % iNumBones);
            Vector(0.f, -20.f, 0.f, P);
            AngleMatrix(o->Owner->Angle, Matrix);
            VectorRotate(P, Matrix, dp);
            VectorAdd(dp, vFirePosition, Position);
            CreateSprite(BITMAP_SHINY + 6, Position, 2.0f, o->Light, o, 0, 1);
        }
        break;
        }
        break;


    case BITMAP_SPARK + 2:
        if (o->Owner == NULL || o->Owner->Live == false)
            o->Live = false;
        else
        {
            o->LifeTime = 100;

            if (rand_fps_check(60))
                CreateParticle(o->Type, o->Position, o->Angle, o->Light, o->SubType, 0.5f, o->Owner);
        }
        break;

    case BITMAP_SPARK + 1:
    {
        vec3_t Position;
        VectorCopy(o->Position, Position);
        float Luminosity = o->LifeTime * 0.1f;
        Vector(Luminosity, Luminosity, Luminosity, Light);
        float Scale = 6.f;
        for (int j = 0; j < 18; j++)
        {
            if (rand_fps_check(1))
            {
                Position[2] += Scale * 4.f;
                if (j == 0)
                    CreateParticle(BITMAP_SPARK + 1, Position, o->Angle, Light, 1, Scale * 2.f);
                else
                    CreateParticle(BITMAP_SPARK + 1, Position, o->Angle, Light, 1, Scale);
            }
        }
        break;
    }
    case BITMAP_ENERGY:
        if (o->SubType == 0)
        {
            Luminosity = o->LifeTime * 0.2f;
            Vector(Luminosity, Luminosity, Luminosity, Light);
            CreateParticleFpsChecked(BITMAP_ENERGY, o->Position, o->Angle, Light);
            CreateParticleFpsChecked(BITMAP_SPARK + 1, o->Position, o->Angle, Light, 0, 4.f);
            Vector(Luminosity * 0.2f, Luminosity * 0.4f, Luminosity * 1.f, Light);
            AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
            CheckTargetRange(o);
        }
        break;
    case MODEL_LIGHTNING_ORB:
    {
        float fRot = (WorldTime * 0.0006f) * 360.0f;
        vec3_t vLight;

        if (o->SubType == 0)
        {
            // shiny
            Vector(0.1f, 0.7f, 1.5f, vLight);
            CreateSprite(BITMAP_SHINY + 1, o->Position, 4.0f, vLight, o, fRot);
            CreateSprite(BITMAP_SHINY + 1, o->Position, 3.0f, vLight, o, -fRot);
            // magic_ground
            Vector(0.1f, 0.1f, 1.5f, vLight);
            CreateSprite(BITMAP_MAGIC, o->Position, 1.0f, vLight, o, fRot);
            CreateSprite(BITMAP_MAGIC, o->Position, 0.5f, vLight, o, -fRot);
            // pin_light
            Vector(0.5f, 0.5f, 1.5f, vLight);
            CreateSprite(BITMAP_PIN_LIGHT, o->Position, 2.0f, vLight, o, (float)(Random::Rand() % 360));
            CreateSprite(BITMAP_PIN_LIGHT, o->Position, 2.0f, vLight, o, (float)(Random::Rand() % 360));

            Vector(0.4f, 0.4f, 1.5f, vLight);
            CreateParticleFpsChecked(BITMAP_MAGIC, o->Position, o->Angle, vLight, 0, 1.f);
            for (int i = 0; i < 3; ++i)
            {
                CreateParticleFpsChecked(BITMAP_SPARK + 1, o->Position, o->Angle, o->Light, 13, 1.0f);
            }

            CheckTargetRange(o);
        }
        else if (o->SubType == 1)
        {
            vec3_t vLight;
            Vector(1.0f, 1.0f, 1.0f, vLight);
            if (o->LifeTime >= 5)
            {
                Vector(0.1f, 0.5f, 1.5f, vLight);
                CreateSprite(BITMAP_SHINY + 5, o->Position, 3.0f, vLight, o, fRot);
                CreateSprite(BITMAP_SHINY + 5, o->Position, 2.0f, vLight, o, -fRot);
                // pin_light
                Vector(o->Light[0] * 0.3f, o->Light[1] * 0.3f, o->Light[2] * 1.0f, vLight);
                CreateSprite(BITMAP_PIN_LIGHT, o->Position, 4.0f, vLight, o, (float)(Random::Rand() % 360));
                CreateSprite(BITMAP_PIN_LIGHT, o->Position, 4.0f, vLight, o, (float)(Random::Rand() % 360));
                // thunder
                CreateSprite(BITMAP_ENERGY, o->Position, 4.0f, o->Light, o, fRot);
            }

            if (o->LifeTime >= 15)
            {
                for (int i = 0; i < 5; ++i)
                {
                    CreateParticleFpsChecked(BITMAP_SPARK + 1, o->Position, o->Angle, o->Light, 20, 1.0f);
                }
            }

            // shockwave
            if (o->LifeTime >= 14)
            {
                Vector(0.4f, 0.3f, 1.0f, vLight);
                CreateParticleFpsChecked(BITMAP_SHOCK_WAVE, o->Position, o->Angle, vLight, 0, 0.3f);
                CreateParticleFpsChecked(BITMAP_SHOCK_WAVE, o->Position, o->Angle, vLight, 0, 0.3f);
            }

            Vector(0.2f, 0.2f, 1.0f, vLight);
            for (int i = 0; i < 2; ++i)
            {
                CreateEffectFpsChecked(MODEL_FENRIR_THUNDER, o->Position, o->Angle, vLight, 3, o);
            }

            if (o->LifeTime <= 5)
            {
                for (int i = 0; i < 2; ++i)
                {
                    CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, o->Light, 40);
                }
            }

            o->Light[0] *= pow(1.0f / (1.08f), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (1.08f), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (1.08f), FPS_ANIMATION_FACTOR);
        }
    }
    break;
    // ChainLighting




    case BITMAP_LIGHTNING + 1:
        if (o->SubType == 0)
        {
            Luminosity = o->LifeTime * 0.2f;
            Vector(Luminosity * 0.2f, Luminosity * 0.5f, Luminosity * 1.f, Light);
            AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
        }
        else if (o->SubType == 1)
        {
            o->Alpha += (0.01f) * FPS_ANIMATION_FACTOR;
            if (o->Alpha >= 1.0f)
            {
                o->Alpha = 1.0f;
            }
        }
        break;
    case BITMAP_LIGHT:
        if (o->SubType == 0)
        {
            VectorAddScaled(o->Position, o->Direction, o->Position, FPS_ANIMATION_FACTOR);
            //o->Direction[2] -= .35f;
            o->Direction[2] -= .01f * FPS_ANIMATION_FACTOR;
            //VectorScale(o->Light, powf(0.9f, FPS_ANIMATION_FACTOR), o->Light);
            CreateParticleFpsChecked(BITMAP_LIGHT, o->Position, o->Angle, o->Light, 1, o->Scale);
            if (o->Direction[2] < -2.f)
            {
                o->LifeTime = 0;
                /*vec3_t Light = { 1.f, 1.f, 1.f};
                CreateParticleFpsChecked(BITMAP_EXPLOTION,o->Position,o->Angle,o->Light);*/
            }
        }
        else if (o->SubType == 1)
        {
            if (o->Owner != NULL && o->Owner->Live == true && g_isCharacterBuff(o->Owner, eBuff_Life))
                o->LifeTime = 10;
            else
                o->LifeTime = 0;

            if (g_isCharacterBuff(o->Owner, eBuff_Cloaking)) break;

            if (!rand_fps_check(1))
            {
                break;
            }

            Vector(1.f, 0.5f, 0.1f, Light);
            Vector(0.f, 0.f, 0.f, Angle);

            Index = Random::Rand() % 7;
            Luminosity = g_byUpperBoneLocation[Index];
            CreateParticle(BITMAP_LIGHT, o->Position, Angle, Light, 4, Luminosity, o->Owner);

            Luminosity = g_byUpperBoneLocation[6 - Index];
            CreateParticle(BITMAP_LIGHT, o->Position, Angle, Light, 4, Luminosity, o->Owner);
        }
        else if (o->SubType == 2)
        {
            if (o->Owner != NULL && o->Owner->Live == true && g_isCharacterBuff(o->Owner, eBuff_AddAG))
                o->LifeTime = 10;
            else
                o->LifeTime = 0;

            if (g_isCharacterBuff(o->Owner, eBuff_Cloaking)) break;

            const int priorStep = (int)o->Velocity;
            o->Velocity += FPS_ANIMATION_FACTOR;

            // Act on the frame Velocity reaches each 50th reference frame, not on every frame it stays there.
            if ((int)o->Velocity != priorStep && ((int)(o->Velocity) % 50) == 0)
            {
                if (o->Owner != NULL)
                {
                    vec3_t Position;
                    o->Angle[2] += 50.f;
                    VectorCopy(o->Owner->Position, Position);

                    o->Position[0] = o->Owner->Position[0] + sinf(o->Angle[2] * 0.1f) * 80.f;
                    o->Position[1] = o->Owner->Position[1] + cosf(o->Angle[2] * 0.1f) * 80.f;
                    o->Position[2] = o->Owner->Position[2] + 50;

                    CreateJoint(BITMAP_JOINT_HEALING, o->Position, o->Position, o->Angle, 9, o->Owner, 15.f);
                }
            }
        }
        else if (o->SubType == 3) // Ancient blur
        {
            o->Velocity += FPS_ANIMATION_FACTOR;
            if (((int)o->LifeTime % 15) == 0)
            {
                o->LifeTime = (int)o->LifeTime - 0.01;
                if (o->Owner != NULL)
                {
                    vec3_t Position;
                    o->Angle[2] += 180;
                    VectorCopy(o->Owner->Position, Position);

                    o->Position[0] = o->Owner->Position[0] + sinf(o->Angle[2] * 0.1f) * 50.f;
                    o->Position[1] = o->Owner->Position[1] + cosf(o->Angle[2] * 0.1f) * 50.f;
                    o->Position[2] = o->Owner->Position[2] + 20;

                    CreateJoint(BITMAP_JOINT_HEALING, o->Position, o->Position, o->Angle, 9, o->Owner, 10.f);
                }
            }
        }
        break;
    case MODEL_BIG_METEO1:
    case MODEL_BIG_METEO2:
    case MODEL_BIG_METEO3:
        Index = TERRAIN_INDEX_REPEAT((int)o->Position[0] / 100, (int)o->Position[1] / 100);
        if ((TerrainWall[Index] & TW_NOGROUND) != TW_NOGROUND)
        {
            Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            if (o->Position[2] < Height)
            {
                o->Position[2] = Height;
                o->Live = false;
                SetEarthQuakeAt(o->Position, (float)(Random::Rand() % 8 - 8) * 0.1f);
                for (int j = 0; j < 5; j++)
                {
                    if (rand_fps_check(1))
                    {
                        CreateEffect(MODEL_METEO1 + Random::Rand() % 2, o->Position, o->Angle, o->Light, 0);
                    }
                }
            }
        }
        VectorAddScaled(o->Position, o->Direction, o->Position, FPS_ANIMATION_FACTOR);
        o->Angle[0] += (10.f / o->Scale) * FPS_ANIMATION_FACTOR;
        CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, o->Light, 3);
        //CreateParticle(BITMAP_ENERGY,o->Position,o->Angle,Light);
        //CreateParticle(BITMAP_SPARK+1,o->Position,o->Angle,Light,0,4.f);
        return;
    case MODEL_SKILL_FURY_STRIKE + 1:
        o->BlendMeshLight = (o->LifeTime * 0.1f) / 3.f;
        if (o->LifeTime < 10)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }
        if (o->LifeTime > 15 && ((int)o->LifeTime % 3) == 0)
        {
            SetEarthQuakeAt(o->Position, (float)(Random::Rand() % 8 - 4) * 0.1f);
        }
        break;
    case MODEL_SKILL_FURY_STRIKE + 3:
        o->BlendMeshLight = (o->LifeTime * 0.1f) / 10.f;
        if (o->LifeTime < 13)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }
        break;
    case MODEL_SKILL_FURY_STRIKE + 2:
        if (o->Scale > 50)o->LifeTime = 0;
        if (o->LifeTime >= 10)
            o->BlendMeshLight = ((20 - o->LifeTime) * 0.1f);
        else
        {
            if (o->LifeTime < 5)
            {
                o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
            }
            o->BlendMeshLight = (o->LifeTime * 0.1f);

            if (o->LifeTime >= 5 && rand_fps_check(10))
            {
                vec3_t p, Position;
                vec3_t Angle;
                float Matrix[3][4];
                Vector(0.f, (float)(Random::Rand() % 150), 0.f, p);
                Vector(0.f, 0.f, (float)(Random::Rand() % 360), Angle);
                AngleMatrix(Angle, Matrix);
                VectorRotate(p, Matrix, Position);
                VectorAdd(Position, o->Position, Position);

                CreateEffect(MODEL_STONE1 + Random::Rand() % 2, Position, o->Angle, o->Light, 0);
            }
        }

        o->BlendMeshTexCoordU = -(float)(int)o->LifeTime * 0.01f;

        if (o->Owner != NULL)
            if (o->Owner->Type == MODEL_WEREWOLF_HERO)
            {
                Vector(Luminosity * 0.0f, Luminosity * 0.0f, Luminosity * 1.0f, Light);
            }
            else
                Vector(Luminosity * 1.0f, Luminosity * 0.0f, Luminosity * 0.0f, Light);
        AddTerrainLight(o->Position[0], o->Position[1], Light, 1, PrimaryTerrainLight);
        break;
    case MODEL_SKILL_FURY_STRIKE + 4:
        o->BlendMeshLight = (o->LifeTime * 0.1f) / 3.f;
        if (o->LifeTime < 10)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }
        break;
    case MODEL_SKILL_FURY_STRIKE + 6:
        o->BlendMeshLight = (o->LifeTime * 0.1f) / 10.f;
        if (o->LifeTime < 13)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }
        break;
    case MODEL_SKILL_FURY_STRIKE + 5:
        if (o->LifeTime >= 30)
            o->BlendMeshLight = ((40 - o->LifeTime) * 0.1f);
        else
        {
            if (o->LifeTime < 15)
            {
                o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
            }

            o->BlendMeshLight = (o->LifeTime * 0.1f);

            if (o->LifeTime >= 5 && rand_fps_check(15))
            {
                vec3_t p, Position;
                vec3_t Angle;
                float Matrix[3][4];
                Vector(0.f, (float)(Random::Rand() % 150), 0.f, p);
                Vector(0.f, 0.f, (float)(Random::Rand() % 360), Angle);
                AngleMatrix(Angle, Matrix);
                VectorRotate(p, Matrix, Position);
                VectorAdd(Position, o->Position, Position);

                CreateEffect(MODEL_STONE1 + Random::Rand() % 2, Position, o->Angle, o->Light, 0);
            }
        }

        o->BlendMeshTexCoordU = -(float)(int)o->LifeTime * 0.01f;

        if (o->Owner != NULL)
        {
            if (o->Owner->Type == MODEL_WEREWOLF_HERO)
            {
                Vector(Luminosity * 0.0f, Luminosity * 0.0f, Luminosity * 1.0f, Light);
            }
            else
            {
                Vector(Luminosity * 1.0f, Luminosity * 0.0f, Luminosity * 0.0f, Light);
            }
        }
        AddTerrainLight(o->Position[0], o->Position[1], Light, 1, PrimaryTerrainLight);
        break;
    case MODEL_SKILL_FURY_STRIKE + 7:
        o->BlendMeshLight = (o->LifeTime * 0.1f) / 3.f;
        if (o->LifeTime < 10)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }
        break;
    case MODEL_SKILL_FURY_STRIKE + 8:
        if (o->LifeTime >= 30)
            o->BlendMeshLight = ((40 - o->LifeTime) * 0.1f);
        else
        {
            o->BlendMeshLight = (o->LifeTime * 0.1f);
        }
        if (o->LifeTime < 15)
        {
            o->Position[2] -= (0.5f) * FPS_ANIMATION_FACTOR;
        }

        if (o->LifeTime >= 13 && rand_fps_check(5))
        {
            vec3_t Position;

            Position[0] = o->Position[0];
            Position[1] = o->Position[1];
            Position[2] = o->Position[2] + 10;
        }

        o->BlendMeshTexCoordU = -(float)(int)o->LifeTime * 0.01f;

        if (o->Owner != NULL)
        {
            if (o->Owner->Type == MODEL_WEREWOLF_HERO)
            {
                Vector(Luminosity * 0.0f, Luminosity * 0.0f, Luminosity * 1.0f, Light);
            }
            else
            {
                Vector(Luminosity * 1.0f, Luminosity * 0.0f, Luminosity * 0.0f, Light);
            }
        }

        AddTerrainLight(o->Position[0], o->Position[1], Light, 1, PrimaryTerrainLight);
        break;


    case MODEL_SNOW2:
    case MODEL_SNOW3:
    case MODEL_STONE1:
    case MODEL_STONE2:
        if (o->SubType == 5)
        {
            VectorAdd(o->Owner->Position, o->StartPosition, o->Position);
            break;
        }
        else if (o->SubType == 11)
        {
            if (o->LifeTime < 10)
            {
                o->Alpha *= pow(0.8f, FPS_ANIMATION_FACTOR);
            }
            break;
        }
        else if (o->SubType == 13 || o->SubType == 14)
        {
            o->HeadAngle[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;

            o->Position[0] += (o->HeadAngle[0]) * FPS_ANIMATION_FACTOR;
            o->Position[1] += (o->HeadAngle[1]) * FPS_ANIMATION_FACTOR;
            o->Position[2] += (o->HeadAngle[2]) * FPS_ANIMATION_FACTOR;

            Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            o->Angle[0] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            o->Angle[1] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            if (o->Position[2] + o->Direction[2] <= Height)
            {
                o->Position[2] = Height;
                o->HeadAngle[0] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[1] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[2] += (1.0f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                if (o->HeadAngle[2] < 0.5f)
                    o->HeadAngle[2] = 0;

                o->Alpha -= (0.1f) * FPS_ANIMATION_FACTOR;
            }

            // 			if (rand_fps_check(3))
            // 			{
            // 				CreateParticle(BITMAP_FIRE_CURSEDLICH, o->Position, o->Angle, o->Light, 0, 1, o);
            // 			}
            break;
        }
    case MODEL_BONE1:
    case MODEL_BONE2:
    case MODEL_BIG_STONE1:
    case MODEL_BIG_STONE2:
        if (o->SubType == 5)
        {
            if (o->Owner->Live == 0) o->Live = 0;
            VectorAddScaled(o->Owner->Position, o->StartPosition, o->Position, FPS_ANIMATION_FACTOR);
            break;
        }
        // The original code went on with the move code of MODEL_ICE_SMALL; it is a handler of
        // the registry now.
        Render::Effects::Behaviors::Move_MODEL_ICE_SMALL(o, iIndex, Luminosity);
        break;
    case MODEL_EFFECT_BROKEN_ICE0:
    case MODEL_EFFECT_BROKEN_ICE1:
    case MODEL_EFFECT_BROKEN_ICE2:
    case MODEL_EFFECT_BROKEN_ICE3:
#ifdef ASG_ADD_KARUTAN_MONSTERS
    case MODEL_CONDRA_STONE:
    case MODEL_CONDRA_STONE1:
    case MODEL_CONDRA_STONE2:
    case MODEL_CONDRA_STONE3:
    case MODEL_CONDRA_STONE4:
    case MODEL_CONDRA_STONE5:
    case MODEL_NARCONDRA_STONE:
    case MODEL_NARCONDRA_STONE1:
    case MODEL_NARCONDRA_STONE2:
    case MODEL_NARCONDRA_STONE3:
#endif	// ASG_ADD_KARUTAN_MONSTERS
        if (o->SubType == 0)
        {
            o->HeadAngle[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;

            o->Position[0] += (o->HeadAngle[0]) * FPS_ANIMATION_FACTOR;
            o->Position[1] += (o->HeadAngle[1]) * FPS_ANIMATION_FACTOR;
            o->Position[2] += (o->HeadAngle[2]) * FPS_ANIMATION_FACTOR;

            Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            o->Angle[0] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            o->Angle[1] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            if (o->Position[2] + o->Direction[2] <= Height)
            {
                o->Position[2] = Height;
                o->HeadAngle[0] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[1] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[2] += (1.0f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                if (o->HeadAngle[2] < 0.5f)
                    o->HeadAngle[2] = 0;

                o->Alpha -= (0.1f) * FPS_ANIMATION_FACTOR;
            }

            if (rand_fps_check(30))
                CreateParticle(BITMAP_SMOKE, o->Position, o->Angle, o->Light);
        }
        else if (o->SubType == 1)
        {
            bool bSuccess = false;

            VectorCopy(o->HeadAngle, o->Angle);

            float fHeight = RequestTerrainHeight(o->Position[0], o->Position[1]);
            if (o->Position[2] < fHeight)
            {
                bSuccess = true;
            }

            if (bSuccess)
            {
                o->Position[2] = fHeight;
                Vector(0.f, 0.f, 0.f, o->Direction);
                vec3_t vPos;
                Vector(o->Position[0], o->Position[1], o->Position[2] + 80.f, vPos);

                Vector(0.0f, 0.6f, 1.f, Light);
                Vector(0.f, 0.f, 0.f, Angle);

                CreateEffectFpsChecked(MODEL_SKILL_INFERNO, o->Position, Angle, Light, 2, o);

                Vector(0.2f, 0.4f, 0.8f, Light);
                for (int i = 0; i < 8; ++i)
                {
                    vPos[0] = o->Position[0] + (Random::Rand() % 80 - 40);
                    vPos[1] = o->Position[1] + (Random::Rand() % 80 - 40);
                    vPos[2] = o->Position[2] + 50;

                    CreateParticleFpsChecked(BITMAP_SMOKE, vPos, o->Angle, Light, 11,
                                             (float)(Random::Rand() % 40 + 60) * 0.025f);
                }

                for (int j = 0; j < 6; j++)
                {
                    CreateEffectFpsChecked(MODEL_EFFECT_BROKEN_ICE0 + Random::Rand() % 3, vPos, o->Angle, Light, 0);
                }

                Vector(0.6f, 0.6f, 1.f, Light);
                vPos[0] = o->Position[0];
                vPos[1] = o->Position[1];
                vPos[2] = o->Position[2] + 100;
                CreateParticleFpsChecked(BITMAP_EXPLOTION_MONO, vPos, o->Angle, Light, 1, 1.5f);

                o->Live = false;
            }
        }
        else if (o->SubType == 2)
        {
            o->Position[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;

            float fHeight = RequestTerrainHeight(o->Position[0], o->Position[1]);
            if (o->Position[2] < fHeight)
            {
                CreateEffectFpsChecked(o->Type, o->Position, o->Angle, o->Light, 0);

                o->Live = false;
            }
        }
        break;
    case MODEL_SNOW1:
        o->Direction[2] -= (2.5f) * FPS_ANIMATION_FACTOR;
        CheckTargetRange(o);
        break;
    case MODEL_WOOSISTONE:
        if (o->SubType == 1)
        {
            o->HeadAngle[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;

            o->Position[0] += (o->HeadAngle[0]) * FPS_ANIMATION_FACTOR;
            o->Position[1] += (o->HeadAngle[1]) * FPS_ANIMATION_FACTOR;
            o->Position[2] += (o->HeadAngle[2]) * FPS_ANIMATION_FACTOR;

            Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            o->Angle[0] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            o->Angle[1] += (0.5f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            if (o->Position[2] + o->Direction[2] <= Height)
            {
                o->Position[2] = Height;
                o->HeadAngle[0] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[1] *= pow(0.6f, FPS_ANIMATION_FACTOR);
                o->HeadAngle[2] += (1.0f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                if (o->HeadAngle[2] < 0.5f)
                    o->HeadAngle[2] = 0;

                o->Alpha -= (0.1f) * FPS_ANIMATION_FACTOR;
            }
        }
        else
        {
            o->Direction[2] -= (2.0f) * FPS_ANIMATION_FACTOR;
            CheckTargetRange(o);
        }
        break;
    case MODEL_TOTEMGOLEM_PART1:
    case MODEL_TOTEMGOLEM_PART2:
    case MODEL_TOTEMGOLEM_PART3:
    case MODEL_TOTEMGOLEM_PART4:
    case MODEL_TOTEMGOLEM_PART5:
    case MODEL_TOTEMGOLEM_PART6:
#ifdef ASG_ADD_KARUTAN_MONSTERS
    case MODEL_CONDRA_ARM_L:
    case MODEL_CONDRA_ARM_L2:
    case MODEL_CONDRA_SHOULDER:
    case MODEL_CONDRA_ARM_R:
    case MODEL_CONDRA_ARM_R2:
    case MODEL_CONDRA_CONE_L:
    case MODEL_CONDRA_CONE_R:
    case MODEL_CONDRA_PELVIS:
    case MODEL_CONDRA_STOMACH:
    case MODEL_CONDRA_NECK:
    case MODEL_NARCONDRA_ARM_L:
    case MODEL_NARCONDRA_ARM_L2:
    case MODEL_NARCONDRA_SHOULDER_L:
    case MODEL_NARCONDRA_SHOULDER_R:
    case MODEL_NARCONDRA_ARM_R:
    case MODEL_NARCONDRA_ARM_R2:
    case MODEL_NARCONDRA_ARM_R3:
    case MODEL_NARCONDRA_CONE_1:
    case MODEL_NARCONDRA_CONE_2:
    case MODEL_NARCONDRA_CONE_3:
    case MODEL_NARCONDRA_CONE_4:
    case MODEL_NARCONDRA_CONE_5:
    case MODEL_NARCONDRA_CONE_6:
    case MODEL_NARCONDRA_PELVIS:
    case MODEL_NARCONDRA_STOMACH:
    case MODEL_NARCONDRA_NECK:
#endif	// ASG_ADD_KARUTAN_MONSTERS
        o->HeadAngle[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;
        VectorCopy(o->Light, Light);

        o->Position[0] += (o->HeadAngle[0]) * FPS_ANIMATION_FACTOR;
        o->Position[1] += (o->HeadAngle[1]) * FPS_ANIMATION_FACTOR;
        o->Position[2] += (o->HeadAngle[2]) * FPS_ANIMATION_FACTOR;

        Height = RequestTerrainHeight(o->Position[0], o->Position[1]) + 20;

        if (o->Position[2] + o->Direction[2] <= Height)
        {
            o->Position[2] = Height;
            o->HeadAngle[0] *= pow(0.8f, FPS_ANIMATION_FACTOR);
            o->HeadAngle[1] *= pow(0.8f, FPS_ANIMATION_FACTOR);
            o->HeadAngle[2] += (0.6f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            if (o->HeadAngle[2] < 5.0f)
                o->HeadAngle[2] = 0;

            o->Alpha -= (0.05f) * FPS_ANIMATION_FACTOR;
        }
        else
        {
            if (o->SubType == 0)
            {
                o->Angle[0] += (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                o->Angle[1] += (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            }
            else
            {
                o->Angle[0] -= (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                o->Angle[1] -= (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            }
        }
        break;

    case MODEL_SHADOW_PAWN_ANKLE_LEFT:		case MODEL_SHADOW_PAWN_ANKLE_RIGHT:
    case MODEL_SHADOW_PAWN_BELT:			case MODEL_SHADOW_PAWN_CHEST:
    case MODEL_SHADOW_PAWN_HELMET:
    case MODEL_SHADOW_PAWN_KNEE_LEFT:		case MODEL_SHADOW_PAWN_KNEE_RIGHT:
    case MODEL_SHADOW_PAWN_WRIST_LEFT:		case MODEL_SHADOW_PAWN_WRIST_RIGHT:

    case MODEL_SHADOW_KNIGHT_ANKLE_LEFT:	case MODEL_SHADOW_KNIGHT_ANKLE_RIGHT:
    case MODEL_SHADOW_KNIGHT_BELT:			case MODEL_SHADOW_KNIGHT_CHEST:
    case MODEL_SHADOW_KNIGHT_HELMET:
    case MODEL_SHADOW_KNIGHT_KNEE_LEFT:		case MODEL_SHADOW_KNIGHT_KNEE_RIGHT:
    case MODEL_SHADOW_KNIGHT_WRIST_LEFT:	case MODEL_SHADOW_KNIGHT_WRIST_RIGHT:

    case MODEL_SHADOW_ROOK_ANKLE_LEFT:		case MODEL_SHADOW_ROOK_ANKLE_RIGHT:
    case MODEL_SHADOW_ROOK_BELT:			case MODEL_SHADOW_ROOK_CHEST:
    case MODEL_SHADOW_ROOK_HELMET:
    case MODEL_SHADOW_ROOK_KNEE_LEFT:		case MODEL_SHADOW_ROOK_KNEE_RIGHT:
    case MODEL_SHADOW_ROOK_WRIST_LEFT:		case MODEL_SHADOW_ROOK_WRIST_RIGHT:

    case MODEL_ICE_GIANT_PART1:				case MODEL_ICE_GIANT_PART2:
    case MODEL_ICE_GIANT_PART3:				case MODEL_ICE_GIANT_PART4:
    case MODEL_ICE_GIANT_PART5:				case MODEL_ICE_GIANT_PART6:

        o->HeadAngle[2] -= (o->Gravity) * FPS_ANIMATION_FACTOR;
        VectorCopy(o->Light, Light);

        o->Position[0] += (o->HeadAngle[0]) * FPS_ANIMATION_FACTOR;
        o->Position[1] += (o->HeadAngle[1]) * FPS_ANIMATION_FACTOR;
        o->Position[2] += (o->HeadAngle[2]) * FPS_ANIMATION_FACTOR;

        Height = RequestTerrainHeight(o->Position[0], o->Position[1]) + 20;

        if (o->Position[2] + o->Direction[2] <= Height)
        {
            o->Position[2] = Height;
            o->HeadAngle[0] *= pow(0.5f, FPS_ANIMATION_FACTOR);
            o->HeadAngle[1] *= pow(0.5f, FPS_ANIMATION_FACTOR);
            o->HeadAngle[2] += (0.6f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            if (o->HeadAngle[2] < 5.0f)
                o->HeadAngle[2] = 0;

            o->Alpha -= (0.05f) * FPS_ANIMATION_FACTOR;
        }
        else
        {
            if (o->SubType == 0)
            {
                o->Angle[0] += (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                o->Angle[1] += (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            }
            else
            {
                o->Angle[0] -= (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
                o->Angle[1] -= (0.15f * o->LifeTime) * FPS_ANIMATION_FACTOR;
            }
        }
        break;




    case MODEL_PIERCING + 1:
        if (rand_fps_check(2))
        {
            CreateParticle(BITMAP_SMOKE, o->Position, o->Angle, Light, 0);
        }
        CreateParticleFpsChecked(BITMAP_FIRE, o->Position, o->Angle, Light, 5);
        CreateParticleFpsChecked(BITMAP_FIRE, o->Position, o->Angle, Light, 5);

        Vector(Luminosity * 0.6f, Luminosity * 0.8f, Luminosity * 0.8f, Light);
        AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
        break;



    case MODEL_ARROW_GAMBLE:
    {
        vec3_t vLight;
        Vector(0.2f, 0.8f, 0.5f, vLight);

        o->Angle[1] += (60.f) * FPS_ANIMATION_FACTOR;

        for (int j = 0; j < 2; j++)
        {
            Vector((float)(Random::Rand() % 32 - 16), (float)(Random::Rand() % 64 - 32),
                   (float)(Random::Rand() % 32 - 16), Position);
            VectorAdd(Position, o->Position, Position);

            CreateParticleFpsChecked(BITMAP_SPARK + 1, Position, o->Angle, vLight, 30, 1.f);
        }

        VectorCopy(o->Position, o->EyeLeft);
        CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, vLight, 24, 1.0f);

        Vector(Luminosity * 0.2f, Luminosity * 0.8f, Luminosity * 0.5f, vLight);
        AddTerrainLight(o->Position[0], o->Position[1], vLight, 2, PrimaryTerrainLight);

        CheckClientArrow(o);
    }break;
    case MODEL_FEATHER_FOREIGN:
    {
        switch (o->SubType)
        {
        case 4:
        {
            o->Light[0] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Alpha *= pow(0.97f, FPS_ANIMATION_FACTOR);

            VectorAdd(o->EyeRight, o->Angle, o->Angle);
        }
        break;
        }
    }break;
    case MODEL_ICE:
        //o->Position[0] += (o->Owner->Position[0]-o->Position[0])*0.3f;
        //o->Position[1] += (o->Owner->Position[1]-o->Position[1])*0.3f;
        switch (o->SubType)
        {
        case 0:
            if (o->AnimationFrame >= 5.f)
            {
                o->Velocity = 0.f;
                if (rand_fps_check(2))
                {
                    vec3_t Position;
                    Vector(o->Position[0] + (float)(Random::Rand() % 64 - 32),
                           o->Position[1] + (float)(Random::Rand() % 64 - 32),
                           o->Position[2] + (float)(Random::Rand() % 128 + 32), Position);
                    CreateParticle(BITMAP_SMOKE, Position, o->Angle, o->Light);
                }
                //AttackRange(o->Position,200.f,10);
                o->Alpha -= (0.05f) * FPS_ANIMATION_FACTOR;
                if (o->Alpha < 0.f)
                    o->Live = false;
            }
            Vector(-Luminosity * 0.4f, -Luminosity * 0.3f, -Luminosity * 0.2f, Light);
            //Vector(Luminosity*0.2f,Luminosity*0.4f,Luminosity,Light);
            AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
            break;

        case 1:
        case 2:
            if (o->Owner != NULL)
            {
                if (o->Owner->Live && g_isCharacterBuff(o->Owner, eDeBuff_Harden))
                {
#ifdef GUILD_WAR_EVENT
                    if (o->Owner->Type == MODEL_BALL) break;
#endif
                    if (o->Owner->Type == MODEL_PLAYER)
                    {
                        if ((o->Owner->CurrentAction >= PLAYER_WALK_MALE && o->Owner->CurrentAction <= PLAYER_RUN_RIDE_WEAPON) ||
                            (o->Owner->CurrentAction >= PLAYER_FLY_RIDE && o->Owner->CurrentAction <= PLAYER_FLY_RIDE_WEAPON)
                            || (o->Owner->CurrentAction == PLAYER_RAGE_UNI_RUN || o->Owner->CurrentAction == PLAYER_RAGE_UNI_RUN_ONE_RIGHT))
                        {
                            o->AnimationFrame = 0.f;
                            o->PriorAnimationFrame = 0.f;
                            o->HiddenMesh = -2;
                        }
                        else
                        {
                            o->HiddenMesh = -1;
                        }
                    }
                    else
                    {
                        if (o->Owner->CurrentAction != 2)
                        {
                            o->HiddenMesh = -1;
                        }
                        else
                        {
                            o->PriorAnimationFrame = 0.f;
                            o->AnimationFrame = 0.f;
                            o->HiddenMesh = -2;
                        }
                    }
                    VectorCopy(o->Owner->Position, o->Position);
                    if (o->AnimationFrame >= 4.f) o->AnimationFrame = 4.f;
                    o->LifeTime = 10;
                }
                else
                {
                    o->Alpha -= (0.05f) * FPS_ANIMATION_FACTOR;
                }

                if (o->SubType == 1)
                {
                    o->HeadAngle[2] += (20.f) * FPS_ANIMATION_FACTOR;
                    o->Gravity = sinf(WorldTime * 0.01f) * 20.f + 30;

                    Vector(60.f, 0.f, 0.f, p);
                    AngleMatrix(o->HeadAngle, Matrix);
                    VectorRotate(p, Matrix, Position);
                    VectorAdd(o->Owner->Position, Position, Position);

                    Position[2] += o->Gravity;
                    Vector(1.f, 1.f, 1.f, Light);
                    CreateParticleFpsChecked(BITMAP_FIRE + 2, Position, o->Angle, Light, 10, 2.f);
                }
            }
            else
            {
                o->Live = false;
            }
            break;
        }
        break;
    case MODEL_FIRE:
        if (o->SubType == 0 || o->SubType == 2 || o->SubType == 4 || o->SubType == 6 || o->SubType == 7 || o->SubType == 8)
        {
            bool success = false;
            float Height;
            if (o->SubType == 4)
            {
                int PositionX = (int)(o->Position[0] / TERRAIN_SCALE);
                int PositionY = (int)(o->Position[1] / TERRAIN_SCALE);
                int WallIndex = TERRAIN_INDEX_REPEAT(PositionX, PositionY);
                int Wall = TerrainWall[WallIndex] & TW_NOGROUND;

                if (Wall != TW_NOGROUND)
                {
                    Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
                    if (o->Position[2] < Height)
                    {
                        success = true;
                        SetEarthQuakeAt(o->Position, (float)(Random::Rand() % 4 - 4) * 0.1f);

                        for (int i = 0; i < MAX_CHARACTERS_CLIENT; i++)
                        {
                            CHARACTER* tc = &CharactersClient[i];
                            OBJECT* to = &tc->Object;
                            float dx = o->Position[0] - to->Position[0];
                            float dy = o->Position[1] - to->Position[1];
                            float Distance = sqrtf(dx * dx + dy * dy);
                            if (to->Live && to->Visible && tc != Hero && tc->Dead == 0 && Distance <= 200)
                            {
                                if (to->Type == MODEL_PLAYER)
                                {
                                    if (tc->Helper.Type == MODEL_HORN_OF_FENRIR)
                                        SetAction_Fenrir_Damage(tc, to);
                                    else
                                        SetAction(to, PLAYER_SHOCK);
                                }
                                else
                                {
                                    SetAction(to, MONSTER01_SHOCK);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (o->Position[2] < -200)
                    {
                        success = true;
                        Height = o->Position[2];
                    }
                }
            }
            else
            {
                if (o->SubType == 6 || o->SubType == 7 || o->SubType == 8)
                {
                    Vector(0.5f, 0.5f, 1.f, Light);
                    CreateSprite(BITMAP_LIGHT, o->Position, 3.f, Light, o);
                    Vector(1.f, 1.f, 1.f, Light);
                    CreateSprite(BITMAP_SHINY + 1, o->Position, 3.f, Light, o, (float)(Random::Rand() % 360), 1);
                    CreateSprite(BITMAP_SHINY + 1, o->Position, 4.f, o->Light, o, (float)(Random::Rand() % 360));

                    VectorCopy(o->HeadAngle, o->Angle);
                }
                float AddHeight = 0.f;
                if (gMapManager.InHellas())
                {
                    AddHeight = 50.f;
                }
                Height = RequestTerrainHeight(o->Position[0], o->Position[1]) + AddHeight;
                if (o->Position[2] < Height)
                {
                    success = true;
                }
            }

            if (success)
            {
                o->Position[2] = Height;
                Vector(0.f, 0.f, 0.f, o->Direction);
                vec3_t Position;
                Vector(o->Position[0], o->Position[1], o->Position[2] + 80.f, Position);
                if (o->SubType == 6 || o->SubType == 7 || o->SubType == 8)
                {
                    BYTE smokeNum = 15;

                    Vector(0.f, 0.5f, 0.f, Light);
                    Vector(0.f, 0.f, 0.f, Angle);
                    CreateEffectFpsChecked(MODEL_SKILL_INFERNO, o->Position, Angle, Light, 2, o, 30, 0);

                    if (o->SubType == 7)
                    {
                        smokeNum = 7;
                    }
                    else if (o->SubType == 8)
                    {
                        smokeNum = 5;
                    }

                    for (int i = 0; i < smokeNum; ++i)
                    {
                        Position[0] = o->Position[0] + (Random::Rand() % 160 - 80);
                        Position[1] = o->Position[1] + (Random::Rand() % 160 - 100);
                        Position[2] = o->Position[2] + 50;

                        Vector(0.1f, 0.5f, 0.1f, Light);
                        CreateParticleFpsChecked(BITMAP_SMOKE, Position, o->Angle, Light, 11,
                                                 (float)(Random::Rand() % 32 + 80) * 0.025f);
                    }

                    if (o->SubType != 7 && o->SubType != 8)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            CreateEffectFpsChecked(MODEL_STONE1 + Random::Rand() % 2, o->Position, o->Angle, Light);
                        }
                    }
                    PlayBuffer(SOUND_DEATH_POISON2);
                }
                else
                {
                    for (int j = 0; j < 6; j++)
                    {
                        CreateEffectFpsChecked(MODEL_STONE1 + Random::Rand() % 2, o->Position, o->Angle, o->Light);
                    }
                }
                CreateParticleFpsChecked(BITMAP_EXPLOTION, Position, o->Angle, Light);

                o->Live = false;
            }
        }
        else if (o->SubType == 5)
        {
            o->Position[2] += (o->Gravity) * FPS_ANIMATION_FACTOR;
            o->Gravity -= (2.f) * FPS_ANIMATION_FACTOR;

            Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            if (o->Position[2] < Height)
            {
                o->Gravity = 10.f;
                o->Position[2] += (10.f) * FPS_ANIMATION_FACTOR;
                o->Direction[1] *= pow(0.5f, FPS_ANIMATION_FACTOR);
                o->Scale *= pow(1.1f, FPS_ANIMATION_FACTOR);
            }

            int PositionX = (int)(o->Position[0] / TERRAIN_SCALE);
            int PositionY = (int)(o->Position[1] / TERRAIN_SCALE);
            int WallIndex = TERRAIN_INDEX_REPEAT(PositionX, PositionY);
            int Wall = TerrainWall[WallIndex] & TW_NOGROUND;

            if ((int)o->LifeTime == 1 || Wall == TW_NOGROUND)
            {
                o->Position[2] = Height;

                Vector(0.f, 0.f, 0.f, o->Direction);
                vec3_t Position;
                Vector(o->Position[0], o->Position[1], o->Position[2] + 80.f, Position);
                CreateParticleFpsChecked(BITMAP_EXPLOTION, Position, o->Angle, Light);
                for (int j = 0; j < 6; j++)
                {
                    CreateEffectFpsChecked(MODEL_STONE1 + Random::Rand() % 2, o->Position, o->Angle, o->Light);
                }
                o->Live = false;
            }
        }
        else if (o->SubType == 9)
        {
            CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, o->Direction, 36, 1.0f + o->Scale, o);
            CreateParticleFpsChecked(BITMAP_SMOKE, o->Position, o->Angle, o->Direction, 37, 2.0f + o->Scale, o);
            Vector(1.0f, 0.2f, 0.2f, o->Light);
            AddTerrainLight(o->Position[0], o->Position[1], o->Light, 4, PrimaryTerrainLight);

            float Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
            if (o->Position[2] < Height)
            {
                o->Live = false;
                break;
            }
        }

        if (o->SubType == 5)
        {
            o->HiddenMesh = 0;
            o->BlendMeshLight = 0.f;

            Vector(Luminosity * 1.f, Luminosity * 0.1f, Luminosity * 0.f, Light);
            AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
            if ((Random::Rand() % 5) != 0)
            {
                CreateParticleFpsChecked(BITMAP_POUNDING_BALL, o->Position, o->Angle, Light);
            }
        }
        else
        {
            if (o->SubType == 3)
            {
                o->HiddenMesh = 0;
                o->BlendMeshLight = 0.f;
            }
            else if (o->SubType == 0)
                o->BlendMeshLight = (float)(Random::Rand() % 4 + 4) * 0.1f;
            else if (o->SubType == 6 || o->SubType == 7)
                o->BlendMeshLight = (float)(Random::Rand() % 4 + 4) * 0.1f;
            else
                o->BlendMeshLight = 0.f;

            if (o->SubType == 6 || o->SubType == 7 || o->SubType == 8)
            {
                Vector(Luminosity * 0.1f, Luminosity * 1.f, Luminosity * 0.f, Light);
            }
            else
            {
                Vector(Luminosity * 1.f, Luminosity * 0.1f, Luminosity * 0.f, Light);
            }
            AddTerrainLight(o->Position[0], o->Position[1], Light, 2, PrimaryTerrainLight);
            if (o->SubType == 6 || o->SubType == 7)
            {
                for (int j = 0; j < 2; j++)
                {
                    Position[0] = o->Position[0] + Random::Rand() % 50 - 25;
                    Position[1] = o->Position[1];
                    Position[2] = o->Position[2];
                    CreateParticleFpsChecked(BITMAP_FIRE, Position, o->Angle, Light, 5);
                }
            }
            else if (o->SubType != 3)
            {
                CreateParticleFpsChecked(BITMAP_FIRE, o->Position, o->Angle, Light, 5);
            }
            else
            {
                vec3_t Pos;
                vec3_t vRot;
                GetMagicScrew(iIndex * 5371, vRot);
                VectorScale(vRot, 50.f, vRot);
                VectorCopy(o->Position, Pos);
                VectorAdd(Pos, vRot, Pos);

                Vector(0.0f, 0.0f, 0.0f, Angle);
                Vector(1.0f, 1.0f, 1.0f, Light);
                CreateParticleFpsChecked(BITMAP_FIRE, Pos, Angle, Light, 8, o->Scale * 2.5f);
                CreateSprite(BITMAP_SHINY + 1, Pos, o->Scale * 3.0f, Light, NULL, (float)(Random::Rand() % 360));
            }
            //                CreateParticleFpsChecked(BITMAP_SMOKE,o->Position,o->Angle,Light, 5);
            if (o->SubType == 1)
            {
                CheckTargetRange(o);
            }
        }
        break;


    case MODEL_GATE:
    case MODEL_GATE + 1:
        VectorAddScaled(o->Position, o->Direction, o->Position, FPS_ANIMATION_FACTOR);
        VectorScale(o->Direction, powf(0.9f, FPS_ANIMATION_FACTOR), o->Direction);
        o->Position[2] += (o->Gravity) * FPS_ANIMATION_FACTOR;

        if (o->SubType == 1)
        {
            VectorScale(o->Direction, powf(1.1f, FPS_ANIMATION_FACTOR), o->Direction);
        }

        o->Gravity -= (4.f) * FPS_ANIMATION_FACTOR;
        Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
        if (o->Position[2] < Height)
        {
            o->Position[2] = Height;
            o->Gravity = -o->Gravity * 0.5f;
            o->LifeTime -= (5) * FPS_ANIMATION_FACTOR;
            o->Angle[0] -= (o->Scale * 128.f) * FPS_ANIMATION_FACTOR;
        }
        else
            o->Angle[0] -= (o->Scale * 16.f) * FPS_ANIMATION_FACTOR;

        if (rand_fps_check(10))
        {
            CreateParticle(BITMAP_SMOKE + 1, Position, o->Angle, Light);
        }
        break;

    case MODEL_STONE_COFFIN:
    case MODEL_STONE_COFFIN + 1:
        VectorAddScaled(o->Position, o->Direction, o->Position, FPS_ANIMATION_FACTOR);
        VectorScale(o->Direction, powf(0.9f, FPS_ANIMATION_FACTOR), o->Direction);
        o->Position[2] += (o->Gravity) * FPS_ANIMATION_FACTOR;

        if (o->SubType == 1)
        {
            VectorScale(o->Direction, powf(1.1f, FPS_ANIMATION_FACTOR), o->Direction);
        }

        o->Gravity -= (3.f) * FPS_ANIMATION_FACTOR;
        Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
        if (o->Position[2] < Height)
        {
            o->Position[2] = Height;
            o->Gravity = -o->Gravity * 0.2f;
            o->LifeTime -= (5) * FPS_ANIMATION_FACTOR;
            o->Angle[0] -= (o->Scale * 128.f) * FPS_ANIMATION_FACTOR;
        }
        else
            o->Angle[0] -= (o->Scale * 16.f) * FPS_ANIMATION_FACTOR;

        o->Alpha = o->LifeTime / 10.f;
        if (rand_fps_check(10))
        {
            CreateParticle(BITMAP_SMOKE + 1, Position, o->Angle, Light);
        }
        break;




        if (o->SubType <= 1)
        {
            o->Scale += (o->Velocity) * FPS_ANIMATION_FACTOR;
            o->Velocity += (0.02f) * FPS_ANIMATION_FACTOR;
            if (o->LifeTime < 7)
            {
                o->BlendMeshLight *= pow(1.0f / (1.8f), FPS_ANIMATION_FACTOR);
            }
        }
        else if (o->SubType == 2)
        {
            o->Scale += (o->Velocity) * FPS_ANIMATION_FACTOR;
            o->Velocity -= (0.06f) * FPS_ANIMATION_FACTOR;
            if (o->LifeTime < 8)
            {
                o->BlendMeshLight *= pow(1.0f / (1.5f), FPS_ANIMATION_FACTOR);
            }
        }
        else
        {
            o->Scale += (o->Velocity) * FPS_ANIMATION_FACTOR;
            o->Velocity += (0.04f) * FPS_ANIMATION_FACTOR;
            if (o->LifeTime < 8)
            {
                o->BlendMeshLight *= pow(1.0f / (1.8f), FPS_ANIMATION_FACTOR);
            }
        }
        break;
    case BITMAP_JOINT_THUNDER + 1:
        if (o->LifeTime < 5 && (int)o->LifeTime % 2 == 0 && o->SubType == 0)
        {
            VectorCopy(o->Position, Position);

            Position[0] += Random::Rand() % 64 - 32.f;
            Position[1] += Random::Rand() % 64 - 32.f;

            CreateJointFpsChecked(BITMAP_JOINT_THUNDER + 1, Position, Position, o->Angle, 5, NULL,
                                  50.f + Random::Rand() % 10);
        }
        break;















    case MODEL_EFFECT_SAPITRES_ATTACK_1:
    {
        if (o->SubType == 0)
        {
            float fMoveSpeed = 40.0f;
            o->Position[0] += ((o->Direction[0] * fMoveSpeed)) * FPS_ANIMATION_FACTOR;
            o->Position[1] += ((o->Direction[1] * fMoveSpeed)) * FPS_ANIMATION_FACTOR;

            vec3_t vLight;
            Vector(0.1f, 0.3f, 1.0f, vLight);
            CreateSprite(BITMAP_LIGHT, o->Position, 3.0f, vLight, o);

            CheckTargetRange(o);

            if ((int)o->LifeTime == 1)
            {
                for (int i = 0; i < 3; i++)
                {
                    CreateEffectFpsChecked(MODEL_EFFECT_SAPITRES_ATTACK_2, o->Position, o->Angle, vLight, 0);
                }
            }
        }
    }
    break;

    case MODEL_SWELL_OF_MAGICPOWER:
    {
        if (o->SubType == 0)
        {
            if (o->Owner->Type != MODEL_PLAYER)
                break;

            BMD* pModel = &Models[o->Owner->Type];
            VectorCopy(o->Owner->Position, o->Position);
            vec3_t vLight, vPos;

            Vector(0.4f, 0.3f, 0.9f, vLight);
            if ((int)o->LifeTime == 45 || (int)o->LifeTime == 35 || (int)o->LifeTime == 25)
            {
                CreateEffectFpsChecked(BITMAP_SHOCK_WAVE, o->Position, o->Angle, vLight, 14, o, -1, 0, 0, 0, 5.0f);
                CreateEffectFpsChecked(BITMAP_SHOCK_WAVE, o->Position, o->Angle, vLight, 14, o, -1, 0, 0, 0, 5.0f);
                CreateEffectFpsChecked(BITMAP_TWLIGHT, o->Position, o->Angle, vLight, 3, o, -1, 0, 0, 0, 6.0f);
            }

            Vector(0.7f, 0.3f, 0.9f, vLight);
            if (o->LifeTime <= 20)
            {
                vec3_t vDLight;
                float fDynamicLightVal = o->LifeTime * 0.05f;
                Vector(fDynamicLightVal * vLight[0], fDynamicLightVal * vLight[1], fDynamicLightVal * vLight[2], vDLight);
                for (int i = 0; i < pModel->NumBones; i++)
                {
                    pModel->TransformByObjectBone(vPos, o->Owner, i);

                    CreateSprite(BITMAP_LIGHT, vPos, 1.5f, vDLight, o);
                }
            }

            Vector(0.2f, 0.2f, 0.9f, vLight);
            if ((int)o->LifeTime == 45)
            {
                pModel->TransformByObjectBone(vPos, o->Owner, 28);
                CreateEffectFpsChecked(MODEL_ARROWSRE06, vPos, o->Angle, vLight, 1, o->Owner, 28);
                pModel->TransformByObjectBone(vPos, o->Owner, 37);
                CreateEffectFpsChecked(MODEL_ARROWSRE06, vPos, o->Angle, vLight, 1, o->Owner, 37);
            }

            if (o->LifeTime >= 30)
            {
                Vector(0.3f, 0.2f, 0.9f, vLight);
                for (int i = 0; i < 2; i++)
                {
                    CreateJointFpsChecked(BITMAP_2LINE_GHOST, o->Position, o->Position, o->Angle, 1, o,
                                          20.0f + Random::Rand() % 10, -1, 0, 0, -1, vLight);
                }
            }
        }
    }break;
    case MODEL_ARROWSRE06:
    {
        if (o->SubType == 0)
        {
            if (o->Owner->Type != MODEL_PLAYER)
                break;

            BMD* pModel = &Models[o->Owner->Type];
            vec3_t vPos;
            pModel->TransformByObjectBone(vPos, o->Owner, o->PKKey);
            VectorCopy(vPos, o->Position);
            o->Scale -= (1.0f) * FPS_ANIMATION_FACTOR;
            if (o->LifeTime <= 15)
            {
                o->Scale += (0.5f) * FPS_ANIMATION_FACTOR;
            }
        }
        else if (o->SubType == 1)
        {
            if (o->Owner->Type != MODEL_PLAYER)
                break;

            BMD* pModel = &Models[o->Owner->Type];
            vec3_t vPos;
            pModel->TransformByObjectBone(vPos, o->Owner, o->PKKey);
            VectorCopy(vPos, o->Position);

            if (o->LifeTime >= 15)
            {
                o->Scale *= pow(1.05f, FPS_ANIMATION_FACTOR);
            }
            else
            {
                o->Scale *= pow(0.95f, FPS_ANIMATION_FACTOR);
            }

            CreateSprite(BITMAP_LIGHT, o->Position, o->Scale, o->Light, o->Owner);
            CreateSprite(BITMAP_LIGHT, o->Position, o->Scale * 0.8f, o->Light, o->Owner);

            if (o->LifeTime <= 10)
            {
                o->Alpha *= pow(0.95f, FPS_ANIMATION_FACTOR);
            }
        }
#ifdef PJH_ADD_PANDA_CHANGERING
        else if (o->SubType == 2)
        {
            vec3_t vRelativePos;
            BMD* b = &Models[o->Owner->Type];
            if (o->Owner->Type != MODEL_PLAYER)
                break;

            if (o->LifeTime > 15)
            {
                o->Scale *= pow(0.9f, FPS_ANIMATION_FACTOR);
            }
            else
                if ((int)o->LifeTime == 15)
                {
                    o->Scale = 2.f;
                }
                else
                {
                    o->Scale *= pow(0.65f, FPS_ANIMATION_FACTOR);
                }

            if (o->PKKey == 0)
            {
                Vector(13.f, 14.f, -10.f, vRelativePos);
                b->TransformPosition(o->Owner->BoneTransform[20], vRelativePos, o->Position);
                VectorAdd(o->Position, o->Owner->Position, o->Position);
            }
            else
            {
                Vector(13.f, 14.f, 10.f, vRelativePos);
                b->TransformPosition(o->Owner->BoneTransform[20], vRelativePos, o->Position);
                VectorAdd(o->Position, o->Owner->Position, o->Position);
            }

            CreateSprite(BITMAP_LIGHT, o->Position, o->Scale, o->Light, o->Owner);
            CreateSprite(BITMAP_LIGHT, o->Position, o->Scale * 0.8f, o->Light, o->Owner);

            if (o->LifeTime <= 10)
            {
                o->Alpha *= pow(0.95f, FPS_ANIMATION_FACTOR);
            }
        }
#endif //PJH_ADD_PANDA_CHANGERING
    }break;
    case MODEL_SWELL_OF_MAGICPOWER_BUFF_EFF:
    {
        if (o->SubType == 0)
        {
            VectorCopy(o->Owner->Position, o->Position);

            int iPastTime = WorldTime - o->Timer;

            if (iPastTime >= 6000)
            {
                vec3_t vLight;
                Vector(0.2f, 0.2f, 0.9f, vLight);

                // Bip01 R Hand
                CreateEffectFpsChecked(MODEL_ARROWSRE06, o->Position, o->Angle, vLight, 1, o->Owner, 28);

                // Bip01 L Hand
                CreateEffectFpsChecked(MODEL_ARROWSRE06, o->Position, o->Angle, vLight, 1, o->Owner, 37);

                o->Timer = WorldTime;
            }
            o->LifeTime = 999;
        }
    }break;
    case MODEL_STAR_SHINE:
    {
        if (o->SubType == 0)
        {
            if (o->LifeTime <= 10)
            {
                o->Scale *= pow(0.9f, FPS_ANIMATION_FACTOR);
                o->Alpha *= pow(0.9f, FPS_ANIMATION_FACTOR);
                o->Light[0] *= pow(0.9f, FPS_ANIMATION_FACTOR);
                o->Light[1] *= pow(0.9f, FPS_ANIMATION_FACTOR);
                o->Light[2] *= pow(0.9f, FPS_ANIMATION_FACTOR);
            }
            else if (o->LifeTime <= 20)
            {
                CreateSprite(BITMAP_SHINY, o->Position, o->Scale, o->Light, o, o->Angle[0]);
            }
            else if (o->LifeTime <= 30)
            {
                o->Scale *= pow(1.1f, FPS_ANIMATION_FACTOR);
                o->Alpha *= pow(1.1f, FPS_ANIMATION_FACTOR);
                o->Light[0] *= pow(1.1f, FPS_ANIMATION_FACTOR);
                o->Light[1] *= pow(1.1f, FPS_ANIMATION_FACTOR);
                o->Light[2] *= pow(1.1f, FPS_ANIMATION_FACTOR);
            }

            CreateSprite(BITMAP_SHINY, o->Position, o->Scale, o->Light, o, o->Angle[0]);
        }
    }break;
    case MODEL_FEATHER:
    {
        switch (o->SubType)
        {
        case 2:
        {
            o->Light[0] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Scale *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Alpha *= pow(0.97f, FPS_ANIMATION_FACTOR);
            VectorAdd(o->EyeRight, o->Angle, o->Angle);
        }
        break;
        case 0:
        {
            o->Light[0] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Alpha *= pow(0.97f, FPS_ANIMATION_FACTOR);

            VectorAdd(o->EyeRight, o->Angle, o->Angle);
        }
        break;
        case 3:
        {
            o->Light[0] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Alpha *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Scale *= pow(0.97f, FPS_ANIMATION_FACTOR);

            VectorAdd(o->EyeRight, o->Angle, o->Angle);
        }break;
        case 1:
        {
            o->Light[0] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(0.97f, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Alpha *= pow(0.97f, FPS_ANIMATION_FACTOR);

            o->Scale *= pow(0.99f, FPS_ANIMATION_FACTOR);

            VectorAdd(o->EyeRight, o->Angle, o->Angle);
        }break;
        }
    }break;

    case MODEL_STREAMOFICEBREATH:
    {
        if (0 == o->SubType)
        {
            if (o->LifeTime > 1)
            {
                for (INT i_ = 0; i_ < 4; ++i_)
                {
                    const	float RANDOMOFFSET_ANGLE = 15.0f;
                    const	float RANDOMOFFSET_SCALE = 0.01f;
                    const	float RANDOMOFFSET_POSITION = 20.0f;
                    const float RANDNUM = ((float)((Random::Rand() % 2000) - 1000) * 0.001f);

                    vec3_t		v3ResultAngle, v3ResultPos, v3Light_;
                    float		fResultScale;
                    float		fCurrentOffsetScale, fCurrentOffsetPos, fCurrentOffsetAngle;

                    fCurrentOffsetScale = RANDOMOFFSET_SCALE * RANDNUM;
                    fCurrentOffsetPos = RANDOMOFFSET_POSITION * RANDNUM;
                    fCurrentOffsetAngle = RANDOMOFFSET_ANGLE * RANDNUM;

                    v3ResultPos[0] = o->StartPosition[0] + fCurrentOffsetPos;
                    v3ResultPos[1] = o->StartPosition[1] + fCurrentOffsetPos;
                    v3ResultPos[2] = o->StartPosition[2] + fCurrentOffsetPos;

                    v3ResultAngle[0] = o->Angle[0] + fCurrentOffsetAngle;
                    v3ResultAngle[1] = o->Angle[1] + fCurrentOffsetAngle;
                    v3ResultAngle[2] = o->Angle[2] + fCurrentOffsetAngle;

                    fResultScale = o->Scale + fCurrentOffsetScale;

                    v3Light_[0] = 0.5f; v3Light_[1] = 0.6f; v3Light_[2] = 0.94f;

                    CreateParticleFpsChecked(BITMAP_RAKLION_CLOUDS, v3ResultPos, v3ResultAngle, v3Light_, 1, fResultScale);
                }
            }
        }
    }break;
    case BITMAP_RING_OF_GRADATION:
    {
        if (o->SubType == 0)
        {
            if ((int)o->LifeTime == 20)
                break;

            o->Scale += (0.1f) * FPS_ANIMATION_FACTOR;

            o->Light[0] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);

            o->Alpha *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
        }
    }break;
    case MODEL_EFFECT_UMBRELLA_DIE:
    {
        if (o->SubType == 0)
        {
            if ((int)o->LifeTime == 28 || (int)o->LifeTime == 18 || (int)o->LifeTime == 8)
            {
                vec3_t vLight;
                Vector(1.0f, 0.2f, 0.5f, vLight);
                CreateEffectFpsChecked(BITMAP_RING_OF_GRADATION, o->Owner->Position, o->Angle, vLight, 0, o->Owner, 0, 0, 0, 0, 1.2f);
            }
        }
    }break;
    case MODEL_EFFECT_UMBRELLA_GOLD:
    {
        o->Angle[0] += (10.f) * FPS_ANIMATION_FACTOR;
        o->Position[0] += ((o->Direction[0] * 2.2f)) * FPS_ANIMATION_FACTOR;
        o->Position[1] += ((o->Direction[1] * 2.2f)) * FPS_ANIMATION_FACTOR;
        o->Position[2] += ((o->Gravity * 1.5f)) * FPS_ANIMATION_FACTOR;
        o->Gravity -= (1.5f) * FPS_ANIMATION_FACTOR;

        Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
        if (o->Position[2] < Height)
        {
            o->Position[2] = Height;
            o->Gravity = -o->Gravity * 0.3f;
            o->LifeTime -= (2) * FPS_ANIMATION_FACTOR;
        }
    }break;
    case MODEL_EFFECT_EG_GUARDIANDEFENDER_ATTACK2:
    {
        if (o->LifeTime <= 18)
        {
            o->Light[0] *= pow(1.0f / (1.4f), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (1.4f), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (1.4f), FPS_ANIMATION_FACTOR);
            o->Scale *= pow(1.1f, FPS_ANIMATION_FACTOR);
        }
        CreateSprite(BITMAP_SHOCK_WAVE, o->Position, o->Scale, o->Light, o->Owner);
        CreateParticleFpsChecked(BITMAP_FIRE + 2, o->Position, o->Angle, o->Light, 16, 2.5f);
    }break;
    case BITMAP_SHINY + 4:
    {
        vec3_t vPosition, Light;
        VectorCopy(o->Position, vPosition);
        VectorCopy(o->Light, Light);
        Vector(vPosition[0] + Random::Rand() % 100 - 40, vPosition[1] + Random::Rand() % 100 - 40,
               vPosition[2] + Random::Rand() % 100 + 50, vPosition);
        CreateParticleFpsChecked(BITMAP_SHINY + 4, vPosition, o->Angle, Light, 2, o->Scale);
    }
    break;
    }

    if (
        o->Type == MODEL_SKILL_WHEEL1
        || o->Type == MODEL_SKILL_WHEEL2
        || o->Type == MODEL_SKILL_FURY_STRIKE
        || ((o->Type == MODEL_STONE1 || o->Type == MODEL_STONE2) && o->SubType == 5)
        || (o->Type == MODEL_ARROW_DRILL && o->SubType == 3)
        || o->Type == MODEL_PIER_PART
        || o->Type == MODEL_DEATH_SPI_SKILL
        || o->Type == MODEL_CHANGE_UP_EFF
        )
    {
    }
    else
    {
        if (o->Type >= MODEL_BIRD01 && o->Type < MODEL_SKILL_END)
        {
            BMD* b = &Models[o->Type];
            b->CurrentAction = o->CurrentAction;
            if (o->CurrentAction != 255 && b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, o->Velocity, o->Position, o->Angle) == false)
            {
                o->AnimationFrame = b->Actions[b->CurrentAction].NumAnimationKeys;
                o->CurrentAction = 255;
            }
        }
        if (o->Type<BITMAP_BOSS_LASER || o->Type>BITMAP_BOSS_LASER + 2)
        {
            switch (o->Type)
            {
            case MODEL_SAW:
            case MODEL_SPEARSKILL:
                MoveParticle(o, false);
                break;
            case MODEL_ARROW_HOLY:
            {
                float Matrix[3][4];
                vec3_t Angle;
                vec3_t Position;
                //					if(o->LifeTime > 12 && o->SubType == 1)
                //						break;
                VectorCopy(o->Angle, Angle);
                AngleMatrix(Angle, Matrix);
                VectorRotate(o->Direction, Matrix, Position);
                VectorAdd(o->StartPosition, Position, o->StartPosition);
            }
            break;
            case MODEL_FLY_BIG_STONE1:
            case MODEL_FLY_BIG_STONE2:
                break;

            case MODEL_SKILL_JAVELIN:
                break;
            case MODEL_SWORD_FORCE:
            {
                BMD* b = &Models[o->Type];
                b->CurrentAction = o->CurrentAction;
                b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, o->Velocity, o->Position, o->Angle);
                MoveParticle(o, true);
            }
            break;
            default:
                MoveParticle(o, true);
                break;
            }
        }
    }
    o->LifeTime -= FPS_ANIMATION_FACTOR;
    if (o->LifeTime <= 0)
    {
        EffectDestructor(o);
    }
    else
    {
        switch (o->Type)
        {
            case BITMAP_LIGHT:
                if (o->SubType == 0 && rand_fps_check(2))
                {
                    MoveEffect(o, iIndex);
                }
                break;
            case MODEL_FIRE:
                if (o->SubType == 3 && rand_fps_check(2))
                {
                    MoveEffect(o, iIndex);
                }
                break;
        }
    }
}

void MoveEffects()
{
    if (SceneFlag == MAIN_SCENE)
    {
        g_pCatapultWindow->SetCameraPos();
    }

    for (int i = 0; i < MAX_EFFECTS; i++)
    {
        OBJECT* o = &Effects[i];
        if (o->Live)
        {
            MoveEffect(o, i);
        }
    }
    g_SkillEffects.MoveEffects();
}

// An effect drawn as its owner's weapon draws a copy that takes the weapon item's attributes.
void RenderWheelWeapon(const OBJECT* effect)
{
    const int Type = Render::Models::CosmeticArmor::SkillWeaponModel(effect->Owner);
    if (Type < 0)
        return;
    OBJECT weapon = *effect;
    const Random::DrawnAs drawnAs(&weapon, effect);
    OBJECT* o = &weapon;
    o->Angle[2] += o->Direction[2];
    o->Angle[1] = 90;
    o->Position[2] += 100.f;

    float Alpha = o->Alpha;

    BMD* b = &Models[Type];
    b->CurrentAction = 0;
    b->Skin = gCharacterManager.GetBaseClass(Hero->Class);
    b->CurrentAction = o->CurrentAction;
    VectorCopy(o->Position, b->BodyOrigin);

    o->Type = Type;
    ItemObjectAttribute(o);
    b->Animation(BoneTransform, o->AnimationFrame, o->PriorAnimationFrame, o->PriorAction, o->Angle, o->HeadAngle, false, false);
    vec3_t Light;
    RequestModelTerrainLight(o->Position[0], o->Position[1], Light);
    VectorAdd(Light, o->Light, Light);
    const int level =
        Type == Data::Items::ToModelSlot(effect->Owner->Weapon) ? effect->Owner->WeaponLevel : 0;
    RenderPartObject(o, Type, NULL, Light, Alpha, level, 0, 0, true, true, true);
}

void RenderFuryStrike(const OBJECT* effect)
{
    if (effect->LifeTime > 10.f && effect->Kind == 0)
    {
        OBJECT weapon = *effect;
        const Random::DrawnAs drawnAs(&weapon, effect);
        OBJECT* o = &weapon;
        vec3_t p, Light, Angle;
        float Alpha = o->Alpha;

        Vector(0.f, 100.f, 0.f, p);

        const int Type = Render::Models::CosmeticArmor::SkillWeaponModel(effect->Owner);
        if (Type < 0)
            return;
        BMD* b = &Models[Type];
        b->CurrentAction = 0;
        b->Skin = gCharacterManager.GetBaseClass(Hero->Class);
        b->CurrentAction = o->CurrentAction;
        VectorCopy(o->Position, b->BodyOrigin);

        float tempGravity = o->Gravity;
        o->Type = Type;
        ItemObjectAttribute(o);
        o->Gravity = tempGravity;

        RequestModelTerrainLight(o->Position[0], o->Position[1], Light);
        VectorAdd(Light, o->Light, Light);
        VectorCopy(o->Angle, Angle);

        b->Animation(BoneTransform, o->AnimationFrame, o->PriorAnimationFrame, o->PriorAction, Angle, o->HeadAngle, false, false);
        const int level =
            Type == Data::Items::ToModelSlot(effect->Owner->Weapon) ? effect->Owner->WeaponLevel : 0;
        RenderPartObject(o, Type, NULL, Light, Alpha, level, 0, 0, true, true, true);
    }
}

void RenderSkillSpear(const OBJECT* o)
{
    BMD* b = &Models[MODEL_SPEARSKILL];
    b->Animation(BoneTransform, o->AnimationFrame, o->PriorAnimationFrame, o->PriorAction, o->Angle, o->HeadAngle, false, false);
    vec3_t Light;
    for (int i = 0; i < 3; ++i)
        Light[i] = o->Light[i] * o->LifeTime * 0.05f;
    RenderPartObject(o, MODEL_SPEARSKILL, NULL, Light, 1.0f, 0, 0, 0, true, true, true, false, RENDER_BRIGHT | RENDER_TEXTURE);
}

static unsigned int s_effectCullFrame = 0;

void CullEffects()
{
    ++s_effectCullFrame;
    const int iEffectSize = MAX_EFFECTS + g_SkillEffects.GetSize();
    for (int i = 0; i < iEffectSize; ++i)
    {
        OBJECT* o = i < MAX_EFFECTS ? &Effects[i] : g_SkillEffects.GetEffect(i - MAX_EFFECTS);
        if (!o->Live)
            continue;

        o->Visible = TestFrustrum(o->Position, 400.f);
        if (gMapManager.WorldActive == WD_39KANTURU_3RD && (o->Type == MODEL_STORM3 || o->Type == MODEL_MAYASTAR))
            o->Visible = true;
        if (o->Visible)
            o->DrawnFrame = s_effectCullFrame;
    }
}

void RenderEffects(bool bRenderBlendMesh)
{
    using Render::EffectDrawing::Blend;
    using Render::EffectDrawing::Decal;
    Render::EffectDrawing::EffectDrawer& out = Render::EffectDrawing::ActiveEffectDrawer();
    int iEffectSize = MAX_EFFECTS + g_SkillEffects.GetSize();

    for (int i = 0; i < iEffectSize; ++i)
    {
        const OBJECT* o;
        if (i < MAX_EFFECTS)
        {
            o = &Effects[i];
        }
        else
        {
            if (IsSkillEffectModelsDisabledDebug())
            {
                continue;
            }
            o = g_SkillEffects.GetEffect(i - MAX_EFFECTS);
        }

        if (o->Live)
        {
            if (o->Visible)
            {
                if (bRenderBlendMesh)
                {
                    if (o->BlendMesh == -1 || o->BlendMesh < -2) continue;
                    // Effects with a texture number (BITMAP_*) have no model.
                    if (o->Type < MAX_MODELS && Models[o->Type].NumMeshs < o->BlendMesh)
                        continue;
                    //if ( (o->Position[2]+o->BoundingBoxMax[2])<350.f ) continue;
                }

                switch (o->Type)
                {
                case MODEL_DRAGON:
                case MODEL_WARP3:
                case MODEL_WARP2:
                case MODEL_WARP:
                case MODEL_WARP6:
                case MODEL_WARP5:
                case MODEL_WARP4:
                case MODEL_GHOST:
                case MODEL_TREE_ATTACK:
                    RenderObject(o);
                    break;
                case MODEL_MULTI_SHOT1:
                case MODEL_MULTI_SHOT2:
                case MODEL_MULTI_SHOT3:
                {
                    Vector(1.f, 1.f, 1.f, Models[o->Type].BodyLight);
                    RenderObject(o);
                }
                break;
                case MODEL_STORM:

                    if (o->SubType == 3 || o->SubType == 4 || o->SubType == 5 || o->SubType == 6 || o->SubType == 7)
                    {
                        vec3_t Light;
                        out.SetState({.blend = Blend::Glow});
                        Vector(0.3f, 0.3f, 0.3f, Light);
                        auto Rotation = (float)(WorldTime);
                        out.DrawDecal(
                            Decal(BITMAP_POUNDING_BALL, o->Position[0], o->Position[1], 2.f, 2.f, Light, Rotation));
                    }
                    else
                        RenderObject(o);
                    break;
                case MODEL_STORM3:
                case MODEL_MAYAHANDSKILL:
                    SendAfterCharacter(o);
                    break;
                case MODEL_SUMMON:
                case MODEL_STORM2:
                case MODEL_MAYASTAR:
                case MODEL_MAYASTONE1:
                case MODEL_MAYASTONE2:
                case MODEL_MAYASTONE3:
                case MODEL_MAYASTONE4:
                case MODEL_MAYASTONE5:
                case MODEL_MAYASTONEFIRE:
                case MODEL_BUTTERFLY01:
                    RenderObject(o);
                    break;
                case 9:
                    RenderObject(o);
                    break;

                case MODEL_HALLOWEEN_CANDY_BLUE:
                case MODEL_HALLOWEEN_CANDY_ORANGE:
                case MODEL_HALLOWEEN_CANDY_YELLOW:
                case MODEL_HALLOWEEN_CANDY_RED:
                case MODEL_HALLOWEEN_CANDY_HOBAK:
                case MODEL_HALLOWEEN_CANDY_STAR:
                    RenderObject(o);
                    break;
                case MODEL_HALLOWEEN:
                case MODEL_HALLOWEEN_EX:
                    break;

                case MODEL_XMAS_EVENT_BOX:
                case MODEL_XMAS_EVENT_CANDY:
                case MODEL_XMAS_EVENT_TREE:
                case MODEL_XMAS_EVENT_SOCKS:
                    RenderObject(o);
                    break;
                case MODEL_XMAS_EVENT_ICEHEART:
                    RenderObject(o);
                    break;

                case MODEL_NEWYEARSDAY_EVENT_BEKSULKI:
                case MODEL_NEWYEARSDAY_EVENT_CANDY:
                case MODEL_NEWYEARSDAY_EVENT_MONEY:
                case MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_GREEN:
                case MODEL_NEWYEARSDAY_EVENT_HOTPEPPER_RED:
                case MODEL_NEWYEARSDAY_EVENT_PIG:
                case MODEL_NEWYEARSDAY_EVENT_YUT:
                    RenderObject(o);
                    break;
                case MODEL_MOONHARVEST_MOON:
                {
                    if (o->SubType == 0)
                    {
                        RenderObject(o);
                    }
                    else if (o->SubType == 1)
                    {
                        RenderObject(o);
                    }
                    else if (o->SubType == 2)
                    {
                        RenderObject(o);
                    }
                }
                break;
                case MODEL_MOONHARVEST_GAM:
                case MODEL_MOONHARVEST_SONGPUEN1:
                case MODEL_MOONHARVEST_SONGPUEN2:
                    RenderObject(o);
                    break;

                case MODEL_CHANGE_UP_EFF:
                    RenderObject(o);
                    break;
                case MODEL_CURSEDTEMPLE_HOLYITEM:
                case MODEL_CURSEDTEMPLE_PRODECTION_SKILL:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_CURSEDTEMPLE_RESTRAINT_SKILL:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_SPEARSKILL:
                    RenderSkillSpear(o);
                    break;
                case BITMAP_FIRE_CURSEDLICH:
                    break;
                case MODEL_SUMMONER_WRISTRING_EFFECT:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_EQUIP_HEAD_SAHAMUTT:
                    if (o->SubType == 0)
                    {
                        RenderObject(o);
                    }
                    break;
                case MODEL_SUMMONER_EQUIP_HEAD_NEIL:
                    if (o->SubType == 0)
                    {
                        RenderObject(o);
                    }
                    break;
                case MODEL_SUMMONER_CASTING_EFFECT1:
                case MODEL_SUMMONER_CASTING_EFFECT11:
                case MODEL_SUMMONER_CASTING_EFFECT111:
                case MODEL_SUMMONER_CASTING_EFFECT2:
                case MODEL_SUMMONER_CASTING_EFFECT22:
                case MODEL_SUMMONER_CASTING_EFFECT222:
                case MODEL_SUMMONER_CASTING_EFFECT4:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_SUMMON_SAHAMUTT:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_SUMMON_NEIL:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_SUMMON_NEIL_NIFE1:
                case MODEL_SUMMONER_SUMMON_NEIL_NIFE2:
                case MODEL_SUMMONER_SUMMON_NEIL_NIFE3:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_SUMMON_NEIL_GROUND1:
                case MODEL_SUMMONER_SUMMON_NEIL_GROUND2:
                case MODEL_SUMMONER_SUMMON_NEIL_GROUND3:
                    RenderObject(o);
                    break;
                case MODEL_SUMMONER_SUMMON_LAGUL:
                    if (o->SubType == 1)
                    {
                        RenderObject(o);
                    }
                    break;
                case MODEL_EFFECT_BROKEN_ICE0:
                case MODEL_EFFECT_BROKEN_ICE1:
                case MODEL_EFFECT_BROKEN_ICE2:
                case MODEL_EFFECT_BROKEN_ICE3:
                    RenderObject(o);
                    break;
                case MODEL_SKILL_WHEEL1:
                    break;
                case MODEL_SKILL_WHEEL2:
                    RenderWheelWeapon(o);
                    break;
                case MODEL_SKILL_FURY_STRIKE:
                    RenderFuryStrike(o);
                    break;
                case MODEL_ARROW_HOLY:
                    break;
                case BITMAP_BOSS_LASER:
                case BITMAP_BOSS_LASER + 1:
                case BITMAP_BOSS_LASER + 2:
                {
                    vec3_t Position;
                    VectorCopy(o->Position, Position);
                    for (int j = 0; j < 20; j++)
                    {
                        if (o->SubType == 1)
                        {
                            // The update turned the beam once per segment; the turn this segment had.
                            const float angle = o->Angle[2] + (19 - j) * 0.1f * FPS_ANIMATION_FACTOR;
                            out.SetState({.blend = Blend::Glow});
                            out.DrawDecal(Decal(BITMAP_SMOKE, Position[0], Position[1], 4.0f, 4.0f, o->Light, -angle));
                            out.SetState({.blend = Blend::Off});
                        }

                        VectorAdd(Position, o->Direction, Position);

                        if (battleCastle::IsBattleCastleStart())
                        {
                            DWORD att = TERRAIN_ATTRIBUTE(Position[0], Position[1]);
                            if ((att & TW_NOATTACKZONE) == TW_NOATTACKZONE)
                            {
                                return;
                            }
                        }
                    }
                }
                break;

                case MODEL_GATE:
                case MODEL_GATE + 1:
                case MODEL_STONE_COFFIN:
                case MODEL_STONE_COFFIN + 1:
                case MODEL_STAFF_OF_DESTRUCTION:
                case MODEL_CLOUD:
                    RenderObject(o);
                    break;
                case MODEL_SHINE:
                    break;
                case MODEL_WAVE_FORCE:
                    RenderObject(o);
                    break;
                case MODEL_MAGIC_CAPSULE2:
                    RenderObject(o);
                    break;
                case MODEL_AIR_FORCE:
                case MODEL_PIER_PART:
                    RenderObject(o);
                    break;
                case MODEL_PIERCING2:
                    if (o->SubType == 1 || o->SubType == 2)
                        break;
                    RenderObject(o);
                    break;
                case MODEL_PIERCING:
                    if (o->SubType == 3)
                        break;
                    RenderObject(o);
                    break;
                case MODEL_TOWER_GATE_PLANE:
                {
                    RenderObject(o);

                    // Its mirror image above the gate.
                    OBJECT mirror = *o;
                    const Random::DrawnAs drawnAs(&mirror, o);
                    mirror.Position[2] = o->StartPosition[2] + 400.f - (o->Position[2] - o->StartPosition[2]);
                    RenderObject(&mirror);
                }
                break;

                case BATTLE_CASTLE_WALL1:
                case BATTLE_CASTLE_WALL2:
                case BATTLE_CASTLE_WALL3:
                case BATTLE_CASTLE_WALL4:
                    RenderObject(o);
                    break;
                case MODEL_FENRIR_THUNDER:
                    RenderObject(o);
                    break;
                case MODEL_FALL_STONE_EFFECT:
                    RenderObject(o);
                    break;
                case MODEL_FENRIR_FOOT_THUNDER:
                {
                    out.SetState({.blend = Blend::Glow});
                    out.DrawDecal(Decal(BITMAP_FENRIR_FOOT_THUNDER1 + (o->m_iAnimation % 5), o->Position[0],
                                        o->Position[1], 0.6f, 0.6f, o->Light));
                    out.SetState({.blend = Blend::Off});
                }
                break;
                case MODEL_TWINTAIL_EFFECT:
                {
                    if (o->SubType == 0)
                    {
                        out.SetState({.blend = Blend::Glow});
                        out.DrawDecal(Decal(BITMAP_SPARK + 1, o->Position[0], o->Position[1], o->Scale, o->Scale,
                                            o->Light, 0.f, o->Alpha));
                        out.SetState({.blend = Blend::Off});
                    }
                    else if (o->SubType == 1 || o->SubType == 2)
                    {
                        out.SetState({.blend = Blend::Glow});
                        out.DrawDecal(Decal(BITMAP_CLOUD, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light,
                                            o->Angle[0], o->Alpha));
                        out.SetState({.blend = Blend::Off});
                    }
                }
                break;
                case MODEL_CUNDUN_PART1:
                case MODEL_CUNDUN_PART2:
                case MODEL_CUNDUN_PART3:
                case MODEL_CUNDUN_PART4:
                case MODEL_CUNDUN_PART5:
                case MODEL_CUNDUN_PART6:
                case MODEL_CUNDUN_PART7:
                case MODEL_CUNDUN_PART8:
                case MODEL_ILLUSION_OF_KUNDUN:
                case MODEL_CUNDUN_DRAGON_HEAD:
                case MODEL_CUNDUN_PHOENIX:
                case MODEL_CUNDUN_GHOST:
                    RenderObject(o);
                    break;
                case MODEL_CURSEDTEMPLE_STATUE_PART1:
                case MODEL_CURSEDTEMPLE_STATUE_PART2:
                    RenderObject(o);
                    break;
                case MODEL_XMAS2008_SNOWMAN_HEAD:
                case MODEL_XMAS2008_SNOWMAN_BODY:
                    RenderObject(o);
                    break;
#ifdef PJH_ADD_PANDA_CHANGERING
                case MODEL_PANDA:
                    RenderObject(o);
                    break;
#endif //PJH_ADD_PANDA_CHANGERING
                case MODEL_TOTEMGOLEM_PART1:
                case MODEL_TOTEMGOLEM_PART2:
                case MODEL_TOTEMGOLEM_PART3:
                case MODEL_TOTEMGOLEM_PART4:
                case MODEL_TOTEMGOLEM_PART5:
                case MODEL_TOTEMGOLEM_PART6:
                    RenderObject(o);
                    break;
                case MODEL_SHADOW_PAWN_ANKLE_LEFT:		case MODEL_SHADOW_PAWN_ANKLE_RIGHT:
                case MODEL_SHADOW_PAWN_BELT:			case MODEL_SHADOW_PAWN_CHEST:
                case MODEL_SHADOW_PAWN_HELMET:
                case MODEL_SHADOW_PAWN_KNEE_LEFT:		case MODEL_SHADOW_PAWN_KNEE_RIGHT:
                case MODEL_SHADOW_PAWN_WRIST_LEFT:		case MODEL_SHADOW_PAWN_WRIST_RIGHT:

                case MODEL_SHADOW_KNIGHT_ANKLE_LEFT:	case MODEL_SHADOW_KNIGHT_ANKLE_RIGHT:
                case MODEL_SHADOW_KNIGHT_BELT:			case MODEL_SHADOW_KNIGHT_CHEST:
                case MODEL_SHADOW_KNIGHT_HELMET:
                case MODEL_SHADOW_KNIGHT_KNEE_LEFT:		case MODEL_SHADOW_KNIGHT_KNEE_RIGHT:
                case MODEL_SHADOW_KNIGHT_WRIST_LEFT:	case MODEL_SHADOW_KNIGHT_WRIST_RIGHT:

                case MODEL_SHADOW_ROOK_ANKLE_LEFT:		case MODEL_SHADOW_ROOK_ANKLE_RIGHT:
                case MODEL_SHADOW_ROOK_BELT:			case MODEL_SHADOW_ROOK_CHEST:
                case MODEL_SHADOW_ROOK_HELMET:
                case MODEL_SHADOW_ROOK_KNEE_LEFT:		case MODEL_SHADOW_ROOK_KNEE_RIGHT:
                case MODEL_SHADOW_ROOK_WRIST_LEFT:		case MODEL_SHADOW_ROOK_WRIST_RIGHT:

                case MODEL_ICE_GIANT_PART1:				case MODEL_ICE_GIANT_PART2:
                case MODEL_ICE_GIANT_PART3:				case MODEL_ICE_GIANT_PART4:
                case MODEL_ICE_GIANT_PART5:				case MODEL_ICE_GIANT_PART6:
                    RenderObject(o);
                    break;

                case MODEL_PROTECTGUILD:
                    RenderObject(o);
                    break;
                case MODEL_ARROW_AUTOLOAD:
                    if (o->SubType == 1) RenderObject(o);
                    break;

                case MODEL_INFINITY_ARROW:
                    if (o->SubType == 1) RenderObject(o);
                    break;

                case MODEL_INFINITY_ARROW1:
                case MODEL_INFINITY_ARROW2:
                case MODEL_INFINITY_ARROW3:
                case MODEL_INFINITY_ARROW4:
                    RenderObject(o);
                    break;

                case MODEL_ARROW_BEST_CROSSBOW:
                    RenderObject(o);
                    break;

                case MODEL_ALICE_BUFFSKILL_EFFECT:
                case MODEL_ALICE_BUFFSKILL_EFFECT2:
                {
                    if (o->SubType == 0 || o->SubType == 1 || o->SubType == 2)
                    {
                        RenderObject(o);
                    }
                }
                break;
                case MODEL_RAKLION_BOSS_CRACKEFFECT:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_RAKLION_BOSS_MAGIC:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_LAVAGIANT_FOOTPRINT_R:
                case MODEL_LAVAGIANT_FOOTPRINT_V:
                {
                    out.SetState({.blend = Blend::Glow});
                    if (o->Type == MODEL_LAVAGIANT_FOOTPRINT_R)
                    {
                        out.DrawDecal(Decal(BITMAP_LAVAGIANT_FOOTPRINT_R, o->Position[0], o->Position[1], o->Scale,
                                            o->Scale, o->Light));
                    }
                    else
                    {
                        out.DrawDecal(Decal(BITMAP_LAVAGIANT_FOOTPRINT_V, o->Position[0], o->Position[1], o->Scale,
                                            o->Scale, o->Light));
                    }
                    out.SetState({.blend = Blend::Off});
                }
                break;
#ifdef PBG_ADD_CHARACTERSLOT
                case MODEL_SLOT_LOCK:
                {
                    RenderObject(o);
                }
                break;
#endif //PBG_ADD_CHARACTERSLOT
                case MODEL_MOVE_TARGETPOSITION_EFFECT:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_EFFECT_SAPITRES_ATTACK_1:
                case MODEL_EFFECT_SAPITRES_ATTACK_2:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_BLOW_OF_DESTRUCTION:
                {
                    // Only its sprites show; the update spawns them.
                }
                break;
                case MODEL_NIGHTWATER_01:
                case MODEL_KNIGHT_PLANCRACK_A:
                case MODEL_KNIGHT_PLANCRACK_B:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_EFFECT_FLAME_STRIKE:
                {
                    if (o->SubType == 0)
                    {
                        const OBJECT* pObject = o;
                        BMD* pModel = &Models[pObject->Type];
                        const OBJECT* pOwner = pObject->Owner;
                        BMD* pOwnerModel = &Models[pOwner->Type];

                        vec3_t vPos, p;
                        Vector(0.0f, 0.0f, 0.0f, p);
                        pOwnerModel->RotationPosition(pOwner->BoneTransform[33], p, vPos);
                        VectorAdd(pOwner->Position, vPos, pModel->BodyOrigin);

                        OBB_t OBB;
                        vec3_t Temp;
                        pModel->Animation(BoneTransform, pObject->AnimationFrame, pObject->PriorAnimationFrame, pObject->PriorAction, pObject->Angle, pObject->Angle, true);
                        pModel->Transform(BoneTransform, Temp, Temp, &OBB, true);

                        BodyLight(pObject, pModel);
                        pModel->BodyScale = pObject->Scale;

                        pModel->RenderMesh(0, RENDER_TEXTURE | RENDER_BRIGHT, pObject->Alpha, 0, pObject->Alpha, pObject->BlendMeshTexCoordU, pObject->BlendMeshTexCoordV, -1);
                        float fV = (((int)(WorldTime * 0.05) % 16) / 4) * 0.25f;
                        pModel->RenderMesh(1, RENDER_TEXTURE | RENDER_BRIGHT, pObject->Alpha, 1, pObject->Alpha, pObject->BlendMeshTexCoordU, fV);
                    }
                }
                break;
                case BITMAP_LIGHT_MARKS:
                {
                    // Only its sprites show; the update spawns them.
                }
                break;
                case MODEL_SWELL_OF_MAGICPOWER_BUFF_EFF:
                {
                    // Only its sprites show; the update spawns them.
                }break;
                case MODEL_PROJECTILE:
                {
                    RenderObject(o);
                }
                break;

                case MODEL_DOOR_CRUSH_EFFECT_PIECE01:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE02:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE03:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE04:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE05:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE06:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE07:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE08:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE09:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE10:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE11:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE12:
                case MODEL_DOOR_CRUSH_EFFECT_PIECE13:
                case MODEL_STATUE_CRUSH_EFFECT_PIECE01:
                case MODEL_STATUE_CRUSH_EFFECT_PIECE02:
                case MODEL_STATUE_CRUSH_EFFECT_PIECE03:
                case MODEL_STATUE_CRUSH_EFFECT_PIECE04:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_:
                case MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_:
                case MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_:
                case MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_:
                case MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_:
                {
                    BMD* pBMDSwordModel = &Models[o->Type];

                    vec3_t* arrEachBoneTranslations = nullptr;
                    vec3_t			v3CurrentHighHierarchyNodePos;

                    if (true == o->ChromeEnable)
                    {
                        arrEachBoneTranslations = new vec3_t[pBMDSwordModel->NumBones];

                        BMD* pOwnerModel = &Models[o->Owner->Type];

                        int arrBoneIdxs[] = { 4, 2, 8, 10, 6 };		//INDEX.
                        int iBoneIdx = arrBoneIdxs[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
                        pBMDSwordModel->AnimationTransformWithAttachHighModel_usingGlobalTM(o->Owner, pOwnerModel, iBoneIdx, v3CurrentHighHierarchyNodePos, arrEachBoneTranslations, true);
                    }
                    else
                    {
                        pBMDSwordModel->BodyHeight = 0.f;
                        pBMDSwordModel->ContrastEnable = o->ContrastEnable;
                        BodyLight(o, pBMDSwordModel);
                        pBMDSwordModel->BodyScale = o->Scale;
                        pBMDSwordModel->CurrentAction = o->CurrentAction;
                        VectorCopy(o->Position, pBMDSwordModel->BodyOrigin);

                        pBMDSwordModel->Animation(BoneTransform, o->AnimationFrame, o->PriorAnimationFrame, o->PriorAction, o->Angle, o->HeadAngle, false, true);
                        pBMDSwordModel->Transform(BoneTransform, o->BoundingBoxMin, o->BoundingBoxMax, nullptr, false);
                    }

                    pBMDSwordModel->LightEnable = true;

                    Vector(1.0f, 1.0f, 1.0f, pBMDSwordModel->BodyLight);
                    pBMDSwordModel->RenderMesh(0, RENDER_TEXTURE, o->Alpha, o->BlendMesh, o->BlendMeshLight, o->BlendMeshTexCoordU, o->BlendMeshTexCoordV);

                    Vector(1.0f, 1.0f, 1.0f, pBMDSwordModel->BodyLight);
                    pBMDSwordModel->RenderMesh(1, RENDER_TEXTURE | RENDER_BRIGHT, o->Alpha, o->BlendMesh, o->BlendMeshLight, o->BlendMeshTexCoordU, o->BlendMeshTexCoordV);

                    Vector(0.2f, 0.2f, 1.0f, pBMDSwordModel->BodyLight);
                    pBMDSwordModel->RenderMesh(2, RENDER_TEXTURE | RENDER_BRIGHT, 1.0f, o->BlendMesh, o->BlendMeshLight,
                                               o->BlendMeshTexCoordU, o->BlendMeshTexCoordV);

                    delete[] arrEachBoneTranslations;
                }
                break;
                case MODEL_EMPIREGUARDIANBOSS_FRAMESTRIKE:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_EMPIREGUARDIAN_BLOW_OF_DESTRUCTION:
                {
                    // Only its sprites show; the update spawns them.
                }
                break;
                case BITMAP_WATERFALL_4:
                {
                    //CreateSprite(BITMAP_WATERFALL_4, o->Position, o->Scale, o->Light, o, o->Angle[0]);
                }
                break;
                case BITMAP_EVENT_CLOUD:
                {
                    out.SetState({.blend = Blend::Glow});
                    out.DrawDecal(Decal(BITMAP_EVENT_CLOUD, o->Position[0], o->Position[1], o->Scale, o->Scale,
                                        o->Light, o->Angle[0], o->Alpha));
                    out.SetState({.blend = Blend::Off});
                }
                break;
                case MODEL_SHOCKWAVE02:
                {
                    RenderObject(o);
                }
                break;
                case MODEL_DRAGON_LOWER_DUMMY:
                {
                    RenderObject(o);
                }
                break;
                case BITMAP_LIGHT_RED:
                {
                    vec3_t vLight;
                    VectorCopy(o->Light, vLight);
                    float fScale = 1.0f;
                    fScale = 3.5f;
                    Vector(1.0f, 1.0f, 1.0f, vLight);
                    float fFadeInOut = (float)(sinf(WorldTime * 0.0005f) + 1.0f) * 0.25f + 0.2f;
                    if (o->SubType == 3 || o->SubType == 4)
                    {
                        fScale = o->Scale;
                        fFadeInOut = o->LifeTime * 0.01f;
                    }
                    VectorScale(vLight, fFadeInOut, vLight);

                    if (o->SubType == 0)
                    {
                        out.SetState({.blend = Blend::Glow});
                        out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Owner->Position[0], o->Owner->Position[1], fScale,
                                            fScale, vLight, o->Angle[0], o->Alpha));
                        out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Owner->Position[0], o->Owner->Position[1], fScale,
                                            fScale, vLight, o->Angle[0], o->Alpha));
                        out.SetState({.blend = Blend::Off});
                    }
                    else if (o->SubType == 3)
                    {
                        out.SetState({.blend = Blend::Glow});
                        out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Owner->Position[0], o->Owner->Position[1], fScale,
                                            fScale, vLight, o->Angle[0], o->Alpha));
                        out.SetState({.blend = Blend::Off});
                    }
                    else if (o->SubType == 4)
                    {
                        out.SetState({.blend = Blend::Glow});
                        out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Position[0], o->Position[1], fScale, fScale, vLight,
                                            o->Angle[0], o->Alpha));
                        out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Position[0], o->Position[1], fScale, fScale, vLight,
                                            o->Angle[0], o->Alpha));
                        out.SetState({.blend = Blend::Off});
                    }

                }
                break;
                default:
                    if (o->Type >= MODEL_SKILL_BEGIN && o->Type < MODEL_SKILL_END)
                    {
                        RenderObject(o);
                    }
                    break;
                }
            }
        }
    }
}

// The jewel and edge lights of Gaion's swords, on the bones their draw poses them with.
static void SpawnGaionSwordLights(OBJECT* o)
{
    BMD* pBMDSwordModel = &Models[o->Type];
    static vec3_t arrEachBoneTranslations[MAX_BONES];
    if (o->ChromeEnable)
    {
        int arrBoneIdxs[] = {4, 2, 8, 10, 6};
        vec3_t v3CurrentHighHierarchyNodePos;
        pBMDSwordModel->AnimationTransformWithAttachHighModel(
            o->Owner, &Models[o->Owner->Type], arrBoneIdxs[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_],
            v3CurrentHighHierarchyNodePos, arrEachBoneTranslations);
    }
    else
    {
        pBMDSwordModel->AnimationTransformOnlySelf(arrEachBoneTranslations, o);
    }

    if (o->SubType != 20)
    {
        vec3_t vRelative, vLight;
        vec3_t vPos_SwordEffectRed01, vPos_SwordEffectRed02, vPos_SwordEffectEdge01, vPos_SwordEffectEdge02,
            vPos_SwordEffectEdge03, vPos_SwordEffectEdge04, vPos_SwordEffectEdge05, vPos_SwordEffectEdge06,
            vPos_SwordEffectEdge07, vPos_SwordEffectEdge08, vPos_SwordEffectEdge09;
        float fLumi1;
        int arrBoneIdxs_SwordEffectRed01[] = {2, 9, 1, 3, 10};    // SWORD MainEffect01 BoneINDEX.
        int arrBoneIdxs_SwordEffectRed02[] = {3, 10, 2, 10, 11};  // SWORD MainEffect02 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge01[] = {13, 13, 3, 4, 1};  // SWORD EdgeEffect01 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge02[] = {12, 6, 4, 12, 2};  // SWORD EdgeEffect02 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge03[] = {5, 1, 5, 2, 3};    // SWORD EdgeEffect03 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge04[] = {6, 7, 6, 9, 4};    // SWORD EdgeEffect04 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge05[] = {1, 2, 12, 5, 5};   // SWORD EdgeEffect05 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge06[] = {8, 4, 8, 7, 6};    // SWORD EdgeEffect06 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge07[] = {9, 3, 9, 6, 7};    // SWORD EdgeEffect07 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge08[] = {10, 11, 10, 8, 8}; // SWORD EdgeEffect08 BoneINDEX.
        int arrBoneIdxs_SwordEffectEdge09[] = {4, 8, 7, 1, 9};    // SWORD EdgeEffect09 BoneINDEX.
        // MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_
        // MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_
        // MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_
        // MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_
        // MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_

        int iBoneIdx_SwordEffectMain01 =
            arrBoneIdxs_SwordEffectRed01[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectMain02 =
            arrBoneIdxs_SwordEffectRed02[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];

        int iBoneIdx_SwordEffectEdge01 =
            arrBoneIdxs_SwordEffectEdge01[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge02 =
            arrBoneIdxs_SwordEffectEdge02[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge03 =
            arrBoneIdxs_SwordEffectEdge03[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge04 =
            arrBoneIdxs_SwordEffectEdge04[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge05 =
            arrBoneIdxs_SwordEffectEdge05[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge06 =
            arrBoneIdxs_SwordEffectEdge06[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge07 =
            arrBoneIdxs_SwordEffectEdge07[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge08 =
            arrBoneIdxs_SwordEffectEdge08[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];
        int iBoneIdx_SwordEffectEdge09 =
            arrBoneIdxs_SwordEffectEdge09[o->Type - MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_];

        fLumi1 = 1.0f;
        Vector(0.0f, 0.0f, 0.0f, vRelative);

        Vector(0.0f, 0.0f, 0.0f, vLight);

        // 2-2. 기본 Jewel Effect //
        Vector(fLumi1 * 1.0f, fLumi1 * 0.4f, fLumi1 * 0.1f, vLight);

        //			if( MODEL_MONSTER01+164 == o->Owner->Type )	// 2-3-1.
        {
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectMain01], vPos_SwordEffectRed01);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectMain02], vPos_SwordEffectRed02);
        }
        // 			else // 2-3-1. Effect를 통한 렌더의 경우.
        // 			{
        // 				pBMDSwordModel->TransformByObjectBone(vPos_SwordEffectRed01, o, iBoneIdx_SwordEffectMain01,
        // vRelative); 				pBMDSwordModel->TransformByObjectBone(vPos_SwordEffectRed02, o,
        // iBoneIdx_SwordEffectMain02, vRelative);
        // 			}

        CreateSprite(BITMAP_LIGHT_RED, vPos_SwordEffectRed01, 1.3f, vLight, o);
        CreateSprite(BITMAP_LIGHT_RED, vPos_SwordEffectRed02, 1.3f, vLight, o);
        // 2-2. 기본 Jewel Effect //

        // 2-3. 기본 Edge Effect
        {
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge01], vPos_SwordEffectEdge01);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge02], vPos_SwordEffectEdge02);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge03], vPos_SwordEffectEdge03);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge04], vPos_SwordEffectEdge04);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge05], vPos_SwordEffectEdge05);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge06], vPos_SwordEffectEdge06);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge07], vPos_SwordEffectEdge07);

            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge08], vPos_SwordEffectEdge08);
            VectorCopy(arrEachBoneTranslations[iBoneIdx_SwordEffectEdge09], vPos_SwordEffectEdge09);
        }

        Vector(fLumi1 * 0.3f, fLumi1 * 0.3f, fLumi1 * 1.0f, vLight);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge01, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge02, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge03, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge04, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge05, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge06, 1.5f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge07, 1.5f, vLight, o);

        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge08, 1.0f, vLight, o);
        CreateSprite(BITMAP_LIGHT, vPos_SwordEffectEdge09, 1.0f, vLight, o);
    }
}

// The sprites and steps of the effects RenderEffects draws, for the effects the last frame drew.
static void UpdateDrawnEffectSprites(OBJECT* o)
{
    switch (o->Type)
    {
    case MODEL_EFFECT_FLAME_STRIKE:
        // The flame is drawn and moved unturned.
        if (o->SubType == 0)
            Vector(0.0f, 0.0f, 0.0f, o->Angle);
        break;
    case MODEL_SKILL_WHEEL2:
        // The wheel spins faster each frame.
        o->Direction[2] -= (30) * FPS_ANIMATION_FACTOR;
        break;
    case MODEL_MOONHARVEST_MOON:
        if (o->SubType == 0)
        {
            vec3_t vLight;
            // (Shockwave)
            Vector(0.6f, 0.8f, 0.6f, vLight);
            o->m_iAnimation += REFERENCE_FRAME_STEP;
            CreateSprite(BITMAP_SHOCK_WAVE, o->Position, 0.8f, vLight, o, -(o->m_iAnimation * 3.f));
            // Flare1
            Vector(0.8f, 0.6f, 0.f, vLight);
            CreateSprite(BITMAP_LIGHT, o->Position, 5.0f, vLight, o, 0);
        }
        else if (o->SubType == 1)
        {
            CreateSprite(BITMAP_LIGHT, o->Position, 5.0f, o->Light, o, 0);
            CreateSprite(BITMAP_LIGHT, o->Position, 3.0f, o->Light, o, 0);
            CreateSprite(BITMAP_LIGHT, o->Position, 3.0f, o->Light, o, 0);
            CreateSprite(BITMAP_SHINY + 6, o->Position, 2.0f, o->Light, o, 0);
        }
        break;
    case MODEL_SUMMONER_SUMMON_LAGUL:
        if (o->SubType == 1)
        {
            BMD* pModel = &Models[o->Type];
            static vec34_t bones[MAX_BONES];
            pModel->Animation(bones, o->AnimationFrame, o->PriorAnimationFrame, o->PriorAction, o->Angle, o->HeadAngle,
                              false, false);
            vec3_t vPos, vLight, vZero = {0.f, 0.f, 0.f};

            const int nBoneCount = 6;
            int nBone[nBoneCount] = {54, 55, 56, 57, 58, 59};
            Vector(0.2f, 0.3f, 1.0f, vLight);
            for (int i = 0; i < nBoneCount; ++i)
            {
                pModel->TransformPosition(bones[nBone[i]], vZero, vPos, true);
                CreateSprite(BITMAP_SHINY + 6, vPos, o->Scale * 0.3f, vLight, NULL);
            }

            if (rand_fps_check(5))
            {
                int nBones = Models[o->Type].NumBones;
                pModel->TransformPosition(bones[Random::Rand() % nBones], vZero, vPos, true);
                Vector(0.6f, 0.5f, 0.9f, vLight);
                CreateParticle(BITMAP_SMOKE, vPos, o->Angle, vLight, 57, 2.0f);
                Vector(0.7f, 0.7f, 1.f, vLight);
                CreateParticle(BITMAP_TWINTAIL_WATER, vPos, o->Angle, vLight, 1);
            }
        }
        break;
    case BITMAP_BOSS_LASER:
    case BITMAP_BOSS_LASER + 1:
    case BITMAP_BOSS_LASER + 2:
    {
        vec3_t Position, Light;
        VectorCopy(o->Position, Position);
        for (int j = 0; j < 20; j++)
        {
            if (o->SubType == 1)
            {
                o->Angle[2] -= (0.1f) * FPS_ANIMATION_FACTOR;
                Vector(1.0f, 1.0f, 1.0f, Light);
                CreateSprite(BITMAP_FIRE + 1, Position, o->Scale, Light, o, o->Angle[2]);
            }
            else if (o->SubType == 2)
            {
                Vector(0.0f, 0.2f, 1.f, o->Light);
                o->Angle[2] -= (0.1f) * FPS_ANIMATION_FACTOR;
                CreateSprite(BITMAP_FIRE + 1, Position, o->Scale, o->Light, o, o->Angle[2]);
            }
            else
                CreateSprite(BITMAP_SPARK + 1, Position, o->Scale, o->Light, o);

            VectorAdd(Position, o->Direction, Position);
            if (battleCastle::IsBattleCastleStart() &&
                (TERRAIN_ATTRIBUTE(Position[0], Position[1]) & TW_NOATTACKZONE) == TW_NOATTACKZONE)
                break;
        }
        // The light the draw paints the beam's smoke with, and the terrain light below.
        if (o->SubType == 1)
            Vector(0.2f, 0.0f, 0.0f, o->Light);
        // The beam lights the terrain along its segments, up to a no-attack zone during a siege.
        VectorCopy(o->Position, Position);
        for (int j = 0; j < 20; j++)
        {
            VectorAdd(Position, o->Direction, Position);
            if (battleCastle::IsBattleCastleStart() &&
                (TERRAIN_ATTRIBUTE(Position[0], Position[1]) & TW_NOATTACKZONE) == TW_NOATTACKZONE)
                break;
            AddTerrainLight(Position[0], Position[1], o->Light, 2, PrimaryTerrainLight);
        }
    }
    break;
    case MODEL_BLOW_OF_DESTRUCTION:
    case MODEL_EMPIREGUARDIAN_BLOW_OF_DESTRUCTION:
        if (o->SubType == 0)
        {
            if (o->LifeTime <= 24)
            {
                vec3_t vLight, vPos;
                Vector(0.5f, 0.5f, 1.f, vLight);
                VectorCopy(o->Position, vPos);
                vPos[2] += 65.f;
                float fScale = (float)(Random::Rand() % 10 * 0.011f) + 3.f;
                CreateSprite(BITMAP_SWORD_EFFECT_MONO, vPos, fScale, vLight, NULL);
            }
        }
        else if (o->SubType == 1)
        {
            if (o->LifeTime <= 24)
            {
                vec3_t vLight, vPos;
                Vector(o->Light[0] * 0.5f, o->Light[1] * 0.5f, o->Light[2] * 1.0f, vLight);
                VectorCopy(o->Position, vPos);
                vPos[2] += 100.f;
                CreateSprite(BITMAP_LIGHT, vPos, o->Scale, vLight, NULL);
            }
        }
        break;
    case BITMAP_LIGHT_MARKS:
    {
        // The owner's model scaled for the owner, not for the character placed last.
        Models[o->Owner->Type].BodyScale = o->Owner->Scale;
        float fLight = 1.035f;
        if (o->LifeTime >= 35)
        {
            o->Light[0] *= pow(1.0f / (fLight), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (fLight), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (fLight), FPS_ANIMATION_FACTOR);
        }
        else
        {
            o->Light[0] *= pow(fLight, FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(fLight, FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(fLight, FPS_ANIMATION_FACTOR);
        }
        BMD* pModel = &Models[o->Owner->Type];
        vec3_t vPos;
        const int nBoneCount = 14;
        int nBone[nBoneCount] = {20, 20, 19, 18, 17, 2, 35, 26, 36, 27, 37, 28, 39, 30};
        float fScale[nBoneCount] = {1.5f, 1.5f, 0.6f, 1.1f, 0.9f, 0.8f, 0.6f, 0.6f, 0.8f, 0.8f, 0.8f, 0.8f, 0.7f, 0.7f};
        for (int i = 0; i < nBoneCount; ++i)
        {
            pModel->TransformByObjectBone(vPos, o->Owner, nBone[i]);
            CreateSprite(o->Type, vPos, o->Scale * fScale[i], o->Light, o->Owner);
        }
    }
    break;
    case MODEL_SWELL_OF_MAGICPOWER_BUFF_EFF:
    {
        if (o->SubType == 0)
        {
            BMD* pModel = &Models[o->Owner->Type];
            vec3_t vPos, vDLight;
            if (o->Owner->Type != MODEL_PLAYER)
                break;
            pModel->BodyScale = o->Owner->Scale;

            float fLumi = (absf((sinf(WorldTime * 0.001f))) + 0.2f) * 0.5f;
            // 							if( fLumi >= 0.5f)
            // 							{
            // 								fLumi = 0.5f;
            // 							}
            Vector(fLumi * 0.7f, fLumi * 0.3f, fLumi * 0.9f, vDLight);

            for (int i = 0; i < pModel->NumBones; i++)
            {
                pModel->TransformByObjectBone(vPos, o->Owner, i);

                CreateSprite(BITMAP_LIGHT, vPos, 1.8f, vDLight, o);
            }
        }
    }
    break;
    case MODEL_SWORDLEFT01_EMPIREGUARDIAN_BOSS_GAION_:
    case MODEL_SWORDLEFT02_EMPIREGUARDIAN_BOSS_GAION_:
    case MODEL_SWORDRIGHT01_EMPIREGUARDIAN_BOSS_GAION_:
    case MODEL_SWORDRIGHT02_EMPIREGUARDIAN_BOSS_GAION_:
    case MODEL_SWORDMAIN01_EMPIREGUARDIAN_BOSS_GAION_:
        SpawnGaionSwordLights(o);
        break;
    case BITMAP_LIGHT_RED:
        if (o->SubType == 0)
        {
            vec3_t Light, Angle;
            int arr[17] = {12, 17, 5, 10, 36, 27, 37, 28, 11, 35, 2, 3, 36, 20, 27, 4, 26};
            BMD* b = &Models[o->Owner->Type];
            b->BodyScale = o->Owner->Scale;
            vec3_t _vPos;
            Vector(0.f, 0.f, 0.f, Angle);

            for (int i = 0; i < 17; ++i)
            {
                float fFadeInOut = (float)(sinf(WorldTime * 0.01f) + 1.0f) * 0.25f + 0.2f;
                VectorCopy(o->Owner->Position, o->Position);
                Vector(1.0f, 1.0f, 1.0f, Light);

                if (i == 0 || i == 1 || i == 2)
                {
                    // Vector(0.0f, 0.0f, 15.0f, _vPos);
                    Vector(0.0f, 0.0f, 0.0f, _vPos);
                    b->TransformByObjectBone(_vPos, o->Owner, arr[i], _vPos);
                    VectorScale(Light, fFadeInOut, Light);
                    CreateSprite(BITMAP_LIGHT_RED, _vPos, 1.5f, Light, o);
                }
                else if (i == 5 || i == 12 || i == 7 || i == 8 || i == 9 || i == 14 || i == 15 || i == 16)
                {
                    // Vector(0.0f, 5.0f, 0.0f, _vPos);
                    Vector(0.0f, 0.0f, 0.0f, _vPos);
                    b->TransformByObjectBone(_vPos, o->Owner, arr[i], _vPos);
                    fFadeInOut = (float)(sinf(WorldTime * 0.005f) + 1.0f) * 0.25f + 0.5f;
                    VectorScale(Light, fFadeInOut, Light);
                    CreateSprite(BITMAP_LIGHT_RED, _vPos, 1.5f, Light, o);
                }
                else
                {
                    Vector(0.0f, 0.0f, 0.0f, _vPos);
                    b->TransformByObjectBone(_vPos, o->Owner, arr[i], _vPos);
                    fFadeInOut = (float)(sinf(WorldTime * 0.01f) + 1.0f) * 0.3f + 0.3f;
                    VectorScale(Light, fFadeInOut, Light);
                    CreateSprite(BITMAP_LIGHT_RED, _vPos, 1.5f, Light, o);
                }
            }
        }
        break;
    }
}

// The steps and spawns of the ground marks RenderEffectShadows draws, where the main scene draws them.
static void UpdateDrawnEffectShadowState(OBJECT* o)
{
    if (SceneFlag != MAIN_SCENE || g_pOption == nullptr || !g_pOption->GetRenderAllEffects())
        return;

    if (o->Type == BITMAP_LIGHTNING + 1)
    {
        o->Scale += (0.2f) * FPS_ANIMATION_FACTOR;
    }
    else if (o->Type == BITMAP_MAGIC && o->SubType == 1)
    {
        o->Light[0] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
        o->Light[1] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
        o->Light[2] *= pow(1.0f / (1.1f), FPS_ANIMATION_FACTOR);
        o->Scale += (0.05f) * FPS_ANIMATION_FACTOR;
    }
    else if (o->Type == BITMAP_MAGIC + 1)
    {
        if (o->SubType == 7)
        {
            VectorCopy(o->Owner->Position, o->Position);
            o->Angle[2] += (10.0f) * FPS_ANIMATION_FACTOR;
        }
        else if (o->SubType == 6 && (int)o->LifeTime % 25 == 0)
        {
            CreateEffect(BITMAP_MAGIC + 1, o->Position, o->Angle, o->Light, 7, o->Owner);
        }
        else if (o->SubType == 8 && (int)o->LifeTime % 2 == 0)
        {
            CreateEffect(BITMAP_MAGIC + 1, o->Position, o->Angle, o->Light, 9, o->Owner);
        }
        else if (o->SubType == 13)
        {
            o->Light[0] *= pow(1.0f / (1.05f), FPS_ANIMATION_FACTOR);
            o->Light[1] *= pow(1.0f / (1.05f), FPS_ANIMATION_FACTOR);
            o->Light[2] *= pow(1.0f / (1.05f), FPS_ANIMATION_FACTOR);
        }
    }
}

void UpdateEffectModelEffects()
{
    // Spawns once per culled frame, for the effects that frame drew, as when their draw spawned them.
    static unsigned int updatedFrame = 0;
    if (updatedFrame == s_effectCullFrame)
        return;
    updatedFrame = s_effectCullFrame;

    const int iEffectSize = MAX_EFFECTS + g_SkillEffects.GetSize();
    for (int i = 0; i < iEffectSize; ++i)
    {
        OBJECT* o = i < MAX_EFFECTS ? &Effects[i] : g_SkillEffects.GetEffect(i - MAX_EFFECTS);
        if (!o->Live || o->DrawnFrame != s_effectCullFrame)
            continue;
        if (o->Type >= MAX_MODELS)
        {
            UpdateDrawnEffectShadowState(o);
            UpdateDrawnEffectSprites(o);
            continue;
        }
        if (o->Type == MODEL_MULTI_SHOT1 || o->Type == MODEL_MULTI_SHOT2 || o->Type == MODEL_MULTI_SHOT3 ||
            o->Type == MODEL_DRAGON_LOWER_DUMMY)
        {
            // The extra, slower animation step their draw gave them.
            BMD* b = &Models[o->Type];
            b->CurrentAction = o->CurrentAction;
            b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, o->Velocity / 6.f,
                             o->Position, o->Angle);
        }
        UpdateDrawnObjectHold(o);
        PlaceObjectModel(o, &Models[o->Type]);
        UpdateRenderObjectEffects(o);
        UpdateDrawnEffectSprites(o);
    }
}

void RenderAfterEffects()
{
    if (!g_Direction.m_CKanturu.IsMayaScene())
        return;

    int iEffectSize = MAX_EFFECTS + g_SkillEffects.GetSize();
    for (int i = 0; i < iEffectSize; ++i)
    {
        const OBJECT* o;
        if (i < MAX_EFFECTS)
        {
            o = &Effects[i];
        }
        else
        {
            o = g_SkillEffects.GetEffect(i - MAX_EFFECTS);
        }
        // CullEffects marked it.
        if (o->Live && IsSentAfterCharacter(o))
        {
            if (o->Visible)
            {
                switch (o->Type)
                {
                case MODEL_STORM3:
                case MODEL_MAYASTAR:
                case MODEL_MAYAHANDSKILL:
                    RenderObject_AfterCharacter(o);
                }
            }
        }
    }
}

// The ground marks and rings an effect lays under itself.
void DescribeEffectShadow(const OBJECT& effect, Render::EffectDrawing::EffectDrawer& out)
{
    using namespace Render::EffectDrawing;
    const OBJECT* o = &effect;
    vec3_t Light;
    float Luminosity = (float)(Random::DrawRand(o, 1) % 4 + 8) * 0.1f;
    float Rotation, Scale;
    out.SetState({.blend = Blend::Glow});

    switch (o->Type)
    {
    case BITMAP_MAGIC:
        if (o->SubType == 1)
        {
            out.DrawDecal(
                Decal(BITMAP_MAGIC, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        else if (o->SubType == 8)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale * 0.8f, o->Scale * 0.8f, o->Light,
                                -o->Angle[2]));
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale * 1.2f, o->Scale * 1.2f, o->Light,
                                -o->Angle[2]));
        }
        else if (o->SubType == 9)
        {
            vec3_t vLight;
            Vector(o->Light[0] * o->Alpha, o->Light[1] * o->Alpha, o->Light[2] * o->Alpha, vLight);
            out.DrawDecal(Decal(BITMAP_SUMMON_IMPACT, o->Position[0], o->Position[1], o->Scale, o->Scale, vLight,
                                o->HeadAngle[1]));
            // RenderTerrainAlphaBitmap ( BITMAP_SUMMON_IMPACT, o->Position[0], o->Position[1], o->Scale*0.8f,
            // o->Scale*0.8f, vLight, o->HeadAngle[0] );
            out.DrawDecal(Decal(BITMAP_SUMMON_IMPACT, o->Position[0], o->Position[1], o->Scale * 1.2f, o->Scale * 1.2f,
                                vLight, o->HeadAngle[2]));
        }
        else if (o->SubType == 10)
        {
            out.SetState({.blend = Blend::Subtract});
            vec3_t vLight;
            Vector(o->Light[0] * o->Alpha, o->Light[1] * o->Alpha, o->Light[2] * o->Alpha, vLight);
            for (int i = 0; i < 5; ++i)
            {
                if (o->LifeTime < 3 && i > 0)
                    continue;
                else if (o->LifeTime < 6 && i > 1)
                    continue;
                else if (o->LifeTime < 9 && i > 2)
                    continue;
                else if (o->LifeTime < 12 && i > 3)
                    continue;
                else if (o->LifeTime < 16 && i > 4)
                    continue;
                out.DrawDecal(
                    Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], o->Scale, o->Scale, vLight, -o->Angle[2]));
            }
        }
        else if (o->SubType == 11)
        {
            vec3_t vLight;
            Vector(o->Light[0] * o->Alpha, o->Light[1] * o->Alpha, o->Light[2] * o->Alpha, vLight);
            out.DrawDecal(Decal(BITMAP_SUMMON_IMPACT, o->Position[0], o->Position[1], o->Scale, o->Scale, vLight,
                                o->HeadAngle[1]));
            out.DrawDecal(Decal(BITMAP_SUMMON_IMPACT, o->Position[0], o->Position[1], o->Scale * 1.2f, o->Scale * 1.2f,
                                vLight, o->HeadAngle[2]));
        }
        else if (o->SubType == 12)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        else if (o->SubType == 13 || o->SubType == 14)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        break;
    case BITMAP_MAGIC + 1:
        Luminosity = 1.f;
        if (o->LifeTime < 5)
        {
            Luminosity -= (float)(5 - o->LifeTime) * 0.2f;
        }
        else if (o->SubType == 7)
        {
            if (o->LifeTime > 30)
                Luminosity = (float)(40 - o->LifeTime) * 0.1f;
        }

        if (o->SubType == 4 || o->SubType == 10)
        {
            Scale = o->Scale; //(Random::Rand()%100)/100.f*4.f;
            if (Luminosity == 1.f)
            {
                Luminosity = sinf((60 - o->LifeTime) * 0.05f) * 1.f + 0.5f;
            }
        }
        else if (o->SubType == 6)
        {
            Scale = (80 - o->LifeTime) * 0.05f;
        }
        else if (o->SubType == 7)
        {
            Scale = (o->LifeTime) * 0.07f;
        }
        else if (o->SubType == 9)
        {
            Scale = o->Scale;
        }
        else if (o->SubType == 11)
        {
            Scale = (20 - o->LifeTime) * 0.15f;
        }
        else if (o->SubType == 12)
        {
            Scale = (20 - o->LifeTime) * 0.15f;
        }
        else if (o->SubType == 13)
        {
            Scale = o->Scale;
        }
        else
        {
            Scale = (20 - o->LifeTime) * 0.15f;
        }
        if (o->SubType != 5 && o->SubType != 6 && o->SubType != 8)
        {
            switch (o->SubType)
            {
            case 0:
                Vector(Luminosity * 0.4f, Luminosity * 0.6f, Luminosity * 1.f, Light);
                break;
            case 1:
                Vector(Luminosity * 0.4f, Luminosity * 0.6f, Luminosity * 1.f, Light);
                break;
            case 2:
                Vector(Luminosity * 0.4f, Luminosity * 1.f, Luminosity * 0.6f, Light);
                break;
            case 3:
                Vector(Luminosity * 1.f, Luminosity * 0.6f, Luminosity * 0.4f, Light);
                break;
            case 4:
                Vector(Luminosity * 1.f, Luminosity * 0.5f, Luminosity * 0.1f, Light);
                break;
            case 7:
                Vector(Luminosity * 0.9f, Luminosity * 0.4f, Luminosity * 0.2f, Light);
                break;
            case 9:
                Vector(Luminosity * 0.9f, Luminosity * 0.4f, Luminosity * 0.2f, Light);
                break;
            case 10:
                Vector(Luminosity * 0.1f, Luminosity * 0.5f, Luminosity * 1.f, Light);
                break;
            case 11:
                Vector(Luminosity * o->Light[0], Luminosity * o->Light[1], Luminosity * o->Light[2], Light);
                break;
            case 12:
                out.SetState({.blend = Blend::Subtract});
                Vector(Luminosity * o->Light[0], Luminosity * o->Light[1], Luminosity * o->Light[2], Light);
                break;
            case 13:
                Vector(o->Light[0], o->Light[1], o->Light[2], Light);
                break;
            }
            out.DrawDecal(Decal(BITMAP_MAGIC + 1, o->Position[0], o->Position[1], Scale, Scale, Light, -o->Angle[2]));
        }
        break;

    case BITMAP_FIRE_HIK2_MONO:
        if (o->SubType == 0)
        {
            Vector(Luminosity * 1.f, Luminosity * 1.0f, Luminosity * 1.0f, Light);
            out.DrawDecal(Decal(BITMAP_LIGHTNING + 1, o->Position[0], o->Position[1], 2.f, 2.f, Light, -o->Angle[2]));
        }
        break;

    case BITMAP_CLOUD:
        if (o->SubType == 0)
        {
            Vector(Luminosity * o->Light[0], Luminosity * o->Light[1], Luminosity * o->Light[2], Light);
            out.DrawDecal(Decal(BITMAP_CLOUD, o->Position[0], o->Position[1], o->Scale, o->Scale, Light, -o->Angle[2]));
        }
        break;
    case MODEL_RAKLION_BOSS_MAGIC:
    {
        if (o->SubType == 0)
        {
            Vector(Luminosity * 0.4f, Luminosity * 0.4f, Luminosity * 1.f, Light);
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 15.f, 15.f, Light, -o->Angle[2]));
            Vector(Luminosity * 1.0f, Luminosity * 1.0f, Luminosity * 1.f, Light);
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 5.f, 5.f, Light, -o->Angle[2]));
        }
    }
    break;
    case MODEL_EFFECT_BROKEN_ICE0:
    case MODEL_EFFECT_BROKEN_ICE1:
    case MODEL_EFFECT_BROKEN_ICE2:
    case MODEL_EFFECT_BROKEN_ICE3:
    {
        if (o->SubType == 1)
        {
            Vector(Luminosity * o->Light[0], Luminosity * o->Light[0], Luminosity * o->Light[0], Light);
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 5.f, 5.f, Light, -o->Angle[2]));
        }
    }
    break;
    case BITMAP_MAGIC + 2:
        out.SetState({.blend = Blend::Glow});
        Rotation = (int)WorldTime % 3600 / (float)10.f;

        Luminosity = 1.f;
        if (o->SubType != 2)
        {
            out.DrawCircle(Circle(BITMAP_MAGIC + 2, o->Position, 90.f, 130.f, 200.f, Rotation, 0.f, 0.f));
            out.DrawCircle(Circle(BITMAP_MAGIC + 2, o->Position, 90.f, 130.f, 200.f, -Rotation, 0.f, 0.f));

            if (o->LifeTime < 5)
                Luminosity -= (float)(5 - o->LifeTime) * 0.2f;
            Scale = (20 - o->LifeTime) * 0.15f;
        }
        else if (o->SubType == 2)
        {
            if (o->LifeTime > 10)
            {
                Scale = (20 - o->LifeTime) * 0.55f;
            }
            else
            {
                Luminosity -= (float)(10 - o->LifeTime) * 0.1f;
            }
        }
        Vector(Luminosity * 1.f, Luminosity * 0.4f, Luminosity * 0.2f, Light);
        out.DrawDecal(Decal(BITMAP_MAGIC + 1, o->Position[0], o->Position[1], Scale, Scale, Light, -o->Angle[2]));
        break;

    case BITMAP_MAGIC_ZIN:
    {
        vec3_t vLight;
        switch (o->SubType)
        {
        case 0:
            Vector(o->Light[0] * o->Alpha * 2.f, o->Light[1] * o->Alpha * 2.f, o->Light[2] * o->Alpha * 2.f, vLight);
            break;
        case 1:
            Vector(o->Light[0] * o->Alpha / 2.5f, o->Light[1] * o->Alpha / 2.5f, o->Light[2] * o->Alpha / 2.5f, vLight);
            break;
        case 2:
            Vector(o->Light[0] * o->Alpha, o->Light[1] * o->Alpha, o->Light[2] * o->Alpha, vLight);
            break;
        }
        out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, vLight, o->HeadAngle[1]));
    }
    break;

#ifdef ASG_ADD_INFLUENCE_GROUND_EFFECT
    case BITMAP_OUR_INFLUENCE_GROUND:
        if (o->SubType == 0)
        {
            vec3_t vLight;

            Vector(0.6f * o->Alpha, 0.9f * o->Alpha, 1.0f * o->Alpha, vLight);
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, vLight, 45.f));

            Vector(0.6f * o->AlphaTarget, 0.9f * o->AlphaTarget, 1.0f * o->AlphaTarget, vLight);
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], 0.8f, 0.8f, vLight, 45.f));

            Vector(0.2f * o->AlphaTarget, 0.8f * o->AlphaTarget, 1.0f * o->AlphaTarget, vLight);
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 2.0f, 2.0f, vLight));
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 2.0f, 2.0f, vLight));
        }
        break;

    case BITMAP_ENEMY_INFLUENCE_GROUND:
        if (o->SubType == 0)
        {
            vec3_t vLight;

            Vector(1.0f * o->Alpha, 0.3f * o->Alpha, 0.2f * o->Alpha, vLight);
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale * 1.6f, o->Scale * 1.6f, vLight));

            Vector(1.0f * o->AlphaTarget, 0.3f * o->AlphaTarget, 0.2f * o->AlphaTarget, vLight);
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], 1.15f, 1.15f, vLight));

            Vector(1.0f * o->AlphaTarget, 1.0f * o->AlphaTarget, 1.0f * o->AlphaTarget, vLight);
            out.DrawDecal(Decal(BITMAP_LIGHT_RED, o->Position[0], o->Position[1], 1.8f, 1.8f, vLight));
            Vector(1.0f * o->AlphaTarget, 0.0f * o->AlphaTarget, 0.0f * o->AlphaTarget, vLight);
            out.DrawDecal(Decal(BITMAP_LIGHT, o->Position[0], o->Position[1], 2.0f, 2.0f, vLight));
        }
        break;
#endif	// ASG_ADD_INFLUENCE_GROUND_EFFECT
    case BITMAP_FLAME:
        if (o->SubType != 3 && o->SubType != 6)
        {
            Luminosity = (float)(Random::DrawRand(o, 2) % 4 + 8) * 0.1f;
            Vector(Luminosity, Luminosity, Luminosity, Light);
            out.DrawDecal(Decal(BITMAP_FLAME, o->Position[0], o->Position[1], 2.f, 2.f, Light, -o->Angle[2]));
        }
        break;
    case BITMAP_LIGHTNING + 1:
        Luminosity = (float)(o->LifeTime) * 0.1f;
        Vector(Luminosity, Luminosity, Luminosity, Light);
        out.DrawDecal(
            Decal(BITMAP_LIGHTNING + 1, o->Position[0], o->Position[1], o->Scale, o->Scale, Light, -o->Angle[2]));
        break;
    case BITMAP_TWLIGHT:
    case BITMAP_SHOCK_WAVE:
        if (o->Type == BITMAP_SHOCK_WAVE && gMapManager.InHellas() && o->SubType != 6)
        {
            out.SetState({.depthMask = Toggle::Off});
            out.DrawDecal(
                WaterDecal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
            out.SetState({.depthMask = Toggle::On});
        }
        else
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        break;

    case BITMAP_DAMAGE_01_MONO:
        if (o->SubType == 0)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        else if (o->SubType == 1)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light, -o->Angle[2]));
        }
        break;

    case BITMAP_CRATER:
        out.SetState({.blend = Blend::AlphaTest});
        out.DrawDecal(
            Decal(o->Type, o->Position[0], o->Position[1], o->StartPosition[0], o->StartPosition[1], o->Light));
        break;
    case MODEL_BLOW_OF_DESTRUCTION:
        if (o->SubType == 0)
        {
            if (o->LifeTime <= 24)
            {
                out.DrawDecal(
                    Decal(BITMAP_FLARE_BLUE, o->Position[0], o->Position[1], 4.f, 4.f, o->Light, -o->Angle[2]));
            }
        }
        else if (o->SubType == 1)
        {
            if (o->LifeTime <= 24)
            {
                out.DrawDecal(
                    Decal(BITMAP_FLARE_BLUE, o->Position[0], o->Position[1], 6.f, 6.f, o->Light, -o->Angle[2]));
            }
        }
        break;
    case BITMAP_CHROME_ENERGY2:
        out.SetState({.blend = Blend::Glow});
        out.DrawDecal(
            Decal(o->Type, o->Position[0], o->Position[1], o->StartPosition[0], o->StartPosition[1], o->Light));
        break;
    case BITMAP_TARGET_POSITION_EFFECT1:
    {
        if (o->SubType == 0)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light));
        }
    }
    break;
    case BITMAP_TARGET_POSITION_EFFECT2:
    {
        if (o->SubType == 0)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light));
        }
    }
    break;
    case BITMAP_RING_OF_GRADATION:
    {
        if (o->SubType == 0)
        {
            out.DrawDecal(Decal(o->Type, o->Position[0], o->Position[1], o->Scale, o->Scale, o->Light));
        }
    }
    break;
    }
}

void RenderEffectShadows()
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    int iEffectSize = MAX_EFFECTS + g_SkillEffects.GetSize();
    for (int i = 0; i < iEffectSize; ++i)
    {
        const OBJECT* o;
        if (i < MAX_EFFECTS)
        {
            o = &Effects[i];
        }
        else
        {
            o = g_SkillEffects.GetEffect(i - MAX_EFFECTS);
        }
        if (o->Live)
        {
            if (o->Visible)
            {
                DescribeEffectShadow(*o, Render::EffectDrawing::ActiveEffectDrawer());
            }
        }
    }
}

void CreateMyGensInfluenceGroundEffect()
{
    DeleteEffect(BITMAP_OUR_INFLUENCE_GROUND, &Hero->Object, 0);
    if (::IsStrifeMap(gMapManager.WorldActive))
    {
        vec3_t vTemp = { 0.f, 0.f, 0.f };
        CreateEffect(BITMAP_OUR_INFLUENCE_GROUND, Hero->Object.Position, vTemp, vTemp, 0, &Hero->Object);
    }
}
