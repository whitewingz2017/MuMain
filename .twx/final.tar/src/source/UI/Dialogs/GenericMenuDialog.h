//*****************************************************************************
// File: GenericMenuDialog.h
//*****************************************************************************
#pragma once

#include "UI/Core/WindowObject.h"
#include "UI/RmlBridge/RmlThemedView.h"

#include <RmlUi/Core/Types.h>

#include <deque>
#include <functional>
#include <string>
#include <vector>

namespace Rml { class ElementDocument; }
namespace Rml { class Element; }

namespace mu::ui::window
{
    class CManager;

    // Config for one menu dialog. Passed by value to CGenericMenuDialog::Show() -- sibling
    // primitive to CGenericConfirmDialog/GenericDialogConfig, for native "N labeled action
    // buttons" dialogs (CSystemMenuMsgBox and similar, CustomMessageBox.cpp) instead of a plain
    // OK/Cancel confirm. Kept separate from GenericDialogConfig rather than folded in: an
    // arbitrary button list is a different shape from two fixed named slots
    // (primaryLabel/secondaryLabel), and native itself never needs both at once.
    struct GenericMenuConfig
    {
        std::wstring title; // optional heading row above `lines`. Empty = no title row.
        // The native box drew its title in its highlight colour instead of plain white (the
        // chaos-mix method menu); a theme may style it so.
        bool highlightTitle = false;

        struct Line
        {
            std::wstring text;
            bool bold = false;
            unsigned long color = 0; // native RGBA() line colour; 0 = the theme's own
        };
        std::vector<Line> lines; // optional description text above the buttons

        struct MenuButton
        {
            std::wstring label;
            std::wstring detail;
            std::wstring secondaryLabel, tertiaryLabel;
            std::function<void()> onSecondary, onTertiary;
            std::function<void()> onIncrement, onDecrement;
            std::function<std::wstring()> liveDetail; // Countdown text, sampled while the dialog is visible.
            Rml::String iconDecorator;
            std::wstring tooltip;          // optional hover text; empty = no tooltip
            std::vector<Line> lines;        // optional description text rendered directly above
                                            // this button (not the shared summary above) --
                                            // native dialogs like CChaosMixMenuMsgBox interleave a
                                            // few lines of body text with each individual button
                                            // rather than grouping all of it above the whole list
            bool enabled = true;            // forward-looking -- no current consumer disables a
                                            // button (the one native case that gates an action
                                            // does so server-side, not via a disabled button),
                                            // but it's a one-bool add worth reserving
            bool compact = false;           // true = native's smaller "Cancel/Exit" button style;
                                            // false = the larger action-button style
            bool narrow = false;            // MSGBOX_BTN_EMPTY_WIDTH (108) instead of the menus'
                                            // usual + 20 (CGemIntegrationMsgBox)
            bool linesBelow = false;        // `lines` sit under the button (CTrainerRecoverMsgBox)
            bool dismiss = false;           // only closes the menu, as Esc does; a theme with a
                                            // close action of its own may leave it out
            std::function<void(Rml::Element*)> syncIcon;
            std::function<void()> onClick;
        };
        std::vector<MenuButton> buttons; // 1..N, data-driven -- no hardcoded max

        // 0 = unspecified (today's default: buttons flow at their normal width, one per row in
        // every current consumer's fixed-width panel -- unchanged behavior). >0 = every button in
        // `buttons` that isn't `compact` is sized to fit exactly that many per row (see
        // generic_menu_dialog.rcss's own `.gmd-btn.cols-2`/`.gmd-button-cell.cols-2`), instead of
        // `compact` being (mis)used as a stand-in for "narrow enough to fit two per row" -- that
        // conflated two unrelated concerns (a small Close/Cancel-style button vs. a same-purpose
        // button grid). Only 2 is implemented (Gem Integration's 10-button jewel-type grid is the
        // only consumer so far); add a new `.cols-N` CSS class + a same-named MenuButtonEntry flag
        // in GenericMenuDialog.cpp the same way if a future consumer needs a different count.
        int columns = 0;

        // Which native box this menu replaces (CNewUIMessageBoxBase::Create's frame, and where
        // its RenderTexts() and buttons drew), by name: "chaos-mix", "npc-menu", ... A theme may
        // lay the menu out like that box, by kind (legacy does); empty = not described / flow.
        std::string kind;
        bool keepOpen = false; // Action buttons leave the menu visible; dismiss and Esc still close it.
        // Which menu this is, by name ("trainer", "seed-master", "personal-shop-price-type", ...):
        // for a theme to target one menu (data-id on the body). Unlike `kind`, it changes nothing
        // in the layout, so it also names menus no native box drew. Every caller sets it.
        std::string id;
        // The in-game system menu (native CSystemMenuMsgBox): a theme may lay it out like native.
        bool systemMenu = false;

        // Optional, fires on Esc. Decoupled from `buttons` (not "whichever button is last") so a
        // caller can't accidentally rely on button order for cancel semantics.
        std::function<void()> onCancel;
    };

    // Reusable RmlUi menu dialog -- one document/model, one instance, shown with different
    // GenericMenuConfig content per call. Sibling to CGenericConfirmDialog (UI/Dialogs/
    // GenericConfirmDialog.h): same single-active-instance-plus-queue shape, same dp-unit
    // centred panel, same per-theme RCSS fork convention -- but no foreground/
    // background document split (that split exists solely to solve item3D's compositing-order
    // problem; no native consumer of this primitive uses item3D), no native text-input widget
    // seam, no 3D render pass.
    class CGenericMenuDialog : public CObject
    {
    public:
        void Create(CManager* pMng);
        void Release();

        // Shows now if idle, otherwise queues (see class comment).
        void Show(GenericMenuConfig cfg);
        // Refreshes the same active kind, retaining icons for unchanged row labels; otherwise queues/shows.
        void ShowOrRefresh(GenericMenuConfig cfg);

        bool Render() override;
        bool Update() override;
        // Unconditionally claims input while shown -- a true modal, matching CMessageBoxMng's own
        // "return false while any box is open" contract.
        bool UpdateMouseEvent() override { return !IsVisible(); }
        bool UpdateKeyEvent() override;
        bool IsVisible() const override { return m_bActive; }
        // Same layer as CGenericConfirmDialog -- these dialogs are never shown simultaneously in
        // practice (both are modal, single-instance), so the exact relative order doesn't matter.
        float GetLayerDepth() override { return 60.0f; }
        // See CGenericConfirmDialog::GetKeyEventOrder()'s own comment for why this must be a HIGH
        // value, not low -- CManager::CompareKeyEventOrder sorts descending (highest runs first),
        // the opposite of what "first priority" suggests. 100.0f, matching that sibling exactly.
        float GetKeyEventOrder() override { return 100.0f; }

    private:
        void BuildRmlUi();
        void OnRmlBuilt();
        void SyncRmlModel();
        void SyncCanvasTop();
        void ShowNext();           // pops m_Queue (if non-empty) and opens the document
        std::function<void()> ButtonCallback(const GenericMenuConfig::MenuButton& button) const;
        void Resolve(int buttonIndex); // -1 = cancel; keepOpen actions invoke their callback in place.

        struct LineEntry
        {
            Rml::String text;
            bool bold = false;
            Rml::String color; // CSS colour of Line::color, empty for the theme's own
        };
        static LineEntry ToLineEntry(const GenericMenuConfig::Line& line);
        static bool SameLine(const LineEntry& a, const LineEntry& b);
        struct MenuButtonEntry
        {
            Rml::String label;
            Rml::String detail, iconDecorator;
            Rml::String secondaryLabel, tertiaryLabel;
            bool hasStepActions = false;
            Rml::String tooltip;
            std::vector<LineEntry> lines;
            bool hasLines = false;  // toggles .gmd-button-cell's extra bottom margin (RCSS)
            bool hasIcon = false;
            bool enabled = true;
            bool compact = false;
            bool cols2 = false;     // GenericMenuConfig::columns == 2 && !compact -- see its comment
            bool narrow = false;
            bool linesBelow = false;
            bool dismiss = false;
        };
        MenuButtonEntry ToButtonEntry(const GenericMenuConfig::MenuButton& button) const;
        struct GenericMenuRmlModel
        {
            bool hasTitle = false;
            bool isSystemMenu = false; // GenericMenuConfig::systemMenu
            // For a theme that gives the system menu its own heading and a close action.
            Rml::String systemMenuLabel;
            Rml::String closeLabel;
            bool highlightTitle = false;
            Rml::String kind;      // GenericMenuConfig::kind
            Rml::String id;        // GenericMenuConfig::id
            float canvasTop = 0.f; // UI::RmlBridge::DialogCanvasTop, in dp
            Rml::String title;
            std::vector<LineEntry> lines;
            std::vector<MenuButtonEntry> buttons;

            // window_shell's own positioning/dragging extension (added for CGenericMenuDialog's
            // sake as much as option_window.rml's -- the shared template requires every consumer's
            // model to carry these fields even if unused). Never set true here: this dialog stays
            // screen-centered, matching every native menu dialog it replaces.
            bool positioned = false;
            float rootX = 0.f;
            float rootY = 0.f;
        };
        void BindRmlModel(Rml::DataModelConstructor& c, GenericMenuRmlModel& model);
        void BindButtonEvents(Rml::DataModelConstructor& c);
        void SyncButtonIcons();
        UI::RmlBridge::ThemedView<GenericMenuRmlModel> m_RmlView{"generic_menu_dialog",
            [this](Rml::DataModelConstructor& c, GenericMenuRmlModel& model) { BindRmlModel(c, model); },
            {{"Data/Interface/RmlUi/generic_menu_dialog.rml"}},
            {.modal = Rml::ModalFlag::Modal, .focus = Rml::FocusFlag::Document,
             .afterBuild = [this] { OnRmlBuilt(); }}};

        bool m_bButtonClicked = false;
        int m_iClickedButtonIndex = -1;
        int m_iClickedButtonAction = 0;

        std::deque<GenericMenuConfig> m_Queue;
        GenericMenuConfig m_Active;
        bool m_bActive = false;
    };

    // Convenience global, same convention as g_pGenericConfirmDialog. Set once, in
    // CSystem::Create() (WindowSystem.cpp); never null after that point during normal play.
    extern CGenericMenuDialog* g_pGenericMenuDialog;
}
