//////////////////////////////////////////////////////////////////////////
//
//  GOBoid.cpp
//
//////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "Core/Utilities/Random.h"
#include "GameLogic/Pets/MountCompanions.h"
#include "GameLogic/Pets/MuunMounts.h"
#include "GameLogic/Cosmetics/CosmeticArmor.h"
#include "GameLogic/Cosmetics/FenrirMounts.h"
#include "Render/Models/FenrirMount.h"
#include "Engine/Object/ZzzInfomation.h"
#include "Render/Textures/ZzzOpenglUtil.h"
#include "Render/Models/ZzzBMD.h"
#include "GOBoid.h"
#include "Engine/Object/ZzzCharacter.h"
#include "Render/Terrain/ZzzLodTerrain.h"
#include "Render/Textures/ZzzTexture.h"
#include "Engine/AI/ZzzAI.h"
#include "Engine/AI/BirdLanding.h"
#include "Engine/AI/BoidSteering.h"
#include "Engine/Object/ObjectPose.h"
#include "Render/Effects/ZzzEffect.h"
#include "Engine/Object/ZzzOpenData.h"
#include "GameLogic/Events/CSChaosCastle.h"
#include "GameLogic/Events/Cinematic/CDirection.h"
#include "Audio/DSPlaySound.h"
#include "World/MapInfra/MapManager.h"
#include "Camera/CameraMove.h"
#include "UI/Core/WindowSystem.h"
#include "Scenes/MainScene.h"
#include "GameLogic/Items/ItemCategories.h"
#include "Render/Renderer/MuRenderer.h"

int EnableEvent = 0;

static  const   BYTE    BOID_FLY = 0;
static  const   BYTE    BOID_DOWN = 1;
static  const   BYTE    BOID_GROUND = 2;
static  const   BYTE    BOID_UP = 3;

// Actions of the bird and crow models.
static const int BIRD_ACTION_FLY = 0;
static const int BIRD_ACTION_GROUND = 1;

void DeleteMount(OBJECT* Owner)
{
    GameLogic::Cosmetics::FenrirMounts::Clear(Owner);
    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        OBJECT* o = &Mounts[i];
        if (o->Live)
        {
            if (o->Owner == Owner)
                o->Live = false;
        }
    }
}

bool IsMount(ITEM* pItem)
{
    if (pItem == NULL)
    {
        return false;
    }

    if (pItem->Type == ITEM_GUARDIAN_ANGEL
        || pItem->Type == ITEM_IMP
        || pItem->Type == ITEM_HORN_OF_UNIRIA
        || pItem->Type == ITEM_HORN_OF_DINORANT
        || GameLogic::Items::IsDarkLordPet(pItem)
        || GameLogic::Cosmetics::HelperBehaviorItem(pItem->Type) == ITEM_HORN_OF_FENRIR
        )
    {
        return true;
    }

    return false;
}

bool CreateMountSub(int Type, vec3_t Position, OBJECT* Owner, OBJECT* o, int SubType, int LinkBone)
{
    if (gMapManager.InChaosCastle() == true)
    {
        return false;
    }

    if (!o->Live)
    {
        o->Type = Type;
        o->Live = true;
        o->Visible = false;
        o->LightEnable = true;
        o->ContrastEnable = false;
        o->AlphaEnable = false;
        o->EnableBoneMatrix = false;
        o->Owner = Owner;
        o->SubType = SubType;
        o->HiddenMesh = -1;
        o->BlendMesh = -1;
        o->BlendMeshLight = 1.f;
        o->Scale = 0.7f;
        o->LifeTime = 30;
        o->Alpha = 0.f;
        o->AlphaTarget = 1.f;
        VectorCopy(Position, o->Position);
        VectorCopy(Owner->Angle, o->Angle);
        Vector(3.f, 3.f, 3.f, o->Light);

        //int AnimationFrame = Models[o->Type].NumAnimationKeys[Models[o->Type].CurrentAction];
        o->PriorAnimationFrame = 0.f;
        o->AnimationFrame = 0.f;
        o->Velocity = 0.5f;
        switch (o->Type)
        {
        case MODEL_FENRIR_BLACK:
        case MODEL_FENRIR_BLUE:
        case MODEL_FENRIR_RED:
        case MODEL_FENRIR_GOLD:
            o->Scale = 0.9f;
            break;
        case MODEL_DARK_HORSE:
            o->Scale = 1.f;
            break;
        case MODEL_PEGASUS:
        case MODEL_UNICON:
            o->Scale = 0.9f;
            break;
        case MODEL_HELPER:
            o->BlendMesh = 1;
            Vector(Owner->Position[0] + (float)(Random::Rand() % 512 - 256),
                   Owner->Position[1] + (float)(Random::Rand() % 512 - 256),
                   Owner->Position[2] + (float)(Random::Rand() % 128 + 128), o->Position);
            break;
        case MODEL_IMP:
            Vector(Owner->Position[0] + (float)(Random::Rand() % 128 - 64),
                   Owner->Position[1] + (float)(Random::Rand() % 128 - 64), Owner->Position[2], o->Position);
            o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]) + (float)(Random::Rand() % 100);
            break;
        }

        return FALSE;
    }

    return TRUE;
}

void CreateMount(int Type, vec3_t Position, OBJECT* Owner, int SubType, int LinkBone)
{
    if (gMapManager.InChaosCastle() == true) return;

    // A transformation ring keeps its wearer a player; the mount then follows on foot.
    if (Owner->Type != MODEL_PLAYER && Owner->Kind != KIND_PLAYER && Type != MODEL_HELPER)
        return;

    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        OBJECT* o = &Mounts[i];
        if (CreateMountSub(Type, Position, Owner, o, SubType, LinkBone) == FALSE)
        {
            // False means, it has been successful ...
            return;
        }
    }
}


// Advances a mount's animation by one frame at its own speed.
static void PlayMountAnimation(OBJECT* o)
{
    BMD* b = &Models[o->Type];
    b->CurrentAction = o->CurrentAction;
    b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, o->Velocity, o->Position, o->Angle);
}

bool MoveMount(OBJECT* o, bool bForceRender)
{
    if (o->Live)
    {
        if (SceneFlag == MAIN_SCENE)
        {
            if (gMapManager.WorldActive >= WD_65DOPPLEGANGER1 && gMapManager.WorldActive <= WD_68DOPPLEGANGER4);
            else
                if (!o->Owner->Live || o->Owner->Kind != KIND_PLAYER)
                {
                    o->Live = false;
                    return TRUE;
                }
        }

        Alpha(o);
        if (GameLogic::Pets::MountCompanions::FollowInTown(o, bForceRender))
        {
            // Following on foot skips the ride code below, which is where the frame normally advances.
            PlayMountAnimation(o);
            return true;
        }

        int     j;
        float   FlyRange = 0.0f;
        vec3_t  Light, Position;
        vec3_t  TargetPosition;
        BMD* b = &Models[o->Type];
        // The mount's own world pose, for the spawns below; the shared bones hold whatever was posed last.
        const auto bones = [o, b]
        {
            PlaceObjectModel(o, b);
            return Engine::Object::Pose::World(o, b);
        };

        VectorCopy(o->Owner->Position, TargetPosition);
        switch (o->Type)
        {
        case MODEL_FENRIR_BLACK:
        case MODEL_FENRIR_BLUE:
        case MODEL_FENRIR_RED:
        case MODEL_FENRIR_GOLD:
            if ((TerrainWall[TERRAIN_INDEX_REPEAT((int)(o->Owner->Position[0] / TERRAIN_SCALE), (int)(o->Owner->Position[1] / TERRAIN_SCALE))] & TW_SAFEZONE) == TW_SAFEZONE && bForceRender == FALSE)
            {
                o->Alpha = 0.f;
                break;
            }

            if (o->Owner->Teleport == TELEPORT_BEGIN || o->Owner->Teleport == TELEPORT)
            {
                // *FPS_ANIMATION_FACTOR -- was a fixed 0.1/call fade with no time basis, so the
                // teleport fade-out vanished N times faster at high/uncapped FPS than the ~10
                // frames it was tuned to take.
                o->Alpha -= 0.1f * FPS_ANIMATION_FACTOR;
                if (o->Alpha < 0) o->Alpha = 0.f;
            }
            else
            {
                o->Alpha = 1.f;
            }

            VectorCopy(o->Owner->HeadAngle, o->HeadAngle);
            VectorCopy(o->Owner->Position, o->Position);
            VectorCopy(o->Owner->Angle, o->Angle);
            GameLogic::Pets::MountCompanions::SyncFenrirRider(o);

            if ((o->Owner->CurrentAction >= PLAYER_FENRIR_ATTACK && o->Owner->CurrentAction <= PLAYER_FENRIR_ATTACK_BOW)
                || IsAliceRideAction_Fenrir(o->Owner->CurrentAction) == true
                || o->Owner->CurrentAction == PLAYER_RAGE_FENRIR_ATTACK_RIGHT)
            {
                SetAction(o, FENRIR_ATTACK);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_FENRIR_SKILL && o->Owner->CurrentAction <= PLAYER_FENRIR_SKILL_ONE_LEFT)
            {
                SetAction(o, FENRIR_ATTACK_SKILL);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_FENRIR_DAMAGE && o->Owner->CurrentAction <= PLAYER_FENRIR_DAMAGE_ONE_LEFT)
            {
                SetAction(o, FENRIR_DAMAGE);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_FENRIR_STAND && o->Owner->CurrentAction <= PLAYER_FENRIR_STAND_ONE_LEFT)
            {
                SetAction(o, FENRIR_STAND);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction == PLAYER_DIE1)
            {
                SetAction(o, FENRIR_STAND);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_RAGE_FENRIR_DAMAGE && o->Owner->CurrentAction <= PLAYER_RAGE_FENRIR_DAMAGE_ONE_LEFT)
            {
                SetAction(o, FENRIR_DAMAGE);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_RAGE_FENRIR && o->Owner->CurrentAction <= PLAYER_RAGE_FENRIR_ONE_LEFT)
            {
                SetAction(o, FENRIR_ATTACK_SKILL);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_RAGE_FENRIR_STAND && o->Owner->CurrentAction <= PLAYER_RAGE_FENRIR_STAND_ONE_LEFT)
            {
                SetAction(o, FENRIR_STAND);
                o->Velocity = 0.4f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_SKILL_THRUST && o->Owner->CurrentAction <= PLAYER_SKILL_HP_UP_OURFORCES)
            {
                SetAction(o, FENRIR_STAND);
                o->Velocity = 0.4f;
            }
            else
            {
                if (o->Owner->CurrentAction >= PLAYER_FENRIR_WALK && o->Owner->CurrentAction <= PLAYER_FENRIR_WALK_ONE_LEFT)
                {
                    SetAction(o, FENRIR_WALK);
                    o->Velocity = 1.0f;
                }
                else if (o->Owner->CurrentAction >= PLAYER_FENRIR_RUN && o->Owner->CurrentAction <= PLAYER_FENRIR_RUN_ONE_LEFT_ELF)
                {
                    SetAction(o, FENRIR_RUN);
                    o->Velocity = 0.6f;
                }
                else if (o->Owner->CurrentAction >= PLAYER_RAGE_FENRIR_RUN && o->Owner->CurrentAction <= PLAYER_RAGE_FENRIR_RUN_ONE_LEFT)
                {
                    SetAction(o, FENRIR_RUN);
                    o->Velocity = 0.6f;
                }
                else if (o->Owner->CurrentAction >= PLAYER_RAGE_FENRIR_WALK && o->Owner->CurrentAction <= PLAYER_RAGE_FENRIR_WALK_TWO_SWORD)
                {
                    SetAction(o, FENRIR_WALK);
                    o->Velocity = 1.0f;
                }

                Vector(1.f, 1.f, 1.f, Light);
                if (gMapManager.WorldActive == WD_10HEAVEN)
                {
                    bool   bWave = false;
                    vec3_t p = { 120.f, 0.f, 32.f };

                    if (o->AnimationFrame > 1.f && o->AnimationFrame < 1.2f)
                    {
                        b->TransformPosition(bones()[22], p, Position); // R Hand
                        Position[0] += 40.f;
                        bWave = true;
                    }
                    else if (o->AnimationFrame > 4.8f && o->AnimationFrame <= 5.0f)
                    {
                        b->TransformPosition(bones()[44], p, Position); // R Foot
                        Position[0] += 40.f;
                        Position[2] += 700.f;
                        bWave = true;
                    }

                    if (bWave && rand_fps_check(1))
                    {
                        Vector(Position[0], Position[1], Position[2], p);
                        CreateEffect(BITMAP_SHOCK_WAVE, p, o->Angle, Light, 1);

                        for (int i = 0; i < Random::Rand() % 5 + 5; ++i)
                        {
                            Vector(Position[0] + (float)(Random::Rand() % 50 - 25),
                                   Position[1] + (float)(Random::Rand() % 50 - 25),
                                   Position[2] + (float)(Random::Rand() % 16 - 8) - 10, p);
                            CreateParticle(BITMAP_SMOKE, p, o->Angle, Light);
                        }
                    }
                }
                else if (rand_fps_check(3) && !gMapManager.InHellas())
                {
                    if (o->Owner && !g_isCharacterBuff(o->Owner, eBuff_Cloaking))
                    {
                        Vector(o->Position[0] + (float)(Random::Rand() % 64 - 32),
                               o->Position[1] + (float)(Random::Rand() % 64 - 32),
                               o->Position[2] + (float)(Random::Rand() % 32 - 16), Position);
                        if (gMapManager.WorldActive == WD_2DEVIAS)
                            CreateParticle(BITMAP_SMOKE, Position, o->Angle, Light);
                        else if (gMapManager.WorldActive != WD_10HEAVEN)
                            if (!g_Direction.m_CKanturu.IsMayaScene())
                                CreateParticle(BITMAP_SMOKE + 1, Position, o->Angle, Light);
                    }
                }
            }
            break;
        case MODEL_DARK_HORSE:
            if ((TerrainWall[TERRAIN_INDEX_REPEAT((int)(o->Owner->Position[0] / TERRAIN_SCALE), (int)(o->Owner->Position[1] / TERRAIN_SCALE))] & TW_SAFEZONE) == TW_SAFEZONE
                && bForceRender == FALSE)
            {
                o->Alpha = 0.f;
                break;
            }

            b->BoneHead = 7;

            // Take riders position and angle:
            VectorCopy(o->Owner->HeadAngle, o->HeadAngle);
            VectorCopy(o->Owner->Position, o->Position);
            VectorCopy(o->Owner->Angle, o->Angle);

            if (o->Owner->CurrentAction == PLAYER_ATTACK_DARKHORSE)
            {
                SetAction(o, 3);
                o->Velocity = 0.34f;
            }
            else if (o->Owner->CurrentAction == PLAYER_RUN_RIDE_HORSE)
            {
                Vector(1.f, 1.f, 1.f, Light);

                SetAction(o, 1);
                if (gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                {
                    bool   bWave = false;
                    vec3_t p = {120.f, 0.f, Random::Rand() % 64 - 32.f};

                    if (o->AnimationFrame > 1.f && o->AnimationFrame < 1.2f)
                    {
                        b->TransformPosition(bones()[19], p, Position);
                        bWave = true;
                    }
                    else if (o->AnimationFrame > 1.1f && o->AnimationFrame < 1.4f)
                    {
                        b->TransformPosition(bones()[25], p, Position);
                        bWave = true;
                    }
                    else if (o->AnimationFrame > 1.3f && o->AnimationFrame < 1.6f)
                    {
                        b->TransformPosition(bones()[32], p, Position);
                        bWave = true;
                    }
                    else if (o->AnimationFrame > 1.5f && o->AnimationFrame <= 1.8f)
                    {
                        b->TransformPosition(bones()[38], p, Position);
                        bWave = true;
                    }

                    if (bWave)
                    {
                        Vector(Position[0] + (float)(Random::Rand() % 16 - 8),
                               Position[1] + (float)(Random::Rand() % 16 - 8), Position[2], p);
                        CreateEffect(BITMAP_SHOCK_WAVE, p, o->Angle, Light, 1);

                        for (int i = 0; i < Random::Rand() % 5 + 5; ++i)
                        {
                            Vector(Position[0] + (float)(Random::Rand() % 50 - 25),
                                   Position[1] + (float)(Random::Rand() % 50 - 25),
                                   Position[2] + (float)(Random::Rand() % 16 - 8) - 10, p);
                            CreateParticle(BITMAP_SMOKE, p, o->Angle, Light);
                        }
                    }
                }
                else if (rand_fps_check(2) && !gMapManager.InHellas())
                {
                    if (o->Owner && !g_isCharacterBuff(o->Owner, eBuff_Cloaking))
                    {
                        // Smoke at the back feet of the horse.
                        Vector(o->Position[0] + (float)(Random::Rand() % 64 - 32),
                               o->Position[1] + (float)(Random::Rand() % 64 - 32),
                               o->Position[2] + (float)(Random::Rand() % 32 - 16), Position);

                        if (gMapManager.WorldActive == WD_2DEVIAS)
                            CreateParticle(BITMAP_SMOKE, Position, o->Angle, Light);
                        else if (gMapManager.WorldActive != WD_10HEAVEN && !g_Direction.m_CKanturu.IsMayaScene())
                            CreateParticle(BITMAP_SMOKE + 1, Position, o->Angle, Light);
                    }
                }

                o->Velocity = 0.34f;
            }
            else if (o->Owner->CurrentAction >= PLAYER_ATTACK_RIDE_STRIKE && o->Owner->CurrentAction <= PLAYER_ATTACK_RIDE_ATTACK_MAGIC)
            {
                SetAction(o, 2);
                o->Velocity = 0.34f;
            }
            else if (o->Owner->CurrentAction == PLAYER_IDLE1_DARKHORSE)
            {
                SetAction(o, 5);
                o->Velocity = 1.0f;
            }
            else if (o->Owner->CurrentAction == PLAYER_IDLE2_DARKHORSE)
            {
                SetAction(o, 6);
                o->Velocity = 1.0f;
            }
            else
            {
                SetAction(o, 0);
                o->WeaponLevel = 0;
                o->Velocity = 0.3f;
            }

            // Breathing smoke/bubbles:
            //if (o->CurrentAction != 1)
            {
                if (o->Owner && !g_isCharacterBuff(o->Owner, eBuff_Cloaking))
                {
                    if (rand_fps_check(3))
                    {
                        vec3_t p = { 50.f, -4.f, 0.f };
                        b->TransformPosition(bones()[27], p, Position);

                        if (gMapManager.WorldActive == WD_7ATLANSE || gMapManager.WorldActive == WD_67DOPPLEGANGER3)
                        {
                            CreateParticle(BITMAP_BUBBLE, Position, o->Angle, o->Light);
                        }
                        else
                        {
                            CreateParticle(BITMAP_SMOKE, Position, o->Angle, o->Light);
                        }
                    }
                }
            }

            if (o->CurrentAction == 3)
            {
                vec3_t Pos1, Pos2, p, p2;

                Vector(60.f, 0.f, 0.f, Pos1);
                Vector(0.f, 0.f, 0.f, Pos2);
                Vector(1.f, 1.f, 1.f, Light);
                b->TransformPosition(bones()[9], Pos1, p);
                b->TransformPosition(bones()[9], Pos2, p2);
                CreateBlur(Hero, p, p2, Light, 0);
            }

            if (o->CurrentAction == 3)
            {
                UpdateDarkHorseSkill(o, b);
            }

            if (o->Owner->ExtState == 1)
            {
                vec3_t p;
                vec3_t Angle = { 0.f, 0.f, 0.f };
                float  Matrix[3][4];

                Vector(0.f, 50, 0.f, p);
                for (int i = 0; i < 4; ++i)
                {
                    Angle[2] += 90.f;
                    AngleMatrix(Angle, Matrix);
                    VectorRotate(p, Matrix, Position);
                    VectorAdd(Position, o->Position, Position);

                    for (int j = 0; j < 3; ++j)
                    {
                        CreateJoint(BITMAP_FLARE, Position, Position, Angle, 0, o, 40, 2);
                    }
                }
            }
            else if (o->Owner->ExtState == 2)
            {
            }
            o->Owner->ExtState = 0;

            o->Live = o->Owner->Live;
            break;
        case MODEL_PEGASUS:
        case MODEL_UNICON:
            if ((TerrainWall[TERRAIN_INDEX_REPEAT((int)(o->Owner->Position[0] / TERRAIN_SCALE), (int)(o->Owner->Position[1] / TERRAIN_SCALE))] & TW_SAFEZONE) == TW_SAFEZONE
                && bForceRender == FALSE)
            {
                o->Alpha = 0.f;
                break;
            }

            if (o->Owner->Teleport == TELEPORT_BEGIN || o->Owner->Teleport == TELEPORT)
            {
                // *FPS_ANIMATION_FACTOR -- was a fixed 0.1/call fade with no time basis, so the
                // teleport fade-out vanished N times faster at high/uncapped FPS than the ~10
                // frames it was tuned to take.
                o->Alpha -= 0.1f * FPS_ANIMATION_FACTOR;
                if (o->Alpha < 0) o->Alpha = 0.f;
            }
            else
            {
                o->Alpha = 1.f;
            }

            VectorCopy(o->Owner->Position, o->Position);

            if (o->Type == MODEL_PEGASUS)
            {
                if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                    o->Position[2] -= 10.f;
                else if (gMapManager.WorldActive != -1)
                    o->Position[2] -= 30.f;
            }
            VectorCopy(o->Owner->Angle, o->Angle);
            if (o->Owner->CurrentAction >= PLAYER_WALK_MALE && o->Owner->CurrentAction <= PLAYER_RUN_RIDE_WEAPON
                || o->Owner->CurrentAction == PLAYER_FLY_RIDE || o->Owner->CurrentAction == PLAYER_FLY_RIDE_WEAPON
                || o->Owner->CurrentAction == PLAYER_RAGE_UNI_RUN || o->Owner->CurrentAction == PLAYER_RAGE_UNI_RUN_ONE_RIGHT)
            {
                //  페가수스.
                if (o->Type == MODEL_PEGASUS)
                {
                    if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                        SetAction(o, 3);
                    else
                        SetAction(o, 2);
                }
                else
                {
                    SetAction(o, 2);
                }

                if (rand_fps_check(2) && gMapManager.WorldActive != WD_10HEAVEN)
                {
                    if (!g_Direction.m_CKanturu.IsMayaScene())

                        if (o->Owner && !g_isCharacterBuff(o->Owner, eBuff_Cloaking))
                        {
                            Vector(1.f, 1.f, 1.f, Light);
                            Vector(o->Position[0] + (float)(Random::Rand() % 64 - 32),
                                   o->Position[1] + (float)(Random::Rand() % 64 - 32),
                                   o->Position[2] + (float)(Random::Rand() % 32 - 16), Position);
                            if (gMapManager.WorldActive == 2)
                                CreateParticle(BITMAP_SMOKE, Position, o->Angle, Light);
                            else
                                CreateParticle(BITMAP_SMOKE + 1, Position, o->Angle, Light);
                        }
                }
            }
            else if (o->Owner->CurrentAction == PLAYER_SKILL_RIDER || o->Owner->CurrentAction == PLAYER_SKILL_RIDER_FLY)
            {
                if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                    SetAction(o, 7);
                else
                    SetAction(o, 6);
            }
            else if ((o->Owner->CurrentAction >= PLAYER_ATTACK_FIST && o->Owner->CurrentAction <= PLAYER_ATTACK_RIDE_CROSSBOW)
                || IsAliceRideAction_UniDino(o->Owner->CurrentAction) == true
                )
            {
                if (o->Type == MODEL_PEGASUS)
                {
                    if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                        SetAction(o, 5);
                    else
                        SetAction(o, 4);
                }
                else
                {
                    SetAction(o, 3);
                }
            }
            else
            {
                if (o->Type == MODEL_PEGASUS)
                {
                    if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.WorldActive == WD_10HEAVEN || g_Direction.m_CKanturu.IsMayaScene())
                        SetAction(o, 1);
                    else
                        SetAction(o, 0);
                }
                else
                {
                    SetAction(o, 0);
                }
            }
            o->Velocity = 0.34f;
            o->Live = o->Owner->Live;
            break;
        case MODEL_BUTTERFLY01:
            FlyRange = 100.f;
            Vector(0.4f, 0.6f, 1.f, Light);
            if (rand_fps_check(2))
                CreateParticle(BITMAP_SMOKE, o->Position, o->Angle, Light, 1);
            break;
        case MODEL_HELPER:
            if (o->Owner && !g_isCharacterBuff(o->Owner, eBuff_Cloaking))
            {
                FlyRange = 150.f;
                vec3_t Position, Light;
                Vector(0.4f, 0.4f, 0.4f, Light);
                if (rand_fps_check(1))
                {
                    for (j = 0; j < 4; j++)
                    {
                        Vector((float)(Random::Rand() % 16 - 8), (float)(Random::Rand() % 16 - 8),
                               (float)(Random::Rand() % 16 - 8), Position);
                        VectorAdd(Position, o->Position, Position);
                        CreateParticle(BITMAP_SPARK, Position, o->Angle, Light, 1);
                    }
                }
            }
        case MODEL_IMP:
            FlyRange = 150.f;
            break;
        }
        b->CurrentAction = o->CurrentAction;

        PlayMountAnimation(o);

        if (o->Type == MODEL_HELPER || o->Type == MODEL_IMP)
        {
            vec3_t Range;
            VectorSubtract(TargetPosition, o->Position, Range);
            float Distance = Range[0] * Range[0] + Range[1] * Range[1];
            if (Distance >= FlyRange * FlyRange)
            {
                float Angle = CreateAngle(o->Position[0], o->Position[1], TargetPosition[0], TargetPosition[1]);
                o->Angle[2] = TurnAngle2(o->Angle[2], Angle, 20.f);
            }
            AngleMatrix(o->Angle, o->Matrix);
            vec3_t Direction;
            VectorRotate(o->Direction, o->Matrix, Direction);
            VectorAddScaled(o->Position, Direction, o->Position, FPS_ANIMATION_FACTOR);
            o->Position[2] += (float)(Random::Rand() % 16 - 8);
            if (rand_fps_check(32))
            {
                float Speed = 0;
                if (Distance >= FlyRange * FlyRange)
                    Speed = -(float)(Random::Rand() % 64 + 128) * 0.1f;
                else
                {
                    Speed = -(float)(Random::Rand() % 64 + 16) * 0.1f;
                    o->Angle[2] = (float)(Random::Rand() % 360);
                }
                o->Direction[0] = 0.f;
                o->Direction[1] = Speed;
                o->Direction[2] = (float)(Random::Rand() % 64 - 32) * 0.1f;
            }
            if (o->Position[2] < o->Owner->Position[2] + 100.f)
                o->Direction[2] += 1.5f * FPS_ANIMATION_FACTOR;
            if (o->Position[2] > o->Owner->Position[2] + 200.f)
                o->Direction[2] -= 1.5f * FPS_ANIMATION_FACTOR;
        }
    }
    return TRUE;
}
void MoveMounts()
{
    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        OBJECT* o = &Mounts[i];
        if (MoveMount(o) == FALSE) return;
    }
}

static unsigned int s_mountCullFrame = 0;

// Whether the mount draws at all, for its rider.
static bool IsMountDrawn(const OBJECT* o)
{
    return o->Owner->Type == MODEL_PLAYER || o->Owner->Kind == KIND_PLAYER || o->Type == MODEL_HELPER;
}

void CullMounts()
{
    ++s_mountCullFrame;
    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        OBJECT* o = &Mounts[i];
        if (!o->Live)
            continue;
        o->Visible = TestFrustrum2D(o->Position[0] * 0.01f, o->Position[1] * 0.01f, -20.f);
        if (!o->Visible || !IsMountDrawn(o))
            continue;

        if (GameLogic::Pets::MountCompanions::InTown(o))
        {
            // A town companion keeps the scale its follow gave it.
        }
        else if (SceneFlag == CHARACTER_SCENE)
            o->Scale = 1.2f;
        else if (o->Type != MODEL_FENRIR_BLACK && o->Type != MODEL_FENRIR_BLUE && o->Type != MODEL_FENRIR_RED &&
                 o->Type != MODEL_FENRIR_GOLD)
            o->Scale = 1.0f;
        o->DrawnFrame = s_mountCullFrame;
    }
}

bool RenderMount(const OBJECT* o, bool bForceRender)
{
    // A rider on a Muun mount leaves the regular mount undrawn.
    if (!bForceRender && SceneFlag == MAIN_SCENE && GameLogic::Pets::MuunMounts::IsRiding(o->Owner))
        return TRUE;
    // A forced mount (a preview's) draws wherever it stands, at the scale its owner gave it.
    if (!o->Live || (!bForceRender && !o->Visible) || !IsMountDrawn(o))
        return TRUE;

    int State = 0;
    if (g_isCharacterBuff(o->Owner, eBuff_Cloaking))
    {
        State = 10;
    }
    if (!Render::Models::FenrirMount::Draw(const_cast<OBJECT*>(o), State))
        RenderObject(o, false, 0, State);
    return TRUE;
}

void RenderMount()
{
    // Like their riders, mounts keep their Classic look: no bloom from them.
    const mu::ScopedBloomExclusion classicMounts;
    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        const OBJECT* o = &Mounts[i];
        if (RenderMount(o) == FALSE)
        {
            return;
        }
    }
}

void UpdateMountEffects()
{
    // Spawns once per culled frame, for the mounts that frame drew, as when the draw spawned them.
    static unsigned int updatedFrame = 0;
    if (updatedFrame == s_mountCullFrame)
        return;
    updatedFrame = s_mountCullFrame;

    for (int i = 0; i < MAX_MOUNTS; i++)
    {
        OBJECT* o = &Mounts[i];
        if (!o->Live || o->DrawnFrame != s_mountCullFrame)
            continue;
        UpdateDrawnMountEffects(o);
    }
}

void UpdateDrawnMountEffects(OBJECT* o)
{
    UpdateDrawnObjectHold(o);
    // Like their draws, the mounts' sprites stay out of the bloom.
    const mu::ScopedBloomExclusion classicMounts;
    if (o->Type == MODEL_HELPER)
    {
        vec3_t Light;
        const float Luminosity = (float)(Random::Rand() % 30 + 70) * 0.01f;
        Vector(Luminosity * 0.5f, Luminosity * 0.8f, Luminosity * 0.6f, Light);
        CreateSprite(BITMAP_LIGHT, o->Position, 1.f, Light, o);
    }
    // A cloaked rider's mount draws only as a faint outline (Draw_RenderObject's ExtraMon 10), with no effects.
    if (g_isCharacterBuff(o->Owner, eBuff_Cloaking))
        return;
    PlaceObjectModel(o, &Models[o->Type]);
    UpdateRenderObjectEffects(o);
}

constexpr float HorseEffectInterval = 10 * (1000.f / 25.f); // every 10 frames on a 25fps basis (400 ms)

void UpdateDarkHorseSkill(OBJECT* o, BMD* b)
{
    if (o == NULL)	return;
    if (b == NULL)	return;

    // The weapon level is misused here to count the reference frames of this effect.
    o->WeaponLevel += REFERENCE_FRAME_STEP;

    if (o->LastHorseWaveEffect < WorldTime - HorseEffectInterval)
    {
        CreateEffect(BITMAP_SHOCK_WAVE, o->Position, o->Angle, o->Light);
        o->LastHorseWaveEffect = WorldTime;
    }

    if (o->AnimationFrame >= 8.f && o->AnimationFrame <= 9.5f)
    {
        if (REFERENCE_FRAME_STEP > 0 && (o->WeaponLevel % 2) == 1)
        {
            float  Matrix[3][4];
            vec3_t Angle, p, Position;
            Vector(0.f, 150.f * (o->WeaponLevel / 2), 0.f, p);
            Vector(0.f, 0.f, (float)(Random::Rand() % 360), Angle);
            for (int i = 0; i < 6; ++i)
            {
                Angle[2] += 60.f;
                AngleMatrix(Angle, Matrix);
                VectorRotate(p, Matrix, Position);
                VectorAdd(o->Position, Position, Position);

                CreateEffect(MODEL_GROUND_STONE + Random::Rand() % 2, Position, o->Angle, o->Light);
            }
        }
        SetEarthQuakeAt(o->Position, (Random::Rand() % 3 - 3) * 0.7f);
    }
    else if (o->WeaponLevel == 19)
    {
        CreateEffect(MODEL_SKILL_FURY_STRIKE, o->Position, o->Angle, o->Light, 0, o, -1, 0, 2);
        o->WeaponLevel = -3;
    }
}

void SpawnSkillEarthQuake(CHARACTER* c, OBJECT* o, BMD* b, int iMaxSkill)
{
    if (c == NULL)	return;
    if (o == NULL)	return;
    if (b == NULL)	return;

    float  Matrix[3][4];
    vec3_t Angle, p, Position;
    OBJECT& TargetO = CharactersClient[c->TargetCharacter].Object;

    // The weapon level counts reference frames; each value lasts one of them.
    if (REFERENCE_FRAME_STEP == 0)
    {
        return;
    }
    o->WeaponLevel++;

    //if ( o->WeaponLevel >= 6 && o->WeaponLevel <= 8 )
    if (o->WeaponLevel == iMaxSkill - 2 ||
        o->WeaponLevel == iMaxSkill - 1 ||
        o->WeaponLevel == iMaxSkill - 0)
    {
        Vector(0.f, 40.f * (o->WeaponLevel / 2), 0.f, p);
        Vector(0.f, 0.f, (float)(Random::Rand() % 360), Angle);
        for (int i = 0; i < 6; ++i)
        {
            Angle[2] += 60.f;
            AngleMatrix(Angle, Matrix);
            VectorRotate(p, Matrix, Position);
            VectorAdd(TargetO.Position, Position, Position);

            int iCurrentStone = MODEL_GROUND_STONE;

            CreateEffect(iCurrentStone + 1, Position, TargetO.Angle, TargetO.Light);
        }
    }

    if (o->WeaponLevel == iMaxSkill - 1)
    {
        SetEarthQuakeAt(o->Position, (Random::Rand() % 3 - 3) * 0.7f);
        CreateEffect(MODEL_SKILL_FURY_STRIKE, TargetO.Position, TargetO.Angle, TargetO.Light, 0, o, -1, 0, 2);
    }

    if (o->WeaponLevel > iMaxSkill)
    {
        o->WeaponLevel = 0;
    }
}

void DeleteBoids()
{
    for (int i = 0; i < MAX_BOIDS; i++)
    {
        OBJECT* o = &Boids[i];
        o->Live = false;
    }
}

int CreateDragon(OBJECT* o, int index)
{
    if (gMapManager.WorldActive != WD_10HEAVEN) return 0;

    if (index < 3)
    {
        o->Live = true;
        OpenMonsterModel(MONSTER_MODEL_DRAGON);
        o->Type = MODEL_DRAGON_;
        o->Scale = (float)(Random::Rand() % 3 + 6) * 0.05f;
        o->Alpha = 1.f;
        o->AlphaTarget = o->Alpha;
        o->Velocity = (float)(Random::Rand() % 10 + 10) * 0.02f;
        o->Gravity = (float)(Random::Rand() % 10 + 10) * 0.05f;
        o->LightEnable = true;
        o->AlphaEnable = false;
        o->SubType = 0;
        o->HiddenMesh = -1;
        o->BlendMesh = -1;
        // o->LifeTime    = 128+Random::Rand()%128;
        // o->Timer       = (float)(Random::Rand()%10)*0.1f;
        o->CurrentAction = MONSTER01_DIE + 1;
        SetAction(o, o->CurrentAction);
        Vector(0.f, 0.f, (float)(Random::Rand() % 360), o->Angle);
        Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 4000 - 2000),
               Hero->Object.Position[1] + (float)(Random::Rand() % 4000 - 2000), Hero->Object.Position[2] - 600.f,
               o->Position);
    }
    else
    {
        o->Type = MODEL_SPEARSKILL;
        o->Velocity = 2.2f;
        o->LightEnable = false;
        o->LifeTime = 240 * 40;
        o->AI = BOID_GROUND;
        Vector(1.f, 1.f, 1.f, o->Light);

        o->AlphaEnable = true;
        o->Scale = 0.8f;
        o->ShadowScale = 10.f;
        o->HiddenMesh = -1;
        o->BlendMesh = -1;
        o->Timer = (float)(Random::Rand() % 314) * 0.01f;
        Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 1024 - 512),
               Hero->Object.Position[1] + (float)(Random::Rand() % 1024 - 512), Hero->Object.Position[2], o->Position);

        o->Position[2] = Hero->Object.Position[2];
        if (gMapManager.InBloodCastle() == true)
        {
            CreateJoint(MODEL_SPEARSKILL, o->Position, o->Position, o->Angle, 3, o, 25.0f);
        }
        else
        {
            CreateJoint(MODEL_SPEARSKILL, o->Position, o->Position, o->Angle, 1, o, 25.0f);
        }
        Vector(0.f, 0.f, 0.f, o->Angle);
        o->Angle[2] = (float)(Random::Rand() % 360);
    }
    return 1;
}

int CreateAtlanseFish(OBJECT* o)
{
    if (gMapManager.WorldActive != WD_7ATLANSE && gMapManager.WorldActive != WD_67DOPPLEGANGER3)
        return 0;

    if (Hero->Object.Position[1] * 0.01f < 128)
    {
        o->Type = MODEL_FISH01 + 1 + Random::Rand() % 2;
        o->Gravity = 15;
        o->AlphaEnable = true;
        o->Scale = 0.8f;
        o->ShadowScale = 10.f;
        o->HiddenMesh = -1;
        o->BlendMesh = -1;
        o->Timer = (float)(Random::Rand() % 314) * 0.01f;
        if (Random::Rand() % 100 < 90)
        {
            o->Velocity = 0.3f;
        }
        else
        {
            o->Velocity = 0.25f;
        }
        o->LightEnable = false;
        Vector(0.f, 0.f, 0.f, o->Angle);
        Vector(1.f, 1.f, 1.f, o->Light);
        Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 1024 - 512),
               Hero->Object.Position[1] + (float)(Random::Rand() % 1024 - 512), Hero->Object.Position[2], o->Position);

        o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]) + (float)(Random::Rand() % 200 + 150);
    }
    else
    {
        o->Live = false;
    }
    return 1;
}

void MoveBat(OBJECT* o)
{
    o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
    o->Position[2] += ( - absf(sinf(o->Timer)) * 150.f + 350.f) * FPS_ANIMATION_FACTOR;
    o->Timer += 0.2f * FPS_ANIMATION_FACTOR;
}

void MoveButterFly(OBJECT* o)
{
    if (rand_fps_check(32))
    {
        o->Angle[2] = (float)(Random::Rand() % 360);
        o->Direction[2] = (float)(Random::Rand() % 15 - 7) * 1.f;
    }
    o->Direction[2] += (float)(Random::Rand() % 15 - 7) * 0.2f * FPS_ANIMATION_FACTOR;
    float Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
    if (o->Position[2] < Height + 50.f)
    {
        o->Direction[2] *= pow(0.8f, FPS_ANIMATION_FACTOR);
        o->Direction[2] += 1.f * FPS_ANIMATION_FACTOR;
    }
    if (o->Position[2] > Height + 300.f)
    {
        o->Direction[2] *= pow(0.8f, FPS_ANIMATION_FACTOR);
        o->Direction[2] -= 1.f * FPS_ANIMATION_FACTOR;
    }
    o->Position[2] += (float)(Random::Rand() % 15 - 7) * 0.3f;
}

static void LandBird(OBJECT* o, float height)
{
    o->Position[2] = height;
    o->AI = BOID_GROUND;
    SetAction(o, BIRD_ACTION_GROUND);
}

static void TakeOffBird(OBJECT* o)
{
    o->AI = BOID_UP;
    o->Velocity = 1.1f;
    o->Direction[2] = 20.f;
    SetAction(o, BIRD_ACTION_FLY);
}

// A hero in a monster form (a Transformation Ring) has that monster's model and actions.
static bool HeroStandsStill()
{
    const OBJECT& hero = Hero->Object;
    return Engine::AI::BirdLanding::IsHeroStill(hero.CurrentAction, hero.Type == MODEL_PLAYER);
}

void MoveBird(OBJECT* o)
{
    if (o->AI == BOID_FLY)
    {
        if ((int)WorldTime % 8192 < 2048)
        {
            vec3_t Range;
            VectorSubtract(o->Position, Hero->Object.Position, Range);
            float Distance = sqrtf(Range[0] * Range[0] + Range[1] * Range[1]);
            if (Distance >= 200.f && Distance <= 400.f)
            {
                //int Index = TERRAIN_INDEX_REPEAT((int)(o->Position[0]/TERRAIN_SCALE),(int)(o->Position[1]/TERRAIN_SCALE));
                //if(TerrainMappingLayer1[Index]==0)
                o->AI = BOID_DOWN;
            }
        }
        o->Velocity = 1.f;
        o->Position[2] += (float)(Random::Rand() % 16 - 8) * FPS_ANIMATION_FACTOR;
        if (o->Position[2] < 200.f) o->Direction[2] = 10.f;
        else if (o->Position[2] > 600.f) o->Direction[2] = -10.f;
    }
    if (o->AI == BOID_DOWN)
    {
        //o->Velocity *= pow(0.95f, FPS_ANIMATION_FACTOR);
        o->Direction[2] = -20.f;
        float Height = RequestTerrainHeight(o->Position[0], o->Position[1]);
        if (o->Position[2] < Height)
        {
            // Land and stay until the hero moves or a random take-off (BOID_GROUND below). Where a bird
            // cannot sit, or while the hero moves, it bounces back up and keeps flapping.
            const int Index =
                TERRAIN_INDEX_REPEAT((int)(o->Position[0] / TERRAIN_SCALE), (int)(o->Position[1] / TERRAIN_SCALE));
            if (Engine::AI::BirdLanding::CanLandOn(TerrainWall[Index]) && HeroStandsStill())
            {
                LandBird(o, Height);
            }
            else
            {
                TakeOffBird(o);
            }
        }
    }
    if (o->AI == BOID_GROUND)
    {
        if (!HeroStandsStill() || rand_fps_check(256))
        {
            TakeOffBird(o);
        }
    }
    if (o->AI == BOID_UP)
    {
        o->Position[2] += (float)(Random::Rand() % 16 - 8) * FPS_ANIMATION_FACTOR;
        o->Velocity -= 0.005f * FPS_ANIMATION_FACTOR;
        if (o->Velocity <= 1.f)
        {
            o->AI = BOID_FLY;
        }
    }
}

void MoveHeavenBug(OBJECT* o, int index)
{
    const float iFrame = WorldTime / 40.0f;

    o->Position[0] += o->Velocity * (float)sinf(o->Angle[2]) * FPS_ANIMATION_FACTOR;
    o->Position[1] -= o->Velocity * (float)cosf(o->Angle[2]) * FPS_ANIMATION_FACTOR;
    o->Angle[2] += 0.01f * cosf((float)(34571 + iFrame + index * 41273) * 0.0003f) * sinf((float)(17732 + iFrame + index * 5161) * 0.0003f) * FPS_ANIMATION_FACTOR;

    float dx = o->Position[0] - Hero->Object.Position[0];
    float dy = o->Position[1] - Hero->Object.Position[1];
    float Range = sqrtf(dx * dx + dy * dy);
    if (Range >= 1500.f)
        o->Live = false;
    if (rand_fps_check(5120))
        o->Live = false;

    if (gMapManager.InBloodCastle())
    {
        if (o->LifeTime <= 0)
        {
            o->Live = false;
        }
    }
}

void MoveEagle(OBJECT* o)
{
    if (o->SubType == 0 && rand_fps_check(120))
    {
        o->SubType = 1;
        o->AnimationFrame = 0;
    }
    else if (o->SubType == 1 && o->AnimationFrame == 24)
    {
        o->SubType = 2;
    }
    else if (o->SubType == 2 && o->AnimationFrame == 0)
    {
        o->SubType = 0;
    }
    else if (o->SubType == 0)
    {
        o->AnimationFrame = 0;
    }

    float fSeedAngle = WorldTime * 0.001f;
    float fFlyRange = o->Gravity * FPS_ANIMATION_FACTOR;
    float fAngle = 0;
    if (o->AI == BOID_FLY)
    {
        o->HeadAngle[0] = cosf(fSeedAngle) * fFlyRange;
        o->HeadAngle[1] = sinf(fSeedAngle) * fFlyRange;
        fAngle = CreateAngle(o->Position[0], o->Position[1], o->Position[0] + o->HeadAngle[0], o->Position[1] + o->HeadAngle[1]);

        if (o->HeadAngle[2] == 0 && o->HeadAngle[0] > o->HeadAngle[1])
        {
            o->HeadAngle[2] = 1;
        }
        else if (o->HeadAngle[2] == 1 && o->HeadAngle[0] < o->HeadAngle[1])
        {
            o->HeadAngle[2] = 2;
        }
        else if (o->HeadAngle[2] == 2 && o->HeadAngle[0] > o->HeadAngle[1])
        {
            o->AI = BOID_GROUND;
            o->HeadAngle[2] = 0;

            o->HeadAngle[0] = sinf(fSeedAngle) * fFlyRange;
            o->HeadAngle[1] = cosf(fSeedAngle) * fFlyRange;
            fAngle = CreateAngle(o->Position[0], o->Position[1], o->Position[0] + o->HeadAngle[0], o->Position[1] + o->HeadAngle[1]);
        }
    }
    else if (o->AI == BOID_GROUND)
    {
        o->HeadAngle[0] = sinf(fSeedAngle) * fFlyRange;
        o->HeadAngle[1] = cosf(fSeedAngle) * fFlyRange;
        fAngle = CreateAngle(o->Position[0], o->Position[1], o->Position[0] + o->HeadAngle[0], o->Position[1] + o->HeadAngle[1]);

        if (o->HeadAngle[2] == 0 && o->HeadAngle[0] < o->HeadAngle[1])
        {
            o->HeadAngle[2] = 1;
        }
        else if (o->HeadAngle[2] == 1 && o->HeadAngle[0] > o->HeadAngle[1])
        {
            o->HeadAngle[2] = 2;
        }
        else if (o->HeadAngle[2] == 2 && o->HeadAngle[0] < o->HeadAngle[1])
        {
            o->AI = BOID_FLY;
            o->HeadAngle[2] = 0;

            o->HeadAngle[0] = cosf(fSeedAngle) * fFlyRange * FPS_ANIMATION_FACTOR;
            o->HeadAngle[1] = sinf(fSeedAngle) * fFlyRange * FPS_ANIMATION_FACTOR;
            fAngle = CreateAngle(o->Position[0], o->Position[1], o->Position[0] + o->HeadAngle[0], o->Position[1] + o->HeadAngle[1]);
        }
    }

    o->Position[0] += o->HeadAngle[0];
    o->Position[1] += o->HeadAngle[1];
    o->Position[2] += sinf(WorldTime * 0.0005f) * 1.0f;
    o->Angle[1] += sinf(WorldTime * 0.001f) * 0.4f;
    o->Angle[2] = fAngle + 270;
}

void MoveTornado(OBJECT* o)
{
    o->Scale = 1.0f;
    if (rand_fps_check(500))
    {
        o->HeadAngle[0] = (Random::Rand() % 314) / 100.0f;
    }
    o->Position[0] += sinf(o->HeadAngle[0]) * 2.0f * FPS_ANIMATION_FACTOR;
    o->Position[1] += cosf(o->HeadAngle[0]) * 2.0f * FPS_ANIMATION_FACTOR;
    o->Angle[2] = 0;
    if (o->BlendMeshLight < 1.0f) o->BlendMeshLight += 0.1f * FPS_ANIMATION_FACTOR;
}

void MoveBoidGroup(OBJECT* o, int index)
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    if (o->AI != BOID_GROUND)
    {
        const float steerFrames =
            Engine::AI::BoidSteering::SteerFrames(o->Type == MODEL_BUTTERFLY01, FPS_ANIMATION_FACTOR);
        if (steerFrames > 0.f)
        {
            MoveBoid(o, index, Boids, MAX_BOIDS, steerFrames);
        }

        AngleMatrix(o->Angle, o->Matrix);
        vec3_t p, Direction;
        if (gMapManager.WorldActive == WD_7ATLANSE || gMapManager.WorldActive == WD_67DOPPLEGANGER3)
        {
            if (o->Timer < 5.f)
            {
                if (index < 35)
                {
                    Vector(o->Velocity * (float)(Random::Rand() % 16 + 8), 0.f, o->Direction[2], Direction);
                }
                else
                {
                    Vector(o->Velocity * (float)(Random::Rand() % 16 + 16), 0.f, o->Direction[2], Direction);
                }
                o->Gravity = 15;
            }
            else
            {
                Vector(o->Velocity * (float)(Random::Rand() % 32 + 32), 0.f, o->Direction[2], Direction);
                o->Gravity = 5;
            }
            o->Timer += 0.1f * FPS_ANIMATION_FACTOR;
            if (o->Timer >= 10)
            {
                o->Timer = 0.f;
            }
        }
        else
        {
            Vector(o->Velocity * 25.f, 0.f, o->Direction[2], Direction);
        }
        VectorRotate(Direction, o->Matrix, p);
        VectorAddScaled(o->Position, p, o->Position, FPS_ANIMATION_FACTOR);
        o->Direction[0] = o->Position[0] + 3.f * p[0];
        o->Direction[1] = o->Position[1] + 3.f * p[1];

        if (o->Type != MODEL_DRAGON_ && o->Type != MODEL_BAHAMUT && gMapManager.WorldActive != WD_51HOME_6TH_CHAR &&
            rand_fps_check(512))
        {
            o->Live = false;
        }
    }

    // A grounded boid (a landed bird) skips the flight above, but still goes away when the hero leaves it behind.
    float dx = o->Position[0] - Hero->Object.Position[0];
    float dy = o->Position[1] - Hero->Object.Position[1];
    float Range = sqrtf(dx * dx + dy * dy);
    float FlyDistance = 1500.f;
    if (o->Type == MODEL_DRAGON_)
    {
        FlyDistance = 4000.f;
    }
    else if (o->Type == MODEL_BAHAMUT)
    {
        FlyDistance = 3000.f;
    }
    if (Range >= FlyDistance)
    {
        o->Live = false;
    }
}

// The sparks, glows and smoke of the boids the last frame drew, posed as their draw poses them.
static void UpdateDrawnBoidEffects()
{
    for (int i = 0; i < MAX_BOIDS; i++)
    {
        OBJECT* o = &Boids[i];
        if (!o->Live || !o->Visible || o->Type == MODEL_SPEARSKILL)
            continue;
        // The draw turns a boid a quarter for its model.
        const float angle = o->Angle[2];
        o->Angle[2] += 90.f;
        BMD* b = &Models[o->Type];
        const auto bones = [o, b]
        {
            PlaceObjectModel(o, b);
            return Engine::Object::Pose::World(o, b);
        };
        vec3_t p, Position, Light;
        switch (o->Type)
        {
        case MODEL_DRAGON_:
            if (EnableEvent != 0)
            {
                Vector(0.f, -50.f, 0.f, p);
                b->TransformPosition(bones()[11], p, Position);
                Vector(1.f, 0.f, 0.f, Light);
                CreateSprite(BITMAP_LIGHTNING + 1, Position, 1.f, Light, o);
                Vector(1.f, 1.f, 1.f, Light);
                CreateParticleFpsChecked(BITMAP_FIRE, Position, o->Angle, Light);
            }
            break;

        case MODEL_BUTTERFLY01:
        {
            float Luminosity = (float)(Random::Rand() % 32 + 64) * 0.01f;

            Vector(Luminosity * 0.2f, Luminosity * 0.4f, Luminosity * 0.4f, Light);
            CreateSprite(BITMAP_LIGHT, o->Position, 1.f, Light, o);
        }
        break;

        case MODEL_MAP_TORNADO:
        {
            CreateParticleFpsChecked(BITMAP_CLOUD, o->Position, o->Angle, o->Light, 18, o->Scale, o);
        }
        break;

        case MODEL_CROW:
            Vector(-5.f, 0.f, 0.f, p);
            b->TransformPosition(bones()[1], p, Position);

            float Luminosity = (float)(Random::Rand() % 32 + 128) * 0.01f;
            Vector(Luminosity * 1.f, Luminosity * 0.2f, 0.f, Light);
            CreateSprite(BITMAP_LIGHT, Position, 0.1f, Light, o);

            Vector(5.f, 0.f, 0.f, p);
            b->TransformPosition(bones()[1], p, Position);
            CreateSprite(BITMAP_LIGHT, Position, 0.1f, Light, o);
            break;
        }
        o->Angle[2] = angle;
    }
}

void MoveBoids()
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    if (EnableEvent != 0)
    {
        OBJECT* o = &Hero->Object;
        vec3_t Position, Angle, Light;
        if (rand_fps_check(40))
        {
            Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 600 - 200) * FPS_ANIMATION_FACTOR,
                   Hero->Object.Position[1] + (float)(Random::Rand() % 400 + 200) * FPS_ANIMATION_FACTOR,
                   Hero->Object.Position[2] + 300.f * FPS_ANIMATION_FACTOR, Position);
            Vector(0.f, 0.f, 0.f, Angle);
            Vector(1.f, 1.f, 1.f, Light);
            CreateEffect(MODEL_FIRE, Position, Angle, Light, 3);
            PlayBuffer(SOUND_METEORITE01);
        }
        Vector(-0.3f, -0.3f, -0.2f, Light);
        AddTerrainLight(o->Position[0], o->Position[1], Light, 16, PrimaryTerrainLight);
    }

    int Index = TERRAIN_INDEX_REPEAT((int)(Hero->Object.Position[0] / TERRAIN_SCALE), (int)(Hero->Object.Position[1] / TERRAIN_SCALE));
    for (int i = 0; i < MAX_BOIDS; i++)
    {
        bool bOut = false;
        bool bCreate = true;
        switch (gMapManager.WorldActive)
        {
        case WD_7ATLANSE:
        case WD_67DOPPLEGANGER3:
            break;
        case WD_10HEAVEN:
            if (i >= 13)
            {
                bOut = true;
            }
            break;
        case WD_51HOME_6TH_CHAR:
            if (i >= 2)
            {
                bOut = TRUE;
            }
            break;
        default:
            if (gMapManager.InHellas() == true)
            {
                if (i > 1)
                {
                    bOut = true;
                }
                if ((Random::Rand() % 10))
                {
                    bCreate = false;
                }
                break;
            }

            if (i >= 5)
            {
                bOut = true;
            }
            break;
        }
        if (bOut)
        {
            break;
        }
        OBJECT* o = &Boids[i];
        if (!o->Live && bCreate)
        {
            if (EnableEvent != 0)
            {
                if (rand_fps_check(300))
                {
                    o->Live = true;
                    OpenMonsterModel(MONSTER_MODEL_DRAGON);
                    o->Type = MODEL_DRAGON_;
                    o->Scale = (float)(Random::Rand() % 3 + 6) * 0.1f;
                    o->Alpha = 1.f;
                    o->AlphaTarget = 1.f;
                    o->Velocity = 0.5f;
                    o->LightEnable = true;
                    o->AlphaEnable = false;
                    o->SubType = 0;
                    o->HiddenMesh = -1;
                    o->BlendMesh = -1;
                    o->LifeTime = 128 + Random::Rand() % 128;
                    o->Timer = (float)(Random::Rand() % 10) * 0.1f;
                    Vector(0.f, 0.f, -90.f, o->Angle);
                    if (EnableEvent == 3)
                    {
                        o->SubType = 1;
                    }
                    Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 600 - 100),
                           Hero->Object.Position[1] + (float)(Random::Rand() % 400 + 200),
                           Hero->Object.Position[2] + 300.f, o->Position);
                }
            }
            else if (gMapManager.WorldActive == WD_0LORENCIA
                || gMapManager.WorldActive == WD_1DUNGEON
                || gMapManager.WorldActive == WD_3NORIA
                || gMapManager.WorldActive == WD_4LOSTTOWER
                || gMapManager.WorldActive == WD_10HEAVEN
                || ((gMapManager.WorldActive == WD_7ATLANSE || gMapManager.WorldActive == WD_67DOPPLEGANGER3) && (TerrainWall[Index] == 0 || TerrainWall[Index] == TW_CHARACTER))
                || gMapManager.InBloodCastle()
                || gMapManager.InHellas()
                || (gMapManager.WorldActive == WD_51HOME_6TH_CHAR && i < 1 && rand_fps_check(500) && Hero->SafeZone != true)
                )
            {
                int iCreateBoid = 0;

                Engine::Object::Pose::Release(o);
                o->Initialize();

                o->Live = true;
                o->Velocity = 1.f;
                o->LightEnable = true;
                o->LifeTime = 0;
                o->SubType = 0;
                Vector(0.5f, 0.5f, 0.5f, o->Light);
                o->Alpha = 0.f;
                o->AlphaTarget = 1.f;
                o->Gravity = 13;
                o->AI = 0;
                o->CurrentAction = 0;

                if (gMapManager.WorldActive == WD_0LORENCIA)
                    o->Type = MODEL_BIRD01;
                else if (gMapManager.WorldActive == WD_1DUNGEON || gMapManager.WorldActive == WD_4LOSTTOWER)
                    o->Type = MODEL_BAT01;
                else if (gMapManager.WorldActive == WD_3NORIA)
                {
                    o->Type = MODEL_BUTTERFLY01;
                    o->Velocity = 0.3f;
                    o->LightEnable = false;
                    Vector(1.f, 1.f, 1.f, o->Light);
                }
                else if (gMapManager.InBloodCastle() == true)
                {
                    o->Type = MODEL_CROW;
                }
                else if (gMapManager.WorldActive == WD_51HOME_6TH_CHAR)
                {
                    o->Type = MODEL_MAP_TORNADO;
                    o->Velocity = 0.0f;
                    o->BlendMeshLight = 0.0f;
                    o->HeadAngle[0] = (Random::Rand() % 314) / 100.0f;
                    o->Position[1] += 5.0f;
                    o->m_bRenderAfterCharacter = true;
                }
                else
                {
                    if (iCreateBoid == 0)
                    {
                        iCreateBoid = CreateDragon(o, i);
                    }
                    if (iCreateBoid == 0)
                    {
                        iCreateBoid = CreateAtlanseFish(o);
                    }
                    if (iCreateBoid == 0)
                    {
                        iCreateBoid = CreateBigMon(o);
                    }
                }
                if (iCreateBoid != 1)
                {
                    o->AlphaEnable = true;
                    o->Scale = 0.8f;
                    o->ShadowScale = 10.f;
                    o->HiddenMesh = -1;
                    o->BlendMesh = -1;
                    o->Timer = (float)(Random::Rand() % 314) * 0.01f;
                    Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 1024 - 512),
                           Hero->Object.Position[1] + (float)(Random::Rand() % 1024 - 512), Hero->Object.Position[2],
                           o->Position);
                    o->Position[2] =
                        RequestTerrainHeight(o->Position[0], o->Position[1]) + (float)(Random::Rand() % 200 + 150);
                    Vector(0.f, 0.f, 0.f, o->Angle);
                }
            }
        }

        if (o->Live)
        {
            BMD* b = &Models[o->Type];
            float PlaySpeed = 1.f;
            if (o->Type == MODEL_DRAGON_ || o->Type == MODEL_BAHAMUT)
            {
                PlaySpeed = 0.5f;
            }

            if (EnableEvent != 0 && o->Type == MODEL_DRAGON_)
            {
                SetAction(o, MONSTER01_DIE + 1);
                b->CurrentAction = o->CurrentAction;
                b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, PlaySpeed, o->Position, o->Angle);
                AngleMatrix(o->Angle, o->Matrix);
                vec3_t Position, Direction;
                Vector(o->Scale * 40.f, 0.f, 0.f, Position);
                VectorRotate(Position, o->Matrix, Direction);
                VectorAddScaled(o->Position, Direction, o->Position, FPS_ANIMATION_FACTOR);
                o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]) + 300.f;
                o->Position[2] += -absf(sinf(o->Timer)) * 100.f + 100.f;
                o->Timer += o->Scale * 0.05f * FPS_ANIMATION_FACTOR;
                o->LifeTime -= FPS_ANIMATION_FACTOR;
                if (o->LifeTime <= 0)
                    o->Live = false;
                if (rand_fps_check(128))
                    PlayBuffer(SOUND_MONSTER_BULLATTACK1);
            }
            else
            {
                b->CurrentAction = o->CurrentAction;

                if (gMapManager.WorldActive == WD_51HOME_6TH_CHAR
                    )
                {
                    PlaySpeed = b->Actions[b->CurrentAction].PlaySpeed;
                }
                b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, PlaySpeed, o->Position, o->Angle);

                switch (o->Type)
                {
                case MODEL_BAT01:
                    MoveBat(o);
                    break;

                case MODEL_BUTTERFLY01:
                    MoveButterFly(o);
                    break;

                case MODEL_BIRD01:
                case MODEL_CROW:
                    MoveBird(o);
                    break;

                case MODEL_SPEARSKILL:
                    MoveHeavenBug(o, i);
                    break;

                case MODEL_BAHAMUT:
                    MoveBigMon(o);
                    break;

                case MODEL_EAGLE:
                    MoveEagle(o);
                    break;
                case MODEL_MAP_TORNADO:
                    MoveTornado(o);
                    break;
                }

                MoveBoidGroup(o, i);

                if (o->LifeTime <= 0 && (gMapManager.WorldActive == WD_7ATLANSE || gMapManager.WorldActive == WD_67DOPPLEGANGER3) && TerrainWall[Index] == TW_SAFEZONE)
                {
                    o->Angle[2] += 180.f;
                    if (o->Angle[2] >= 360.f) o->Angle[2] -= 360.f;
                    o->LifeTime = 10;
                    o->SubType++;
                }

                if (o->Type == MODEL_EAGLE || o->Type == MODEL_MAP_TORNADO)
                {
                    // do nothing?
                }
                else if (o->SubType >= 2)
                {
                    o->Live = false;
                }

                o->LifeTime -= FPS_ANIMATION_FACTOR;

                float dx = o->Position[0] - Hero->Object.Position[0];
                float dy = o->Position[1] - Hero->Object.Position[1];
                float Range = sqrtf(dx * dx + dy * dy);
                if (Range < 600)
                {
                    if (o->Type == MODEL_BIRD01)
                    {
                        if (rand_fps_check(512))
                            PlayBuffer(SOUND_BIRD01, o);
                        if (rand_fps_check(512))
                            PlayBuffer(SOUND_BIRD02, o);
                    }
                    else if (o->Type == MODEL_BAT01)
                    {
                        if (rand_fps_check(256))
                            PlayBuffer(SOUND_BAT01, o);
                    }
                    else if (o->Type == MODEL_CROW)
                    {
                        if (TerrainWall[Index] == TW_SAFEZONE)
                        {
                            if (rand_fps_check(128))
                                PlayBuffer(SOUND_CROW, o);
                        }
                    }
                }
            }
            Alpha(o);
        }
    }
    UpdateDrawnBoidEffects();
}

void CullBoids()
{
    const auto cull = [](OBJECT* objects, int count)
    {
        for (int i = 0; i < count; i++)
        {
            OBJECT* o = &objects[i];
            if (o->Live)
                o->Visible = TestFrustrum2D(o->Position[0] * 0.01f, o->Position[1] * 0.01f, -20.f);
        }
    };
    cull(Boids, MAX_BOIDS);
    cull(Fishs, MAX_FISHS);
}

void RenderBoids(bool bAfterCharacter)
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    for (int i = 0; i < MAX_BOIDS; i++)
    {
        const OBJECT& boid = Boids[i];
        if (boid.m_bRenderAfterCharacter != bAfterCharacter)
            continue;
        if (boid.Live)
        {
            if (boid.Visible)
            {
                if (MODEL_SPEARSKILL == boid.Type)
                {
                    continue;
                }
                // Drawn a quarter turn round, from a copy.
                OBJECT turned = boid;
                const Random::DrawnAs drawnAs(&turned, &boid);
                turned.Angle[2] += 90.f;
                const OBJECT* o = &turned;
                RenderObject(o, true);

                BMD* b = &Models[o->Type];
                vec3_t Position;
                if (o->Type == MODEL_DRAGON_ && o->SubType == 1)
                {
                    float Bright = 1.0f;
                    RenderPartObjectBodyColor(&Models[o->Type], o, o->Type, o->Alpha, RENDER_METAL | RENDER_BRIGHT,
                                              Bright);
                    RenderPartObjectBodyColor(&Models[o->Type], o, o->Type, o->Alpha, RENDER_CHROME | RENDER_BRIGHT,
                                              Bright);
                }
                if (gMapManager.WorldActive != WD_10HEAVEN)
                {
                    EnableAlphaTest();
                    if (gMapManager.WorldActive == WD_51HOME_6TH_CHAR && o->Type == MODEL_MAP_TORNADO);
                    else
                    {
                        const float shadowAlpha = o->Type == MODEL_EAGLE
                            ? (o->ShadowScale == 0 ? 0.f : 1.f)
                            : 0.2f;
                        VectorCopy(o->Position, Position);
                        Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
                        VectorCopy(Position, b->BodyOrigin);

                        b->RenderBodyShadow(-1, -1, -1, -1, nullptr, 0, shadowAlpha);
                    }
                }
            }
        }
    }
}

void RenderFishs()
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    for (int i = 0; i < MAX_FISHS; i++)
    {
        const OBJECT& fish = Fishs[i];
        if (fish.Live)
        {
            if (fish.Visible && fish.Type != -1)
            {
                // Drawn a quarter turn round, from a copy.
                OBJECT turned = fish;
                const Random::DrawnAs drawnAs(&turned, &fish);
                turned.Angle[2] += 90.f;
                const OBJECT* o = &turned;
                RenderObject(o);

                if (o->Type == MODEL_FISH01 + 7 || o->Type == MODEL_FISH01 + 8)
                {
                }
                else
                {
                    if (gMapManager.WorldActive != WD_10HEAVEN)
                    {
                        EnableAlphaTest();
                        BMD* b = &Models[o->Type];
                        vec3_t Position;
                        VectorCopy(o->Position, Position);
                        Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
                        VectorCopy(Position, b->BodyOrigin);
                        b->RenderBodyShadow(-1, -1, -1, -1, nullptr, 0, 0.2f);
                    }
                }
            }
        }
    }
}

void MoveFishs()
{
    if (!g_pOption->GetRenderAllEffects())
    {
        return;
    }

    for (int i = 0; i < MAX_FISHS; i++)
    {
        if (gMapManager.WorldActive != WD_7ATLANSE && gMapManager.WorldActive != WD_8TARKAN
            && gMapManager.InHellas() == false
            && gMapManager.WorldActive != WD_34CRYWOLF_1ST
            && gMapManager.WorldActive != WD_67DOPPLEGANGER3
            )
        {
            if (i >= 3) continue;
        }

        OBJECT* o = &Fishs[i];
        if (!o->Live)
        {
            Vector(Hero->Object.Position[0] + (float)(Random::Rand() % 1024 - 512),
                   Hero->Object.Position[1] + (float)(Random::Rand() % 1024 - 512), Hero->Object.Position[2],
                   o->Position);
            int Index = TERRAIN_INDEX_REPEAT((int)(o->Position[0] / TERRAIN_SCALE), (int)(o->Position[1] / TERRAIN_SCALE));
            if ((gMapManager.WorldActive == WD_0LORENCIA && TerrainMappingLayer1[Index] == 5) ||
                (gMapManager.WorldActive == WD_1DUNGEON && TerrainWall[Index] < TW_NOGROUND) ||
                (gMapManager.WorldActive == WD_6STADIUM && TerrainWall[Index] < TW_NOGROUND) ||
                ((gMapManager.WorldActive == WD_7ATLANSE
                    || gMapManager.WorldActive == WD_67DOPPLEGANGER3
                    ) && (TerrainWall[Index] == 0 || TerrainWall[Index] == TW_CHARACTER)) ||
                (gMapManager.InHellas() && (TerrainWall[Index] == 0 || TerrainWall[Index] == TW_CHARACTER)) ||
                (M33Aida::IsInAida() && (TerrainWall[Index] == 0 || TerrainWall[Index] == TW_CHARACTER)) ||
                ((gMapManager.WorldActive == WD_8TARKAN
                    || gMapManager.WorldActive == WD_34CRYWOLF_1ST
                    ) && (TerrainWall[Index] == 0 || TerrainWall[Index] == TW_CHARACTER))
                )
            {
                o->Live = true;
                o->Alpha = 0.f;
                o->AlphaTarget = 1.f;
                o->BlendMesh = -1;
                Vector(0.5f, 0.5f, 0.5f, o->Light);
                Vector(0.f, 0.f, 0.f, o->Angle);
                o->LightEnable = true;
                o->AlphaEnable = true;
                o->SubType = 0;
                o->HiddenMesh = -1;
                o->LifeTime = Random::Rand() % 128;
                o->Scale = (float)(Random::Rand() % 4 + 4) * 0.1f;
                o->Gravity = 13;
                o->bBillBoard = true;
                switch (gMapManager.WorldActive)
                {
                case WD_0LORENCIA:
                    o->Type = MODEL_FISH01;
                    o->AlphaTarget = (float)(Random::Rand() % 2 + 2) * 0.1f;
                    o->Velocity = 0.6f / o->Scale;
                    break;
                case WD_1DUNGEON:
                    o->Type = MODEL_RAT01;
                    o->Velocity = 0.6f / o->Scale;
                    break;
                case WD_6STADIUM:
                    o->Type = MODEL_BUG01;
                    o->Velocity = 0.6f / o->Scale;
                    break;
                case WD_33AIDA:
                case WD_8TARKAN:
                    o->Type = MODEL_BUG01 + 1;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    o->Velocity = 2.5f / o->Scale;
                    o->Gravity = 9;
                    o->LifeTime = 100;
                    VectorCopy(o->Position, o->EyeLeft);
                    CreateJointFpsChecked(BITMAP_JOINT_ENERGY, o->Position, o->Position, o->Angle, 4, o, 30.f);
                    break;
                case WD_34CRYWOLF_1ST:
                    if (Hero->SafeZone != true)
                    {
                        o->Type = MODEL_SCOLPION;
                        o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                        o->Velocity = (((Random::Rand() % 8 + 1)) * 0.1f) / o->Scale;
                        VectorCopy(o->Position, o->EyeLeft);
                        o->Gravity = 1;
                        o->LifeTime = 100;
                        CreateJointFpsChecked(BITMAP_SCOLPION_TAIL, o->Position, o->Position, o->Angle, 0, o, 30.f);
                    }
                    else
                        o->Live = false;
                    break;
                case WD_7ATLANSE:
                case WD_67DOPPLEGANGER3:
                    o->Scale = (float)(Random::Rand() % 2 + 8) * 0.1f;
                    if (Hero->Object.Position[1] * 0.01f < 128)
                    {
                        o->Type = MODEL_FISH01 + 1 + 2 + Random::Rand() % 4;
                        o->Velocity = 1.f / o->Scale;
                        if (rand_fps_check(2))
                            o->Gravity = 2;
                        else
                            o->Gravity = 3;
                    }
                    else
                    {
                        o->Type = MODEL_FISH01 + 1 + 6 + Random::Rand() % 2;
                        if (o->Type == MODEL_FISH01 + 7 || o->Type == MODEL_FISH01 + 8)
                        {
                            o->BlendMesh = 0;
                            o->BlendMeshLight = 1.f;
                        }
                        o->Velocity = 0.5f / o->Scale;
                        if (rand_fps_check(2))
                            o->Gravity = 1;
                        else
                            o->Gravity = 2;
                    }
                    o->Timer = (float)(Random::Rand() % 32) * 0.1f;
                    o->Position[2] =
                        RequestTerrainHeight(o->Position[0], o->Position[1]) + (float)(Random::Rand() % 150 + 50);
                    break;
                }

                if (gMapManager.InHellas())
                {
                    o->Type = -1;
                    o->Scale = (float)(Random::Rand() % 4 + 8) * 0.1f;
                    o->Velocity = 2.5f / o->Scale;
                    o->Gravity = 9;
                    o->LifeTime = 70;
                    CreateJointFpsChecked(BITMAP_FLARE + 1, o->Position, o->Position, o->Angle, 8, o, 50.f);
                }
            }
        }
        if (o->Live)
        {
            if (o->Type != -1)
            {
                BMD* b = &Models[o->Type];
                b->CurrentAction = o->CurrentAction;

                b->PlayAnimation(&o->AnimationFrame, &o->PriorAnimationFrame, &o->PriorAction, o->Velocity * 0.5f, o->Position, o->Angle);
            }
            if (o->Type == MODEL_FISH01 + 7 || o->Type == MODEL_FISH01 + 8)
            {
                o->BlendMeshLight = sinf(o->Timer) * 0.4f + 0.5f;
                o->Timer += 0.1f * FPS_ANIMATION_FACTOR;
            }

            if ((o->Type >= MODEL_FISH01 && o->Type <= MODEL_FISH01 + 10) ||
                o->LifeTime > 0)
            {
                if (o->Type == MODEL_BUG01
                    || o->Type == MODEL_SCOLPION
                    )
                    SetAction(o, 1);
                else
                    SetAction(o, 0);
                MoveBoid(o, i, Fishs, MAX_FISHS, FPS_ANIMATION_FACTOR);
                AngleMatrix(o->Angle, o->Matrix);
                vec3_t Position, Direction;
                Vector(o->Velocity * (float)(Random::Rand() % 4 + 6), 0.f, 0.f, Position);
                VectorRotate(Position, o->Matrix, Direction);
                VectorAddScaled(o->Position, Direction, o->Position, FPS_ANIMATION_FACTOR);
                if (gMapManager.WorldActive != 7 || gMapManager.InHellas() == false || gMapManager.WorldActive != WD_67DOPPLEGANGER3)
                {
                    o->Position[2] = RequestTerrainHeight(o->Position[0], o->Position[1]);
                }
                o->Direction[0] = o->Position[0] + 3.f * Direction[0];
                o->Direction[1] = o->Position[1] + 3.f * Direction[1];
                int Index = TERRAIN_INDEX_REPEAT((int)(o->Position[0] / TERRAIN_SCALE), (int)(o->Position[1] / TERRAIN_SCALE));

                if (gMapManager.WorldActive == WD_8TARKAN || gMapManager.InHellas() || M33Aida::IsInAida())
                {
                    if (TerrainWall[Index] == 1 || TerrainWall[Index] >= TW_NOGROUND)
                    {
                        o->Angle[2] += 180.f;
                        if (o->Angle[2] >= 360.f) o->Angle[2] -= 360.f;
                        o->SubType++;
                    }
                    else
                    {
                        if (o->SubType > 0) o->SubType--;
                    }

                    if (gMapManager.InHellas() && o->LifeTime <= 1)
                    {
                        o->Live = false;
                    }
                }
                else if ((o->Type == MODEL_FISH01 && TerrainMappingLayer1[Index] != 5) ||
                    (o->Type == MODEL_RAT01 && TerrainWall[Index] >= TW_NOGROUND) ||
                    ((gMapManager.WorldActive == WD_7ATLANSE || gMapManager.WorldActive == WD_67DOPPLEGANGER3) && (TerrainWall[Index] == 1 || TerrainWall[Index] >= TW_NOGROUND)))
                {
                    o->Angle[2] += 180.f;
                    if (o->Angle[2] >= 360.f) o->Angle[2] -= 360.f;
                    o->SubType++;
                }
                else
                {
                    if (o->SubType > 0) o->SubType--;
                }
                if (o->SubType >= 2) o->Live = false;

                if (o->Type == MODEL_BUG01 + 1
                    || o->Type == MODEL_SCOLPION
                    )
                {
                    VectorCopy(o->Position, o->EyeLeft);
                }

                float dx = o->Position[0] - Hero->Object.Position[0];
                float dy = o->Position[1] - Hero->Object.Position[1];
                float Range = sqrtf(dx * dx + dy * dy);
                if (Range >= 1500.f)
                    o->Live = false;

                if (Range < 600.f)
                    if (o->Type == MODEL_RAT01 && rand_fps_check(256))
                        PlayBuffer(SOUND_RAT01, o);
            }
            else
            {
                SetAction(o, 0);
            }

            o->LifeTime -= FPS_ANIMATION_FACTOR;
            if (o->LifeTime <= 0)
            {
                if (o->Type == MODEL_BUG01)
                {
                }
                else
                {
                    if (rand_fps_check(64))
                        o->LifeTime = Random::Rand() % 128;
                }
            }
            Alpha(o);
        }
    }
}
