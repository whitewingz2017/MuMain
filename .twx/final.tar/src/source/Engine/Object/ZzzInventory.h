#ifndef __ZZZINVENTORY_H__
#define __ZZZINVENTORY_H__

#include <optional>
#include <string>
#include <vector>

enum _COLUMN_TYPE
{
    _COLUMN_TYPE_LEVEL = 0,
    _COLUMN_TYPE_CAN_EQUIP,
    _COLUMN_TYPE_ATTMIN,
    _COLUMN_TYPE_ATTMAX,
    _COLUMN_TYPE_MAGIC,
    _COLUMN_TYPE_CURSE,
    _COLUMN_TYPE_PET_ATTACK,
    _COLUMN_TYPE_DEFENCE,
    _COLUMN_TYPE_DEFRATE,
    _COLUMN_TYPE_REQSTR,
    _COLUMN_TYPE_REQDEX,
    _COLUMN_TYPE_REQENG,
    _COLUMN_TYPE_A_SET,
    _COLUMN_TYPE_B_SET,
    _COLUMN_TYPE_REQCHA,
    _COLUMN_TYPE_REQVIT,
    _COLUMN_TYPE_REQNLV,
    _COLUMN_TYPE_COUNT
};

enum SKILL_TOOLTIP_RENDER_POINT
{
    STRP_NONE = 0,
    STRP_TOPLEFT,
    STRP_TOPCENTER,
    STRP_TOPRIGHT,
    STRP_LEFTCENTER,
    STRP_CENTER,
    STRP_RIGHTCENTER,
    STRP_BOTTOMLEFT,
    STRP_BOTTOMCENTER,
    STRP_BOOTOMRIGHT
};

// 세율정보

extern int		g_nTaxRate;
extern int		g_nChaosTaxRate;

// The item help table (/<item name> in the chat): ComputeItemInfo fills a row for each + level of
// the item it is given, with a column for each _COLUMN_TYPE.
inline constexpr int iMaxLevel = 15;
extern int g_iItemInfo[iMaxLevel + 1][_COLUMN_TYPE_COUNT];

// The hero's level and stats, the stats with the bonuses of items and buffs: what the item help
// table compares with each level's requirements.
struct ItemInfoHeroStats
{
    WORD level;
    WORD strength;
    WORD dexterity;
    WORD energy;
    WORD vitality;
    WORD charisma;

    bool operator==(const ItemInfoHeroStats&) const = default;
};

ItemInfoHeroStats GetItemInfoHeroStats();

///////////////////////////////////////////////////////////////////////////////
// guild
///////////////////////////////////////////////////////////////////////////////

extern wchar_t         g_GuildNotice[3][128];
extern GUILD_LIST_t GuildList[MAX_GUILDS];
extern int          g_nGuildMemberCount;
extern int          GuildListPage;
extern MARK_t		GuildMark[MAX_MARKS];
extern int			SelectMarkColor;
extern int			GuildPlayerKey;
extern int			GuildNumber;
extern int			GuildTotalScore;

extern int AllRepairGold;

//////////////////////////////////////////////////////////////////////////
// text 관련
//////////////////////////////////////////////////////////////////////////
// The rows an item's description may write into a tooltip, on top of the original client's 50: the description
// gets rows of its own, so it never takes the room the rest of the tooltip needs.
constexpr int MaxItemDescriptionRows = 32;
constexpr int MaxTextListRows = 50 + MaxItemDescriptionRows;

extern wchar_t TextList[MaxTextListRows][100];
extern int TextListColor[MaxTextListRows];
extern int TextBold[MaxTextListRows];
extern SIZE Size[MaxTextListRows];

namespace Data::Items
{
struct ItemDefinition;
}
struct ItemTooltipValues;

// The server's pet information that a Dark Lord pet's tooltip asks for: the Dark Horse's when it is pointed at as the
// equipped helper, the Dark Raven's when it is pointed at in the left hand; nothing elsewhere. `inventype` is the
// tooltip's storage.
struct PetInfoRequest
{
    PetType pet;
    StorageType storage;
    BYTE slot;
};
std::optional<PetInfoRequest> GetPetInfoRequest(int itemType, int pointedIndex, int inventype);

// How wide a text is in the tooltip's text units.
using ItemTooltipTextMeasure = int (*)(const wchar_t* text, size_t length);
// Writes the item data's description in the UI's language, with its placeholders filled in for the item (`values`,
// and the stat file's tables at `level`), into TextList, TextListColor and TextBold from TextNum on: the lines of that
// level whose conditions hold (a line may be a shared text of the tooltip file), each wrapped to the tooltip's width
// and at its line breaks, the pieces in the line's color (its first color rule that holds) and style, a blank line or
// piece as the tooltip's own blank rows. At
// most `rowsLeft` rows, which it lowers by the rows it wrote: a tooltip's description, both its parts together, has
// MaxItemDescriptionRows. `afterOptions` picks the lines drawn after the item's options ("after": "options") or
// the others.
void WriteItemDescriptionLines(const Data::Items::ItemDefinition& definition, int level,
                               const ItemTooltipValues& values, bool afterOptions, int& rowsLeft,
                               ItemTooltipTextMeasure measure);

///////////////////////////////////////////////////////////////////////////////
// party
///////////////////////////////////////////////////////////////////////////////

extern PARTY_t Party[MAX_PARTYS];
extern int     PartyKey;
extern int     PartyNumber;

///////////////////////////////////////////////////////////////////////////////
// inventory
///////////////////////////////////////////////////////////////////////////////

extern ITEM Inventory[MAX_INVENTORY];
extern ITEM InventoryExt[MAX_INVENTORY_EXT];
extern ITEM ShopInventory[MAX_SHOP_INVENTORY];
extern int  InventoryType;
extern ITEM g_PersonalShopInven[MAX_PERSONALSHOP_INVEN];
extern ITEM g_PersonalShopBackup[MAX_PERSONALSHOP_INVEN];
extern bool g_bEnablePersonalShop;
extern int g_iPShopWndType;
extern int g_iPersonalShopMsgType;
extern wchar_t g_szPersonalShopTitle[MAX_SHOPTITLE + 1];
extern CHARACTER g_PersonalShopSeller;

extern bool EnableRenderInventory;
extern int  g_bEventChipDialogEnable;
extern int  g_shEventChipCount;
extern short g_shMutoNumber[3];
extern bool g_bServerDivisionAccept;
extern wchar_t g_strGiftName[64];

extern bool RepairShop;
extern int  RepairEnable;
extern int AskYesOrNo;
extern char OkYesOrNo;

extern int  StorageGoldFlag;
extern ITEM* SrcInventory;
extern int  SrcInventoryIndex;
extern int  DstInventoryIndex;
extern int  CheckSkill;
extern ITEM* CheckInventory;
extern ITEM* CheckInvenParent;
extern BYTE BuyItem[4];
extern int  EnableUse;
extern bool EquipmentItem;
extern wchar_t	g_lpszKeyPadInput[2][MAX_KEYPADINPUT + 1];

#ifdef ASG_ADD_GENS_SYSTEM
bool IsStrifeMap(int nMapIndex);
#endif	// ASG_ADD_GENS_SYSTEM
void CreateShiny(OBJECT* o);
void ClearInventory();
bool CheckEmptyInventory(ITEM* Inv, int InvWidth, int InvHeight);
#ifdef  AUTO_CHANGE_ITEM
void AutoEquipmentChange(int sx, int sy, ITEM* Inv, int InvWidth, int InvHeight);
#endif // AUTO_CHANGE_ITEM

int CompareItem(ITEM item1, ITEM item2);
void ConvertGold(double dGold, wchar_t* szText, int iDecimals = 0);
void ConvertGold64(__int64 Gold, wchar_t* Text);
void ConvertTaxGold(DWORD Gold, wchar_t* Text);
void ConvertChaosTaxGold(DWORD Gold, wchar_t* Text);
int64_t CalcSelfRepairCost(int64_t ItemValue, int Durability, int MaxDurability, short Type);
int64_t ConvertRepairGold(int64_t Gold, int Durability, int MaxDurability, short Type, wchar_t* Text);
void RepairAllGold(void);
WORD CalcMaxDurability(const ITEM* ip, ITEM_ATTRIBUTE* p, int Level);
void RenderTipTextList(const int sx, const int sy, int TextNum, int Tab, int iSort = RT3_SORT_CENTER, int iRenderPoint = STRP_NONE, BOOL bUseBG = TRUE);

void SendRequestUse(int Index, int Target, bool addPoints = true);
bool SendRequestEquipmentItem(STORAGE_TYPE iSrcType, int iSrcIndex, ITEM* pItem, STORAGE_TYPE iDstType, int iDstIndex);
bool IsCanUseItem();
bool IsCanTrade();
//  Party.
void InitPartyList();
void OpenPersonalShop(int iType);
void ClosePersonalShop();
void ClearPersonalShop();
bool IsExistUndecidedPrice();

void CreateGuildMark(int nMarkIndex, bool blend = true);
void CreateCastleMark(int Type, BYTE* buffer = NULL, bool blend = true);

namespace UI::Items
{
bool ShouldAnimatePreview(bool pointerInside, bool pickedItemActive, bool renderingPickedItem);
}

// The box in window pixels; the item animates while the pointer is over it.
void RenderItem3D(float sx, float sy, float Width, float Height, int Type, int Level, int excellentFlags, int ancientDiscriminator, bool PickUp = false, bool fitSlot = false);
// For a slot that already knows whether it is hovered -- an RmlUi element -- instead of testing the
// legacy mouse globals against the rectangle, which need not be where the item is shown.
void RenderItem3DWithHover(float sx, float sy, float Width, float Height, int Type, int Level, int excellentFlags, int ancientDiscriminator, bool hovered);
void RenderObjectScreen(int Type, int ItemLevel, int excellentFlags, int ancientDiscriminator, vec3_t Target, int Select, bool PickUp, float slotWidth = 0, float slotHeight = 0);
bool GetAttackDamage(int* iMinDamage, int* iMaxDamage);
// The item's name in the item names' language (the UI's, or English with "Translate item names" off), as windows,
// messages and ground labels write it: the text of the first of its
// name lines whose levels and conditions hold (the item data's nameLines), else its name with " +level" above +0.
// Without `item`, one of the type at the level, whose durability and options are 0.
std::wstring GetItemNameText(int type, int level, const ITEM* item = nullptr);
// Writes GetItemNameText into a buffer of `textSize` characters, cut short to fit.
void GetItemName(int iType, int iLevel, wchar_t* Text, size_t textSize);
template <size_t N> void GetItemName(int iType, int iLevel, wchar_t (&Text)[N])
{
    GetItemName(iType, iLevel, Text, N);
}
std::wstring GetItemName(int iType, int iLevel);
std::wstring GetItemDisplayName(ITEM* pItem);
void GetSpecialOptionText(int Type, wchar_t* Text, WORD Option, BYTE Value, int iMana);
// The item's information and repair tooltips, anchored in window pixels: their layout runs in the
// screen's 640x480 stretch, the space the original computed it in, whichever window asks.
void RenderItemInfoAtPx(float x, float y, const ITEM* ip, bool Sell, int Inventype = 0,
                        bool bItemTextListBoxUse = false);
// One line of an item's information tooltip as RenderItemInfoAtPx builds it: its text ("\n" for a blank line), its
// TEXT_COLOR_* and whether it is bold.
struct ItemTooltipLine
{
    std::wstring text;
    int color = 0;
    bool bold = false;
};
// How the tooltip measures a description piece for wrapping: the game's font (g_pRenderText), unless a test sets
// a measure of its own, which needs no font; nullptr puts the font back.
void SetItemTooltipTextMeasure(ItemTooltipTextMeasure measure);
// The lines of `ip`'s information tooltip, built as RenderItemInfoAtPx builds them but not drawn; none when it shows
// no tooltip or the pet manager draws its own (the Dark Lord's pets).
std::vector<ItemTooltipLine> BuildItemTooltipLines(ITEM* ip, bool Sell, int Inventype = 0,
                                                   bool bItemTextListBoxUse = false);
void RenderRepairInfoAtPx(float x, float y, const ITEM* ip, bool Sell);
// What BuildRepairInfoText built: the count of lines, and what a click on the item does in repair mode.
struct RepairInfoText
{
    // 0 when the item shows no repair tooltip.
    int lineCount = 0;
    // RepairEnable for the drawn tooltip: 2 a click repairs the item, 1 it has nothing to repair; none: as it was.
    std::optional<int> repairEnable;
};
// Fills TextList, TextListColor and TextBold with the repair tooltip's lines for the item, as RenderRepairInfoAtPx
// shows them; leaves RepairEnable to the caller that draws them.
RepairInfoText BuildRepairInfoText(const ITEM* ip);
// A drop's name on the ground (Alt, or the pointer over it): its text, colors and whether its font is bold.
struct GroundItemLabel
{
    std::wstring text;
    DWORD textColor;
    DWORD backgroundColor;
    bool bold;
    // The ground label style it took: the item's own rule's or the first standard rule's that holds; "" for none.
    std::string style;
};
GroundItemLabel DescribeGroundItemLabel(const OBJECT* o, const ITEM* ip);
void RenderSkillInfo(int sx, int sy, int Type, int SkillNum = 0, int iRenderPoint = STRP_NONE);
void RequireClass(ITEM_ATTRIBUTE* p);
unsigned int getGoldColor(DWORD Gold);

bool IsExcellentItem(ITEM* pItem);
bool IsAncientItem(ITEM* pItem);
bool IsMoneyItem(ITEM* pItem);

void ComputeItemInfo(int iHelpItem);
void SetGroundItemLabelBuildBudget(int buildBudget);
void RenderItemName(int i, const OBJECT* o, const ITEM* ip, bool Sort);

BYTE CaculateFreeTicketLevel(int iType);

#endif //__ZZZINVENTORY_H__
